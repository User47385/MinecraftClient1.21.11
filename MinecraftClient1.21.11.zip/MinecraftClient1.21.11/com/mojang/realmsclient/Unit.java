package com.mojang.realmsclient;

import java.util.Locale;

public enum Unit {
   B,
   KB,
   MB,
   GB;

   private static final int BASE_UNIT = 1024;

   public static Unit getLargest(long p8e3244f5_3_0) {
      if (p8e3244f5_3_0 < 1024L) {
         return B;
      }

      try {
         int $$1 = (int)(Math.log(p8e3244f5_3_0) / Math.log(1024.0));
         String $$2 = String.valueOf("KMGTPE".charAt($$1 - 1));
         return valueOf($$2 + "B");
      } catch (Exception $$3) {
         return GB;
      }
   }

   public static double convertTo(long p8e3244f5_4_0, Unit p8e3244f5_5_1) {
      return p8e3244f5_5_1 == B ? p8e3244f5_4_0 : p8e3244f5_4_0 / Math.pow(1024.0, p8e3244f5_5_1.ordinal());
   }

   public static String humanReadable(long p8e3244f5_6_0) {
      int $$1 = 1024;
      if (p8e3244f5_6_0 < 1024L) {
         return p8e3244f5_6_0 + " B";
      }

      int $$2 = (int)(Math.log(p8e3244f5_6_0) / Math.log(1024.0));
      String $$3 = "KMGTPE".charAt($$2 - 1) + "";
      return String.format(Locale.ROOT, "%.1f %sB", p8e3244f5_6_0 / Math.pow(1024.0, $$2), $$3);
   }

   public static String humanReadable(long p8e3244f5_7_0, Unit p8e3244f5_8_1) {
      return String.format(Locale.ROOT, "%." + (p8e3244f5_8_1 == GB ? "1" : "0") + "f %s", convertTo(p8e3244f5_7_0, p8e3244f5_8_1), p8e3244f5_8_1.name());
   }
}
