package com.mojang.realmsclient.util;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import org.jspecify.annotations.Nullable;

public class UploadTokenCache {
   private static final Long2ObjectMap<String> TOKEN_CACHE = new Long2ObjectOpenHashMap<>();

   public static String get(long p6004c546_0_0) {
      return TOKEN_CACHE.get(p6004c546_0_0);
   }

   public static void invalidate(long p6004c546_1_0) {
      TOKEN_CACHE.remove(p6004c546_1_0);
   }

   public static void put(long p6004c546_2_0, @Nullable String p6004c546_3_1) {
      TOKEN_CACHE.put(p6004c546_2_0, p6004c546_3_1);
   }
}
