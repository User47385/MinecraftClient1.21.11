package com.mojang.realmsclient.util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.util.UndashedUuid;
import java.time.Instant;
import java.util.UUID;
import java.util.function.Function;
import org.jetbrains.annotations.Contract;
import org.jspecify.annotations.Nullable;

public class JsonUtils {
   public static <T> T getRequired(String p718a04cd_0_0, JsonObject p718a04cd_1_1, Function<JsonObject, T> p718a04cd_2_2) {
      JsonElement $$3 = p718a04cd_1_1.get(p718a04cd_0_0);
      if ($$3 == null || $$3.isJsonNull()) {
         throw new IllegalStateException("Missing required property: " + p718a04cd_0_0);
      } else if (!$$3.isJsonObject()) {
         throw new IllegalStateException("Required property " + p718a04cd_0_0 + " was not a JsonObject as espected");
      } else {
         return p718a04cd_2_2.apply($$3.getAsJsonObject());
      }
   }

   public static <T> @Nullable T getOptional(String p718a04cd_3_0, JsonObject p718a04cd_4_1, Function<JsonObject, T> p718a04cd_5_2) {
      JsonElement $$3 = p718a04cd_4_1.get(p718a04cd_3_0);
      if ($$3 == null || $$3.isJsonNull()) {
         return null;
      } else if (!$$3.isJsonObject()) {
         throw new IllegalStateException("Required property " + p718a04cd_3_0 + " was not a JsonObject as espected");
      } else {
         return p718a04cd_5_2.apply($$3.getAsJsonObject());
      }
   }

   public static String getRequiredString(String p718a04cd_6_0, JsonObject p718a04cd_7_1) {
      String $$2 = getStringOr(p718a04cd_6_0, p718a04cd_7_1, null);
      if ($$2 == null) {
         throw new IllegalStateException("Missing required property: " + p718a04cd_6_0);
      } else {
         return $$2;
      }
   }

   @Contract("_,_,!null->!null;_,_,null->_")
   public static @Nullable String getStringOr(String p718a04cd_8_0, JsonObject p718a04cd_9_1, @Nullable String p718a04cd_10_2) {
      JsonElement $$3 = p718a04cd_9_1.get(p718a04cd_8_0);
      if ($$3 != null) {
         return $$3.isJsonNull() ? p718a04cd_10_2 : $$3.getAsString();
      } else {
         return p718a04cd_10_2;
      }
   }

   @Contract("_,_,!null->!null;_,_,null->_")
   public static @Nullable UUID getUuidOr(String p718a04cd_11_0, JsonObject p718a04cd_12_1, @Nullable UUID p718a04cd_13_2) {
      String $$3 = getStringOr(p718a04cd_11_0, p718a04cd_12_1, null);
      return $$3 == null ? p718a04cd_13_2 : UndashedUuid.fromStringLenient($$3);
   }

   public static int getIntOr(String p718a04cd_14_0, JsonObject p718a04cd_15_1, int p718a04cd_16_2) {
      JsonElement $$3 = p718a04cd_15_1.get(p718a04cd_14_0);
      if ($$3 != null) {
         return $$3.isJsonNull() ? p718a04cd_16_2 : $$3.getAsInt();
      } else {
         return p718a04cd_16_2;
      }
   }

   public static long getLongOr(String p718a04cd_17_0, JsonObject p718a04cd_18_1, long p718a04cd_19_2) {
      JsonElement $$3 = p718a04cd_18_1.get(p718a04cd_17_0);
      if ($$3 != null) {
         return $$3.isJsonNull() ? p718a04cd_19_2 : $$3.getAsLong();
      } else {
         return p718a04cd_19_2;
      }
   }

   public static boolean getBooleanOr(String p718a04cd_20_0, JsonObject p718a04cd_21_1, boolean p718a04cd_22_2) {
      JsonElement $$3 = p718a04cd_21_1.get(p718a04cd_20_0);
      if ($$3 != null) {
         return $$3.isJsonNull() ? p718a04cd_22_2 : $$3.getAsBoolean();
      } else {
         return p718a04cd_22_2;
      }
   }

   public static Instant getDateOr(String p718a04cd_23_0, JsonObject p718a04cd_24_1) {
      JsonElement $$2 = p718a04cd_24_1.get(p718a04cd_23_0);
      return $$2 != null ? Instant.ofEpochMilli(Long.parseLong($$2.getAsString())) : Instant.EPOCH;
   }
}
