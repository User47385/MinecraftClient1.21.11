package com.mojang.realmsclient.util;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import org.jspecify.annotations.Nullable;

public class TextRenderingUtils {
   private TextRenderingUtils() {
   }

   @VisibleForTesting
   protected static List<String> lineBreak(String p5169586e_0_0) {
      return Arrays.asList(p5169586e_0_0.split("\\n"));
   }

   public static List<TextRenderingUtils.Line> decompose(String p5169586e_1_0, TextRenderingUtils.LineSegment... p5169586e_2_1) {
      return decompose(p5169586e_1_0, Arrays.asList(p5169586e_2_1));
   }

   private static List<TextRenderingUtils.Line> decompose(String p5169586e_3_0, List<TextRenderingUtils.LineSegment> p5169586e_4_1) {
      List<String> $$2 = lineBreak(p5169586e_3_0);
      return insertLinks($$2, p5169586e_4_1);
   }

   private static List<TextRenderingUtils.Line> insertLinks(List<String> p5169586e_5_0, List<TextRenderingUtils.LineSegment> p5169586e_6_1) {
      int $$2 = 0;
      List<TextRenderingUtils.Line> $$3 = Lists.newArrayList();

      for (String $$4 : p5169586e_5_0) {
         List<TextRenderingUtils.LineSegment> $$5 = Lists.newArrayList();

         for (String $$7 : split($$4, "%link")) {
            if ("%link".equals($$7)) {
               $$5.add(p5169586e_6_1.get($$2++));
            } else {
               $$5.add(TextRenderingUtils.LineSegment.text($$7));
            }
         }

         $$3.add(new TextRenderingUtils.Line($$5));
      }

      return $$3;
   }

   public static List<String> split(String p5169586e_7_0, String p5169586e_8_1) {
      if (p5169586e_8_1.isEmpty()) {
         throw new IllegalArgumentException("Delimiter cannot be the empty string");
      }

      List<String> $$2 = Lists.newArrayList();
      int $$3 = 0;

      int $$4;
      while (($$4 = p5169586e_7_0.indexOf(p5169586e_8_1, $$3)) != -1) {
         if ($$4 > $$3) {
            $$2.add(p5169586e_7_0.substring($$3, $$4));
         }

         $$2.add(p5169586e_8_1);
         $$3 = $$4 + p5169586e_8_1.length();
      }

      if ($$3 < p5169586e_7_0.length()) {
         $$2.add(p5169586e_7_0.substring($$3));
      }

      return $$2;
   }

   public static class Line {
      public final List<TextRenderingUtils.LineSegment> segments;

      Line(TextRenderingUtils.LineSegment... p10822e8a_0_0) {
         this(Arrays.asList(p10822e8a_0_0));
      }

      Line(List<TextRenderingUtils.LineSegment> p10822e8a_1_0) {
         this.segments = p10822e8a_1_0;
      }

      @Override
      public String toString() {
         return "Line{segments=" + this.segments + "}";
      }

      @Override
      public boolean equals(Object p10822e8a_2_0) {
         if (this == p10822e8a_2_0) {
            return true;
         } else if (p10822e8a_2_0 != null && this.getClass() == p10822e8a_2_0.getClass()) {
            TextRenderingUtils.Line $$1 = (TextRenderingUtils.Line)p10822e8a_2_0;
            return Objects.equals(this.segments, $$1.segments);
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         return Objects.hash(this.segments);
      }
   }

   public static class LineSegment {
      private final String fullText;
      private final @Nullable String linkTitle;
      private final @Nullable String linkUrl;

      private LineSegment(String p78d7949_0_0) {
         this.fullText = p78d7949_0_0;
         this.linkTitle = null;
         this.linkUrl = null;
      }

      private LineSegment(String p78d7949_1_0, @Nullable String p78d7949_2_1, @Nullable String p78d7949_3_2) {
         this.fullText = p78d7949_1_0;
         this.linkTitle = p78d7949_2_1;
         this.linkUrl = p78d7949_3_2;
      }

      @Override
      public boolean equals(Object p78d7949_4_0) {
         if (this == p78d7949_4_0) {
            return true;
         } else if (p78d7949_4_0 != null && this.getClass() == p78d7949_4_0.getClass()) {
            TextRenderingUtils.LineSegment $$1 = (TextRenderingUtils.LineSegment)p78d7949_4_0;
            return Objects.equals(this.fullText, $$1.fullText) && Objects.equals(this.linkTitle, $$1.linkTitle) && Objects.equals(this.linkUrl, $$1.linkUrl);
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         return Objects.hash(this.fullText, this.linkTitle, this.linkUrl);
      }

      @Override
      public String toString() {
         return "Segment{fullText='" + this.fullText + "', linkTitle='" + this.linkTitle + "', linkUrl='" + this.linkUrl + "'}";
      }

      public String renderedText() {
         return this.isLink() ? this.linkTitle : this.fullText;
      }

      public boolean isLink() {
         return this.linkTitle != null;
      }

      public String getLinkUrl() {
         if (!this.isLink()) {
            throw new IllegalStateException("Not a link: " + this);
         } else {
            return this.linkUrl;
         }
      }

      public static TextRenderingUtils.LineSegment link(String p78d7949_5_0, String p78d7949_6_1) {
         return new TextRenderingUtils.LineSegment(null, p78d7949_5_0, p78d7949_6_1);
      }

      @VisibleForTesting
      protected static TextRenderingUtils.LineSegment text(String p78d7949_7_0) {
         return new TextRenderingUtils.LineSegment(p78d7949_7_0);
      }
   }
}
