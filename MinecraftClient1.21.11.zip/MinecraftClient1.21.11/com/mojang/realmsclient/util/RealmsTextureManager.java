package com.mojang.realmsclient.util;

import com.google.common.collect.Maps;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Base64;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.MemoryUtil;
import org.slf4j.Logger;

public class RealmsTextureManager {
   private static final Map<String, RealmsTextureManager.RealmsTexture> TEXTURES = Maps.newHashMap();
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final Identifier TEMPLATE_ICON_LOCATION = Identifier.withDefaultNamespace("textures/gui/presets/isles.png");

   public static Identifier worldTemplate(String p3a828c52_0_0, @Nullable String p3a828c52_1_1) {
      return p3a828c52_1_1 == null ? TEMPLATE_ICON_LOCATION : getTexture(p3a828c52_0_0, p3a828c52_1_1);
   }

   private static Identifier getTexture(String p3a828c52_2_0, String p3a828c52_3_1) {
      RealmsTextureManager.RealmsTexture $$2 = TEXTURES.get(p3a828c52_2_0);
      if ($$2 != null && $$2.image().equals(p3a828c52_3_1)) {
         return $$2.textureId;
      } else {
         NativeImage $$3 = loadImage(p3a828c52_3_1);
         if ($$3 == null) {
            Identifier $$4 = MissingTextureAtlasSprite.getLocation();
            TEXTURES.put(p3a828c52_2_0, new RealmsTextureManager.RealmsTexture(p3a828c52_3_1, $$4));
            return $$4;
         } else {
            Identifier $$5 = Identifier.fromNamespaceAndPath("realms", "dynamic/" + p3a828c52_2_0);
            Minecraft.getInstance().getTextureManager().register($$5, new DynamicTexture($$5::toString, $$3));
            TEXTURES.put(p3a828c52_2_0, new RealmsTextureManager.RealmsTexture(p3a828c52_3_1, $$5));
            return $$5;
         }
      }
   }

   private static @Nullable NativeImage loadImage(String p3a828c52_4_0) {
      byte[] $$1 = Base64.getDecoder().decode(p3a828c52_4_0);
      ByteBuffer $$2 = MemoryUtil.memAlloc($$1.length);

      try {
         return NativeImage.read($$2.put($$1).flip());
      } catch (IOException $$3) {
         LOGGER.warn("Failed to load world image: {}", p3a828c52_4_0, $$3);
      } finally {
         MemoryUtil.memFree($$2);
      }

      return null;
   }

   public record RealmsTexture(String image, Identifier textureId) {
   }
}
