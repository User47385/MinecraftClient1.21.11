package com.mojang.realmsclient.util;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.exception.RealmsServiceException;
import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.PlayerSkinRenderCache;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;
import net.minecraft.world.item.component.ResolvableProfile;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsUtil {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final Component RIGHT_NOW = Component.translatable("mco.util.time.now");
   private static final int MINUTES = 60;
   private static final int HOURS = 3600;
   private static final int DAYS = 86400;

   public static Component convertToAgePresentation(long p57045e42_0_0) {
      if (p57045e42_0_0 < 0L) {
         return RIGHT_NOW;
      } else {
         long $$1 = p57045e42_0_0 / 1000L;
         if ($$1 < 60L) {
            return Component.translatable("mco.time.secondsAgo", $$1);
         } else if ($$1 < 3600L) {
            long $$2 = $$1 / 60L;
            return Component.translatable("mco.time.minutesAgo", $$2);
         } else if ($$1 < 86400L) {
            long $$3 = $$1 / 3600L;
            return Component.translatable("mco.time.hoursAgo", $$3);
         } else {
            long $$4 = $$1 / 86400L;
            return Component.translatable("mco.time.daysAgo", $$4);
         }
      }
   }

   public static Component convertToAgePresentationFromInstant(Instant p57045e42_1_0) {
      return convertToAgePresentation(System.currentTimeMillis() - p57045e42_1_0.toEpochMilli());
   }

   public static void renderPlayerFace(GuiGraphics p57045e42_2_0, int p57045e42_3_1, int p57045e42_4_2, int p57045e42_5_3, UUID p57045e42_6_4) {
      PlayerSkinRenderCache.RenderInfo $$5 = Minecraft.getInstance().playerSkinRenderCache().getOrDefault(ResolvableProfile.createUnresolved(p57045e42_6_4));
      PlayerFaceRenderer.draw(p57045e42_2_0, $$5.playerSkin(), p57045e42_3_1, p57045e42_4_2, p57045e42_5_3);
   }

   public static <T> CompletableFuture<T> supplyAsync(RealmsUtil.RealmsIoFunction<T> p57045e42_7_0, @Nullable Consumer<RealmsServiceException> p57045e42_8_1) {
      return CompletableFuture.supplyAsync(() -> {
         RealmsClient $$2 = RealmsClient.getOrCreate();

         try {
            return p57045e42_7_0.apply($$2);
         } catch (Throwable $$3) {
            if ($$3 instanceof RealmsServiceException $$4) {
               if (p57045e42_8_1 != null) {
                  p57045e42_8_1.accept($$4);
               }
            } else {
               LOGGER.error("Unhandled exception", $$3);
            }

            throw new RuntimeException($$3);
         }
      }, Util.nonCriticalIoPool());
   }

   public static CompletableFuture<Void> runAsync(RealmsUtil.RealmsIoConsumer p57045e42_9_0, @Nullable Consumer<RealmsServiceException> p57045e42_10_1) {
      return supplyAsync(p57045e42_9_0, p57045e42_10_1);
   }

   public static Consumer<RealmsServiceException> openScreenOnFailure(Function<RealmsServiceException, Screen> p57045e42_11_0) {
      Minecraft $$1 = Minecraft.getInstance();
      return p57045e42_18_2 -> $$1.execute(() -> $$1.setScreen(p57045e42_11_0.apply(p57045e42_18_2)));
   }

   public static Consumer<RealmsServiceException> openScreenAndLogOnFailure(Function<RealmsServiceException, Screen> p57045e42_12_0, String p57045e42_13_1) {
      return openScreenOnFailure(p57045e42_12_0).andThen(p57045e42_15_1 -> LOGGER.error(p57045e42_13_1, p57045e42_15_1));
   }

   @FunctionalInterface
   public interface RealmsIoConsumer extends RealmsUtil.RealmsIoFunction<Void> {
      void accept(RealmsClient var1) throws RealmsServiceException;

      default Void apply(RealmsClient p8e9d0862_0_0) throws RealmsServiceException {
         this.accept(p8e9d0862_0_0);
         return null;
      }
   }

   @FunctionalInterface
   public interface RealmsIoFunction<T> {
      T apply(RealmsClient var1) throws RealmsServiceException;
   }
}
