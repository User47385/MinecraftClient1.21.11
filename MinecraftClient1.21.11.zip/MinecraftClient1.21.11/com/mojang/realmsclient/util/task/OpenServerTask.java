package com.mojang.realmsclient.util.task;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.exception.RetryCallException;
import com.mojang.realmsclient.gui.screens.configuration.RealmsConfigureWorldScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

public class OpenServerTask extends LongRunningTask {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final Component TITLE = Component.translatable("mco.configure.world.opening");
   private final RealmsServer serverData;
   private final Screen returnScreen;
   private final boolean join;
   private final Minecraft minecraft;

   public OpenServerTask(RealmsServer p5a3ac680_0_0, Screen p5a3ac680_1_1, boolean p5a3ac680_2_2, Minecraft p5a3ac680_3_3) {
      this.serverData = p5a3ac680_0_0;
      this.returnScreen = p5a3ac680_1_1;
      this.join = p5a3ac680_2_2;
      this.minecraft = p5a3ac680_3_3;
   }

   @Override
   public void run() {
      RealmsClient $$0 = RealmsClient.getOrCreate();

      for (int $$1 = 0; $$1 < 25; $$1++) {
         if (this.aborted()) {
            return;
         }

         try {
            boolean $$2 = $$0.open(this.serverData.id);
            if ($$2) {
               this.minecraft.execute(() -> {
                  if (this.returnScreen instanceof RealmsConfigureWorldScreen $$1x) {
                     $$1x.stateChanged();
                  }

                  this.serverData.state = RealmsServer.State.OPEN;
                  if (this.join) {
                     RealmsMainScreen.play(this.serverData, this.returnScreen);
                  } else {
                     this.minecraft.setScreen(this.returnScreen);
                  }
               });
               break;
            }
         } catch (RetryCallException $$3) {
            if (this.aborted()) {
               return;
            }

            pause($$3.delaySeconds);
         } catch (Exception $$4) {
            if (this.aborted()) {
               return;
            }

            LOGGER.error("Failed to open server", $$4);
            this.error($$4);
         }
      }
   }

   @Override
   public Component getTitle() {
      return TITLE;
   }
}
