package com.mojang.realmsclient.util.task;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.Backup;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.exception.RetryCallException;
import com.mojang.realmsclient.gui.screens.RealmsGenericErrorScreen;
import com.mojang.realmsclient.gui.screens.configuration.RealmsConfigureWorldScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

public class RestoreTask extends LongRunningTask {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final Component TITLE = Component.translatable("mco.backup.restoring");
   private final Backup backup;
   private final long realmId;
   private final RealmsConfigureWorldScreen lastScreen;

   public RestoreTask(Backup p3198aac5_0_0, long p3198aac5_1_1, RealmsConfigureWorldScreen p3198aac5_2_2) {
      this.backup = p3198aac5_0_0;
      this.realmId = p3198aac5_1_1;
      this.lastScreen = p3198aac5_2_2;
   }

   @Override
   public void run() {
      RealmsClient $$0 = RealmsClient.getOrCreate();
      int $$1 = 0;

      while ($$1 < 25) {
         try {
            if (this.aborted()) {
               return;
            }

            $$0.restoreWorld(this.realmId, this.backup.backupId);
            pause(1L);
            if (this.aborted()) {
               return;
            }

            setScreen(this.lastScreen);
            return;
         } catch (RetryCallException $$2) {
            if (this.aborted()) {
               return;
            }

            pause($$2.delaySeconds);
            $$1++;
         } catch (RealmsServiceException $$3) {
            if (this.aborted()) {
               return;
            }

            LOGGER.error("Couldn't restore backup", $$3);
            setScreen(new RealmsGenericErrorScreen($$3, this.lastScreen));
            return;
         } catch (Exception $$4) {
            if (this.aborted()) {
               return;
            }

            LOGGER.error("Couldn't restore backup", $$4);
            this.error($$4);
            return;
         }
      }
   }

   @Override
   public Component getTitle() {
      return TITLE;
   }
}
