package com.mojang.realmsclient.util.task;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.exception.RetryCallException;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

public abstract class ResettingWorldTask extends LongRunningTask {
   private static final Logger LOGGER = LogUtils.getLogger();
   private final long serverId;
   private final Component title;
   private final Runnable callback;

   public ResettingWorldTask(long p7a37f228_0_0, Component p7a37f228_1_1, Runnable p7a37f228_2_2) {
      this.serverId = p7a37f228_0_0;
      this.title = p7a37f228_1_1;
      this.callback = p7a37f228_2_2;
   }

   protected abstract void sendResetRequest(RealmsClient var1, long var2) throws RealmsServiceException;

   @Override
   public void run() {
      RealmsClient $$0 = RealmsClient.getOrCreate();
      int $$1 = 0;

      while ($$1 < 25) {
         try {
            if (this.aborted()) {
               return;
            }

            this.sendResetRequest($$0, this.serverId);
            if (this.aborted()) {
               return;
            }

            this.callback.run();
            return;
         } catch (RetryCallException $$2) {
            if (this.aborted()) {
               return;
            }

            pause($$2.delaySeconds);
            $$1++;
         } catch (Exception $$3) {
            if (this.aborted()) {
               return;
            }

            LOGGER.error("Couldn't reset world");
            this.error($$3);
            return;
         }
      }
   }

   @Override
   public Component getTitle() {
      return this.title;
   }
}
