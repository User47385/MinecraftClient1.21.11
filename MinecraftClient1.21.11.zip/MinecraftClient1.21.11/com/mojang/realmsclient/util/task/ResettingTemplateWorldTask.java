package com.mojang.realmsclient.util.task;

import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.WorldTemplate;
import com.mojang.realmsclient.exception.RealmsServiceException;
import net.minecraft.network.chat.Component;

public class ResettingTemplateWorldTask extends ResettingWorldTask {
   private final WorldTemplate template;

   public ResettingTemplateWorldTask(WorldTemplate p7e2c2dce_0_0, long p7e2c2dce_1_1, Component p7e2c2dce_2_2, Runnable p7e2c2dce_3_3) {
      super(p7e2c2dce_1_1, p7e2c2dce_2_2, p7e2c2dce_3_3);
      this.template = p7e2c2dce_0_0;
   }

   @Override
   protected void sendResetRequest(RealmsClient p7e2c2dce_4_0, long p7e2c2dce_5_1) throws RealmsServiceException {
      p7e2c2dce_4_0.resetWorldWithTemplate(p7e2c2dce_5_1, this.template.id());
   }
}
