package com.mojang.realmsclient.util.task;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.exception.RealmsServiceException;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

public class RealmCreationTask extends LongRunningTask {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final Component TITLE = Component.translatable("mco.create.world.wait");
   private final String name;
   private final String motd;
   private final long realmId;

   public RealmCreationTask(long p1b4f9145_0_0, String p1b4f9145_1_1, String p1b4f9145_2_2) {
      this.realmId = p1b4f9145_0_0;
      this.name = p1b4f9145_1_1;
      this.motd = p1b4f9145_2_2;
   }

   @Override
   public void run() {
      RealmsClient $$0 = RealmsClient.getOrCreate();

      try {
         $$0.initializeRealm(this.realmId, this.name, this.motd);
      } catch (RealmsServiceException $$1) {
         LOGGER.error("Couldn't create world", $$1);
         this.error($$1);
      } catch (Exception $$2) {
         LOGGER.error("Could not create world", $$2);
         this.error($$2);
      }
   }

   @Override
   public Component getTitle() {
      return TITLE;
   }
}
