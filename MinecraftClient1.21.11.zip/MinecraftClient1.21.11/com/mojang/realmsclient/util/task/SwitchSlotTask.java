package com.mojang.realmsclient.util.task;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.exception.RetryCallException;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

public class SwitchSlotTask extends LongRunningTask {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final Component TITLE = Component.translatable("mco.minigame.world.slot.screen.title");
   private final long realmId;
   private final int slot;
   private final Runnable callback;

   public SwitchSlotTask(long p70b82525_0_0, int p70b82525_1_1, Runnable p70b82525_2_2) {
      this.realmId = p70b82525_0_0;
      this.slot = p70b82525_1_1;
      this.callback = p70b82525_2_2;
   }

   @Override
   public void run() {
      RealmsClient $$0 = RealmsClient.getOrCreate();

      for (int $$1 = 0; $$1 < 25; $$1++) {
         try {
            if (this.aborted()) {
               return;
            }

            if ($$0.switchSlot(this.realmId, this.slot)) {
               this.callback.run();
               break;
            }
         } catch (RetryCallException $$2) {
            if (this.aborted()) {
               return;
            }

            pause($$2.delaySeconds);
         } catch (Exception $$3) {
            if (this.aborted()) {
               return;
            }

            LOGGER.error("Couldn't switch world!");
            this.error($$3);
         }
      }
   }

   @Override
   public Component getTitle() {
      return TITLE;
   }
}
