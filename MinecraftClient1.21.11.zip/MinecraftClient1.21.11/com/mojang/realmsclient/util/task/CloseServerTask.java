package com.mojang.realmsclient.util.task;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.exception.RetryCallException;
import com.mojang.realmsclient.gui.screens.configuration.RealmsConfigureWorldScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

public class CloseServerTask extends LongRunningTask {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final Component TITLE = Component.translatable("mco.configure.world.closing");
   private final RealmsServer serverData;
   private final RealmsConfigureWorldScreen configureScreen;

   public CloseServerTask(RealmsServer p399c3012_0_0, RealmsConfigureWorldScreen p399c3012_1_1) {
      this.serverData = p399c3012_0_0;
      this.configureScreen = p399c3012_1_1;
   }

   @Override
   public void run() {
      RealmsClient $$0 = RealmsClient.getOrCreate();

      for (int $$1 = 0; $$1 < 25; $$1++) {
         if (this.aborted()) {
            return;
         }

         try {
            boolean $$2 = $$0.close(this.serverData.id);
            if ($$2) {
               this.configureScreen.stateChanged();
               this.serverData.state = RealmsServer.State.CLOSED;
               setScreen(this.configureScreen);
               break;
            }
         } catch (RetryCallException $$3) {
            if (this.aborted()) {
               return;
            }

            pause($$3.delaySeconds);
         } catch (Exception $$4) {
            if (this.aborted()) {
               return;
            }

            LOGGER.error("Failed to close server", $$4);
            this.error($$4);
         }
      }
   }

   @Override
   public Component getTitle() {
      return TITLE;
   }
}
