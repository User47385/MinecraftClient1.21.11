package com.mojang.realmsclient.util.task;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.WorldDownload;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.exception.RetryCallException;
import com.mojang.realmsclient.gui.screens.RealmsDownloadLatestWorldScreen;
import com.mojang.realmsclient.gui.screens.RealmsGenericErrorScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

public class DownloadTask extends LongRunningTask {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final Component TITLE = Component.translatable("mco.download.preparing");
   private final long realmId;
   private final int slot;
   private final Screen lastScreen;
   private final String downloadName;

   public DownloadTask(long pe1f17adb_0_0, int pe1f17adb_1_1, String pe1f17adb_2_2, Screen pe1f17adb_3_3) {
      this.realmId = pe1f17adb_0_0;
      this.slot = pe1f17adb_1_1;
      this.lastScreen = pe1f17adb_3_3;
      this.downloadName = pe1f17adb_2_2;
   }

   @Override
   public void run() {
      RealmsClient $$0 = RealmsClient.getOrCreate();
      int $$1 = 0;

      while ($$1 < 25) {
         try {
            if (this.aborted()) {
               return;
            }

            WorldDownload $$2 = $$0.requestDownloadInfo(this.realmId, this.slot);
            pause(1L);
            if (this.aborted()) {
               return;
            }

            setScreen(new RealmsDownloadLatestWorldScreen(this.lastScreen, $$2, this.downloadName, pe1f17adb_4_0 -> {}));
            return;
         } catch (RetryCallException $$3) {
            if (this.aborted()) {
               return;
            }

            pause($$3.delaySeconds);
            $$1++;
         } catch (RealmsServiceException $$4) {
            if (this.aborted()) {
               return;
            }

            LOGGER.error("Couldn't download world data", $$4);
            setScreen(new RealmsGenericErrorScreen($$4, this.lastScreen));
            return;
         } catch (Exception $$5) {
            if (this.aborted()) {
               return;
            }

            LOGGER.error("Couldn't download world data", $$5);
            this.error($$5);
            return;
         }
      }
   }

   @Override
   public Component getTitle() {
      return TITLE;
   }
}
