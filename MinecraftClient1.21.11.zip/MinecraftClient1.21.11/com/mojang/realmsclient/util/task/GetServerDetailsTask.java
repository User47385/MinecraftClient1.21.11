package com.mojang.realmsclient.util.task;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsJoinInformation;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.exception.RetryCallException;
import com.mojang.realmsclient.gui.screens.RealmsBrokenWorldScreen;
import com.mojang.realmsclient.gui.screens.RealmsGenericErrorScreen;
import com.mojang.realmsclient.gui.screens.RealmsLongRunningMcoConnectTaskScreen;
import com.mojang.realmsclient.gui.screens.RealmsLongRunningMcoTaskScreen;
import com.mojang.realmsclient.gui.screens.RealmsPopups;
import com.mojang.realmsclient.gui.screens.RealmsTermsScreen;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.PopupScreen;
import net.minecraft.client.gui.screens.GenericMessageScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.server.DownloadedPackSource;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

public class GetServerDetailsTask extends LongRunningTask {
   private static final Component APPLYING_PACK_TEXT = Component.translatable("multiplayer.applyingPack");
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final Component TITLE = Component.translatable("mco.connect.connecting");
   private final RealmsServer server;
   private final Screen lastScreen;

   public GetServerDetailsTask(Screen pbc1e919c_0_0, RealmsServer pbc1e919c_1_1) {
      this.lastScreen = pbc1e919c_0_0;
      this.server = pbc1e919c_1_1;
   }

   @Override
   public void run() {
      RealmsJoinInformation $$0;
      try {
         $$0 = this.fetchServerAddress();
      } catch (CancellationException $$1) {
         LOGGER.info("User aborted connecting to realms");
         return;
      } catch (RealmsServiceException $$2) {
         switch ($$2.realmsError.errorCode()) {
            case 6002:
               setScreen(new RealmsTermsScreen(this.lastScreen, this.server));
               return;
            case 6006:
               boolean $$3 = Minecraft.getInstance().isLocalPlayer(this.server.ownerUUID);
               setScreen(
                  $$3
                     ? new RealmsBrokenWorldScreen(this.lastScreen, this.server.id, this.server.isMinigameActive())
                     : new RealmsGenericErrorScreen(
                        Component.translatable("mco.brokenworld.nonowner.title"), Component.translatable("mco.brokenworld.nonowner.error"), this.lastScreen
                     )
               );
               return;
            default:
               this.error($$2);
               LOGGER.error("Couldn't connect to world", $$2);
               return;
         }
      } catch (TimeoutException $$4) {
         this.error(Component.translatable("mco.errorMessage.connectionFailure"));
         return;
      } catch (Exception $$5) {
         LOGGER.error("Couldn't connect to world", $$5);
         this.error($$5);
         return;
      }

      if ($$0.address() == null) {
         this.error(Component.translatable("mco.errorMessage.connectionFailure"));
      } else {
         boolean $$7 = $$0.resourcePackUrl() != null && $$0.resourcePackHash() != null;
         Screen $$8 = $$7 ? this.resourcePackDownloadConfirmationScreen($$0, generatePackId(this.server), this::connectScreen) : this.connectScreen($$0);
         setScreen($$8);
      }
   }

   private static UUID generatePackId(RealmsServer pbc1e919c_2_0) {
      return pbc1e919c_2_0.minigameName != null
         ? UUID.nameUUIDFromBytes(("minigame:" + pbc1e919c_2_0.minigameName).getBytes(StandardCharsets.UTF_8))
         : UUID.nameUUIDFromBytes(
            ("realms:" + Objects.requireNonNullElse(pbc1e919c_2_0.name, "") + ":" + pbc1e919c_2_0.activeSlot).getBytes(StandardCharsets.UTF_8)
         );
   }

   @Override
   public Component getTitle() {
      return TITLE;
   }

   private RealmsJoinInformation fetchServerAddress() throws RealmsServiceException, TimeoutException, CancellationException {
      RealmsClient $$0 = RealmsClient.getOrCreate();

      for (int $$1 = 0; $$1 < 40; $$1++) {
         if (this.aborted()) {
            throw new CancellationException();
         }

         try {
            return $$0.join(this.server.id);
         } catch (RetryCallException $$2) {
            pause($$2.delaySeconds);
         }
      }

      throw new TimeoutException();
   }

   public RealmsLongRunningMcoTaskScreen connectScreen(RealmsJoinInformation pbc1e919c_3_0) {
      return new RealmsLongRunningMcoConnectTaskScreen(this.lastScreen, pbc1e919c_3_0, new ConnectTask(this.lastScreen, this.server, pbc1e919c_3_0));
   }

   private PopupScreen resourcePackDownloadConfirmationScreen(
      RealmsJoinInformation pbc1e919c_4_0, UUID pbc1e919c_5_1, Function<RealmsJoinInformation, Screen> pbc1e919c_6_2
   ) {
      Component $$3 = Component.translatable("mco.configure.world.resourcepack.question");
      return RealmsPopups.infoPopupScreen(
         this.lastScreen,
         $$3,
         pbc1e919c_12_3 -> {
            setScreen(new GenericMessageScreen(APPLYING_PACK_TEXT));
            this.scheduleResourcePackDownload(pbc1e919c_4_0, pbc1e919c_5_1)
               .thenRun(() -> setScreen(pbc1e919c_6_2.apply(pbc1e919c_4_0)))
               .exceptionally(pbc1e919c_14_1 -> {
                  Minecraft.getInstance().getDownloadedPackSource().cleanupAfterDisconnect();
                  LOGGER.error("Failed to download resource pack from {}", pbc1e919c_4_0, pbc1e919c_14_1);
                  setScreen(new RealmsGenericErrorScreen(Component.translatable("mco.download.resourcePack.fail"), this.lastScreen));
                  return null;
               });
         }
      );
   }

   private CompletableFuture<?> scheduleResourcePackDownload(RealmsJoinInformation pbc1e919c_7_0, UUID pbc1e919c_8_1) {
      try {
         if (pbc1e919c_7_0.resourcePackUrl() == null) {
            return CompletableFuture.failedFuture(new IllegalStateException("resourcePackUrl was null"));
         }

         if (pbc1e919c_7_0.resourcePackHash() == null) {
            return CompletableFuture.failedFuture(new IllegalStateException("resourcePackHash was null"));
         }

         DownloadedPackSource $$2 = Minecraft.getInstance().getDownloadedPackSource();
         CompletableFuture<Void> $$3 = $$2.waitForPackFeedback(pbc1e919c_8_1);
         $$2.allowServerPacks();
         $$2.pushPack(pbc1e919c_8_1, new URL(pbc1e919c_7_0.resourcePackUrl()), pbc1e919c_7_0.resourcePackHash());
         return $$3;
      } catch (Exception $$4) {
         return CompletableFuture.failedFuture($$4);
      }
   }
}
