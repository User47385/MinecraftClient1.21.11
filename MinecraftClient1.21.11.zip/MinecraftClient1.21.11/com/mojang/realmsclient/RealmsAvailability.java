package com.mojang.realmsclient;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.gui.screens.RealmsClientOutdatedScreen;
import com.mojang.realmsclient.gui.screens.RealmsGenericErrorScreen;
import com.mojang.realmsclient.gui.screens.RealmsParentalConsentScreen;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsAvailability {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static @Nullable CompletableFuture<RealmsAvailability.Result> future;

   public static CompletableFuture<RealmsAvailability.Result> get() {
      if (future == null || shouldRefresh(future)) {
         future = check();
      }

      return future;
   }

   private static boolean shouldRefresh(CompletableFuture<RealmsAvailability.Result> pe7f56cf0_0_0) {
      RealmsAvailability.Result $$1 = pe7f56cf0_0_0.getNow(null);
      return $$1 != null && $$1.exception() != null;
   }

   private static CompletableFuture<RealmsAvailability.Result> check() {
      if (Minecraft.getInstance().isOfflineDeveloperMode()) {
         return CompletableFuture.completedFuture(new RealmsAvailability.Result(RealmsAvailability.Type.AUTHENTICATION_ERROR));
      } else {
         return SharedConstants.DEBUG_BYPASS_REALMS_VERSION_CHECK
            ? CompletableFuture.completedFuture(new RealmsAvailability.Result(RealmsAvailability.Type.SUCCESS))
            : CompletableFuture.supplyAsync(
               () -> {
                  RealmsClient $$0 = RealmsClient.getOrCreate();

                  try {
                     if ($$0.clientCompatible() != RealmsClient.CompatibleVersionResponse.COMPATIBLE) {
                        return new RealmsAvailability.Result(RealmsAvailability.Type.INCOMPATIBLE_CLIENT);
                     } else {
                        return !$$0.hasParentalConsent()
                           ? new RealmsAvailability.Result(RealmsAvailability.Type.NEEDS_PARENTAL_CONSENT)
                           : new RealmsAvailability.Result(RealmsAvailability.Type.SUCCESS);
                     }
                  } catch (RealmsServiceException $$1) {
                     LOGGER.error("Couldn't connect to realms", $$1);
                     return $$1.realmsError.errorCode() == 401
                        ? new RealmsAvailability.Result(RealmsAvailability.Type.AUTHENTICATION_ERROR)
                        : new RealmsAvailability.Result($$1);
                  }
               },
               Util.ioPool()
            );
      }
   }

   public record Result(RealmsAvailability.Type type, @Nullable RealmsServiceException exception) {
      public Result(RealmsAvailability.Type p8e862e71_0_0) {
         this(p8e862e71_0_0, null);
      }

      public Result(RealmsServiceException p8e862e71_1_0) {
         this(RealmsAvailability.Type.UNEXPECTED_ERROR, p8e862e71_1_0);
      }

      public @Nullable Screen createErrorScreen(Screen p8e862e71_4_0) {
         return switch (this.type) {
            case SUCCESS -> null;
            case INCOMPATIBLE_CLIENT -> new RealmsClientOutdatedScreen(p8e862e71_4_0);
            case NEEDS_PARENTAL_CONSENT -> new RealmsParentalConsentScreen(p8e862e71_4_0);
            case AUTHENTICATION_ERROR -> new RealmsGenericErrorScreen(
               Component.translatable("mco.error.invalid.session.title"), Component.translatable("mco.error.invalid.session.message"), p8e862e71_4_0
            );
            case UNEXPECTED_ERROR -> new RealmsGenericErrorScreen(Objects.requireNonNull(this.exception), p8e862e71_4_0);
         };
      }
   }

   public enum Type {
      SUCCESS,
      INCOMPATIBLE_CLIENT,
      NEEDS_PARENTAL_CONSENT,
      AUTHENTICATION_ERROR,
      UNEXPECTED_ERROR;
   }
}
