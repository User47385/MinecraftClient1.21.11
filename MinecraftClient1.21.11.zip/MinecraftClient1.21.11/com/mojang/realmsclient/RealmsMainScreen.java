package com.mojang.realmsclient;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.RateLimiter;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.Ping;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.PingResult;
import com.mojang.realmsclient.dto.RealmsNotification;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.RealmsServerPlayerLists;
import com.mojang.realmsclient.dto.RegionPingResult;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.gui.RealmsDataFetcher;
import com.mojang.realmsclient.gui.RealmsServerList;
import com.mojang.realmsclient.gui.screens.AddRealmPopupScreen;
import com.mojang.realmsclient.gui.screens.RealmsCreateRealmScreen;
import com.mojang.realmsclient.gui.screens.RealmsGenericErrorScreen;
import com.mojang.realmsclient.gui.screens.RealmsLongRunningMcoTaskScreen;
import com.mojang.realmsclient.gui.screens.RealmsPendingInvitesScreen;
import com.mojang.realmsclient.gui.screens.RealmsPopups;
import com.mojang.realmsclient.gui.screens.configuration.RealmsConfigureWorldScreen;
import com.mojang.realmsclient.gui.task.DataFetcher;
import com.mojang.realmsclient.util.RealmsPersistence;
import com.mojang.realmsclient.util.RealmsUtil;
import com.mojang.realmsclient.util.task.GetServerDetailsTask;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.ChatFormatting;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.FocusableTextWidget;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.ImageWidget;
import net.minecraft.client.gui.components.LoadingDotsWidget;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.gui.components.PopupScreen;
import net.minecraft.client.gui.components.SpriteIconButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.WidgetTooltipHolder;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.Layout;
import net.minecraft.client.gui.layouts.LayoutSettings;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.layouts.SpacerElement;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientActivePlayersTooltip;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.PlayerSkinRenderCache;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.CommonLinks;
import net.minecraft.util.Util;
import net.minecraft.world.item.component.ResolvableProfile;
import net.minecraft.world.level.GameType;
import org.apache.commons.lang3.StringUtils;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsMainScreen extends RealmsScreen {
   static final Identifier INFO_SPRITE = Identifier.withDefaultNamespace("icon/info");
   static final Identifier NEW_REALM_SPRITE = Identifier.withDefaultNamespace("icon/new_realm");
   static final Identifier EXPIRED_SPRITE = Identifier.withDefaultNamespace("realm_status/expired");
   static final Identifier EXPIRES_SOON_SPRITE = Identifier.withDefaultNamespace("realm_status/expires_soon");
   static final Identifier OPEN_SPRITE = Identifier.withDefaultNamespace("realm_status/open");
   static final Identifier CLOSED_SPRITE = Identifier.withDefaultNamespace("realm_status/closed");
   private static final Identifier INVITE_SPRITE = Identifier.withDefaultNamespace("icon/invite");
   private static final Identifier NEWS_SPRITE = Identifier.withDefaultNamespace("icon/news");
   public static final Identifier HARDCORE_MODE_SPRITE = Identifier.withDefaultNamespace("hud/heart/hardcore_full");
   static final Logger LOGGER = LogUtils.getLogger();
   private static final Identifier NO_REALMS_LOCATION = Identifier.withDefaultNamespace("textures/gui/realms/no_realms.png");
   private static final Component TITLE = Component.translatable("menu.online");
   private static final Component LOADING_TEXT = Component.translatable("mco.selectServer.loading");
   static final Component SERVER_UNITIALIZED_TEXT = Component.translatable("mco.selectServer.uninitialized");
   static final Component SUBSCRIPTION_EXPIRED_TEXT = Component.translatable("mco.selectServer.expiredList");
   private static final Component SUBSCRIPTION_RENEW_TEXT = Component.translatable("mco.selectServer.expiredRenew");
   static final Component TRIAL_EXPIRED_TEXT = Component.translatable("mco.selectServer.expiredTrial");
   private static final Component PLAY_TEXT = Component.translatable("mco.selectServer.play");
   private static final Component LEAVE_SERVER_TEXT = Component.translatable("mco.selectServer.leave");
   private static final Component CONFIGURE_SERVER_TEXT = Component.translatable("mco.selectServer.configure");
   static final Component SERVER_EXPIRED_TOOLTIP = Component.translatable("mco.selectServer.expired");
   static final Component SERVER_EXPIRES_SOON_TOOLTIP = Component.translatable("mco.selectServer.expires.soon");
   static final Component SERVER_EXPIRES_IN_DAY_TOOLTIP = Component.translatable("mco.selectServer.expires.day");
   static final Component SERVER_OPEN_TOOLTIP = Component.translatable("mco.selectServer.open");
   static final Component SERVER_CLOSED_TOOLTIP = Component.translatable("mco.selectServer.closed");
   static final Component UNITIALIZED_WORLD_NARRATION = Component.translatable("gui.narrate.button", SERVER_UNITIALIZED_TEXT);
   private static final Component NO_REALMS_TEXT = Component.translatable("mco.selectServer.noRealms");
   private static final Component NO_PENDING_INVITES = Component.translatable("mco.invites.nopending");
   private static final Component PENDING_INVITES = Component.translatable("mco.invites.pending");
   private static final Component INCOMPATIBLE_POPUP_TITLE = Component.translatable("mco.compatibility.incompatible.popup.title");
   private static final Component INCOMPATIBLE_RELEASE_TYPE_POPUP_MESSAGE = Component.translatable("mco.compatibility.incompatible.releaseType.popup.message");
   private static final int BUTTON_WIDTH = 100;
   private static final int BUTTON_COLUMNS = 3;
   private static final int BUTTON_SPACING = 4;
   private static final int CONTENT_WIDTH = 308;
   private static final int LOGO_PADDING = 5;
   private static final int HEADER_HEIGHT = 44;
   private static final int FOOTER_PADDING = 11;
   private static final int NEW_REALM_SPRITE_WIDTH = 40;
   private static final int NEW_REALM_SPRITE_HEIGHT = 20;
   private static final boolean SNAPSHOT = !SharedConstants.getCurrentVersion().stable();
   private static boolean snapshotToggle = SNAPSHOT;
   private final CompletableFuture<RealmsAvailability.Result> availability = RealmsAvailability.get();
   private DataFetcher.@Nullable Subscription dataSubscription;
   private final Set<UUID> handledSeenNotifications = new HashSet<>();
   private static boolean regionsPinged;
   private final RateLimiter inviteNarrationLimiter;
   private final Screen lastScreen;
   private Button playButton;
   private Button backButton;
   private Button renewButton;
   private Button configureButton;
   private Button leaveButton;
   RealmsMainScreen.RealmSelectionList realmSelectionList;
   RealmsServerList serverList;
   List<RealmsServer> availableSnapshotServers = List.of();
   RealmsServerPlayerLists onlinePlayersPerRealm = new RealmsServerPlayerLists(Map.of());
   private volatile boolean trialsAvailable;
   private volatile @Nullable String newsLink;
   final List<RealmsNotification> notifications = new ArrayList<>();
   private Button addRealmButton;
   private RealmsMainScreen.NotificationButton pendingInvitesButton;
   private RealmsMainScreen.NotificationButton newsButton;
   private RealmsMainScreen.LayoutState activeLayoutState;
   private @Nullable HeaderAndFooterLayout layout;

   public RealmsMainScreen(Screen p4ed6fc5a_0_0) {
      super(TITLE);
      this.lastScreen = p4ed6fc5a_0_0;
      this.inviteNarrationLimiter = RateLimiter.create(0.016666668F);
   }

   @Override
   public void init() {
      this.serverList = new RealmsServerList(this.minecraft);
      this.realmSelectionList = new RealmsMainScreen.RealmSelectionList();
      Component $$0 = Component.translatable("mco.invites.title");
      this.pendingInvitesButton = new RealmsMainScreen.NotificationButton(
         $$0, INVITE_SPRITE, p4ed6fc5a_85_1 -> this.minecraft.setScreen(new RealmsPendingInvitesScreen(this, $$0)), null
      );
      Component $$1 = Component.translatable("mco.news");
      this.newsButton = new RealmsMainScreen.NotificationButton($$1, NEWS_SPRITE, p4ed6fc5a_83_0 -> {
         String $$1x = this.newsLink;
         if ($$1x != null) {
            ConfirmLinkScreen.confirmLinkNow(this, $$1x);
            if (this.newsButton.notificationCount() != 0) {
               RealmsPersistence.RealmsPersistenceData $$2 = RealmsPersistence.readFile();
               $$2.hasUnreadNews = false;
               RealmsPersistence.writeFile($$2);
               this.newsButton.setNotificationCount(0);
            }
         }
      }, $$1);
      this.playButton = Button.builder(PLAY_TEXT, p4ed6fc5a_82_0 -> play(this.getSelectedServer(), this)).width(100).build();
      this.configureButton = Button.builder(CONFIGURE_SERVER_TEXT, p4ed6fc5a_81_0 -> this.configureClicked(this.getSelectedServer())).width(100).build();
      this.renewButton = Button.builder(SUBSCRIPTION_RENEW_TEXT, p4ed6fc5a_80_0 -> this.onRenew(this.getSelectedServer())).width(100).build();
      this.leaveButton = Button.builder(LEAVE_SERVER_TEXT, p4ed6fc5a_79_0 -> this.leaveClicked(this.getSelectedServer())).width(100).build();
      this.addRealmButton = Button.builder(Component.translatable("mco.selectServer.purchase"), p4ed6fc5a_78_0 -> this.openTrialAvailablePopup())
         .size(100, 20)
         .build();
      this.backButton = Button.builder(CommonComponents.GUI_BACK, p4ed6fc5a_77_0 -> this.onClose()).width(100).build();
      if (RealmsClient.ENVIRONMENT == RealmsClient.Environment.STAGE) {
         this.addRenderableWidget(
            CycleButton.booleanBuilder(Component.literal("Snapshot"), Component.literal("Release"), snapshotToggle)
               .create(5, 5, 100, 20, Component.literal("Realm"), (p4ed6fc5a_75_0, p4ed6fc5a_76_1) -> {
                  snapshotToggle = p4ed6fc5a_76_1;
                  this.availableSnapshotServers = List.of();
                  this.debugRefreshDataFetchers();
               })
         );
      }

      this.updateLayout(RealmsMainScreen.LayoutState.LOADING);
      this.updateButtonStates();
      this.availability.thenAcceptAsync(p4ed6fc5a_74_0 -> {
         Screen $$1x = p4ed6fc5a_74_0.createErrorScreen(this.lastScreen);
         if ($$1x == null) {
            this.dataSubscription = this.initDataFetcher(this.minecraft.realmsDataFetcher());
         } else {
            this.minecraft.setScreen($$1x);
         }
      }, this.screenExecutor);
   }

   public static boolean isSnapshot() {
      return SNAPSHOT && snapshotToggle;
   }

   @Override
   protected void repositionElements() {
      if (this.layout != null) {
         this.realmSelectionList.updateSize(this.width, this.layout);
         this.layout.arrangeElements();
      }
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.lastScreen);
   }

   private void updateLayout() {
      if (this.serverList.isEmpty() && this.availableSnapshotServers.isEmpty() && this.notifications.isEmpty()) {
         this.updateLayout(RealmsMainScreen.LayoutState.NO_REALMS);
      } else {
         this.updateLayout(RealmsMainScreen.LayoutState.LIST);
      }
   }

   private void updateLayout(RealmsMainScreen.LayoutState p4ed6fc5a_1_0) {
      if (this.activeLayoutState != p4ed6fc5a_1_0) {
         if (this.layout != null) {
            this.layout.visitWidgets(p4ed6fc5a_73_1 -> this.removeWidget(p4ed6fc5a_73_1));
         }

         this.layout = this.createLayout(p4ed6fc5a_1_0);
         this.activeLayoutState = p4ed6fc5a_1_0;
         this.layout.visitWidgets(p4ed6fc5a_71_1 -> {
            AbstractWidget var10000 = this.addRenderableWidget(p4ed6fc5a_71_1);
         });
         this.repositionElements();
      }
   }

   private HeaderAndFooterLayout createLayout(RealmsMainScreen.LayoutState p4ed6fc5a_2_0) {
      HeaderAndFooterLayout $$1 = new HeaderAndFooterLayout(this);
      $$1.setHeaderHeight(44);
      $$1.addToHeader(this.createHeader());
      Layout $$2 = this.createFooter(p4ed6fc5a_2_0);
      $$2.arrangeElements();
      $$1.setFooterHeight($$2.getHeight() + 22);
      $$1.addToFooter($$2);
      switch (p4ed6fc5a_2_0) {
         case LOADING:
            $$1.addToContents(new LoadingDotsWidget(this.font, LOADING_TEXT));
            break;
         case NO_REALMS:
            $$1.addToContents(this.createNoRealmsContent());
            break;
         case LIST:
            $$1.addToContents(this.realmSelectionList);
      }

      return $$1;
   }

   private Layout createHeader() {
      int $$0 = 90;
      LinearLayout $$1 = LinearLayout.horizontal().spacing(4);
      $$1.defaultCellSetting().alignVerticallyMiddle();
      $$1.addChild(this.pendingInvitesButton);
      $$1.addChild(this.newsButton);
      LinearLayout $$2 = LinearLayout.horizontal();
      $$2.defaultCellSetting().alignVerticallyMiddle();
      $$2.addChild(SpacerElement.width(90));
      $$2.addChild(realmsLogo(), LayoutSettings::alignHorizontallyCenter);
      $$2.addChild(new FrameLayout(90, 44)).addChild($$1, LayoutSettings::alignHorizontallyRight);
      return $$2;
   }

   private Layout createFooter(RealmsMainScreen.LayoutState p4ed6fc5a_3_0) {
      GridLayout $$1 = new GridLayout().spacing(4);
      GridLayout.RowHelper $$2 = $$1.createRowHelper(3);
      if (p4ed6fc5a_3_0 == RealmsMainScreen.LayoutState.LIST) {
         $$2.addChild(this.playButton);
         $$2.addChild(this.configureButton);
         $$2.addChild(this.renewButton);
         $$2.addChild(this.leaveButton);
      }

      $$2.addChild(this.addRealmButton);
      $$2.addChild(this.backButton);
      return $$1;
   }

   private LinearLayout createNoRealmsContent() {
      LinearLayout $$0 = LinearLayout.vertical().spacing(8);
      $$0.defaultCellSetting().alignHorizontallyCenter();
      $$0.addChild(ImageWidget.texture(130, 64, NO_REALMS_LOCATION, 130, 64));
      $$0.addChild(
         FocusableTextWidget.builder(NO_REALMS_TEXT, this.font)
            .maxWidth(308)
            .alwaysShowBorder(false)
            .backgroundFill(FocusableTextWidget.BackgroundFill.ON_FOCUS)
            .build()
      );
      return $$0;
   }

   void updateButtonStates() {
      RealmsServer $$0 = this.getSelectedServer();
      boolean $$1 = $$0 != null;
      this.addRealmButton.active = this.activeLayoutState != RealmsMainScreen.LayoutState.LOADING;
      this.playButton.active = $$1 && $$0.shouldPlayButtonBeActive();
      if (!this.playButton.active && $$1 && $$0.state == RealmsServer.State.CLOSED) {
         this.playButton.setTooltip(Tooltip.create(RealmsServer.WORLD_CLOSED_COMPONENT));
      }

      this.renewButton.active = $$1 && this.shouldRenewButtonBeActive($$0);
      this.leaveButton.active = $$1 && this.shouldLeaveButtonBeActive($$0);
      this.configureButton.active = $$1 && this.shouldConfigureButtonBeActive($$0);
   }

   private boolean shouldRenewButtonBeActive(RealmsServer p4ed6fc5a_4_0) {
      return p4ed6fc5a_4_0.expired && isSelfOwnedServer(p4ed6fc5a_4_0);
   }

   private boolean shouldConfigureButtonBeActive(RealmsServer p4ed6fc5a_5_0) {
      return isSelfOwnedServer(p4ed6fc5a_5_0) && p4ed6fc5a_5_0.state != RealmsServer.State.UNINITIALIZED;
   }

   private boolean shouldLeaveButtonBeActive(RealmsServer p4ed6fc5a_6_0) {
      return !isSelfOwnedServer(p4ed6fc5a_6_0);
   }

   @Override
   public void tick() {
      super.tick();
      if (this.dataSubscription != null) {
         this.dataSubscription.tick();
      }
   }

   public static void refreshPendingInvites() {
      Minecraft.getInstance().realmsDataFetcher().pendingInvitesTask.reset();
   }

   public static void refreshServerList() {
      Minecraft.getInstance().realmsDataFetcher().serverListUpdateTask.reset();
   }

   private void debugRefreshDataFetchers() {
      for (DataFetcher.Task<?> $$0 : this.minecraft.realmsDataFetcher().getTasks()) {
         $$0.reset();
      }
   }

   private DataFetcher.Subscription initDataFetcher(RealmsDataFetcher p4ed6fc5a_7_0) {
      DataFetcher.Subscription $$1 = p4ed6fc5a_7_0.dataFetcher.createSubscription();
      $$1.subscribe(p4ed6fc5a_7_0.serverListUpdateTask, p4ed6fc5a_69_0 -> {
         this.serverList.updateServersList(p4ed6fc5a_69_0.serverList());
         this.availableSnapshotServers = p4ed6fc5a_69_0.availableSnapshotServers();
         this.refreshListAndLayout();
         boolean $$1x = false;

         for (RealmsServer $$2 : this.serverList) {
            if (this.isSelfOwnedNonExpiredServer($$2)) {
               $$1x = true;
            }
         }

         if (!regionsPinged && $$1x) {
            regionsPinged = true;
            this.pingRegions();
         }
      });
      callRealmsClient(RealmsClient::getNotifications, p4ed6fc5a_68_0 -> {
         this.notifications.clear();
         this.notifications.addAll(p4ed6fc5a_68_0);

         for (RealmsNotification $$1x : p4ed6fc5a_68_0) {
            if ($$1x instanceof RealmsNotification.InfoPopup $$2) {
               PopupScreen $$3 = $$2.buildScreen(this, this::dismissNotification);
               if ($$3 != null) {
                  this.minecraft.setScreen($$3);
                  this.markNotificationsAsSeen(List.of($$1x));
                  break;
               }
            }
         }

         if (!this.notifications.isEmpty() && this.activeLayoutState != RealmsMainScreen.LayoutState.LOADING) {
            this.refreshListAndLayout();
         }
      });
      $$1.subscribe(p4ed6fc5a_7_0.pendingInvitesTask, p4ed6fc5a_67_0 -> {
         this.pendingInvitesButton.setNotificationCount(p4ed6fc5a_67_0);
         this.pendingInvitesButton.setTooltip(p4ed6fc5a_67_0 == 0 ? Tooltip.create(NO_PENDING_INVITES) : Tooltip.create(PENDING_INVITES));
         if (p4ed6fc5a_67_0 > 0 && this.inviteNarrationLimiter.tryAcquire(1)) {
            this.minecraft.getNarrator().saySystemNow(Component.translatable("mco.configure.world.invite.narration", p4ed6fc5a_67_0));
         }
      });
      $$1.subscribe(p4ed6fc5a_7_0.trialAvailabilityTask, p4ed6fc5a_66_0 -> this.trialsAvailable = p4ed6fc5a_66_0);
      $$1.subscribe(p4ed6fc5a_7_0.onlinePlayersTask, p4ed6fc5a_65_0 -> this.onlinePlayersPerRealm = p4ed6fc5a_65_0);
      $$1.subscribe(p4ed6fc5a_7_0.newsTask, p4ed6fc5a_64_1 -> {
         p4ed6fc5a_7_0.newsManager.updateUnreadNews(p4ed6fc5a_64_1);
         this.newsLink = p4ed6fc5a_7_0.newsManager.newsLink();
         this.newsButton.setNotificationCount(p4ed6fc5a_7_0.newsManager.hasUnreadNews() ? Integer.MAX_VALUE : 0);
      });
      return $$1;
   }

   void markNotificationsAsSeen(Collection<RealmsNotification> p4ed6fc5a_8_0) {
      List<UUID> $$1 = new ArrayList<>(p4ed6fc5a_8_0.size());

      for (RealmsNotification $$2 : p4ed6fc5a_8_0) {
         if (!$$2.seen() && !this.handledSeenNotifications.contains($$2.uuid())) {
            $$1.add($$2.uuid());
         }
      }

      if (!$$1.isEmpty()) {
         callRealmsClient(p4ed6fc5a_62_1 -> {
            p4ed6fc5a_62_1.notificationsSeen($$1);
            return null;
         }, p4ed6fc5a_60_1 -> this.handledSeenNotifications.addAll($$1));
      }
   }

   private static <T> void callRealmsClient(RealmsMainScreen.RealmsCall<T> p4ed6fc5a_9_0, Consumer<T> p4ed6fc5a_10_1) {
      Minecraft $$2 = Minecraft.getInstance();
      CompletableFuture.<T>supplyAsync(() -> {
         try {
            return p4ed6fc5a_9_0.request(RealmsClient.getOrCreate($$2));
         } catch (RealmsServiceException $$2x) {
            throw new RuntimeException($$2x);
         }
      }).thenAcceptAsync(p4ed6fc5a_10_1, $$2).exceptionally(p4ed6fc5a_56_0 -> {
         LOGGER.error("Failed to execute call to Realms Service", p4ed6fc5a_56_0);
         return null;
      });
   }

   private void refreshListAndLayout() {
      this.realmSelectionList.refreshEntries(this);
      this.updateLayout();
      this.updateButtonStates();
   }

   private void pingRegions() {
      new Thread(() -> {
         List<RegionPingResult> $$0 = Ping.pingAllRegions();
         RealmsClient $$1 = RealmsClient.getOrCreate();
         PingResult $$2 = new PingResult($$0, this.getOwnedNonExpiredRealmIds());

         try {
            $$1.sendPingResults($$2);
         } catch (Throwable $$3) {
            LOGGER.warn("Could not send ping result to Realms: ", $$3);
         }
      }).start();
   }

   private List<Long> getOwnedNonExpiredRealmIds() {
      List<Long> $$0 = Lists.newArrayList();

      for (RealmsServer $$1 : this.serverList) {
         if (this.isSelfOwnedNonExpiredServer($$1)) {
            $$0.add($$1.id);
         }
      }

      return $$0;
   }

   private void onRenew(@Nullable RealmsServer p4ed6fc5a_11_0) {
      if (p4ed6fc5a_11_0 != null) {
         String $$1 = CommonLinks.extendRealms(p4ed6fc5a_11_0.remoteSubscriptionId, this.minecraft.getUser().getProfileId(), p4ed6fc5a_11_0.expiredTrial);
         this.minecraft.setScreen(new ConfirmLinkScreen(p4ed6fc5a_55_1 -> {
            if (p4ed6fc5a_55_1) {
               Util.getPlatform().openUri($$1);
            } else {
               this.minecraft.setScreen(this);
            }
         }, $$1, true));
      }
   }

   private void configureClicked(@Nullable RealmsServer p4ed6fc5a_12_0) {
      if (p4ed6fc5a_12_0 != null && this.minecraft.isLocalPlayer(p4ed6fc5a_12_0.ownerUUID)) {
         this.minecraft.setScreen(new RealmsConfigureWorldScreen(this, p4ed6fc5a_12_0.id));
      }
   }

   private void leaveClicked(@Nullable RealmsServer p4ed6fc5a_13_0) {
      if (p4ed6fc5a_13_0 != null && !this.minecraft.isLocalPlayer(p4ed6fc5a_13_0.ownerUUID)) {
         Component $$1 = Component.translatable("mco.configure.world.leave.question.line1");
         this.minecraft.setScreen(RealmsPopups.infoPopupScreen(this, $$1, p4ed6fc5a_53_1 -> this.leaveServer(p4ed6fc5a_13_0)));
      }
   }

   private @Nullable RealmsServer getSelectedServer() {
      return this.realmSelectionList.getSelected() instanceof RealmsMainScreen.ServerEntry $$0 ? $$0.getServer() : null;
   }

   private void leaveServer(RealmsServer p4ed6fc5a_14_0) {
      (new Thread("Realms-leave-server") {
            @Override
            public void run() {
               try {
                  RealmsClient $$0 = RealmsClient.getOrCreate();
                  $$0.uninviteMyselfFrom(p4ed6fc5a_14_0.id);
                  RealmsMainScreen.this.minecraft.execute(RealmsMainScreen::refreshServerList);
               } catch (RealmsServiceException $$1) {
                  RealmsMainScreen.LOGGER.error("Couldn't configure world", $$1);
                  RealmsMainScreen.this.minecraft
                     .execute(() -> RealmsMainScreen.this.minecraft.setScreen(new RealmsGenericErrorScreen($$1, RealmsMainScreen.this)));
               }
            }
         })
         .start();
      this.minecraft.setScreen(this);
   }

   void dismissNotification(UUID p4ed6fc5a_15_0) {
      callRealmsClient(p4ed6fc5a_51_1 -> {
         p4ed6fc5a_51_1.notificationsDismiss(List.of(p4ed6fc5a_15_0));
         return null;
      }, p4ed6fc5a_47_1 -> {
         this.notifications.removeIf(p4ed6fc5a_49_1 -> p4ed6fc5a_49_1.dismissable() && p4ed6fc5a_15_0.equals(p4ed6fc5a_49_1.uuid()));
         this.refreshListAndLayout();
      });
   }

   public void resetScreen() {
      this.realmSelectionList.setSelected((RealmsMainScreen.Entry)null);
      refreshServerList();
   }

   @Override
   public Component getNarrationMessage() {
      return switch (this.activeLayoutState) {
         case LOADING -> CommonComponents.joinForNarration(super.getNarrationMessage(), LOADING_TEXT);
         case NO_REALMS -> CommonComponents.joinForNarration(super.getNarrationMessage(), NO_REALMS_TEXT);
         case LIST -> super.getNarrationMessage();
      };
   }

   @Override
   public void render(GuiGraphics p4ed6fc5a_16_0, int p4ed6fc5a_17_1, int p4ed6fc5a_18_2, float p4ed6fc5a_19_3) {
      super.render(p4ed6fc5a_16_0, p4ed6fc5a_17_1, p4ed6fc5a_18_2, p4ed6fc5a_19_3);
      if (isSnapshot()) {
         p4ed6fc5a_16_0.drawString(this.font, "Minecraft " + SharedConstants.getCurrentVersion().name(), 2, this.height - 10, -1);
      }

      if (this.trialsAvailable && this.addRealmButton.active) {
         AddRealmPopupScreen.renderDiamond(p4ed6fc5a_16_0, this.addRealmButton);
      }

      switch (RealmsClient.ENVIRONMENT) {
         case STAGE:
            this.renderEnvironment(p4ed6fc5a_16_0, "STAGE!", -256);
            break;
         case LOCAL:
            this.renderEnvironment(p4ed6fc5a_16_0, "LOCAL!", -8388737);
      }
   }

   private void openTrialAvailablePopup() {
      this.minecraft.setScreen(new AddRealmPopupScreen(this, this.trialsAvailable));
   }

   public static void play(@Nullable RealmsServer p4ed6fc5a_20_0, Screen p4ed6fc5a_21_1) {
      play(p4ed6fc5a_20_0, p4ed6fc5a_21_1, false);
   }

   public static void play(@Nullable RealmsServer p4ed6fc5a_22_0, Screen p4ed6fc5a_23_1, boolean p4ed6fc5a_24_2) {
      if (p4ed6fc5a_22_0 != null) {
         if (!isSnapshot() || p4ed6fc5a_24_2 || p4ed6fc5a_22_0.isMinigameActive()) {
            Minecraft.getInstance().setScreen(new RealmsLongRunningMcoTaskScreen(p4ed6fc5a_23_1, new GetServerDetailsTask(p4ed6fc5a_23_1, p4ed6fc5a_22_0)));
            return;
         }

         switch (p4ed6fc5a_22_0.compatibility) {
            case COMPATIBLE:
               Minecraft.getInstance().setScreen(new RealmsLongRunningMcoTaskScreen(p4ed6fc5a_23_1, new GetServerDetailsTask(p4ed6fc5a_23_1, p4ed6fc5a_22_0)));
               break;
            case UNVERIFIABLE:
               confirmToPlay(
                  p4ed6fc5a_22_0,
                  p4ed6fc5a_23_1,
                  Component.translatable("mco.compatibility.unverifiable.title").withColor(-171),
                  Component.translatable("mco.compatibility.unverifiable.message"),
                  CommonComponents.GUI_CONTINUE
               );
               break;
            case NEEDS_DOWNGRADE:
               confirmToPlay(
                  p4ed6fc5a_22_0,
                  p4ed6fc5a_23_1,
                  Component.translatable("selectWorld.backupQuestion.downgrade").withColor(-2142128),
                  Component.translatable(
                     "mco.compatibility.downgrade.description",
                     Component.literal(p4ed6fc5a_22_0.activeVersion).withColor(-171),
                     Component.literal(SharedConstants.getCurrentVersion().name()).withColor(-171)
                  ),
                  Component.translatable("mco.compatibility.downgrade")
               );
               break;
            case NEEDS_UPGRADE:
               upgradeRealmAndPlay(p4ed6fc5a_22_0, p4ed6fc5a_23_1);
               break;
            case INCOMPATIBLE:
               Minecraft.getInstance()
                  .setScreen(
                     new PopupScreen.Builder(p4ed6fc5a_23_1, INCOMPATIBLE_POPUP_TITLE)
                        .setMessage(
                           Component.translatable(
                              "mco.compatibility.incompatible.series.popup.message",
                              Component.literal(p4ed6fc5a_22_0.activeVersion).withColor(-171),
                              Component.literal(SharedConstants.getCurrentVersion().name()).withColor(-171)
                           )
                        )
                        .addButton(CommonComponents.GUI_BACK, PopupScreen::onClose)
                        .build()
                  );
               break;
            case RELEASE_TYPE_INCOMPATIBLE:
               Minecraft.getInstance()
                  .setScreen(
                     new PopupScreen.Builder(p4ed6fc5a_23_1, INCOMPATIBLE_POPUP_TITLE)
                        .setMessage(INCOMPATIBLE_RELEASE_TYPE_POPUP_MESSAGE)
                        .addButton(CommonComponents.GUI_BACK, PopupScreen::onClose)
                        .build()
                  );
         }
      }
   }

   private static void confirmToPlay(
      RealmsServer p4ed6fc5a_25_0, Screen p4ed6fc5a_26_1, Component p4ed6fc5a_27_2, Component p4ed6fc5a_28_3, Component p4ed6fc5a_29_4
   ) {
      Minecraft.getInstance()
         .setScreen(new PopupScreen.Builder(p4ed6fc5a_26_1, p4ed6fc5a_27_2).setMessage(p4ed6fc5a_28_3).addButton(p4ed6fc5a_29_4, p4ed6fc5a_45_2 -> {
            Minecraft.getInstance().setScreen(new RealmsLongRunningMcoTaskScreen(p4ed6fc5a_26_1, new GetServerDetailsTask(p4ed6fc5a_26_1, p4ed6fc5a_25_0)));
            refreshServerList();
         }).addButton(CommonComponents.GUI_CANCEL, PopupScreen::onClose).build());
   }

   private static void upgradeRealmAndPlay(RealmsServer p4ed6fc5a_30_0, Screen p4ed6fc5a_31_1) {
      Component $$2 = Component.translatable("mco.compatibility.upgrade.title").withColor(-171);
      Component $$3 = Component.translatable("mco.compatibility.upgrade");
      Component $$4 = Component.literal(p4ed6fc5a_30_0.activeVersion).withColor(-171);
      Component $$5 = Component.literal(SharedConstants.getCurrentVersion().name()).withColor(-171);
      Component $$6 = isSelfOwnedServer(p4ed6fc5a_30_0)
         ? Component.translatable("mco.compatibility.upgrade.description", $$4, $$5)
         : Component.translatable("mco.compatibility.upgrade.friend.description", $$4, $$5);
      confirmToPlay(p4ed6fc5a_30_0, p4ed6fc5a_31_1, $$2, $$6, $$3);
   }

   public static Component getVersionComponent(String p4ed6fc5a_32_0, boolean p4ed6fc5a_33_1) {
      return getVersionComponent(p4ed6fc5a_32_0, p4ed6fc5a_33_1 ? -8355712 : -2142128);
   }

   public static Component getVersionComponent(String p4ed6fc5a_34_0, int p4ed6fc5a_35_1) {
      return StringUtils.isBlank(p4ed6fc5a_34_0) ? CommonComponents.EMPTY : Component.literal(p4ed6fc5a_34_0).withColor(p4ed6fc5a_35_1);
   }

   public static Component getGameModeComponent(int p4ed6fc5a_36_0, boolean p4ed6fc5a_37_1) {
      return p4ed6fc5a_37_1 ? Component.translatable("gameMode.hardcore").withColor(-65536) : GameType.byId(p4ed6fc5a_36_0).getLongDisplayName();
   }

   static boolean isSelfOwnedServer(RealmsServer p4ed6fc5a_38_0) {
      return Minecraft.getInstance().isLocalPlayer(p4ed6fc5a_38_0.ownerUUID);
   }

   private boolean isSelfOwnedNonExpiredServer(RealmsServer p4ed6fc5a_39_0) {
      return isSelfOwnedServer(p4ed6fc5a_39_0) && !p4ed6fc5a_39_0.expired;
   }

   private void renderEnvironment(GuiGraphics p4ed6fc5a_40_0, String p4ed6fc5a_41_1, int p4ed6fc5a_42_2) {
      p4ed6fc5a_40_0.pose().pushMatrix();
      p4ed6fc5a_40_0.pose().translate(this.width / 2 - 25, 20.0F);
      p4ed6fc5a_40_0.pose().rotate((float) (-Math.PI / 9));
      p4ed6fc5a_40_0.pose().scale(1.5F, 1.5F);
      p4ed6fc5a_40_0.drawString(this.font, p4ed6fc5a_41_1, 0, 0, p4ed6fc5a_42_2);
      p4ed6fc5a_40_0.pose().popMatrix();
   }

   class AvailableSnapshotEntry extends RealmsMainScreen.Entry {
      private static final Component START_SNAPSHOT_REALM = Component.translatable("mco.snapshot.start");
      private static final int TEXT_PADDING = 5;
      private final WidgetTooltipHolder tooltip = new WidgetTooltipHolder();
      private final RealmsServer parent;

      public AvailableSnapshotEntry(final RealmsServer p58a5686f_1_1) {
         this.parent = p58a5686f_1_1;
         this.tooltip.set(Tooltip.create(Component.translatable("mco.snapshot.tooltip")));
      }

      @Override
      public void renderContent(GuiGraphics p58a5686f_2_0, int p58a5686f_3_1, int p58a5686f_4_2, boolean p58a5686f_5_3, float p58a5686f_6_4) {
         p58a5686f_2_0.blitSprite(
            RenderPipelines.GUI_TEXTURED, RealmsMainScreen.NEW_REALM_SPRITE, this.getContentX() - 5, this.getContentYMiddle() - 10, 40, 20
         );
         int $$5 = this.getContentYMiddle() - 9 / 2;
         p58a5686f_2_0.drawString(RealmsMainScreen.this.font, START_SNAPSHOT_REALM, this.getContentX() + 40 - 2, $$5 - 5, -8388737);
         p58a5686f_2_0.drawString(
            RealmsMainScreen.this.font,
            Component.translatable("mco.snapshot.description", Objects.requireNonNullElse(this.parent.name, "unknown server")),
            this.getContentX() + 40 - 2,
            $$5 + 5,
            -8355712
         );
         this.tooltip
            .refreshTooltipForNextRenderPass(
               p58a5686f_2_0,
               p58a5686f_3_1,
               p58a5686f_4_2,
               p58a5686f_5_3,
               this.isFocused(),
               new ScreenRectangle(this.getContentX(), this.getContentY(), this.getContentWidth(), this.getContentHeight())
            );
      }

      @Override
      public boolean mouseClicked(MouseButtonEvent p58a5686f_7_0, boolean p58a5686f_8_1) {
         this.addSnapshotRealm();
         return true;
      }

      @Override
      public boolean keyPressed(KeyEvent p58a5686f_9_0) {
         if (p58a5686f_9_0.isSelection()) {
            this.addSnapshotRealm();
            return false;
         } else {
            return super.keyPressed(p58a5686f_9_0);
         }
      }

      private void addSnapshotRealm() {
         RealmsMainScreen.this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         RealmsMainScreen.this.minecraft
            .setScreen(
               new PopupScreen.Builder(RealmsMainScreen.this, Component.translatable("mco.snapshot.createSnapshotPopup.title"))
                  .setMessage(Component.translatable("mco.snapshot.createSnapshotPopup.text"))
                  .addButton(
                     Component.translatable("mco.selectServer.create"),
                     p58a5686f_10_0 -> RealmsMainScreen.this.minecraft.setScreen(new RealmsCreateRealmScreen(RealmsMainScreen.this, this.parent, true))
                  )
                  .addButton(CommonComponents.GUI_CANCEL, PopupScreen::onClose)
                  .build()
            );
      }

      @Override
      public Component getNarration() {
         return Component.translatable(
            "gui.narrate.button",
            CommonComponents.joinForNarration(
               START_SNAPSHOT_REALM, Component.translatable("mco.snapshot.description", Objects.requireNonNullElse(this.parent.name, "unknown server"))
            )
         );
      }
   }

   static class CrossButton extends ImageButton {
      private static final WidgetSprites SPRITES = new WidgetSprites(
         Identifier.withDefaultNamespace("widget/cross_button"), Identifier.withDefaultNamespace("widget/cross_button_highlighted")
      );

      protected CrossButton(Button.OnPress p965eaa28_0_0, Component p965eaa28_1_1) {
         super(0, 0, 14, 14, SPRITES, p965eaa28_0_0);
         this.setTooltip(Tooltip.create(p965eaa28_1_1));
      }
   }

   abstract class Entry extends ObjectSelectionList.Entry<RealmsMainScreen.Entry> {
      protected static final int STATUS_LIGHT_WIDTH = 10;
      private static final int STATUS_LIGHT_HEIGHT = 28;
      protected static final int PADDING_X = 7;
      protected static final int PADDING_Y = 2;

      protected void renderStatusLights(
         RealmsServer pd3095f88_1_0, GuiGraphics pd3095f88_2_1, int pd3095f88_3_2, int pd3095f88_4_3, int pd3095f88_5_4, int pd3095f88_6_5
      ) {
         int $$6 = pd3095f88_3_2 - 10 - 7;
         int $$7 = pd3095f88_4_3 + 2;
         if (pd3095f88_1_0.expired) {
            this.drawRealmStatus(
               pd3095f88_2_1, $$6, $$7, pd3095f88_5_4, pd3095f88_6_5, RealmsMainScreen.EXPIRED_SPRITE, () -> RealmsMainScreen.SERVER_EXPIRED_TOOLTIP
            );
         } else if (pd3095f88_1_0.state == RealmsServer.State.CLOSED) {
            this.drawRealmStatus(
               pd3095f88_2_1, $$6, $$7, pd3095f88_5_4, pd3095f88_6_5, RealmsMainScreen.CLOSED_SPRITE, () -> RealmsMainScreen.SERVER_CLOSED_TOOLTIP
            );
         } else if (RealmsMainScreen.isSelfOwnedServer(pd3095f88_1_0) && pd3095f88_1_0.daysLeft < 7) {
            this.drawRealmStatus(
               pd3095f88_2_1,
               $$6,
               $$7,
               pd3095f88_5_4,
               pd3095f88_6_5,
               RealmsMainScreen.EXPIRES_SOON_SPRITE,
               () -> {
                  if (pd3095f88_1_0.daysLeft <= 0) {
                     return RealmsMainScreen.SERVER_EXPIRES_SOON_TOOLTIP;
                  } else {
                     return pd3095f88_1_0.daysLeft == 1
                        ? RealmsMainScreen.SERVER_EXPIRES_IN_DAY_TOOLTIP
                        : Component.translatable("mco.selectServer.expires.days", pd3095f88_1_0.daysLeft);
                  }
               }
            );
         } else if (pd3095f88_1_0.state == RealmsServer.State.OPEN) {
            this.drawRealmStatus(
               pd3095f88_2_1, $$6, $$7, pd3095f88_5_4, pd3095f88_6_5, RealmsMainScreen.OPEN_SPRITE, () -> RealmsMainScreen.SERVER_OPEN_TOOLTIP
            );
         }
      }

      private void drawRealmStatus(
         GuiGraphics pd3095f88_7_0,
         int pd3095f88_8_1,
         int pd3095f88_9_2,
         int pd3095f88_10_3,
         int pd3095f88_11_4,
         Identifier pd3095f88_12_5,
         Supplier<Component> pd3095f88_13_6
      ) {
         pd3095f88_7_0.blitSprite(RenderPipelines.GUI_TEXTURED, pd3095f88_12_5, pd3095f88_8_1, pd3095f88_9_2, 10, 28);
         if (RealmsMainScreen.this.realmSelectionList.isMouseOver(pd3095f88_10_3, pd3095f88_11_4)
            && pd3095f88_10_3 >= pd3095f88_8_1
            && pd3095f88_10_3 <= pd3095f88_8_1 + 10
            && pd3095f88_11_4 >= pd3095f88_9_2
            && pd3095f88_11_4 <= pd3095f88_9_2 + 28) {
            pd3095f88_7_0.setTooltipForNextFrame(pd3095f88_13_6.get(), pd3095f88_10_3, pd3095f88_11_4);
         }
      }

      protected void renderFirstLine(
         GuiGraphics pd3095f88_14_0, int pd3095f88_15_1, int pd3095f88_16_2, int pd3095f88_17_3, int pd3095f88_18_4, RealmsServer pd3095f88_19_5
      ) {
         int $$6 = this.textX(pd3095f88_16_2);
         int $$7 = this.firstLineY(pd3095f88_15_1);
         Component $$8 = RealmsMainScreen.getVersionComponent(pd3095f88_19_5.activeVersion, pd3095f88_19_5.isCompatible());
         int $$9 = this.versionTextX(pd3095f88_16_2, pd3095f88_17_3, $$8);
         this.renderClampedString(pd3095f88_14_0, pd3095f88_19_5.getName(), $$6, $$7, $$9, pd3095f88_18_4);
         if ($$8 != CommonComponents.EMPTY && !pd3095f88_19_5.isMinigameActive()) {
            pd3095f88_14_0.drawString(RealmsMainScreen.this.font, $$8, $$9, $$7, -8355712);
         }
      }

      protected void renderSecondLine(GuiGraphics pd3095f88_20_0, int pd3095f88_21_1, int pd3095f88_22_2, int pd3095f88_23_3, RealmsServer pd3095f88_24_4) {
         int $$5 = this.textX(pd3095f88_22_2);
         int $$6 = this.firstLineY(pd3095f88_21_1);
         int $$7 = this.secondLineY($$6);
         String $$8 = pd3095f88_24_4.getMinigameName();
         boolean $$9 = pd3095f88_24_4.isMinigameActive();
         if ($$9 && $$8 != null) {
            Component $$10 = Component.literal($$8).withStyle(ChatFormatting.GRAY);
            pd3095f88_20_0.drawString(RealmsMainScreen.this.font, Component.translatable("mco.selectServer.minigameName", $$10).withColor(-171), $$5, $$7, -1);
         } else {
            int $$11 = this.renderGameMode(pd3095f88_24_4, pd3095f88_20_0, pd3095f88_22_2, pd3095f88_23_3, $$6);
            this.renderClampedString(pd3095f88_20_0, pd3095f88_24_4.getDescription(), $$5, this.secondLineY($$6), $$11, -8355712);
         }
      }

      protected void renderThirdLine(GuiGraphics pd3095f88_25_0, int pd3095f88_26_1, int pd3095f88_27_2, RealmsServer pd3095f88_28_3) {
         int $$4 = this.textX(pd3095f88_27_2);
         int $$5 = this.firstLineY(pd3095f88_26_1);
         int $$6 = this.thirdLineY($$5);
         if (!RealmsMainScreen.isSelfOwnedServer(pd3095f88_28_3)) {
            pd3095f88_25_0.drawString(RealmsMainScreen.this.font, pd3095f88_28_3.owner, $$4, this.thirdLineY($$5), -8355712);
         } else if (pd3095f88_28_3.expired) {
            Component $$7 = pd3095f88_28_3.expiredTrial ? RealmsMainScreen.TRIAL_EXPIRED_TEXT : RealmsMainScreen.SUBSCRIPTION_EXPIRED_TEXT;
            pd3095f88_25_0.drawString(RealmsMainScreen.this.font, $$7, $$4, $$6, -2142128);
         }
      }

      protected void renderClampedString(
         GuiGraphics pd3095f88_29_0, @Nullable String pd3095f88_30_1, int pd3095f88_31_2, int pd3095f88_32_3, int pd3095f88_33_4, int pd3095f88_34_5
      ) {
         if (pd3095f88_30_1 != null) {
            int $$6 = pd3095f88_33_4 - pd3095f88_31_2;
            if (RealmsMainScreen.this.font.width(pd3095f88_30_1) > $$6) {
               String $$7 = RealmsMainScreen.this.font.plainSubstrByWidth(pd3095f88_30_1, $$6 - RealmsMainScreen.this.font.width("... "));
               pd3095f88_29_0.drawString(RealmsMainScreen.this.font, $$7 + "...", pd3095f88_31_2, pd3095f88_32_3, pd3095f88_34_5);
            } else {
               pd3095f88_29_0.drawString(RealmsMainScreen.this.font, pd3095f88_30_1, pd3095f88_31_2, pd3095f88_32_3, pd3095f88_34_5);
            }
         }
      }

      protected int versionTextX(int pd3095f88_35_0, int pd3095f88_36_1, Component pd3095f88_37_2) {
         return pd3095f88_35_0 + pd3095f88_36_1 - RealmsMainScreen.this.font.width(pd3095f88_37_2) - 20;
      }

      protected int gameModeTextX(int pd3095f88_38_0, int pd3095f88_39_1, Component pd3095f88_40_2) {
         return pd3095f88_38_0 + pd3095f88_39_1 - RealmsMainScreen.this.font.width(pd3095f88_40_2) - 20;
      }

      protected int renderGameMode(RealmsServer pd3095f88_41_0, GuiGraphics pd3095f88_42_1, int pd3095f88_43_2, int pd3095f88_44_3, int pd3095f88_45_4) {
         boolean $$5 = pd3095f88_41_0.isHardcore;
         int $$6 = pd3095f88_41_0.gameMode;
         int $$7 = pd3095f88_43_2;
         if (GameType.isValidId($$6)) {
            Component $$8 = RealmsMainScreen.getGameModeComponent($$6, $$5);
            $$7 = this.gameModeTextX(pd3095f88_43_2, pd3095f88_44_3, $$8);
            pd3095f88_42_1.drawString(RealmsMainScreen.this.font, $$8, $$7, this.secondLineY(pd3095f88_45_4), -8355712);
         }

         if ($$5) {
            $$7 -= 10;
            pd3095f88_42_1.blitSprite(RenderPipelines.GUI_TEXTURED, RealmsMainScreen.HARDCORE_MODE_SPRITE, $$7, this.secondLineY(pd3095f88_45_4), 8, 8);
         }

         return $$7;
      }

      protected int firstLineY(int pd3095f88_46_0) {
         return pd3095f88_46_0 + 1;
      }

      protected int lineHeight() {
         return 2 + 9;
      }

      protected int textX(int pd3095f88_47_0) {
         return pd3095f88_47_0 + 36 + 2;
      }

      protected int secondLineY(int pd3095f88_48_0) {
         return pd3095f88_48_0 + this.lineHeight();
      }

      protected int thirdLineY(int pd3095f88_49_0) {
         return pd3095f88_49_0 + this.lineHeight() * 2;
      }
   }

   enum LayoutState {
      LOADING,
      NO_REALMS,
      LIST;
   }

   static class NotificationButton extends SpriteIconButton.CenteredIcon {
      private static final Identifier[] NOTIFICATION_ICONS = new Identifier[]{
         Identifier.withDefaultNamespace("notification/1"),
         Identifier.withDefaultNamespace("notification/2"),
         Identifier.withDefaultNamespace("notification/3"),
         Identifier.withDefaultNamespace("notification/4"),
         Identifier.withDefaultNamespace("notification/5"),
         Identifier.withDefaultNamespace("notification/more")
      };
      private static final int UNKNOWN_COUNT = Integer.MAX_VALUE;
      private static final int SIZE = 20;
      private static final int SPRITE_SIZE = 14;
      private int notificationCount;

      public NotificationButton(Component pb3225ca7_0_0, Identifier pb3225ca7_1_1, Button.OnPress pb3225ca7_2_2, @Nullable Component pb3225ca7_3_3) {
         super(20, 20, pb3225ca7_0_0, 14, 14, new WidgetSprites(pb3225ca7_1_1), pb3225ca7_2_2, pb3225ca7_3_3, null);
      }

      int notificationCount() {
         return this.notificationCount;
      }

      public void setNotificationCount(int pb3225ca7_4_0) {
         this.notificationCount = pb3225ca7_4_0;
      }

      @Override
      public void renderContents(GuiGraphics pb3225ca7_5_0, int pb3225ca7_6_1, int pb3225ca7_7_2, float pb3225ca7_8_3) {
         super.renderContents(pb3225ca7_5_0, pb3225ca7_6_1, pb3225ca7_7_2, pb3225ca7_8_3);
         if (this.active && this.notificationCount != 0) {
            this.drawNotificationCounter(pb3225ca7_5_0);
         }
      }

      private void drawNotificationCounter(GuiGraphics pb3225ca7_9_0) {
         pb3225ca7_9_0.blitSprite(
            RenderPipelines.GUI_TEXTURED, NOTIFICATION_ICONS[Math.min(this.notificationCount, 6) - 1], this.getX() + this.getWidth() - 5, this.getY() - 3, 8, 8
         );
      }
   }

   class NotificationMessageEntry extends RealmsMainScreen.Entry {
      private static final int SIDE_MARGINS = 40;
      public static final int PADDING = 7;
      public static final int HEIGHT_WITHOUT_TEXT = 38;
      private final Component text;
      private final List<AbstractWidget> children = new ArrayList<>();
      private final RealmsMainScreen.@Nullable CrossButton dismissButton;
      private final MultiLineTextWidget textWidget;
      private final GridLayout gridLayout;
      private final FrameLayout textFrame;
      private final Button button;
      private int lastEntryWidth = -1;

      public NotificationMessageEntry(
         final RealmsMainScreen p9ea48e60_1_1, final int p9ea48e60_2_2, final Component p9ea48e60_3_3, final RealmsNotification.VisitUrl p9ea48e60_4_4
      ) {
         this.text = p9ea48e60_3_3;
         this.gridLayout = new GridLayout();
         this.gridLayout.addChild(ImageWidget.sprite(20, 20, RealmsMainScreen.INFO_SPRITE), 0, 0, this.gridLayout.newCellSettings().padding(7, 7, 0, 0));
         this.gridLayout.addChild(SpacerElement.width(40), 0, 0);
         this.textFrame = this.gridLayout.addChild(new FrameLayout(0, p9ea48e60_2_2), 0, 1, this.gridLayout.newCellSettings().paddingTop(7));
         this.textWidget = this.textFrame
            .addChild(
               new MultiLineTextWidget(p9ea48e60_3_3, RealmsMainScreen.this.font).setCentered(true),
               this.textFrame.newChildLayoutSettings().alignHorizontallyCenter().alignVerticallyTop()
            );
         this.gridLayout.addChild(SpacerElement.width(40), 0, 2);
         if (p9ea48e60_4_4.dismissable()) {
            this.dismissButton = this.gridLayout
               .addChild(
                  new RealmsMainScreen.CrossButton(
                     p9ea48e60_22_1 -> RealmsMainScreen.this.dismissNotification(p9ea48e60_4_4.uuid()), Component.translatable("mco.notification.dismiss")
                  ),
                  0,
                  2,
                  this.gridLayout.newCellSettings().alignHorizontallyRight().padding(0, 7, 7, 0)
               );
         } else {
            this.dismissButton = null;
         }

         this.button = this.gridLayout
            .addChild(p9ea48e60_4_4.buildOpenLinkButton(p9ea48e60_1_1), 1, 1, this.gridLayout.newCellSettings().alignHorizontallyCenter().padding(4));
         this.button.setOverrideRenderHighlightedSprite(() -> this.isFocused());
         this.gridLayout.visitWidgets(this.children::add);
      }

      @Override
      public boolean keyPressed(KeyEvent p9ea48e60_5_0) {
         if (this.button.keyPressed(p9ea48e60_5_0)) {
            return true;
         } else {
            return this.dismissButton != null && this.dismissButton.keyPressed(p9ea48e60_5_0) ? true : super.keyPressed(p9ea48e60_5_0);
         }
      }

      private void updateEntryWidth() {
         int $$0 = this.getWidth();
         if (this.lastEntryWidth != $$0) {
            this.refreshLayout($$0);
            this.lastEntryWidth = $$0;
         }
      }

      private void refreshLayout(int p9ea48e60_6_0) {
         int $$1 = textWidth(p9ea48e60_6_0);
         this.textFrame.setMinWidth($$1);
         this.textWidget.setMaxWidth($$1);
         this.gridLayout.arrangeElements();
      }

      public static int textWidth(int p9ea48e60_7_0) {
         return p9ea48e60_7_0 - 80;
      }

      @Override
      public void renderContent(GuiGraphics p9ea48e60_8_0, int p9ea48e60_9_1, int p9ea48e60_10_2, boolean p9ea48e60_11_3, float p9ea48e60_12_4) {
         this.gridLayout.setPosition(this.getContentX(), this.getContentY());
         this.updateEntryWidth();
         this.children.forEach(p9ea48e60_19_4 -> p9ea48e60_19_4.render(p9ea48e60_8_0, p9ea48e60_9_1, p9ea48e60_10_2, p9ea48e60_12_4));
      }

      @Override
      public boolean mouseClicked(MouseButtonEvent p9ea48e60_13_0, boolean p9ea48e60_14_1) {
         if (this.dismissButton != null && this.dismissButton.mouseClicked(p9ea48e60_13_0, p9ea48e60_14_1)) {
            return true;
         } else {
            return this.button.mouseClicked(p9ea48e60_13_0, p9ea48e60_14_1) ? true : super.mouseClicked(p9ea48e60_13_0, p9ea48e60_14_1);
         }
      }

      public Component getText() {
         return this.text;
      }

      @Override
      public Component getNarration() {
         return this.getText();
      }
   }

   class ParentEntry extends RealmsMainScreen.Entry {
      private final RealmsServer server;
      private final WidgetTooltipHolder tooltip = new WidgetTooltipHolder();

      public ParentEntry(final RealmsServer p45c4187e_1_1) {
         this.server = p45c4187e_1_1;
         if (!p45c4187e_1_1.expired) {
            this.tooltip.set(Tooltip.create(Component.translatable("mco.snapshot.parent.tooltip")));
         }
      }

      @Override
      public void renderContent(GuiGraphics p45c4187e_2_0, int p45c4187e_3_1, int p45c4187e_4_2, boolean p45c4187e_5_3, float p45c4187e_6_4) {
         this.renderStatusLights(this.server, p45c4187e_2_0, this.getContentRight(), this.getContentY(), p45c4187e_3_1, p45c4187e_4_2);
         RealmsUtil.renderPlayerFace(p45c4187e_2_0, this.getContentX(), this.getContentY(), 32, this.server.ownerUUID);
         this.renderFirstLine(p45c4187e_2_0, this.getContentY(), this.getContentX(), this.getContentWidth(), -8355712, this.server);
         this.renderSecondLine(p45c4187e_2_0, this.getContentY(), this.getContentX(), this.getContentWidth(), this.server);
         this.renderThirdLine(p45c4187e_2_0, this.getContentY(), this.getContentX(), this.server);
         this.tooltip
            .refreshTooltipForNextRenderPass(
               p45c4187e_2_0,
               p45c4187e_3_1,
               p45c4187e_4_2,
               p45c4187e_5_3,
               this.isFocused(),
               new ScreenRectangle(this.getContentX(), this.getContentY(), this.getContentWidth(), this.getContentHeight())
            );
      }

      @Override
      public Component getNarration() {
         return Component.literal(Objects.requireNonNullElse(this.server.name, "unknown server"));
      }
   }

   class RealmSelectionList extends ObjectSelectionList<RealmsMainScreen.Entry> {
      public RealmSelectionList() {
         super(Minecraft.getInstance(), RealmsMainScreen.this.width, RealmsMainScreen.this.height, 0, 36);
      }

      public void setSelected(RealmsMainScreen.@Nullable Entry p92de82a5_1_0) {
         super.setSelected(p92de82a5_1_0);
         RealmsMainScreen.this.updateButtonStates();
      }

      @Override
      public int getRowWidth() {
         return 300;
      }

      void refreshEntries(RealmsMainScreen p92de82a5_2_0) {
         RealmsMainScreen.Entry $$1 = this.getSelected();
         this.clearEntries();

         for (RealmsNotification $$2 : RealmsMainScreen.this.notifications) {
            if ($$2 instanceof RealmsNotification.VisitUrl $$3) {
               this.addEntriesForNotification($$3, p92de82a5_2_0, $$1);
               RealmsMainScreen.this.markNotificationsAsSeen(List.of($$2));
               break;
            }
         }

         this.refreshServerEntries($$1);
      }

      private void addEntriesForNotification(
         RealmsNotification.VisitUrl p92de82a5_3_0, RealmsMainScreen p92de82a5_4_1, RealmsMainScreen.@Nullable Entry p92de82a5_5_2
      ) {
         Component $$3 = p92de82a5_3_0.getMessage();
         int $$4 = RealmsMainScreen.this.font.wordWrapHeight($$3, RealmsMainScreen.NotificationMessageEntry.textWidth(this.getRowWidth()));
         RealmsMainScreen.NotificationMessageEntry $$5 = RealmsMainScreen.this.new NotificationMessageEntry(p92de82a5_4_1, $$4, $$3, p92de82a5_3_0);
         this.addEntry($$5, 38 + $$4);
         if (p92de82a5_5_2 instanceof RealmsMainScreen.NotificationMessageEntry $$6 && $$6.getText().equals($$3)) {
            this.setSelected($$5);
         }
      }

      private void refreshServerEntries(RealmsMainScreen.@Nullable Entry p92de82a5_6_0) {
         for (RealmsServer $$1 : RealmsMainScreen.this.availableSnapshotServers) {
            this.addEntry(RealmsMainScreen.this.new AvailableSnapshotEntry($$1));
         }

         for (RealmsServer $$2 : RealmsMainScreen.this.serverList) {
            RealmsMainScreen.Entry $$3;
            if (RealmsMainScreen.isSnapshot() && !$$2.isSnapshotRealm()) {
               if ($$2.state == RealmsServer.State.UNINITIALIZED) {
                  continue;
               }

               $$3 = RealmsMainScreen.this.new ParentEntry($$2);
            } else {
               $$3 = RealmsMainScreen.this.new ServerEntry($$2);
            }

            this.addEntry($$3);
            if (p92de82a5_6_0 instanceof RealmsMainScreen.ServerEntry $$5 && $$5.serverData.id == $$2.id) {
               this.setSelected($$3);
            }
         }
      }
   }

   interface RealmsCall<T> {
      T request(RealmsClient var1) throws RealmsServiceException;
   }

   class ServerEntry extends RealmsMainScreen.Entry {
      private static final Component ONLINE_PLAYERS_TOOLTIP_HEADER = Component.translatable("mco.onlinePlayers");
      private static final int PLAYERS_ONLINE_SPRITE_SIZE = 9;
      private static final int PLAYERS_ONLINE_SPRITE_SEPARATION = 3;
      private static final int SKIN_HEAD_LARGE_WIDTH = 36;
      final RealmsServer serverData;
      private final WidgetTooltipHolder tooltip = new WidgetTooltipHolder();

      public ServerEntry(final RealmsServer pdc0a2985_1_1) {
         this.serverData = pdc0a2985_1_1;
         boolean $$1 = RealmsMainScreen.isSelfOwnedServer(pdc0a2985_1_1);
         if (RealmsMainScreen.isSnapshot() && $$1 && pdc0a2985_1_1.isSnapshotRealm()) {
            this.tooltip.set(Tooltip.create(Component.translatable("mco.snapshot.paired", pdc0a2985_1_1.parentWorldName)));
         } else if (!$$1 && pdc0a2985_1_1.needsDowngrade()) {
            this.tooltip.set(Tooltip.create(Component.translatable("mco.snapshot.friendsRealm.downgrade", pdc0a2985_1_1.activeVersion)));
         }
      }

      @Override
      public void renderContent(GuiGraphics pdc0a2985_2_0, int pdc0a2985_3_1, int pdc0a2985_4_2, boolean pdc0a2985_5_3, float pdc0a2985_6_4) {
         if (this.serverData.state == RealmsServer.State.UNINITIALIZED) {
            pdc0a2985_2_0.blitSprite(
               RenderPipelines.GUI_TEXTURED, RealmsMainScreen.NEW_REALM_SPRITE, this.getContentX() - 5, this.getContentYMiddle() - 10, 40, 20
            );
            int $$5 = this.getContentYMiddle() - 9 / 2;
            pdc0a2985_2_0.drawString(RealmsMainScreen.this.font, RealmsMainScreen.SERVER_UNITIALIZED_TEXT, this.getContentX() + 40 - 2, $$5, -8388737);
         } else {
            RealmsUtil.renderPlayerFace(pdc0a2985_2_0, this.getContentX(), this.getContentY(), 32, this.serverData.ownerUUID);
            this.renderFirstLine(pdc0a2985_2_0, this.getContentY(), this.getContentX(), this.getContentWidth(), -1, this.serverData);
            this.renderSecondLine(pdc0a2985_2_0, this.getContentY(), this.getContentX(), this.getContentWidth(), this.serverData);
            this.renderThirdLine(pdc0a2985_2_0, this.getContentY(), this.getContentX(), this.serverData);
            this.renderStatusLights(this.serverData, pdc0a2985_2_0, this.getContentRight(), this.getContentY(), pdc0a2985_3_1, pdc0a2985_4_2);
            boolean $$6 = this.renderOnlinePlayers(
               pdc0a2985_2_0,
               this.getContentY(),
               this.getContentX(),
               this.getContentWidth(),
               this.getContentHeight(),
               pdc0a2985_3_1,
               pdc0a2985_4_2,
               pdc0a2985_6_4
            );
            if (!$$6) {
               this.tooltip
                  .refreshTooltipForNextRenderPass(
                     pdc0a2985_2_0,
                     pdc0a2985_3_1,
                     pdc0a2985_4_2,
                     pdc0a2985_5_3,
                     this.isFocused(),
                     new ScreenRectangle(this.getContentX(), this.getContentY(), this.getContentWidth(), this.getContentHeight())
                  );
            }
         }
      }

      private boolean renderOnlinePlayers(
         GuiGraphics pdc0a2985_7_0,
         int pdc0a2985_8_1,
         int pdc0a2985_9_2,
         int pdc0a2985_10_3,
         int pdc0a2985_11_4,
         int pdc0a2985_12_5,
         int pdc0a2985_13_6,
         float pdc0a2985_14_7
      ) {
         List<ResolvableProfile> $$8 = RealmsMainScreen.this.onlinePlayersPerRealm.getProfileResultsFor(this.serverData.id);
         int $$9 = $$8.size();
         if ($$9 > 0) {
            int $$10 = pdc0a2985_9_2 + pdc0a2985_10_3 - 21;
            int $$11 = pdc0a2985_8_1 + pdc0a2985_11_4 - 9 - 2;
            int $$12 = 9 * $$9 + 3 * ($$9 - 1);
            int $$13 = $$10 - $$12;
            List<PlayerSkinRenderCache.RenderInfo> $$14;
            if (pdc0a2985_12_5 >= $$13 && pdc0a2985_12_5 <= $$10 && pdc0a2985_13_6 >= $$11 && pdc0a2985_13_6 <= $$11 + 9) {
               $$14 = new ArrayList<>($$9);
            } else {
               $$14 = null;
            }

            PlayerSkinRenderCache $$16 = RealmsMainScreen.this.minecraft.playerSkinRenderCache();

            for (int $$17 = 0; $$17 < $$8.size(); $$17++) {
               ResolvableProfile $$18 = $$8.get($$17);
               PlayerSkinRenderCache.RenderInfo $$19 = $$16.getOrDefault($$18);
               int $$20 = $$13 + 12 * $$17;
               PlayerFaceRenderer.draw(pdc0a2985_7_0, $$19.playerSkin(), $$20, $$11, 9);
               if ($$14 != null) {
                  $$14.add($$19);
               }
            }

            if ($$14 != null) {
               pdc0a2985_7_0.setTooltipForNextFrame(
                  RealmsMainScreen.this.font,
                  List.of(ONLINE_PLAYERS_TOOLTIP_HEADER),
                  Optional.of(new ClientActivePlayersTooltip.ActivePlayersTooltip($$14)),
                  pdc0a2985_12_5,
                  pdc0a2985_13_6
               );
               return true;
            }
         }

         return false;
      }

      private void playRealm() {
         RealmsMainScreen.this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         RealmsMainScreen.play(this.serverData, RealmsMainScreen.this);
      }

      private void createUnitializedRealm() {
         RealmsMainScreen.this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         RealmsCreateRealmScreen $$0 = new RealmsCreateRealmScreen(RealmsMainScreen.this, this.serverData, this.serverData.isSnapshotRealm());
         RealmsMainScreen.this.minecraft.setScreen($$0);
      }

      @Override
      public boolean mouseClicked(MouseButtonEvent pdc0a2985_15_0, boolean pdc0a2985_16_1) {
         if (this.serverData.state == RealmsServer.State.UNINITIALIZED) {
            this.createUnitializedRealm();
         } else if (this.serverData.shouldPlayButtonBeActive() && pdc0a2985_16_1 && this.isFocused()) {
            this.playRealm();
         }

         return true;
      }

      @Override
      public boolean keyPressed(KeyEvent pdc0a2985_17_0) {
         if (pdc0a2985_17_0.isSelection()) {
            if (this.serverData.state == RealmsServer.State.UNINITIALIZED) {
               this.createUnitializedRealm();
               return true;
            }

            if (this.serverData.shouldPlayButtonBeActive()) {
               this.playRealm();
               return true;
            }
         }

         return super.keyPressed(pdc0a2985_17_0);
      }

      @Override
      public Component getNarration() {
         return this.serverData.state == RealmsServer.State.UNINITIALIZED
            ? RealmsMainScreen.UNITIALIZED_WORLD_NARRATION
            : Component.translatable("narrator.select", Objects.requireNonNullElse(this.serverData.name, "unknown server"));
      }

      public RealmsServer getServer() {
         return this.serverData;
      }
   }
}
