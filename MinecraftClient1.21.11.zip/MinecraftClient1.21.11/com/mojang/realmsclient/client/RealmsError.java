package com.mojang.realmsclient.client;

import com.google.common.base.Strings;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.exception.RealmsHttpException;
import java.util.Locale;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.LenientJsonParser;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public interface RealmsError {
   Component NO_MESSAGE = Component.translatable("mco.errorMessage.noDetails");
   Logger LOGGER = LogUtils.getLogger();

   int errorCode();

   Component errorMessage();

   String logMessage();

   static RealmsError parse(int pdc6a99d1_0_0, String pdc6a99d1_1_1) {
      if (pdc6a99d1_0_0 == 429) {
         return RealmsError.CustomError.SERVICE_BUSY;
      }

      if (Strings.isNullOrEmpty(pdc6a99d1_1_1)) {
         return RealmsError.CustomError.noPayload(pdc6a99d1_0_0);
      }

      try {
         JsonObject $$2 = LenientJsonParser.parse(pdc6a99d1_1_1).getAsJsonObject();
         String $$3 = GsonHelper.getAsString($$2, "reason", null);
         String $$4 = GsonHelper.getAsString($$2, "errorMsg", null);
         int $$5 = GsonHelper.getAsInt($$2, "errorCode", -1);
         if ($$4 != null || $$3 != null || $$5 != -1) {
            return new RealmsError.ErrorWithJsonPayload(pdc6a99d1_0_0, $$5 != -1 ? $$5 : pdc6a99d1_0_0, $$3, $$4);
         }
      } catch (Exception $$6) {
         LOGGER.error("Could not parse RealmsError", $$6);
      }

      return new RealmsError.ErrorWithRawPayload(pdc6a99d1_0_0, pdc6a99d1_1_1);
   }

   record AuthenticationError(String message) implements RealmsError {
      public static final int ERROR_CODE = 401;

      @Override
      public int errorCode() {
         return 401;
      }

      @Override
      public Component errorMessage() {
         return Component.literal(this.message);
      }

      @Override
      public String logMessage() {
         return String.format(Locale.ROOT, "Realms authentication error with message '%s'", this.message);
      }
   }

   record CustomError(int httpCode, @Nullable Component payload) implements RealmsError {
      public static final RealmsError.CustomError SERVICE_BUSY = new RealmsError.CustomError(429, Component.translatable("mco.errorMessage.serviceBusy"));
      public static final Component RETRY_MESSAGE = Component.translatable("mco.errorMessage.retry");
      public static final String BODY_TAG = "<body>";
      public static final String CLOSING_BODY_TAG = "</body>";

      public static RealmsError.CustomError unknownCompatibilityResponse(String pa24826a4_2_0) {
         return new RealmsError.CustomError(500, Component.translatable("mco.errorMessage.realmsService.unknownCompatibility", pa24826a4_2_0));
      }

      public static RealmsError.CustomError configurationError() {
         return new RealmsError.CustomError(500, Component.translatable("mco.errorMessage.realmsService.configurationError"));
      }

      public static RealmsError.CustomError connectivityError(RealmsHttpException pa24826a4_3_0) {
         return new RealmsError.CustomError(500, Component.translatable("mco.errorMessage.realmsService.connectivity", pa24826a4_3_0.getMessage()));
      }

      public static RealmsError.CustomError retry(int pa24826a4_4_0) {
         return new RealmsError.CustomError(pa24826a4_4_0, RETRY_MESSAGE);
      }

      public static RealmsError.CustomError noPayload(int pa24826a4_5_0) {
         return new RealmsError.CustomError(pa24826a4_5_0, null);
      }

      public static RealmsError.CustomError htmlPayload(int pa24826a4_6_0, String pa24826a4_7_1) {
         int $$2 = pa24826a4_7_1.indexOf("<body>");
         int $$3 = pa24826a4_7_1.indexOf("</body>");
         if ($$2 >= 0 && $$3 > $$2) {
            return new RealmsError.CustomError(pa24826a4_6_0, Component.literal(pa24826a4_7_1.substring($$2 + "<body>".length(), $$3).trim()));
         }

         LOGGER.error("Got an error with an unreadable html body {}", pa24826a4_7_1);
         return new RealmsError.CustomError(pa24826a4_6_0, null);
      }

      @Override
      public int errorCode() {
         return this.httpCode;
      }

      @Override
      public Component errorMessage() {
         return this.payload != null ? this.payload : NO_MESSAGE;
      }

      @Override
      public String logMessage() {
         return this.payload != null
            ? String.format(Locale.ROOT, "Realms service error (%d) with message '%s'", this.httpCode, this.payload.getString())
            : String.format(Locale.ROOT, "Realms service error (%d) with no payload", this.httpCode);
      }
   }

   record ErrorWithJsonPayload(int httpCode, int code, @Nullable String reason, @Nullable String message) implements RealmsError {
      @Override
      public int errorCode() {
         return this.code;
      }

      @Override
      public Component errorMessage() {
         String $$0 = "mco.errorMessage." + this.code;
         if (I18n.exists($$0)) {
            return Component.translatable($$0);
         }

         if (this.reason != null) {
            String $$1 = "mco.errorReason." + this.reason;
            if (I18n.exists($$1)) {
               return Component.translatable($$1);
            }
         }

         return this.message != null ? Component.literal(this.message) : NO_MESSAGE;
      }

      @Override
      public String logMessage() {
         return String.format(Locale.ROOT, "Realms service error (%d/%d/%s) with message '%s'", this.httpCode, this.code, this.reason, this.message);
      }
   }

   record ErrorWithRawPayload(int httpCode, String payload) implements RealmsError {
      @Override
      public int errorCode() {
         return this.httpCode;
      }

      @Override
      public Component errorMessage() {
         return Component.literal(this.payload);
      }

      @Override
      public String logMessage() {
         return String.format(Locale.ROOT, "Realms service error (%d) with raw payload '%s'", this.httpCode, this.payload);
      }
   }
}
