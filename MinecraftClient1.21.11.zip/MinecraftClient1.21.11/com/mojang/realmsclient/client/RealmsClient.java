package com.mojang.realmsclient.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.dto.BackupList;
import com.mojang.realmsclient.dto.GuardedSerializer;
import com.mojang.realmsclient.dto.Ops;
import com.mojang.realmsclient.dto.OutboundPlayer;
import com.mojang.realmsclient.dto.PendingInvite;
import com.mojang.realmsclient.dto.PendingInvitesList;
import com.mojang.realmsclient.dto.PingResult;
import com.mojang.realmsclient.dto.PlayerInfo;
import com.mojang.realmsclient.dto.PreferredRegionsDto;
import com.mojang.realmsclient.dto.RealmsConfigurationDto;
import com.mojang.realmsclient.dto.RealmsDescriptionDto;
import com.mojang.realmsclient.dto.RealmsJoinInformation;
import com.mojang.realmsclient.dto.RealmsNews;
import com.mojang.realmsclient.dto.RealmsNotification;
import com.mojang.realmsclient.dto.RealmsRegion;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.RealmsServerList;
import com.mojang.realmsclient.dto.RealmsServerPlayerLists;
import com.mojang.realmsclient.dto.RealmsSetting;
import com.mojang.realmsclient.dto.RealmsSlotUpdateDto;
import com.mojang.realmsclient.dto.RealmsWorldOptions;
import com.mojang.realmsclient.dto.RealmsWorldResetDto;
import com.mojang.realmsclient.dto.RegionDataDto;
import com.mojang.realmsclient.dto.RegionSelectionPreference;
import com.mojang.realmsclient.dto.RegionSelectionPreferenceDto;
import com.mojang.realmsclient.dto.Subscription;
import com.mojang.realmsclient.dto.UploadInfo;
import com.mojang.realmsclient.dto.WorldDownload;
import com.mojang.realmsclient.dto.WorldTemplatePaginatedList;
import com.mojang.realmsclient.exception.RealmsHttpException;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.exception.RetryCallException;
import com.mojang.realmsclient.util.UploadTokenCache;
import com.mojang.util.UndashedUuid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.util.LenientJsonParser;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsClient {
   public static final RealmsClient.Environment ENVIRONMENT = Optional.ofNullable(System.getenv("realms.environment"))
      .or(() -> Optional.ofNullable(System.getProperty("realms.environment")))
      .flatMap(RealmsClient.Environment::byName)
      .orElse(RealmsClient.Environment.PRODUCTION);
   private static final Logger LOGGER = LogUtils.getLogger();
   private static volatile @Nullable RealmsClient realmsClientInstance = null;
   private final CompletableFuture<Set<String>> featureFlags;
   private final String sessionId;
   private final String username;
   private final Minecraft minecraft;
   private static final String WORLDS_RESOURCE_PATH = "worlds";
   private static final String INVITES_RESOURCE_PATH = "invites";
   private static final String MCO_RESOURCE_PATH = "mco";
   private static final String SUBSCRIPTION_RESOURCE = "subscriptions";
   private static final String ACTIVITIES_RESOURCE = "activities";
   private static final String OPS_RESOURCE = "ops";
   private static final String REGIONS_RESOURCE = "regions/ping/stat";
   private static final String PREFERRED_REGION_RESOURCE = "regions/preferredRegions";
   private static final String TRIALS_RESOURCE = "trial";
   private static final String NOTIFICATIONS_RESOURCE = "notifications";
   private static final String FEATURE_FLAGS_RESOURCE = "feature/v1";
   private static final String PATH_LIST_ALL_REALMS = "/listUserWorldsOfType/any";
   private static final String PATH_CREATE_SNAPSHOT_REALM = "/$PARENT_WORLD_ID/createPrereleaseRealm";
   private static final String PATH_SNAPSHOT_ELIGIBLE_REALMS = "/listPrereleaseEligibleWorlds";
   private static final String PATH_INITIALIZE = "/$WORLD_ID/initialize";
   private static final String PATH_GET_LIVESTATS = "/liveplayerlist";
   private static final String PATH_GET_SUBSCRIPTION = "/$WORLD_ID";
   private static final String PATH_OP = "/$WORLD_ID/$PROFILE_UUID";
   private static final String PATH_PUT_INTO_MINIGAMES_MODE = "/minigames/$MINIGAME_ID/$WORLD_ID";
   private static final String PATH_AVAILABLE = "/available";
   private static final String PATH_TEMPLATES = "/templates/$WORLD_TYPE";
   private static final String PATH_WORLD_JOIN = "/v1/$ID/join/pc";
   private static final String PATH_WORLD_GET = "/$ID";
   private static final String PATH_WORLD_INVITES = "/$WORLD_ID";
   private static final String PATH_WORLD_UNINVITE = "/$WORLD_ID/invite/$UUID";
   private static final String PATH_PENDING_INVITES = "/pending";
   private static final String PATH_ACCEPT_INVITE = "/accept/$INVITATION_ID";
   private static final String PATH_REJECT_INVITE = "/reject/$INVITATION_ID";
   private static final String PATH_UNINVITE_MYSELF = "/$WORLD_ID";
   private static final String PATH_WORLD_CONFIGURE = "/$WORLD_ID/configuration";
   private static final String PATH_SLOT = "/$WORLD_ID/slot/$SLOT_ID";
   private static final String PATH_WORLD_OPEN = "/$WORLD_ID/open";
   private static final String PATH_WORLD_CLOSE = "/$WORLD_ID/close";
   private static final String PATH_WORLD_RESET = "/$WORLD_ID/reset";
   private static final String PATH_DELETE_WORLD = "/$WORLD_ID";
   private static final String PATH_WORLD_BACKUPS = "/$WORLD_ID/backups";
   private static final String PATH_WORLD_DOWNLOAD = "/$WORLD_ID/slot/$SLOT_ID/download";
   private static final String PATH_WORLD_UPLOAD = "/$WORLD_ID/backups/upload";
   private static final String PATH_CLIENT_COMPATIBLE = "/client/compatible";
   private static final String PATH_TOS_AGREED = "/tos/agreed";
   private static final String PATH_NEWS = "/v1/news";
   private static final String PATH_MARK_NOTIFICATIONS_SEEN = "/seen";
   private static final String PATH_DISMISS_NOTIFICATIONS = "/dismiss";
   private static final GuardedSerializer GSON = new GuardedSerializer();

   public static RealmsClient getOrCreate() {
      Minecraft $$0 = Minecraft.getInstance();
      return getOrCreate($$0);
   }

   public static RealmsClient getOrCreate(Minecraft pad262522_0_0) {
      String $$1 = pad262522_0_0.getUser().getName();
      String $$2 = pad262522_0_0.getUser().getSessionId();
      RealmsClient $$3 = realmsClientInstance;
      if ($$3 != null) {
         return $$3;
      }

      synchronized (RealmsClient.class) {
         RealmsClient $$4 = realmsClientInstance;
         if ($$4 != null) {
            return $$4;
         }

         $$4 = new RealmsClient($$2, $$1, pad262522_0_0);
         realmsClientInstance = $$4;
         return $$4;
      }
   }

   private RealmsClient(String pad262522_1_0, String pad262522_2_1, Minecraft pad262522_3_2) {
      this.sessionId = pad262522_1_0;
      this.username = pad262522_2_1;
      this.minecraft = pad262522_3_2;
      RealmsClientConfig.setProxy(pad262522_3_2.getProxy());
      this.featureFlags = CompletableFuture.supplyAsync(this::fetchFeatureFlags, Util.nonCriticalIoPool());
   }

   public Set<String> getFeatureFlags() {
      return this.featureFlags.join();
   }

   private Set<String> fetchFeatureFlags() {
      if (Minecraft.getInstance().isOfflineDeveloperMode()) {
         return Set.of();
      }

      String $$0 = url("feature/v1", null, false);

      try {
         String $$1 = this.execute(Request.get($$0, 5000, 10000));
         JsonArray $$2 = LenientJsonParser.parse($$1).getAsJsonArray();
         Set<String> $$3 = $$2.asList().stream().map(JsonElement::getAsString).collect(Collectors.toSet());
         LOGGER.debug("Fetched Realms feature flags: {}", $$3);
         return $$3;
      } catch (RealmsServiceException $$4) {
         LOGGER.error("Failed to fetch Realms feature flags", $$4);
      } catch (Exception $$5) {
         LOGGER.error("Could not parse Realms feature flags", $$5);
      }

      return Set.of();
   }

   public RealmsServerList listRealms() throws RealmsServiceException {
      String $$0 = this.url("worlds");
      if (RealmsMainScreen.isSnapshot()) {
         $$0 = $$0 + "/listUserWorldsOfType/any";
      }

      String $$1 = this.execute(Request.get($$0));
      return RealmsServerList.parse(GSON, $$1);
   }

   public List<RealmsServer> listSnapshotEligibleRealms() throws RealmsServiceException {
      String $$0 = this.url("worlds/listPrereleaseEligibleWorlds");
      String $$1 = this.execute(Request.get($$0));
      return RealmsServerList.parse(GSON, $$1).servers();
   }

   public RealmsServer createSnapshotRealm(Long pad262522_4_0) throws RealmsServiceException {
      String $$1 = String.valueOf(pad262522_4_0);
      String $$2 = this.url("worlds" + "/$PARENT_WORLD_ID/createPrereleaseRealm".replace("$PARENT_WORLD_ID", $$1));
      return RealmsServer.parse(GSON, this.execute(Request.post($$2, $$1)));
   }

   public List<RealmsNotification> getNotifications() throws RealmsServiceException {
      String $$0 = this.url("notifications");
      String $$1 = this.execute(Request.get($$0));
      return RealmsNotification.parseList($$1);
   }

   private static JsonArray uuidListToJsonArray(List<UUID> pad262522_5_0) {
      JsonArray $$1 = new JsonArray();

      for (UUID $$2 : pad262522_5_0) {
         if ($$2 != null) {
            $$1.add($$2.toString());
         }
      }

      return $$1;
   }

   public void notificationsSeen(List<UUID> pad262522_6_0) throws RealmsServiceException {
      String $$1 = this.url("notifications/seen");
      this.execute(Request.post($$1, GSON.toJson(uuidListToJsonArray(pad262522_6_0))));
   }

   public void notificationsDismiss(List<UUID> pad262522_7_0) throws RealmsServiceException {
      String $$1 = this.url("notifications/dismiss");
      this.execute(Request.post($$1, GSON.toJson(uuidListToJsonArray(pad262522_7_0))));
   }

   public RealmsServer getOwnRealm(long pad262522_8_0) throws RealmsServiceException {
      String $$1 = this.url("worlds" + "/$ID".replace("$ID", String.valueOf(pad262522_8_0)));
      String $$2 = this.execute(Request.get($$1));
      return RealmsServer.parse(GSON, $$2);
   }

   public PreferredRegionsDto getPreferredRegionSelections() throws RealmsServiceException {
      String $$0 = this.url("regions/preferredRegions");
      String $$1 = this.execute(Request.get($$0));

      try {
         PreferredRegionsDto $$2 = GSON.fromJson($$1, PreferredRegionsDto.class);
         if ($$2 == null) {
            return PreferredRegionsDto.empty();
         }

         Set<RealmsRegion> $$3 = $$2.regionData().stream().map(RegionDataDto::region).collect(Collectors.toSet());

         for (RealmsRegion $$4 : RealmsRegion.values()) {
            if ($$4 != RealmsRegion.INVALID_REGION && !$$3.contains($$4)) {
               LOGGER.debug("No realms region matching {} in server response", $$4);
            }
         }

         return $$2;
      } catch (Exception $$5) {
         LOGGER.error("Could not parse PreferredRegionSelections", $$5);
         return PreferredRegionsDto.empty();
      }
   }

   public RealmsServerPlayerLists getLiveStats() throws RealmsServiceException {
      String $$0 = this.url("activities/liveplayerlist");
      String $$1 = this.execute(Request.get($$0));
      return RealmsServerPlayerLists.parse($$1);
   }

   public RealmsJoinInformation join(long pad262522_9_0) throws RealmsServiceException {
      String $$1 = this.url("worlds" + "/v1/$ID/join/pc".replace("$ID", pad262522_9_0 + ""));
      String $$2 = this.execute(Request.get($$1, 5000, 30000));
      return RealmsJoinInformation.parse(GSON, $$2);
   }

   public void initializeRealm(long pad262522_10_0, String pad262522_11_1, String pad262522_12_2) throws RealmsServiceException {
      RealmsDescriptionDto $$3 = new RealmsDescriptionDto(pad262522_11_1, pad262522_12_2);
      String $$4 = this.url("worlds" + "/$WORLD_ID/initialize".replace("$WORLD_ID", String.valueOf(pad262522_10_0)));
      String $$5 = GSON.toJson($$3);
      this.execute(Request.post($$4, $$5, 5000, 10000));
   }

   public boolean hasParentalConsent() throws RealmsServiceException {
      String $$0 = this.url("mco/available");
      String $$1 = this.execute(Request.get($$0));
      return Boolean.parseBoolean($$1);
   }

   public RealmsClient.CompatibleVersionResponse clientCompatible() throws RealmsServiceException {
      String $$0 = this.url("mco/client/compatible");
      String $$1 = this.execute(Request.get($$0));

      try {
         return RealmsClient.CompatibleVersionResponse.valueOf($$1);
      } catch (IllegalArgumentException $$3) {
         throw new RealmsServiceException(RealmsError.CustomError.unknownCompatibilityResponse($$1));
      }
   }

   public void uninvite(long pad262522_13_0, UUID pad262522_14_1) throws RealmsServiceException {
      String $$2 = this.url(
         "invites" + "/$WORLD_ID/invite/$UUID".replace("$WORLD_ID", String.valueOf(pad262522_13_0)).replace("$UUID", UndashedUuid.toString(pad262522_14_1))
      );
      this.execute(Request.delete($$2));
   }

   public void uninviteMyselfFrom(long pad262522_15_0) throws RealmsServiceException {
      String $$1 = this.url("invites" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(pad262522_15_0)));
      this.execute(Request.delete($$1));
   }

   public List<PlayerInfo> invite(long pad262522_16_0, String pad262522_17_1) throws RealmsServiceException {
      OutboundPlayer $$2 = new OutboundPlayer();
      $$2.name = pad262522_17_1;
      String $$3 = this.url("invites" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(pad262522_16_0)));
      String $$4 = this.execute(Request.post($$3, GSON.toJson($$2)));
      return RealmsServer.parse(GSON, $$4).players;
   }

   public BackupList backupsFor(long pad262522_18_0) throws RealmsServiceException {
      String $$1 = this.url("worlds" + "/$WORLD_ID/backups".replace("$WORLD_ID", String.valueOf(pad262522_18_0)));
      String $$2 = this.execute(Request.get($$1));
      return BackupList.parse($$2);
   }

   public void updateConfiguration(
      long pad262522_19_0,
      String pad262522_20_1,
      String pad262522_21_2,
      @Nullable RegionSelectionPreferenceDto pad262522_22_3,
      int pad262522_23_4,
      RealmsWorldOptions pad262522_24_5,
      List<RealmsSetting> pad262522_25_6
   ) throws RealmsServiceException {
      RegionSelectionPreferenceDto $$7 = pad262522_22_3 != null
         ? pad262522_22_3
         : new RegionSelectionPreferenceDto(RegionSelectionPreference.DEFAULT_SELECTION, null);
      RealmsDescriptionDto $$8 = new RealmsDescriptionDto(pad262522_20_1, pad262522_21_2);
      RealmsSlotUpdateDto $$9 = new RealmsSlotUpdateDto(pad262522_23_4, pad262522_24_5, RealmsSetting.isHardcore(pad262522_25_6));
      RealmsConfigurationDto $$10 = new RealmsConfigurationDto($$9, pad262522_25_6, $$7, $$8);
      String $$11 = this.url("worlds" + "/$WORLD_ID/configuration".replace("$WORLD_ID", String.valueOf(pad262522_19_0)));
      this.execute(Request.post($$11, GSON.toJson($$10)));
   }

   public void updateSlot(long pad262522_26_0, int pad262522_27_1, RealmsWorldOptions pad262522_28_2, List<RealmsSetting> pad262522_29_3) throws RealmsServiceException {
      String $$4 = this.url(
         "worlds" + "/$WORLD_ID/slot/$SLOT_ID".replace("$WORLD_ID", String.valueOf(pad262522_26_0)).replace("$SLOT_ID", String.valueOf(pad262522_27_1))
      );
      String $$5 = GSON.toJson(new RealmsSlotUpdateDto(pad262522_27_1, pad262522_28_2, RealmsSetting.isHardcore(pad262522_29_3)));
      this.execute(Request.post($$4, $$5));
   }

   public boolean switchSlot(long pad262522_30_0, int pad262522_31_1) throws RealmsServiceException {
      String $$2 = this.url(
         "worlds" + "/$WORLD_ID/slot/$SLOT_ID".replace("$WORLD_ID", String.valueOf(pad262522_30_0)).replace("$SLOT_ID", String.valueOf(pad262522_31_1))
      );
      String $$3 = this.execute(Request.put($$2, ""));
      return Boolean.valueOf($$3);
   }

   public void restoreWorld(long pad262522_32_0, String pad262522_33_1) throws RealmsServiceException {
      String $$2 = this.url("worlds" + "/$WORLD_ID/backups".replace("$WORLD_ID", String.valueOf(pad262522_32_0)), "backupId=" + pad262522_33_1);
      this.execute(Request.put($$2, "", 40000, 600000));
   }

   public WorldTemplatePaginatedList fetchWorldTemplates(int pad262522_34_0, int pad262522_35_1, RealmsServer.WorldType pad262522_36_2) throws RealmsServiceException {
      String $$3 = this.url(
         "worlds" + "/templates/$WORLD_TYPE".replace("$WORLD_TYPE", pad262522_36_2.toString()),
         String.format(Locale.ROOT, "page=%d&pageSize=%d", pad262522_34_0, pad262522_35_1)
      );
      String $$4 = this.execute(Request.get($$3));
      return WorldTemplatePaginatedList.parse($$4);
   }

   public Boolean putIntoMinigameMode(long pad262522_37_0, String pad262522_38_1) throws RealmsServiceException {
      String $$2 = "/minigames/$MINIGAME_ID/$WORLD_ID".replace("$MINIGAME_ID", pad262522_38_1).replace("$WORLD_ID", String.valueOf(pad262522_37_0));
      String $$3 = this.url("worlds" + $$2);
      return Boolean.valueOf(this.execute(Request.put($$3, "")));
   }

   public Ops op(long pad262522_39_0, UUID pad262522_40_1) throws RealmsServiceException {
      String $$2 = "/$WORLD_ID/$PROFILE_UUID"
         .replace("$WORLD_ID", String.valueOf(pad262522_39_0))
         .replace("$PROFILE_UUID", UndashedUuid.toString(pad262522_40_1));
      String $$3 = this.url("ops" + $$2);
      return Ops.parse(this.execute(Request.post($$3, "")));
   }

   public Ops deop(long pad262522_41_0, UUID pad262522_42_1) throws RealmsServiceException {
      String $$2 = "/$WORLD_ID/$PROFILE_UUID"
         .replace("$WORLD_ID", String.valueOf(pad262522_41_0))
         .replace("$PROFILE_UUID", UndashedUuid.toString(pad262522_42_1));
      String $$3 = this.url("ops" + $$2);
      return Ops.parse(this.execute(Request.delete($$3)));
   }

   public Boolean open(long pad262522_43_0) throws RealmsServiceException {
      String $$1 = this.url("worlds" + "/$WORLD_ID/open".replace("$WORLD_ID", String.valueOf(pad262522_43_0)));
      String $$2 = this.execute(Request.put($$1, ""));
      return Boolean.valueOf($$2);
   }

   public Boolean close(long pad262522_44_0) throws RealmsServiceException {
      String $$1 = this.url("worlds" + "/$WORLD_ID/close".replace("$WORLD_ID", String.valueOf(pad262522_44_0)));
      String $$2 = this.execute(Request.put($$1, ""));
      return Boolean.valueOf($$2);
   }

   public Boolean resetWorldWithTemplate(long pad262522_45_0, String pad262522_46_1) throws RealmsServiceException {
      RealmsWorldResetDto $$2 = new RealmsWorldResetDto(null, Long.valueOf(pad262522_46_1), -1, false, Set.of());
      String $$3 = this.url("worlds" + "/$WORLD_ID/reset".replace("$WORLD_ID", String.valueOf(pad262522_45_0)));
      String $$4 = this.execute(Request.post($$3, GSON.toJson($$2), 30000, 80000));
      return Boolean.valueOf($$4);
   }

   public Subscription subscriptionFor(long pad262522_47_0) throws RealmsServiceException {
      String $$1 = this.url("subscriptions" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(pad262522_47_0)));
      String $$2 = this.execute(Request.get($$1));
      return Subscription.parse($$2);
   }

   public int pendingInvitesCount() throws RealmsServiceException {
      return this.pendingInvites().pendingInvites().size();
   }

   public PendingInvitesList pendingInvites() throws RealmsServiceException {
      String $$0 = this.url("invites/pending");
      String $$1 = this.execute(Request.get($$0));
      PendingInvitesList $$2 = PendingInvitesList.parse($$1);
      $$2.pendingInvites().removeIf(this::isBlocked);
      return $$2;
   }

   private boolean isBlocked(PendingInvite pad262522_48_0) {
      return this.minecraft.getPlayerSocialManager().isBlocked(pad262522_48_0.realmOwnerUuid());
   }

   public void acceptInvitation(String pad262522_49_0) throws RealmsServiceException {
      String $$1 = this.url("invites" + "/accept/$INVITATION_ID".replace("$INVITATION_ID", pad262522_49_0));
      this.execute(Request.put($$1, ""));
   }

   public WorldDownload requestDownloadInfo(long pad262522_50_0, int pad262522_51_1) throws RealmsServiceException {
      String $$2 = this.url(
         "worlds"
            + "/$WORLD_ID/slot/$SLOT_ID/download".replace("$WORLD_ID", String.valueOf(pad262522_50_0)).replace("$SLOT_ID", String.valueOf(pad262522_51_1))
      );
      String $$3 = this.execute(Request.get($$2));
      return WorldDownload.parse($$3);
   }

   public @Nullable UploadInfo requestUploadInfo(long pad262522_52_0) throws RealmsServiceException {
      String $$1 = this.url("worlds" + "/$WORLD_ID/backups/upload".replace("$WORLD_ID", String.valueOf(pad262522_52_0)));
      String $$2 = UploadTokenCache.get(pad262522_52_0);
      UploadInfo $$3 = UploadInfo.parse(this.execute(Request.put($$1, UploadInfo.createRequest($$2))));
      if ($$3 != null) {
         UploadTokenCache.put(pad262522_52_0, $$3.token());
      }

      return $$3;
   }

   public void rejectInvitation(String pad262522_53_0) throws RealmsServiceException {
      String $$1 = this.url("invites" + "/reject/$INVITATION_ID".replace("$INVITATION_ID", pad262522_53_0));
      this.execute(Request.put($$1, ""));
   }

   public void agreeToTos() throws RealmsServiceException {
      String $$0 = this.url("mco/tos/agreed");
      this.execute(Request.post($$0, ""));
   }

   public RealmsNews getNews() throws RealmsServiceException {
      String $$0 = this.url("mco/v1/news");
      String $$1 = this.execute(Request.get($$0, 5000, 10000));
      return RealmsNews.parse($$1);
   }

   public void sendPingResults(PingResult pad262522_54_0) throws RealmsServiceException {
      String $$1 = this.url("regions/ping/stat");
      this.execute(Request.post($$1, GSON.toJson(pad262522_54_0)));
   }

   public Boolean trialAvailable() throws RealmsServiceException {
      String $$0 = this.url("trial");
      String $$1 = this.execute(Request.get($$0));
      return Boolean.valueOf($$1);
   }

   public void deleteRealm(long pad262522_55_0) throws RealmsServiceException {
      String $$1 = this.url("worlds" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(pad262522_55_0)));
      this.execute(Request.delete($$1));
   }

   private String url(String pad262522_56_0) throws RealmsServiceException {
      return this.url(pad262522_56_0, null);
   }

   private String url(String pad262522_57_0, @Nullable String pad262522_58_1) {
      return url(pad262522_57_0, pad262522_58_1, this.getFeatureFlags().contains("realms_in_aks"));
   }

   private static String url(String pad262522_59_0, @Nullable String pad262522_60_1, boolean pad262522_61_2) {
      try {
         return new URI(ENVIRONMENT.protocol, pad262522_61_2 ? ENVIRONMENT.alternativeUrl : ENVIRONMENT.baseUrl, "/" + pad262522_59_0, pad262522_60_1, null)
            .toASCIIString();
      } catch (URISyntaxException $$3) {
         throw new IllegalArgumentException(pad262522_59_0, $$3);
      }
   }

   private String execute(Request<?> pad262522_62_0) throws RealmsServiceException {
      pad262522_62_0.cookie("sid", this.sessionId);
      pad262522_62_0.cookie("user", this.username);
      pad262522_62_0.cookie("version", SharedConstants.getCurrentVersion().name());
      pad262522_62_0.addSnapshotHeader(RealmsMainScreen.isSnapshot());

      try {
         int $$1 = pad262522_62_0.responseCode();
         if ($$1 != 503 && $$1 != 277) {
            String $$3 = pad262522_62_0.text();
            if ($$1 >= 200 && $$1 < 300) {
               return $$3;
            }

            if ($$1 == 401) {
               String $$4 = pad262522_62_0.getHeader("WWW-Authenticate");
               LOGGER.info("Could not authorize you against Realms server: {}", $$4);
               throw new RealmsServiceException(new RealmsError.AuthenticationError($$4));
            }

            String $$5 = pad262522_62_0.connection.getContentType();
            if ($$5 != null && $$5.startsWith("text/html")) {
               throw new RealmsServiceException(RealmsError.CustomError.htmlPayload($$1, $$3));
            }

            RealmsError $$6 = RealmsError.parse($$1, $$3);
            throw new RealmsServiceException($$6);
         } else {
            int $$2 = pad262522_62_0.getRetryAfterHeader();
            throw new RetryCallException($$2, $$1);
         }
      } catch (RealmsHttpException $$7) {
         throw new RealmsServiceException(RealmsError.CustomError.connectivityError($$7));
      }
   }

   public enum CompatibleVersionResponse {
      COMPATIBLE,
      OUTDATED,
      OTHER;
   }

   public enum Environment {
      PRODUCTION("pc.realms.minecraft.net", "java.frontendlegacy.realms.minecraft-services.net", "https"),
      STAGE("pc-stage.realms.minecraft.net", "java.frontendlegacy.stage-c2a40e62.realms.minecraft-services.net", "https"),
      LOCAL("localhost:8080", "localhost:8080", "http");

      public final String baseUrl;
      public final String alternativeUrl;
      public final String protocol;

      Environment(final String p34c39d71_3_2, final String p34c39d71_4_3, final String p34c39d71_5_4) {
         this.baseUrl = p34c39d71_3_2;
         this.alternativeUrl = p34c39d71_4_3;
         this.protocol = p34c39d71_5_4;
      }

      public static Optional<RealmsClient.Environment> byName(String p34c39d71_6_0) {
         return switch (p34c39d71_6_0.toLowerCase(Locale.ROOT)) {
            case "production" -> Optional.of(PRODUCTION);
            case "local" -> Optional.of(LOCAL);
            case "stage", "staging" -> Optional.of(STAGE);
            default -> Optional.empty();
         };
      }
   }
}
