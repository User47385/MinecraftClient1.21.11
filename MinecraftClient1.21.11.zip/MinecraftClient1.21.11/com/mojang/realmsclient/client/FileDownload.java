package com.mojang.realmsclient.client;

import com.google.common.hash.Hashing;
import com.google.common.io.Files;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.dto.WorldDownload;
import com.mojang.realmsclient.exception.RealmsDefaultUncaughtExceptionHandler;
import com.mojang.realmsclient.gui.screens.RealmsDownloadLatestWorldScreen;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.Builder;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.Locale;
import java.util.OptionalLong;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.CheckReturnValue;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.NbtException;
import net.minecraft.nbt.ReportedNbtException;
import net.minecraft.util.Util;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.minecraft.world.level.validation.ContentValidationException;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.output.CountingOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class FileDownload {
   private static final Logger LOGGER = LogUtils.getLogger();
   private volatile boolean cancelled;
   private volatile boolean finished;
   private volatile boolean error;
   private volatile boolean extracting;
   private volatile @Nullable File tempFile;
   private volatile File resourcePackPath;
   private volatile @Nullable CompletableFuture<?> pendingRequest;
   private @Nullable Thread currentThread;
   private static final String[] INVALID_FILE_NAMES = new String[]{
      "CON",
      "COM",
      "PRN",
      "AUX",
      "CLOCK$",
      "NUL",
      "COM1",
      "COM2",
      "COM3",
      "COM4",
      "COM5",
      "COM6",
      "COM7",
      "COM8",
      "COM9",
      "LPT1",
      "LPT2",
      "LPT3",
      "LPT4",
      "LPT5",
      "LPT6",
      "LPT7",
      "LPT8",
      "LPT9"
   };

   private <T> @Nullable T joinCancellableRequest(CompletableFuture<T> pf7de9697_0_0) throws Throwable {
      this.pendingRequest = pf7de9697_0_0;
      if (this.cancelled) {
         pf7de9697_0_0.cancel(true);
         return null;
      }

      try {
         try {
            return pf7de9697_0_0.join();
         } catch (CompletionException $$1) {
            throw $$1.getCause();
         }
      } catch (CancellationException $$2) {
         return null;
      }
   }

   private static HttpClient createClient() {
      return HttpClient.newBuilder().executor(Util.nonCriticalIoPool()).connectTimeout(Duration.ofMinutes(2L)).build();
   }

   private static Builder createRequest(String pf7de9697_1_0) {
      return HttpRequest.newBuilder(URI.create(pf7de9697_1_0)).timeout(Duration.ofMinutes(2L));
   }

   @CheckReturnValue
   public static OptionalLong contentLength(String pf7de9697_2_0) {
      try (HttpClient $$1 = createClient()) {
         HttpResponse<Void> $$2 = $$1.send(createRequest(pf7de9697_2_0).HEAD().build(), BodyHandlers.discarding());
         return $$2.headers().firstValueAsLong("Content-Length");
      } catch (Exception $$3) {
         LOGGER.error("Unable to get content length for download");
         return OptionalLong.empty();
      }
   }

   public void download(
      WorldDownload pf7de9697_3_0, String pf7de9697_4_1, RealmsDownloadLatestWorldScreen.DownloadStatus pf7de9697_5_2, LevelStorageSource pf7de9697_6_3
   ) {
      if (this.currentThread == null) {
         this.currentThread = new Thread(() -> {
            try (HttpClient $$4 = createClient()) {
               try {
                  this.tempFile = File.createTempFile("backup", ".tar.gz");
                  this.download(pf7de9697_5_2, $$4, pf7de9697_3_0.downloadLink(), this.tempFile);
                  this.finishWorldDownload(pf7de9697_4_1.trim(), this.tempFile, pf7de9697_6_3, pf7de9697_5_2);
               } catch (Exception $$5) {
                  LOGGER.error("Caught exception while downloading world", $$5);
                  this.error = true;
               } finally {
                  this.pendingRequest = null;
                  if (this.tempFile != null) {
                     this.tempFile.delete();
                  }

                  this.tempFile = null;
               }

               if (this.error) {
                  return;
               }

               String $$6 = pf7de9697_3_0.resourcePackUrl();
               if (!$$6.isEmpty() && !pf7de9697_3_0.resourcePackHash().isEmpty()) {
                  try {
                     this.tempFile = File.createTempFile("resources", ".tar.gz");
                     this.download(pf7de9697_5_2, $$4, $$6, this.tempFile);
                     this.finishResourcePackDownload(pf7de9697_5_2, this.tempFile, pf7de9697_3_0);
                  } catch (Exception $$7) {
                     LOGGER.error("Caught exception while downloading resource pack", $$7);
                     this.error = true;
                  } finally {
                     this.pendingRequest = null;
                     if (this.tempFile != null) {
                        this.tempFile.delete();
                     }

                     this.tempFile = null;
                  }
               }

               this.finished = true;
            }
         });
         this.currentThread.setUncaughtExceptionHandler(new RealmsDefaultUncaughtExceptionHandler(LOGGER));
         this.currentThread.start();
      }
   }

   private void download(RealmsDownloadLatestWorldScreen.DownloadStatus pf7de9697_7_0, HttpClient pf7de9697_8_1, String pf7de9697_9_2, File pf7de9697_10_3) throws IOException {
      HttpRequest $$4 = createRequest(pf7de9697_9_2).GET().build();

      HttpResponse<InputStream> $$5;
      try {
         $$5 = this.joinCancellableRequest(pf7de9697_8_1.sendAsync($$4, BodyHandlers.ofInputStream()));
      } catch (Error $$6) {
         throw $$6;
      } catch (Throwable $$7) {
         LOGGER.error("Failed to download {}", pf7de9697_9_2, $$7);
         this.error = true;
         return;
      }

      if ($$5 != null && !this.cancelled) {
         if ($$5.statusCode() != 200) {
            this.error = true;
         } else {
            pf7de9697_7_0.totalBytes = $$5.headers().firstValueAsLong("Content-Length").orElse(0L);

            try (
               InputStream $$9 = $$5.body();
               OutputStream $$10 = new FileOutputStream(pf7de9697_10_3);
            ) {
               $$9.transferTo(new FileDownload.DownloadCountingOutputStream($$10, pf7de9697_7_0));
            }
         }
      }
   }

   public void cancel() {
      if (this.tempFile != null) {
         this.tempFile.delete();
         this.tempFile = null;
      }

      this.cancelled = true;
      CompletableFuture<?> $$0 = this.pendingRequest;
      if ($$0 != null) {
         $$0.cancel(true);
      }
   }

   public boolean isFinished() {
      return this.finished;
   }

   public boolean isError() {
      return this.error;
   }

   public boolean isExtracting() {
      return this.extracting;
   }

   public static String findAvailableFolderName(String pf7de9697_11_0) {
      pf7de9697_11_0 = pf7de9697_11_0.replaceAll("[\\./\"]", "_");

      for (String $$1 : INVALID_FILE_NAMES) {
         if (pf7de9697_11_0.equalsIgnoreCase($$1)) {
            pf7de9697_11_0 = "_" + pf7de9697_11_0 + "_";
         }
      }

      return pf7de9697_11_0;
   }

   private void untarGzipArchive(String pf7de9697_12_0, @Nullable File pf7de9697_13_1, LevelStorageSource pf7de9697_14_2) throws IOException {
      Pattern $$3 = Pattern.compile(".*-([0-9]+)$");
      int $$4 = 1;

      for (char $$5 : SharedConstants.ILLEGAL_FILE_CHARACTERS) {
         pf7de9697_12_0 = pf7de9697_12_0.replace($$5, '_');
      }

      if (StringUtils.isEmpty(pf7de9697_12_0)) {
         pf7de9697_12_0 = "Realm";
      }

      pf7de9697_12_0 = findAvailableFolderName(pf7de9697_12_0);

      try {
         for (LevelStorageSource.LevelDirectory $$6 : pf7de9697_14_2.findLevelCandidates()) {
            String $$7 = $$6.directoryName();
            if ($$7.toLowerCase(Locale.ROOT).startsWith(pf7de9697_12_0.toLowerCase(Locale.ROOT))) {
               Matcher $$8 = $$3.matcher($$7);
               if ($$8.matches()) {
                  int $$9 = Integer.parseInt($$8.group(1));
                  if ($$9 > $$4) {
                     $$4 = $$9;
                  }
               } else {
                  $$4++;
               }
            }
         }
      } catch (Exception $$10) {
         LOGGER.error("Error getting level list", $$10);
         this.error = true;
         return;
      }

      String $$13;
      if (pf7de9697_14_2.isNewLevelIdAcceptable(pf7de9697_12_0) && $$4 <= 1) {
         $$13 = pf7de9697_12_0;
      } else {
         $$13 = pf7de9697_12_0 + ($$4 == 1 ? "" : "-" + $$4);
         if (!pf7de9697_14_2.isNewLevelIdAcceptable($$13)) {
            boolean $$12 = false;

            while (!$$12) {
               $$4++;
               $$13 = pf7de9697_12_0 + ($$4 == 1 ? "" : "-" + $$4);
               if (pf7de9697_14_2.isNewLevelIdAcceptable($$13)) {
                  $$12 = true;
               }
            }
         }
      }

      TarArchiveInputStream $$14 = null;
      File $$15 = new File(Minecraft.getInstance().gameDirectory.getAbsolutePath(), "saves");

      try {
         $$15.mkdir();
         $$14 = new TarArchiveInputStream(new GzipCompressorInputStream(new BufferedInputStream(new FileInputStream(pf7de9697_13_1))));

         for (TarArchiveEntry $$16 = $$14.getNextTarEntry(); $$16 != null; $$16 = $$14.getNextTarEntry()) {
            File $$17 = new File($$15, $$16.getName().replace("world", $$13));
            if ($$16.isDirectory()) {
               $$17.mkdirs();
            } else {
               $$17.createNewFile();

               try (FileOutputStream $$18 = new FileOutputStream($$17)) {
                  IOUtils.copy($$14, $$18);
               }
            }
         }
      } catch (Exception $$22) {
         LOGGER.error("Error extracting world", $$22);
         this.error = true;
      } finally {
         if ($$14 != null) {
            $$14.close();
         }

         if (pf7de9697_13_1 != null) {
            pf7de9697_13_1.delete();
         }

         try (LevelStorageSource.LevelStorageAccess $$26 = pf7de9697_14_2.validateAndCreateAccess($$13)) {
            $$26.renameAndDropPlayer($$13);
         } catch (IOException | NbtException | ReportedNbtException $$27) {
            LOGGER.error("Failed to modify unpacked realms level {}", $$13, $$27);
         } catch (ContentValidationException $$28) {
            LOGGER.warn("Failed to download file", $$28);
         }

         this.resourcePackPath = new File($$15, $$13 + File.separator + "resources.zip");
      }
   }

   private void finishWorldDownload(
      String pf7de9697_15_0, File pf7de9697_16_1, LevelStorageSource pf7de9697_17_2, RealmsDownloadLatestWorldScreen.DownloadStatus pf7de9697_18_3
   ) {
      if (pf7de9697_18_3.bytesWritten >= pf7de9697_18_3.totalBytes && !this.cancelled && !this.error) {
         try {
            this.extracting = true;
            this.untarGzipArchive(pf7de9697_15_0, pf7de9697_16_1, pf7de9697_17_2);
         } catch (IOException $$4) {
            LOGGER.error("Error extracting archive", $$4);
            this.error = true;
         }
      }
   }

   private void finishResourcePackDownload(RealmsDownloadLatestWorldScreen.DownloadStatus pf7de9697_19_0, File pf7de9697_20_1, WorldDownload pf7de9697_21_2) {
      if (pf7de9697_19_0.bytesWritten >= pf7de9697_19_0.totalBytes && !this.cancelled) {
         try {
            String $$3 = Hashing.sha1().hashBytes(Files.toByteArray(pf7de9697_20_1)).toString();
            if ($$3.equals(pf7de9697_21_2.resourcePackHash())) {
               FileUtils.copyFile(pf7de9697_20_1, this.resourcePackPath);
               this.finished = true;
            } else {
               LOGGER.error("Resourcepack had wrong hash (expected {}, found {}). Deleting it.", pf7de9697_21_2.resourcePackHash(), $$3);
               FileUtils.deleteQuietly(pf7de9697_20_1);
               this.error = true;
            }
         } catch (IOException $$4) {
            LOGGER.error("Error copying resourcepack file: {}", $$4.getMessage());
            this.error = true;
         }
      }
   }

   static class DownloadCountingOutputStream extends CountingOutputStream {
      private final RealmsDownloadLatestWorldScreen.DownloadStatus downloadStatus;

      public DownloadCountingOutputStream(OutputStream pdc958ba9_0_0, RealmsDownloadLatestWorldScreen.DownloadStatus pdc958ba9_1_1) {
         super(pdc958ba9_0_0);
         this.downloadStatus = pdc958ba9_1_1;
      }

      @Override
      protected void afterWrite(int pdc958ba9_2_0) throws IOException {
         super.afterWrite(pdc958ba9_2_0);
         this.downloadStatus.bytesWritten = this.getByteCount();
      }
   }
}
