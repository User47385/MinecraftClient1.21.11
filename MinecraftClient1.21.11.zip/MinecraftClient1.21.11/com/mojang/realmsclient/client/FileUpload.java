package com.mojang.realmsclient.client;

import com.google.gson.JsonElement;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.dto.UploadInfo;
import com.mojang.realmsclient.gui.screens.UploadResult;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublisher;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import net.minecraft.client.User;
import net.minecraft.util.LenientJsonParser;
import net.minecraft.util.Util;
import org.apache.commons.io.input.CountingInputStream;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class FileUpload implements AutoCloseable {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final int MAX_RETRIES = 5;
   private static final String UPLOAD_PATH = "/upload";
   private final File file;
   private final long realmId;
   private final int slotId;
   private final UploadInfo uploadInfo;
   private final String sessionId;
   private final String username;
   private final String clientVersion;
   private final String worldVersion;
   private final UploadStatus uploadStatus;
   private final HttpClient client;

   public FileUpload(
      File p443213d0_0_0,
      long p443213d0_1_1,
      int p443213d0_2_2,
      UploadInfo p443213d0_3_3,
      User p443213d0_4_4,
      String p443213d0_5_5,
      String p443213d0_6_6,
      UploadStatus p443213d0_7_7
   ) {
      this.file = p443213d0_0_0;
      this.realmId = p443213d0_1_1;
      this.slotId = p443213d0_2_2;
      this.uploadInfo = p443213d0_3_3;
      this.sessionId = p443213d0_4_4.getSessionId();
      this.username = p443213d0_4_4.getName();
      this.clientVersion = p443213d0_5_5;
      this.worldVersion = p443213d0_6_6;
      this.uploadStatus = p443213d0_7_7;
      this.client = HttpClient.newBuilder().executor(Util.nonCriticalIoPool()).connectTimeout(Duration.ofSeconds(15L)).build();
   }

   @Override
   public void close() {
      this.client.close();
   }

   public CompletableFuture<UploadResult> startUpload() {
      long $$0 = this.file.length();
      this.uploadStatus.setTotalBytes($$0);
      return this.requestUpload(0, $$0);
   }

   private CompletableFuture<UploadResult> requestUpload(int p443213d0_8_0, long p443213d0_9_1) {
      BodyPublisher $$2 = inputStreamPublisherWithSize(() -> {
         try {
            return new FileUpload.UploadCountingInputStream(new FileInputStream(this.file), this.uploadStatus);
         } catch (IOException $$0) {
            LOGGER.warn("Failed to open file {}", this.file, $$0);
            return null;
         }
      }, p443213d0_9_1);
      HttpRequest $$3 = HttpRequest.newBuilder(this.uploadInfo.uploadEndpoint().resolve("/upload/" + this.realmId + "/" + this.slotId))
         .timeout(Duration.ofMinutes(10L))
         .setHeader("Cookie", this.uploadCookie())
         .setHeader("Content-Type", "application/octet-stream")
         .POST($$2)
         .build();
      return this.client.sendAsync($$3, BodyHandlers.ofString(StandardCharsets.UTF_8)).thenCompose(p443213d0_18_2 -> {
         long $$3x = this.getRetryDelaySeconds((HttpResponse<?>)p443213d0_18_2);
         if (this.shouldRetry($$3x, p443213d0_8_0)) {
            this.uploadStatus.restart();

            try {
               Thread.sleep(Duration.ofSeconds($$3x));
            } catch (InterruptedException var8) {
            }

            return this.requestUpload(p443213d0_8_0 + 1, p443213d0_9_1);
         } else {
            return CompletableFuture.completedFuture(this.handleResponse((HttpResponse<String>)p443213d0_18_2));
         }
      });
   }

   private static BodyPublisher inputStreamPublisherWithSize(Supplier<@Nullable InputStream> p443213d0_10_0, long p443213d0_11_1) {
      return BodyPublishers.fromPublisher(BodyPublishers.ofInputStream(p443213d0_10_0), p443213d0_11_1);
   }

   private String uploadCookie() {
      return "sid="
         + this.sessionId
         + ";token="
         + this.uploadInfo.token()
         + ";user="
         + this.username
         + ";version="
         + this.clientVersion
         + ";worldVersion="
         + this.worldVersion;
   }

   private UploadResult handleResponse(HttpResponse<String> p443213d0_12_0) {
      int $$1 = p443213d0_12_0.statusCode();
      if ($$1 == 401) {
         LOGGER.debug("Realms server returned 401: {}", p443213d0_12_0.headers().firstValue("WWW-Authenticate"));
      }

      String $$2 = null;
      String $$3 = p443213d0_12_0.body();
      if ($$3 != null && !$$3.isBlank()) {
         try {
            JsonElement $$4 = LenientJsonParser.parse($$3).getAsJsonObject().get("errorMsg");
            if ($$4 != null) {
               $$2 = $$4.getAsString();
            }
         } catch (Exception $$5) {
            LOGGER.warn("Failed to parse response {}", $$3, $$5);
         }
      }

      return new UploadResult($$1, $$2);
   }

   private boolean shouldRetry(long p443213d0_13_0, int p443213d0_14_1) {
      return p443213d0_13_0 > 0L && p443213d0_14_1 + 1 < 5;
   }

   private long getRetryDelaySeconds(HttpResponse<?> p443213d0_15_0) {
      return p443213d0_15_0.headers().firstValueAsLong("Retry-After").orElse(0L);
   }

   static class UploadCountingInputStream extends CountingInputStream {
      private final UploadStatus uploadStatus;

      UploadCountingInputStream(InputStream p83aa5dc2_0_0, UploadStatus p83aa5dc2_1_1) {
         super(p83aa5dc2_0_0);
         this.uploadStatus = p83aa5dc2_1_1;
      }

      @Override
      protected void afterRead(int p83aa5dc2_2_0) throws IOException {
         super.afterRead(p83aa5dc2_2_0);
         this.uploadStatus.onWrite(this.getByteCount());
      }
   }
}
