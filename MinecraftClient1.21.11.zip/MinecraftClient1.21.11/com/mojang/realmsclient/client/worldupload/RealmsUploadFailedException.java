package com.mojang.realmsclient.client.worldupload;

import net.minecraft.network.chat.Component;

public class RealmsUploadFailedException extends RealmsUploadException {
   private final Component errorMessage;

   public RealmsUploadFailedException(Component p7f9b269e_0_0) {
      this.errorMessage = p7f9b269e_0_0;
   }

   public RealmsUploadFailedException(String p7f9b269e_1_0) {
      this(Component.literal(p7f9b269e_1_0));
   }

   @Override
   public Component getStatusMessage() {
      return Component.translatable("mco.upload.failed", this.errorMessage);
   }
}
