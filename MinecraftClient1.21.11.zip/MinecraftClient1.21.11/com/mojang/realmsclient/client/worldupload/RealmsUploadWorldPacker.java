package com.mojang.realmsclient.client.worldupload;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.function.BooleanSupplier;
import java.util.zip.GZIPOutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;

public class RealmsUploadWorldPacker {
   private static final long SIZE_LIMIT = 5368709120L;
   private static final String WORLD_FOLDER_NAME = "world";
   private final BooleanSupplier isCanceled;
   private final Path directoryToPack;

   public static File pack(Path p74361ac4_0_0, BooleanSupplier p74361ac4_1_1) throws IOException {
      return new RealmsUploadWorldPacker(p74361ac4_0_0, p74361ac4_1_1).tarGzipArchive();
   }

   private RealmsUploadWorldPacker(Path p74361ac4_2_0, BooleanSupplier p74361ac4_3_1) {
      this.isCanceled = p74361ac4_3_1;
      this.directoryToPack = p74361ac4_2_0;
   }

   private File tarGzipArchive() throws IOException {
      TarArchiveOutputStream $$0 = null;

      try {
         File $$1 = File.createTempFile("realms-upload-file", ".tar.gz");
         $$0 = new TarArchiveOutputStream(new GZIPOutputStream(new FileOutputStream($$1)));
         $$0.setLongFileMode(3);
         this.addFileToTarGz($$0, this.directoryToPack, "world", true);
         if (this.isCanceled.getAsBoolean()) {
            throw new RealmsUploadCanceledException();
         }

         $$0.finish();
         this.verifyBelowSizeLimit($$1.length());
         return $$1;
      } finally {
         if ($$0 != null) {
            $$0.close();
         }
      }
   }

   private void addFileToTarGz(TarArchiveOutputStream p74361ac4_4_0, Path p74361ac4_5_1, String p74361ac4_6_2, boolean p74361ac4_7_3) throws IOException {
      if (this.isCanceled.getAsBoolean()) {
         throw new RealmsUploadCanceledException();
      }

      this.verifyBelowSizeLimit(p74361ac4_4_0.getBytesWritten());
      File $$4 = p74361ac4_5_1.toFile();
      String $$5 = p74361ac4_7_3 ? p74361ac4_6_2 : p74361ac4_6_2 + $$4.getName();
      TarArchiveEntry $$6 = new TarArchiveEntry($$4, $$5);
      p74361ac4_4_0.putArchiveEntry($$6);
      if ($$4.isFile()) {
         try (InputStream $$7 = new FileInputStream($$4)) {
            $$7.transferTo(p74361ac4_4_0);
         }

         p74361ac4_4_0.closeArchiveEntry();
      } else {
         p74361ac4_4_0.closeArchiveEntry();
         File[] $$8 = $$4.listFiles();
         if ($$8 != null) {
            for (File $$9 : $$8) {
               this.addFileToTarGz(p74361ac4_4_0, $$9.toPath(), $$5 + "/", false);
            }
         }
      }
   }

   private void verifyBelowSizeLimit(long p74361ac4_8_0) {
      if (p74361ac4_8_0 > 5368709120L) {
         throw new RealmsUploadTooLargeException(5368709120L);
      }
   }
}
