package com.mojang.realmsclient.client.worldupload;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.RealmsSetting;
import com.mojang.realmsclient.dto.RealmsSlot;
import com.mojang.realmsclient.dto.RealmsWorldOptions;
import com.mojang.realmsclient.gui.screens.RealmsGenericErrorScreen;
import com.mojang.realmsclient.gui.screens.configuration.RealmsConfigureWorldScreen;
import com.mojang.realmsclient.util.task.RealmCreationTask;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CompletionException;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.AlertScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.worldselection.CreateWorldScreen;
import net.minecraft.core.LayeredRegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.RegistryLayer;
import net.minecraft.world.level.storage.PrimaryLevelData;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsCreateWorldFlow {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static void createWorld(
      Minecraft p6400de51_0_0,
      Screen p6400de51_1_1,
      Screen p6400de51_2_2,
      int p6400de51_3_3,
      RealmsServer p6400de51_4_4,
      @Nullable RealmCreationTask p6400de51_5_5
   ) {
      CreateWorldScreen.openFresh(
         p6400de51_0_0,
         () -> p6400de51_0_0.setScreen(p6400de51_1_1),
         (p6400de51_15_6, p6400de51_16_7, p6400de51_17_8, p6400de51_18_9) -> {
            Path $$10;
            try {
               $$10 = createTemporaryWorldFolder(p6400de51_16_7, p6400de51_17_8, p6400de51_18_9);
            } catch (IOException $$11) {
               LOGGER.warn("Failed to create temporary world folder.");
               p6400de51_0_0.setScreen(new RealmsGenericErrorScreen(Component.translatable("mco.create.world.failed"), p6400de51_2_2));
               return true;
            }

            RealmsWorldOptions $$13 = RealmsWorldOptions.createFromSettings(p6400de51_17_8.getLevelSettings(), SharedConstants.getCurrentVersion().name());
            RealmsSlot $$14 = new RealmsSlot(p6400de51_3_3, $$13, List.of(RealmsSetting.hardcoreSetting(p6400de51_17_8.getLevelSettings().hardcore())));
            RealmsWorldUpload $$15 = new RealmsWorldUpload($$10, $$14, p6400de51_0_0.getUser(), p6400de51_4_4.id, RealmsWorldUploadStatusTracker.noOp());
            p6400de51_0_0.setScreenAndShow(
               new AlertScreen($$15::cancel, Component.translatable("mco.create.world.reset.title"), Component.empty(), CommonComponents.GUI_CANCEL, false)
            );
            if (p6400de51_5_5 != null) {
               p6400de51_5_5.run();
            }

            $$15.packAndUpload().handleAsync((p6400de51_24_5, p6400de51_25_6) -> {
               if (p6400de51_25_6 != null) {
                  if (p6400de51_25_6 instanceof CompletionException $$7) {
                     p6400de51_25_6 = $$7.getCause();
                  }

                  if (p6400de51_25_6 instanceof RealmsUploadCanceledException) {
                     p6400de51_0_0.setScreenAndShow(p6400de51_2_2);
                  } else {
                     if (p6400de51_25_6 instanceof RealmsUploadFailedException $$8) {
                        LOGGER.warn("Failed to create realms world {}", $$8.getStatusMessage());
                     } else {
                        LOGGER.warn("Failed to create realms world {}", p6400de51_25_6.getMessage());
                     }

                     p6400de51_0_0.setScreenAndShow(new RealmsGenericErrorScreen(Component.translatable("mco.create.world.failed"), p6400de51_2_2));
                  }
               } else {
                  if (p6400de51_1_1 instanceof RealmsConfigureWorldScreen $$9) {
                     $$9.fetchServerData(p6400de51_4_4.id);
                  }

                  if (p6400de51_5_5 != null) {
                     RealmsMainScreen.play(p6400de51_4_4, p6400de51_1_1, true);
                  } else {
                     p6400de51_0_0.setScreenAndShow(p6400de51_1_1);
                  }

                  RealmsMainScreen.refreshServerList();
               }

               return null;
            }, p6400de51_0_0);
            return true;
         }
      );
   }

   private static Path createTemporaryWorldFolder(
      LayeredRegistryAccess<RegistryLayer> p6400de51_6_0, PrimaryLevelData p6400de51_7_1, @Nullable Path p6400de51_8_2
   ) throws IOException {
      Path $$3 = Files.createTempDirectory("minecraft_realms_world_upload");
      if (p6400de51_8_2 != null) {
         Files.move(p6400de51_8_2, $$3.resolve("datapacks"));
      }

      CompoundTag $$4 = p6400de51_7_1.createTag(p6400de51_6_0.compositeAccess(), null);
      CompoundTag $$5 = new CompoundTag();
      $$5.put("Data", $$4);
      Path $$6 = Files.createFile($$3.resolve("level.dat"));
      NbtIo.writeCompressed($$5, $$6);
      return $$3;
   }
}
