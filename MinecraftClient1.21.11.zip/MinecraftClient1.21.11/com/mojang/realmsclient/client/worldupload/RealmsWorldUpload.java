package com.mojang.realmsclient.client.worldupload;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.FileUpload;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsSlot;
import com.mojang.realmsclient.dto.UploadInfo;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.exception.RetryCallException;
import com.mojang.realmsclient.gui.screens.UploadResult;
import com.mojang.realmsclient.util.UploadTokenCache;
import java.io.File;
import java.nio.file.Path;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import net.minecraft.SharedConstants;
import net.minecraft.client.User;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsWorldUpload {
   private static final Logger LOGGER = LogUtils.getLogger();
   public static final int UPLOAD_RETRIES = 20;
   private final RealmsClient client = RealmsClient.getOrCreate();
   private final Path worldFolder;
   private final RealmsSlot realmsSlot;
   private final User user;
   private final long realmId;
   private final RealmsWorldUploadStatusTracker statusCallback;
   private volatile boolean cancelled;
   private volatile @Nullable CompletableFuture<?> uploadTask;

   public RealmsWorldUpload(Path pb7803ac0_0_0, RealmsSlot pb7803ac0_1_1, User pb7803ac0_2_2, long pb7803ac0_3_3, RealmsWorldUploadStatusTracker pb7803ac0_4_4) {
      this.worldFolder = pb7803ac0_0_0;
      this.realmsSlot = pb7803ac0_1_1;
      this.user = pb7803ac0_2_2;
      this.realmId = pb7803ac0_3_3;
      this.statusCallback = pb7803ac0_4_4;
   }

   public CompletableFuture<?> packAndUpload() {
      return CompletableFuture.runAsync(
         () -> {
            File $$0 = null;

            try {
               UploadInfo $$1 = this.requestUploadInfoWithRetries();
               $$0 = RealmsUploadWorldPacker.pack(this.worldFolder, () -> this.cancelled);
               this.statusCallback.setUploading();

               try (FileUpload $$2 = new FileUpload(
                     $$0,
                     this.realmId,
                     this.realmsSlot.slotId,
                     $$1,
                     this.user,
                     SharedConstants.getCurrentVersion().name(),
                     this.realmsSlot.options.version,
                     this.statusCallback.getUploadStatus()
                  )) {
                  CompletableFuture<UploadResult> $$3 = $$2.startUpload();
                  this.uploadTask = $$3;
                  if (!this.cancelled) {
                     UploadResult $$4;
                     try {
                        $$4 = $$3.join();
                     } catch (CompletionException $$5) {
                        throw $$5.getCause();
                     }

                     String $$7 = $$4.getSimplifiedErrorMessage();
                     if ($$7 != null) {
                        throw new RealmsUploadFailedException($$7);
                     }

                     UploadTokenCache.invalidate(this.realmId);
                     this.client.updateSlot(this.realmId, this.realmsSlot.slotId, this.realmsSlot.options, this.realmsSlot.settings);
                     return;
                  }

                  $$3.cancel(true);
               }
            } catch (RealmsServiceException $$8) {
               throw new RealmsUploadFailedException($$8.realmsError.errorMessage());
            } catch (InterruptedException | CancellationException $$9) {
               throw new RealmsUploadCanceledException();
            } catch (RealmsUploadException $$10) {
               throw $$10;
            } catch (Throwable $$11) {
               if ($$11 instanceof Error $$12) {
                  throw $$12;
               }

               throw new RealmsUploadFailedException($$11.getMessage());
            } finally {
               if ($$0 != null) {
                  LOGGER.debug("Deleting file {}", $$0.getAbsolutePath());
                  $$0.delete();
               }
            }
         },
         Util.backgroundExecutor()
      );
   }

   public void cancel() {
      this.cancelled = true;
      CompletableFuture<?> $$0 = this.uploadTask;
      if ($$0 != null) {
         $$0.cancel(true);
      }
   }

   private UploadInfo requestUploadInfoWithRetries() throws RealmsServiceException, InterruptedException {
      for (int $$0 = 0; $$0 < 20; $$0++) {
         try {
            UploadInfo $$1 = this.client.requestUploadInfo(this.realmId);
            if (this.cancelled) {
               throw new RealmsUploadCanceledException();
            }

            if ($$1 != null) {
               if (!$$1.worldClosed()) {
                  throw new RealmsUploadWorldNotClosedException();
               }

               return $$1;
            }
         } catch (RetryCallException $$2) {
            Thread.sleep($$2.delaySeconds * 1000L);
         }
      }

      throw new RealmsUploadWorldNotClosedException();
   }
}
