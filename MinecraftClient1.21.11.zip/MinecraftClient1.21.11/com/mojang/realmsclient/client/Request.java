package com.mojang.realmsclient.client;

import com.mojang.realmsclient.exception.RealmsHttpException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import org.jspecify.annotations.Nullable;

public abstract class Request<T extends Request<T>> {
   protected HttpURLConnection connection;
   private boolean connected;
   protected String url;
   private static final int DEFAULT_READ_TIMEOUT = 60000;
   private static final int DEFAULT_CONNECT_TIMEOUT = 5000;
   private static final String IS_SNAPSHOT_KEY = "Is-Prerelease";
   private static final String COOKIE_KEY = "Cookie";

   public Request(String pd730863c_0_0, int pd730863c_1_1, int pd730863c_2_2) {
      try {
         this.url = pd730863c_0_0;
         Proxy $$3 = RealmsClientConfig.getProxy();
         if ($$3 != null) {
            this.connection = (HttpURLConnection)new URL(pd730863c_0_0).openConnection($$3);
         } else {
            this.connection = (HttpURLConnection)new URL(pd730863c_0_0).openConnection();
         }

         this.connection.setConnectTimeout(pd730863c_1_1);
         this.connection.setReadTimeout(pd730863c_2_2);
      } catch (MalformedURLException $$4) {
         throw new RealmsHttpException($$4.getMessage(), $$4);
      } catch (IOException $$5) {
         throw new RealmsHttpException($$5.getMessage(), $$5);
      }
   }

   public void cookie(String pd730863c_3_0, String pd730863c_4_1) {
      cookie(this.connection, pd730863c_3_0, pd730863c_4_1);
   }

   public static void cookie(HttpURLConnection pd730863c_5_0, String pd730863c_6_1, String pd730863c_7_2) {
      String $$3 = pd730863c_5_0.getRequestProperty("Cookie");
      if ($$3 == null) {
         pd730863c_5_0.setRequestProperty("Cookie", pd730863c_6_1 + "=" + pd730863c_7_2);
      } else {
         pd730863c_5_0.setRequestProperty("Cookie", $$3 + ";" + pd730863c_6_1 + "=" + pd730863c_7_2);
      }
   }

   public void addSnapshotHeader(boolean pd730863c_8_0) {
      this.connection.addRequestProperty("Is-Prerelease", String.valueOf(pd730863c_8_0));
   }

   public int getRetryAfterHeader() {
      return getRetryAfterHeader(this.connection);
   }

   public static int getRetryAfterHeader(HttpURLConnection pd730863c_9_0) {
      String $$1 = pd730863c_9_0.getHeaderField("Retry-After");

      try {
         return Integer.valueOf($$1);
      } catch (Exception $$2) {
         return 5;
      }
   }

   public int responseCode() {
      try {
         this.connect();
         return this.connection.getResponseCode();
      } catch (Exception $$0) {
         throw new RealmsHttpException($$0.getMessage(), $$0);
      }
   }

   public String text() {
      try {
         this.connect();
         String $$0;
         if (this.responseCode() >= 400) {
            $$0 = this.read(this.connection.getErrorStream());
         } else {
            $$0 = this.read(this.connection.getInputStream());
         }

         this.dispose();
         return $$0;
      } catch (IOException $$2) {
         throw new RealmsHttpException($$2.getMessage(), $$2);
      }
   }

   private String read(@Nullable InputStream pd730863c_10_0) throws IOException {
      if (pd730863c_10_0 == null) {
         return "";
      }

      InputStreamReader $$1 = new InputStreamReader(pd730863c_10_0, StandardCharsets.UTF_8);
      StringBuilder $$2 = new StringBuilder();

      for (int $$3 = $$1.read(); $$3 != -1; $$3 = $$1.read()) {
         $$2.append((char)$$3);
      }

      return $$2.toString();
   }

   private void dispose() {
      byte[] $$0 = new byte[1024];

      try {
         InputStream $$1 = this.connection.getInputStream();

         while ($$1.read($$0) > 0) {
         }

         $$1.close();
         return;
      } catch (Exception $$2) {
         try {
            InputStream $$3 = this.connection.getErrorStream();
            if ($$3 != null) {
               while ($$3.read($$0) > 0) {
               }

               $$3.close();
               return;
            }
         } catch (IOException var8) {
            return;
         }
      } finally {
         if (this.connection != null) {
            this.connection.disconnect();
         }
      }
   }

   protected T connect() {
      if (this.connected) {
         return (T)this;
      }

      T $$0 = this.doConnect();
      this.connected = true;
      return $$0;
   }

   protected abstract T doConnect();

   public static Request<?> get(String pd730863c_11_0) {
      return new Request.Get(pd730863c_11_0, 5000, 60000);
   }

   public static Request<?> get(String pd730863c_12_0, int pd730863c_13_1, int pd730863c_14_2) {
      return new Request.Get(pd730863c_12_0, pd730863c_13_1, pd730863c_14_2);
   }

   public static Request<?> post(String pd730863c_15_0, String pd730863c_16_1) {
      return new Request.Post(pd730863c_15_0, pd730863c_16_1, 5000, 60000);
   }

   public static Request<?> post(String pd730863c_17_0, String pd730863c_18_1, int pd730863c_19_2, int pd730863c_20_3) {
      return new Request.Post(pd730863c_17_0, pd730863c_18_1, pd730863c_19_2, pd730863c_20_3);
   }

   public static Request<?> delete(String pd730863c_21_0) {
      return new Request.Delete(pd730863c_21_0, 5000, 60000);
   }

   public static Request<?> put(String pd730863c_22_0, String pd730863c_23_1) {
      return new Request.Put(pd730863c_22_0, pd730863c_23_1, 5000, 60000);
   }

   public static Request<?> put(String pd730863c_24_0, String pd730863c_25_1, int pd730863c_26_2, int pd730863c_27_3) {
      return new Request.Put(pd730863c_24_0, pd730863c_25_1, pd730863c_26_2, pd730863c_27_3);
   }

   public String getHeader(String pd730863c_28_0) {
      return getHeader(this.connection, pd730863c_28_0);
   }

   public static String getHeader(HttpURLConnection pd730863c_29_0, String pd730863c_30_1) {
      try {
         return pd730863c_29_0.getHeaderField(pd730863c_30_1);
      } catch (Exception $$2) {
         return "";
      }
   }

   public static class Delete extends Request<Request.Delete> {
      public Delete(String pd33f0533_0_0, int pd33f0533_1_1, int pd33f0533_2_2) {
         super(pd33f0533_0_0, pd33f0533_1_1, pd33f0533_2_2);
      }

      public Request.Delete doConnect() {
         try {
            this.connection.setDoOutput(true);
            this.connection.setRequestMethod("DELETE");
            this.connection.connect();
            return this;
         } catch (Exception $$0) {
            throw new RealmsHttpException($$0.getMessage(), $$0);
         }
      }
   }

   public static class Get extends Request<Request.Get> {
      public Get(String p22dc7cce_0_0, int p22dc7cce_1_1, int p22dc7cce_2_2) {
         super(p22dc7cce_0_0, p22dc7cce_1_1, p22dc7cce_2_2);
      }

      public Request.Get doConnect() {
         try {
            this.connection.setDoInput(true);
            this.connection.setDoOutput(true);
            this.connection.setUseCaches(false);
            this.connection.setRequestMethod("GET");
            return this;
         } catch (Exception $$0) {
            throw new RealmsHttpException($$0.getMessage(), $$0);
         }
      }
   }

   public static class Post extends Request<Request.Post> {
      private final String content;

      public Post(String p38b75a28_0_0, String p38b75a28_1_1, int p38b75a28_2_2, int p38b75a28_3_3) {
         super(p38b75a28_0_0, p38b75a28_2_2, p38b75a28_3_3);
         this.content = p38b75a28_1_1;
      }

      public Request.Post doConnect() {
         try {
            if (this.content != null) {
               this.connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            }

            this.connection.setDoInput(true);
            this.connection.setDoOutput(true);
            this.connection.setUseCaches(false);
            this.connection.setRequestMethod("POST");
            OutputStream $$0 = this.connection.getOutputStream();
            OutputStreamWriter $$1 = new OutputStreamWriter($$0, StandardCharsets.UTF_8);
            $$1.write(this.content);
            $$1.close();
            $$0.flush();
            return this;
         } catch (Exception $$2) {
            throw new RealmsHttpException($$2.getMessage(), $$2);
         }
      }
   }

   public static class Put extends Request<Request.Put> {
      private final String content;

      public Put(String p22dca087_0_0, String p22dca087_1_1, int p22dca087_2_2, int p22dca087_3_3) {
         super(p22dca087_0_0, p22dca087_2_2, p22dca087_3_3);
         this.content = p22dca087_1_1;
      }

      public Request.Put doConnect() {
         try {
            if (this.content != null) {
               this.connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            }

            this.connection.setDoOutput(true);
            this.connection.setDoInput(true);
            this.connection.setRequestMethod("PUT");
            OutputStream $$0 = this.connection.getOutputStream();
            OutputStreamWriter $$1 = new OutputStreamWriter($$0, StandardCharsets.UTF_8);
            $$1.write(this.content);
            $$1.close();
            $$0.flush();
            return this;
         } catch (Exception $$2) {
            throw new RealmsHttpException($$2.getMessage(), $$2);
         }
      }
   }
}
