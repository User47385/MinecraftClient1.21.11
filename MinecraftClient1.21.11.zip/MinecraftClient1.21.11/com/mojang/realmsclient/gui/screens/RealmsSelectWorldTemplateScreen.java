package com.mojang.realmsclient.gui.screens;

import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Either;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.WorldTemplate;
import com.mojang.realmsclient.dto.WorldTemplatePaginatedList;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.util.RealmsTextureManager;
import com.mojang.realmsclient.util.TextRenderingUtils;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.resources.Identifier;
import net.minecraft.util.CommonLinks;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsSelectWorldTemplateScreen extends RealmsScreen {
   static final Logger LOGGER = LogUtils.getLogger();
   static final Identifier SLOT_FRAME_SPRITE = Identifier.withDefaultNamespace("widget/slot_frame");
   private static final Component SELECT_BUTTON_NAME = Component.translatable("mco.template.button.select");
   private static final Component TRAILER_BUTTON_NAME = Component.translatable("mco.template.button.trailer");
   private static final Component PUBLISHER_BUTTON_NAME = Component.translatable("mco.template.button.publisher");
   private static final int BUTTON_WIDTH = 100;
   final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);
   final Consumer<WorldTemplate> callback;
   RealmsSelectWorldTemplateScreen.WorldTemplateList worldTemplateList;
   private final RealmsServer.WorldType worldType;
   private final List<Component> subtitle;
   private Button selectButton;
   private Button trailerButton;
   private Button publisherButton;
   @Nullable WorldTemplate selectedTemplate = null;
   @Nullable String currentLink;
   @Nullable List<TextRenderingUtils.Line> noTemplatesMessage;

   public RealmsSelectWorldTemplateScreen(
      Component p747db1cb_0_0, Consumer<WorldTemplate> p747db1cb_1_1, RealmsServer.WorldType p747db1cb_2_2, @Nullable WorldTemplatePaginatedList p747db1cb_3_3
   ) {
      this(p747db1cb_0_0, p747db1cb_1_1, p747db1cb_2_2, p747db1cb_3_3, List.of());
   }

   public RealmsSelectWorldTemplateScreen(
      Component p747db1cb_4_0,
      Consumer<WorldTemplate> p747db1cb_5_1,
      RealmsServer.WorldType p747db1cb_6_2,
      @Nullable WorldTemplatePaginatedList p747db1cb_7_3,
      List<Component> p747db1cb_8_4
   ) {
      super(p747db1cb_4_0);
      this.callback = p747db1cb_5_1;
      this.worldType = p747db1cb_6_2;
      if (p747db1cb_7_3 == null) {
         this.worldTemplateList = new RealmsSelectWorldTemplateScreen.WorldTemplateList();
         this.fetchTemplatesAsync(new WorldTemplatePaginatedList(10));
      } else {
         this.worldTemplateList = new RealmsSelectWorldTemplateScreen.WorldTemplateList(Lists.newArrayList(p747db1cb_7_3.templates()));
         this.fetchTemplatesAsync(p747db1cb_7_3);
      }

      this.subtitle = p747db1cb_8_4;
   }

   @Override
   public void init() {
      this.layout.setHeaderHeight(33 + this.subtitle.size() * (9 + 4));
      LinearLayout $$0 = this.layout.addToHeader(LinearLayout.vertical().spacing(4));
      $$0.defaultCellSetting().alignHorizontallyCenter();
      $$0.addChild(new StringWidget(this.title, this.font));
      this.subtitle.forEach(p747db1cb_28_1 -> $$0.addChild(new StringWidget(p747db1cb_28_1, this.font)));
      this.worldTemplateList = this.layout.addToContents(new RealmsSelectWorldTemplateScreen.WorldTemplateList(this.worldTemplateList.getTemplates()));
      LinearLayout $$1 = this.layout.addToFooter(LinearLayout.horizontal().spacing(8));
      $$1.defaultCellSetting().alignHorizontallyCenter();
      this.trailerButton = $$1.addChild(Button.builder(TRAILER_BUTTON_NAME, p747db1cb_26_0 -> this.onTrailer()).width(100).build());
      this.selectButton = $$1.addChild(Button.builder(SELECT_BUTTON_NAME, p747db1cb_25_0 -> this.selectTemplate()).width(100).build());
      $$1.addChild(Button.builder(CommonComponents.GUI_CANCEL, p747db1cb_24_0 -> this.onClose()).width(100).build());
      this.publisherButton = $$1.addChild(Button.builder(PUBLISHER_BUTTON_NAME, p747db1cb_23_0 -> this.onPublish()).width(100).build());
      this.updateButtonStates();
      this.layout.visitWidgets(p747db1cb_22_1 -> {
         AbstractWidget var10000 = this.addRenderableWidget(p747db1cb_22_1);
      });
      this.repositionElements();
   }

   @Override
   protected void repositionElements() {
      this.worldTemplateList.updateSize(this.width, this.layout);
      this.layout.arrangeElements();
   }

   @Override
   public Component getNarrationMessage() {
      List<Component> $$0 = Lists.newArrayListWithCapacity(2);
      $$0.add(this.title);
      $$0.addAll(this.subtitle);
      return CommonComponents.joinLines($$0);
   }

   void updateButtonStates() {
      this.publisherButton.visible = this.selectedTemplate != null && !this.selectedTemplate.link().isEmpty();
      this.trailerButton.visible = this.selectedTemplate != null && !this.selectedTemplate.trailer().isEmpty();
      this.selectButton.active = this.selectedTemplate != null;
   }

   @Override
   public void onClose() {
      this.callback.accept(null);
   }

   private void selectTemplate() {
      if (this.selectedTemplate != null) {
         this.callback.accept(this.selectedTemplate);
      }
   }

   private void onTrailer() {
      if (this.selectedTemplate != null && !this.selectedTemplate.trailer().isBlank()) {
         ConfirmLinkScreen.confirmLinkNow(this, this.selectedTemplate.trailer());
      }
   }

   private void onPublish() {
      if (this.selectedTemplate != null && !this.selectedTemplate.link().isBlank()) {
         ConfirmLinkScreen.confirmLinkNow(this, this.selectedTemplate.link());
      }
   }

   private void fetchTemplatesAsync(WorldTemplatePaginatedList p747db1cb_9_0) {
      (new Thread("realms-template-fetcher") {
            @Override
            public void run() {
               WorldTemplatePaginatedList $$0 = p747db1cb_9_0;
               RealmsClient $$1 = RealmsClient.getOrCreate();

               while ($$0 != null) {
                  Either<WorldTemplatePaginatedList, Exception> $$2 = RealmsSelectWorldTemplateScreen.this.fetchTemplates($$0, $$1);
                  $$0 = RealmsSelectWorldTemplateScreen.this.minecraft
                     .submit(
                        () -> {
                           if ($$2.right().isPresent()) {
                              RealmsSelectWorldTemplateScreen.LOGGER.error("Couldn't fetch templates", $$2.right().get());
                              if (RealmsSelectWorldTemplateScreen.this.worldTemplateList.isEmpty()) {
                                 RealmsSelectWorldTemplateScreen.this.noTemplatesMessage = TextRenderingUtils.decompose(I18n.get("mco.template.select.failure"));
                              }

                              return null;
                           } else {
                              WorldTemplatePaginatedList $$1x = $$2.left().get();

                              for (WorldTemplate $$2x : $$1x.templates()) {
                                 RealmsSelectWorldTemplateScreen.this.worldTemplateList.addEntry($$2x);
                              }

                              if ($$1x.templates().isEmpty()) {
                                 if (RealmsSelectWorldTemplateScreen.this.worldTemplateList.isEmpty()) {
                                    String $$3 = I18n.get("mco.template.select.none", "%link");
                                    TextRenderingUtils.LineSegment $$4 = TextRenderingUtils.LineSegment.link(
                                       I18n.get("mco.template.select.none.linkTitle"), CommonLinks.REALMS_CONTENT_CREATION.toString()
                                    );
                                    RealmsSelectWorldTemplateScreen.this.noTemplatesMessage = TextRenderingUtils.decompose($$3, $$4);
                                 }

                                 return null;
                              } else {
                                 return $$1x;
                              }
                           }
                        }
                     )
                     .join();
               }
            }
         })
         .start();
   }

   Either<WorldTemplatePaginatedList, Exception> fetchTemplates(WorldTemplatePaginatedList p747db1cb_10_0, RealmsClient p747db1cb_11_1) {
      try {
         return Either.left(p747db1cb_11_1.fetchWorldTemplates(p747db1cb_10_0.page() + 1, p747db1cb_10_0.size(), this.worldType));
      } catch (RealmsServiceException $$2) {
         return Either.right($$2);
      }
   }

   @Override
   public void render(GuiGraphics p747db1cb_12_0, int p747db1cb_13_1, int p747db1cb_14_2, float p747db1cb_15_3) {
      super.render(p747db1cb_12_0, p747db1cb_13_1, p747db1cb_14_2, p747db1cb_15_3);
      this.currentLink = null;
      if (this.noTemplatesMessage != null) {
         this.renderMultilineMessage(p747db1cb_12_0, p747db1cb_13_1, p747db1cb_14_2, this.noTemplatesMessage);
      }
   }

   private void renderMultilineMessage(GuiGraphics p747db1cb_16_0, int p747db1cb_17_1, int p747db1cb_18_2, List<TextRenderingUtils.Line> p747db1cb_19_3) {
      for (int $$4 = 0; $$4 < p747db1cb_19_3.size(); $$4++) {
         TextRenderingUtils.Line $$5 = p747db1cb_19_3.get($$4);
         int $$6 = row(4 + $$4);
         int $$7 = $$5.segments.stream().mapToInt(p747db1cb_20_0 -> this.font.width(p747db1cb_20_0.renderedText())).sum();
         int $$8 = this.width / 2 - $$7 / 2;

         for (TextRenderingUtils.LineSegment $$9 : $$5.segments) {
            int $$10 = $$9.isLink() ? -13408581 : -1;
            String $$11 = $$9.renderedText();
            p747db1cb_16_0.drawString(this.font, $$11, $$8, $$6, $$10);
            int $$12 = $$8 + this.font.width($$11);
            if ($$9.isLink() && p747db1cb_17_1 > $$8 && p747db1cb_17_1 < $$12 && p747db1cb_18_2 > $$6 - 3 && p747db1cb_18_2 < $$6 + 8) {
               p747db1cb_16_0.setTooltipForNextFrame(Component.literal($$9.getLinkUrl()), p747db1cb_17_1, p747db1cb_18_2);
               this.currentLink = $$9.getLinkUrl();
            }

            $$8 = $$12;
         }
      }
   }

   class Entry extends ObjectSelectionList.Entry<RealmsSelectWorldTemplateScreen.Entry> {
      private static final WidgetSprites WEBSITE_LINK_SPRITES = new WidgetSprites(
         Identifier.withDefaultNamespace("icon/link"), Identifier.withDefaultNamespace("icon/link_highlighted")
      );
      private static final WidgetSprites TRAILER_LINK_SPRITES = new WidgetSprites(
         Identifier.withDefaultNamespace("icon/video_link"), Identifier.withDefaultNamespace("icon/video_link_highlighted")
      );
      private static final Component PUBLISHER_LINK_TOOLTIP = Component.translatable("mco.template.info.tooltip");
      private static final Component TRAILER_LINK_TOOLTIP = Component.translatable("mco.template.trailer.tooltip");
      public final WorldTemplate template;
      private @Nullable ImageButton websiteButton;
      private @Nullable ImageButton trailerButton;

      public Entry(final WorldTemplate pc5b47c39_1_1) {
         this.template = pc5b47c39_1_1;
         if (!pc5b47c39_1_1.link().isBlank()) {
            this.websiteButton = new ImageButton(
               15, 15, WEBSITE_LINK_SPRITES, ConfirmLinkScreen.confirmLink(RealmsSelectWorldTemplateScreen.this, pc5b47c39_1_1.link()), PUBLISHER_LINK_TOOLTIP
            );
            this.websiteButton.setTooltip(Tooltip.create(PUBLISHER_LINK_TOOLTIP));
         }

         if (!pc5b47c39_1_1.trailer().isBlank()) {
            this.trailerButton = new ImageButton(
               15, 15, TRAILER_LINK_SPRITES, ConfirmLinkScreen.confirmLink(RealmsSelectWorldTemplateScreen.this, pc5b47c39_1_1.trailer()), TRAILER_LINK_TOOLTIP
            );
            this.trailerButton.setTooltip(Tooltip.create(TRAILER_LINK_TOOLTIP));
         }
      }

      @Override
      public boolean mouseClicked(MouseButtonEvent pc5b47c39_2_0, boolean pc5b47c39_3_1) {
         RealmsSelectWorldTemplateScreen.this.selectedTemplate = this.template;
         RealmsSelectWorldTemplateScreen.this.updateButtonStates();
         if (pc5b47c39_3_1 && this.isFocused()) {
            RealmsSelectWorldTemplateScreen.this.callback.accept(this.template);
         }

         if (this.websiteButton != null) {
            this.websiteButton.mouseClicked(pc5b47c39_2_0, pc5b47c39_3_1);
         }

         if (this.trailerButton != null) {
            this.trailerButton.mouseClicked(pc5b47c39_2_0, pc5b47c39_3_1);
         }

         return super.mouseClicked(pc5b47c39_2_0, pc5b47c39_3_1);
      }

      @Override
      public void renderContent(GuiGraphics pc5b47c39_4_0, int pc5b47c39_5_1, int pc5b47c39_6_2, boolean pc5b47c39_7_3, float pc5b47c39_8_4) {
         pc5b47c39_4_0.blit(
            RenderPipelines.GUI_TEXTURED,
            RealmsTextureManager.worldTemplate(this.template.id(), this.template.image()),
            this.getContentX() + 1,
            this.getContentY() + 1 + 1,
            0.0F,
            0.0F,
            38,
            38,
            38,
            38
         );
         pc5b47c39_4_0.blitSprite(
            RenderPipelines.GUI_TEXTURED, RealmsSelectWorldTemplateScreen.SLOT_FRAME_SPRITE, this.getContentX(), this.getContentY() + 1, 40, 40
         );
         int $$5 = 5;
         int $$6 = RealmsSelectWorldTemplateScreen.this.font.width(this.template.version());
         if (this.websiteButton != null) {
            this.websiteButton.setPosition(this.getContentRight() - $$6 - this.websiteButton.getWidth() - 10, this.getContentY());
            this.websiteButton.render(pc5b47c39_4_0, pc5b47c39_5_1, pc5b47c39_6_2, pc5b47c39_8_4);
         }

         if (this.trailerButton != null) {
            this.trailerButton.setPosition(this.getContentRight() - $$6 - this.trailerButton.getWidth() * 2 - 15, this.getContentY());
            this.trailerButton.render(pc5b47c39_4_0, pc5b47c39_5_1, pc5b47c39_6_2, pc5b47c39_8_4);
         }

         int $$7 = this.getContentX() + 45 + 20;
         int $$8 = this.getContentY() + 5;
         pc5b47c39_4_0.drawString(RealmsSelectWorldTemplateScreen.this.font, this.template.name(), $$7, $$8, -1);
         pc5b47c39_4_0.drawString(RealmsSelectWorldTemplateScreen.this.font, this.template.version(), this.getContentRight() - $$6 - 5, $$8, -6250336);
         pc5b47c39_4_0.drawString(RealmsSelectWorldTemplateScreen.this.font, this.template.author(), $$7, $$8 + 9 + 5, -6250336);
         if (!this.template.recommendedPlayers().isBlank()) {
            pc5b47c39_4_0.drawString(
               RealmsSelectWorldTemplateScreen.this.font, this.template.recommendedPlayers(), $$7, this.getContentBottom() - 9 / 2 - 5, -8355712
            );
         }
      }

      @Override
      public Component getNarration() {
         Component $$0 = CommonComponents.joinLines(
            Component.literal(this.template.name()),
            Component.translatable("mco.template.select.narrate.authors", this.template.author()),
            Component.literal(this.template.recommendedPlayers()),
            Component.translatable("mco.template.select.narrate.version", this.template.version())
         );
         return Component.translatable("narrator.select", $$0);
      }
   }

   class WorldTemplateList extends ObjectSelectionList<RealmsSelectWorldTemplateScreen.Entry> {
      public WorldTemplateList() {
         this(Collections.emptyList());
      }

      public WorldTemplateList(final Iterable<WorldTemplate> p377cca31_2_1) {
         super(
            Minecraft.getInstance(),
            RealmsSelectWorldTemplateScreen.this.width,
            RealmsSelectWorldTemplateScreen.this.layout.getContentHeight(),
            RealmsSelectWorldTemplateScreen.this.layout.getHeaderHeight(),
            46
         );
         p377cca31_2_1.forEach(this::addEntry);
      }

      public void addEntry(WorldTemplate p377cca31_3_0) {
         this.addEntry(RealmsSelectWorldTemplateScreen.this.new Entry(p377cca31_3_0));
      }

      @Override
      public boolean mouseClicked(MouseButtonEvent p377cca31_4_0, boolean p377cca31_5_1) {
         if (RealmsSelectWorldTemplateScreen.this.currentLink != null) {
            ConfirmLinkScreen.confirmLinkNow(RealmsSelectWorldTemplateScreen.this, RealmsSelectWorldTemplateScreen.this.currentLink);
            return true;
         } else {
            return super.mouseClicked(p377cca31_4_0, p377cca31_5_1);
         }
      }

      public void setSelected(RealmsSelectWorldTemplateScreen.@Nullable Entry p377cca31_6_0) {
         super.setSelected(p377cca31_6_0);
         RealmsSelectWorldTemplateScreen.this.selectedTemplate = p377cca31_6_0 == null ? null : p377cca31_6_0.template;
         RealmsSelectWorldTemplateScreen.this.updateButtonStates();
      }

      @Override
      public int getRowWidth() {
         return 300;
      }

      public boolean isEmpty() {
         return this.getItemCount() == 0;
      }

      public List<WorldTemplate> getTemplates() {
         return this.children().stream().map(p377cca31_8_0 -> p377cca31_8_0.template).collect(Collectors.toList());
      }
   }
}
