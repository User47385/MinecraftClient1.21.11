package com.mojang.realmsclient.gui.screens;

import com.google.common.collect.Lists;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.RealmsSlot;
import com.mojang.realmsclient.dto.WorldDownload;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.gui.RealmsWorldSlotButton;
import com.mojang.realmsclient.util.RealmsTextureManager;
import com.mojang.realmsclient.util.RealmsUtil;
import com.mojang.realmsclient.util.task.OpenServerTask;
import com.mojang.realmsclient.util.task.SwitchSlotTask;
import java.util.List;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsBrokenWorldScreen extends RealmsScreen {
   private static final Identifier SLOT_FRAME_SPRITE = Identifier.withDefaultNamespace("widget/slot_frame");
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final int DEFAULT_BUTTON_WIDTH = 80;
   private final Screen lastScreen;
   private @Nullable RealmsServer serverData;
   private final long serverId;
   private final Component[] message = new Component[]{
      Component.translatable("mco.brokenworld.message.line1"), Component.translatable("mco.brokenworld.message.line2")
   };
   private int leftX;
   private final List<Integer> slotsThatHasBeenDownloaded = Lists.newArrayList();
   private int animTick;

   public RealmsBrokenWorldScreen(Screen p775f7d38_0_0, long p775f7d38_1_1, boolean p775f7d38_2_2) {
      super(p775f7d38_2_2 ? Component.translatable("mco.brokenworld.minigame.title") : Component.translatable("mco.brokenworld.title"));
      this.lastScreen = p775f7d38_0_0;
      this.serverId = p775f7d38_1_1;
   }

   @Override
   public void init() {
      this.leftX = this.width / 2 - 150;
      this.addRenderableWidget(
         Button.builder(CommonComponents.GUI_BACK, p775f7d38_35_0 -> this.onClose()).bounds((this.width - 150) / 2, row(13) - 5, 150, 20).build()
      );
      if (this.serverData == null) {
         this.fetchServerData(this.serverId);
      } else {
         this.addButtons();
      }
   }

   @Override
   public Component getNarrationMessage() {
      return ComponentUtils.formatList(Stream.concat(Stream.of(this.title), Stream.of(this.message)).collect(Collectors.toList()), CommonComponents.SPACE);
   }

   private void addButtons() {
      for (Entry<Integer, RealmsSlot> $$0 : this.serverData.slots.entrySet()) {
         int $$1 = $$0.getKey();
         boolean $$2 = $$1 != this.serverData.activeSlot || this.serverData.isMinigameActive();
         Button $$3;
         if ($$2) {
            $$3 = Button.builder(
                  Component.translatable("mco.brokenworld.play"),
                  p775f7d38_34_1 -> this.minecraft
                     .setScreen(new RealmsLongRunningMcoTaskScreen(this.lastScreen, new SwitchSlotTask(this.serverData.id, $$1, this::doSwitchOrReset)))
               )
               .bounds(this.getFramePositionX($$1), row(8), 80, 20)
               .build();
            $$3.active = !this.serverData.slots.get($$1).options.empty;
         } else {
            $$3 = Button.builder(
                  Component.translatable("mco.brokenworld.download"),
                  p775f7d38_30_1 -> this.minecraft
                     .setScreen(
                        RealmsPopups.infoPopupScreen(
                           this, Component.translatable("mco.configure.world.restore.download.question.line1"), p775f7d38_32_1 -> this.downloadWorld($$1)
                        )
                     )
               )
               .bounds(this.getFramePositionX($$1), row(8), 80, 20)
               .build();
         }

         if (this.slotsThatHasBeenDownloaded.contains($$1)) {
            $$3.active = false;
            $$3.setMessage(Component.translatable("mco.brokenworld.downloaded"));
         }

         this.addRenderableWidget($$3);
      }
   }

   @Override
   public void tick() {
      this.animTick++;
   }

   @Override
   public void render(GuiGraphics p775f7d38_3_0, int p775f7d38_4_1, int p775f7d38_5_2, float p775f7d38_6_3) {
      super.render(p775f7d38_3_0, p775f7d38_4_1, p775f7d38_5_2, p775f7d38_6_3);
      p775f7d38_3_0.drawCenteredString(this.font, this.title, this.width / 2, 17, -1);

      for (int $$4 = 0; $$4 < this.message.length; $$4++) {
         p775f7d38_3_0.drawCenteredString(this.font, this.message[$$4], this.width / 2, row(-1) + 3 + $$4 * 12, -6250336);
      }

      if (this.serverData != null) {
         for (Entry<Integer, RealmsSlot> $$5 : this.serverData.slots.entrySet()) {
            if ($$5.getValue().options.templateImage != null && $$5.getValue().options.templateId != -1L) {
               this.drawSlotFrame(
                  p775f7d38_3_0,
                  this.getFramePositionX($$5.getKey()),
                  row(1) + 5,
                  p775f7d38_4_1,
                  p775f7d38_5_2,
                  this.serverData.activeSlot == $$5.getKey() && !this.isMinigame(),
                  $$5.getValue().options.getSlotName($$5.getKey()),
                  $$5.getKey(),
                  $$5.getValue().options.templateId,
                  $$5.getValue().options.templateImage,
                  $$5.getValue().options.empty
               );
            } else {
               this.drawSlotFrame(
                  p775f7d38_3_0,
                  this.getFramePositionX($$5.getKey()),
                  row(1) + 5,
                  p775f7d38_4_1,
                  p775f7d38_5_2,
                  this.serverData.activeSlot == $$5.getKey() && !this.isMinigame(),
                  $$5.getValue().options.getSlotName($$5.getKey()),
                  $$5.getKey(),
                  -1L,
                  null,
                  $$5.getValue().options.empty
               );
            }
         }
      }
   }

   private int getFramePositionX(int p775f7d38_7_0) {
      return this.leftX + (p775f7d38_7_0 - 1) * 110;
   }

   public Screen createErrorScreen(RealmsServiceException p775f7d38_8_0) {
      return new RealmsGenericErrorScreen(p775f7d38_8_0, this.lastScreen);
   }

   private void fetchServerData(long p775f7d38_9_0) {
      RealmsUtil.<RealmsServer>supplyAsync(
            p775f7d38_28_1 -> p775f7d38_28_1.getOwnRealm(p775f7d38_9_0),
            RealmsUtil.openScreenAndLogOnFailure(this::createErrorScreen, "Couldn't get own world")
         )
         .thenAcceptAsync(p775f7d38_26_0 -> {
            this.serverData = p775f7d38_26_0;
            this.addButtons();
         }, this.minecraft);
   }

   public void doSwitchOrReset() {
      new Thread(
            () -> {
               RealmsClient $$0 = RealmsClient.getOrCreate();
               if (this.serverData.state == RealmsServer.State.CLOSED) {
                  this.minecraft
                     .execute(
                        () -> this.minecraft
                           .setScreen(new RealmsLongRunningMcoTaskScreen(this, new OpenServerTask(this.serverData, this, true, this.minecraft)))
                     );
               } else {
                  try {
                     RealmsServer $$1 = $$0.getOwnRealm(this.serverId);
                     this.minecraft.execute(() -> RealmsMainScreen.play($$1, this));
                  } catch (RealmsServiceException $$2) {
                     LOGGER.error("Couldn't get own world", $$2);
                     this.minecraft.execute(() -> this.minecraft.setScreen(this.createErrorScreen($$2)));
                  }
               }
            }
         )
         .start();
   }

   private void downloadWorld(int p775f7d38_10_0) {
      RealmsClient $$1 = RealmsClient.getOrCreate();

      try {
         WorldDownload $$2 = $$1.requestDownloadInfo(this.serverData.id, p775f7d38_10_0);
         RealmsDownloadLatestWorldScreen $$3 = new RealmsDownloadLatestWorldScreen(this, $$2, this.serverData.getWorldName(p775f7d38_10_0), p775f7d38_23_1 -> {
            if (p775f7d38_23_1) {
               this.slotsThatHasBeenDownloaded.add(p775f7d38_10_0);
               this.clearWidgets();
               this.addButtons();
            } else {
               this.minecraft.setScreen(this);
            }
         });
         this.minecraft.setScreen($$3);
      } catch (RealmsServiceException $$4) {
         LOGGER.error("Couldn't download world data", $$4);
         this.minecraft.setScreen(new RealmsGenericErrorScreen($$4, this));
      }
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.lastScreen);
   }

   private boolean isMinigame() {
      return this.serverData != null && this.serverData.isMinigameActive();
   }

   private void drawSlotFrame(
      GuiGraphics p775f7d38_11_0,
      int p775f7d38_12_1,
      int p775f7d38_13_2,
      int p775f7d38_14_3,
      int p775f7d38_15_4,
      boolean p775f7d38_16_5,
      String p775f7d38_17_6,
      int p775f7d38_18_7,
      long p775f7d38_19_8,
      @Nullable String p775f7d38_20_9,
      boolean p775f7d38_21_10
   ) {
      Identifier $$11;
      if (p775f7d38_21_10) {
         $$11 = RealmsWorldSlotButton.EMPTY_SLOT_LOCATION;
      } else if (p775f7d38_20_9 != null && p775f7d38_19_8 != -1L) {
         $$11 = RealmsTextureManager.worldTemplate(String.valueOf(p775f7d38_19_8), p775f7d38_20_9);
      } else if (p775f7d38_18_7 == 1) {
         $$11 = RealmsWorldSlotButton.DEFAULT_WORLD_SLOT_1;
      } else if (p775f7d38_18_7 == 2) {
         $$11 = RealmsWorldSlotButton.DEFAULT_WORLD_SLOT_2;
      } else if (p775f7d38_18_7 == 3) {
         $$11 = RealmsWorldSlotButton.DEFAULT_WORLD_SLOT_3;
      } else {
         $$11 = RealmsTextureManager.worldTemplate(String.valueOf(this.serverData.minigameId), this.serverData.minigameImage);
      }

      if (p775f7d38_16_5) {
         float $$17 = 0.9F + 0.1F * Mth.cos(this.animTick * 0.2F);
         p775f7d38_11_0.blit(
            RenderPipelines.GUI_TEXTURED,
            $$11,
            p775f7d38_12_1 + 3,
            p775f7d38_13_2 + 3,
            0.0F,
            0.0F,
            74,
            74,
            74,
            74,
            74,
            74,
            ARGB.colorFromFloat(1.0F, $$17, $$17, $$17)
         );
         p775f7d38_11_0.blitSprite(RenderPipelines.GUI_TEXTURED, SLOT_FRAME_SPRITE, p775f7d38_12_1, p775f7d38_13_2, 80, 80);
      } else {
         int $$18 = ARGB.colorFromFloat(1.0F, 0.56F, 0.56F, 0.56F);
         p775f7d38_11_0.blit(RenderPipelines.GUI_TEXTURED, $$11, p775f7d38_12_1 + 3, p775f7d38_13_2 + 3, 0.0F, 0.0F, 74, 74, 74, 74, 74, 74, $$18);
         p775f7d38_11_0.blitSprite(RenderPipelines.GUI_TEXTURED, SLOT_FRAME_SPRITE, p775f7d38_12_1, p775f7d38_13_2, 80, 80, $$18);
      }

      p775f7d38_11_0.drawCenteredString(this.font, p775f7d38_17_6, p775f7d38_12_1 + 40, p775f7d38_13_2 + 66, -1);
   }
}
