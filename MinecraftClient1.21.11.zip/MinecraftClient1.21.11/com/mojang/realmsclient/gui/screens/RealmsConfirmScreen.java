package com.mojang.realmsclient.gui.screens;

import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import net.minecraft.client.GameNarrator;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;

public class RealmsConfirmScreen extends RealmsScreen {
   protected BooleanConsumer callback;
   private final Component title1;
   private final Component title2;

   public RealmsConfirmScreen(BooleanConsumer pd6f1747b_0_0, Component pd6f1747b_1_1, Component pd6f1747b_2_2) {
      super(GameNarrator.NO_TITLE);
      this.callback = pd6f1747b_0_0;
      this.title1 = pd6f1747b_1_1;
      this.title2 = pd6f1747b_2_2;
   }

   @Override
   public void init() {
      this.addRenderableWidget(
         Button.builder(CommonComponents.GUI_YES, pd6f1747b_8_0 -> this.callback.accept(true)).bounds(this.width / 2 - 105, row(9), 100, 20).build()
      );
      this.addRenderableWidget(
         Button.builder(CommonComponents.GUI_NO, pd6f1747b_7_0 -> this.callback.accept(false)).bounds(this.width / 2 + 5, row(9), 100, 20).build()
      );
   }

   @Override
   public void render(GuiGraphics pd6f1747b_3_0, int pd6f1747b_4_1, int pd6f1747b_5_2, float pd6f1747b_6_3) {
      super.render(pd6f1747b_3_0, pd6f1747b_4_1, pd6f1747b_5_2, pd6f1747b_6_3);
      pd6f1747b_3_0.drawCenteredString(this.font, this.title1, this.width / 2, row(3), -1);
      pd6f1747b_3_0.drawCenteredString(this.font, this.title2, this.width / 2, row(5), -1);
   }
}
