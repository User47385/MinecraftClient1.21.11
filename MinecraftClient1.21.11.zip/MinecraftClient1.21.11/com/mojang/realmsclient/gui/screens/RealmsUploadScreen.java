package com.mojang.realmsclient.gui.screens;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.RateLimiter;
import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.Unit;
import com.mojang.realmsclient.client.UploadStatus;
import com.mojang.realmsclient.client.worldupload.RealmsUploadException;
import com.mojang.realmsclient.client.worldupload.RealmsWorldUpload;
import com.mojang.realmsclient.client.worldupload.RealmsWorldUploadStatusTracker;
import com.mojang.realmsclient.dto.RealmsSetting;
import com.mojang.realmsclient.dto.RealmsSlot;
import com.mojang.realmsclient.dto.RealmsWorldOptions;
import com.mojang.realmsclient.gui.screens.configuration.RealmsConfigureWorldScreen;
import com.mojang.realmsclient.util.task.LongRunningTask;
import com.mojang.realmsclient.util.task.RealmCreationTask;
import com.mojang.realmsclient.util.task.SwitchSlotTask;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletionException;
import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.client.GameNarrator;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.world.level.storage.LevelSummary;
import org.jspecify.annotations.Nullable;

public class RealmsUploadScreen extends RealmsScreen implements RealmsWorldUploadStatusTracker {
   private static final int BAR_WIDTH = 200;
   private static final int BAR_TOP = 80;
   private static final int BAR_BOTTOM = 95;
   private static final int BAR_BORDER = 1;
   private static final String[] DOTS = new String[]{"", ".", ". .", ". . ."};
   private static final Component VERIFYING_TEXT = Component.translatable("mco.upload.verifying");
   private final RealmsResetWorldScreen lastScreen;
   private final LevelSummary selectedLevel;
   private final @Nullable RealmCreationTask realmCreationTask;
   private final long realmId;
   private final int slotId;
   final AtomicReference<@Nullable RealmsWorldUpload> currentUpload = new AtomicReference<>();
   private final UploadStatus uploadStatus;
   private final RateLimiter narrationRateLimiter;
   private volatile Component @Nullable [] errorMessage;
   private volatile Component status = Component.translatable("mco.upload.preparing");
   private volatile @Nullable String progress;
   private volatile boolean cancelled;
   private volatile boolean uploadFinished;
   private volatile boolean showDots = true;
   private volatile boolean uploadStarted;
   private @Nullable Button backButton;
   private @Nullable Button cancelButton;
   private int tickCount;
   private final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);

   public RealmsUploadScreen(
      @Nullable RealmCreationTask p4e5a22be_0_0, long p4e5a22be_1_1, int p4e5a22be_2_2, RealmsResetWorldScreen p4e5a22be_3_3, LevelSummary p4e5a22be_4_4
   ) {
      super(GameNarrator.NO_TITLE);
      this.realmCreationTask = p4e5a22be_0_0;
      this.realmId = p4e5a22be_1_1;
      this.slotId = p4e5a22be_2_2;
      this.lastScreen = p4e5a22be_3_3;
      this.selectedLevel = p4e5a22be_4_4;
      this.uploadStatus = new UploadStatus();
      this.narrationRateLimiter = RateLimiter.create(0.1F);
   }

   @Override
   public void init() {
      this.backButton = this.layout.addToFooter(Button.builder(CommonComponents.GUI_BACK, p4e5a22be_20_0 -> this.onBack()).build());
      this.backButton.visible = false;
      this.cancelButton = this.layout.addToFooter(Button.builder(CommonComponents.GUI_CANCEL, p4e5a22be_19_0 -> this.onCancel()).build());
      if (!this.uploadStarted) {
         if (this.lastScreen.slot == -1) {
            this.uploadStarted = true;
            this.upload();
         } else {
            List<LongRunningTask> $$0 = new ArrayList<>();
            if (this.realmCreationTask != null) {
               $$0.add(this.realmCreationTask);
            }

            $$0.add(new SwitchSlotTask(this.realmId, this.lastScreen.slot, () -> {
               if (!this.uploadStarted) {
                  this.uploadStarted = true;
                  this.minecraft.execute(() -> {
                     this.minecraft.setScreen(this);
                     this.upload();
                  });
               }
            }));
            this.minecraft.setScreen(new RealmsLongRunningMcoTaskScreen(this.lastScreen, $$0.toArray(new LongRunningTask[0])));
         }
      }

      this.layout.visitWidgets(p4e5a22be_18_1 -> {
         AbstractWidget var10000 = this.addRenderableWidget(p4e5a22be_18_1);
      });
      this.repositionElements();
   }

   @Override
   protected void repositionElements() {
      this.layout.arrangeElements();
   }

   private void onBack() {
      this.minecraft.setScreen(new RealmsConfigureWorldScreen(new RealmsMainScreen(new TitleScreen()), this.realmId));
   }

   private void onCancel() {
      this.cancelled = true;
      RealmsWorldUpload $$0 = this.currentUpload.get();
      if ($$0 != null) {
         $$0.cancel();
      } else {
         this.minecraft.setScreen(this.lastScreen);
      }
   }

   @Override
   public boolean keyPressed(KeyEvent p4e5a22be_5_0) {
      if (p4e5a22be_5_0.key() == 256) {
         if (this.showDots) {
            this.onCancel();
         } else {
            this.onBack();
         }

         return true;
      } else {
         return super.keyPressed(p4e5a22be_5_0);
      }
   }

   @Override
   public void render(GuiGraphics p4e5a22be_6_0, int p4e5a22be_7_1, int p4e5a22be_8_2, float p4e5a22be_9_3) {
      super.render(p4e5a22be_6_0, p4e5a22be_7_1, p4e5a22be_8_2, p4e5a22be_9_3);
      if (!this.uploadFinished && this.uploadStatus.uploadStarted() && this.uploadStatus.uploadCompleted() && this.cancelButton != null) {
         this.status = VERIFYING_TEXT;
         this.cancelButton.active = false;
      }

      p4e5a22be_6_0.drawCenteredString(this.font, this.status, this.width / 2, 50, -1);
      if (this.showDots) {
         p4e5a22be_6_0.drawString(this.font, DOTS[this.tickCount / 10 % DOTS.length], this.width / 2 + this.font.width(this.status) / 2 + 5, 50, -1);
      }

      if (this.uploadStatus.uploadStarted() && !this.cancelled) {
         this.drawProgressBar(p4e5a22be_6_0);
         this.drawUploadSpeed(p4e5a22be_6_0);
      }

      Component[] $$4 = this.errorMessage;
      if ($$4 != null) {
         for (int $$5 = 0; $$5 < $$4.length; $$5++) {
            p4e5a22be_6_0.drawCenteredString(this.font, $$4[$$5], this.width / 2, 110 + 12 * $$5, -65536);
         }
      }
   }

   private void drawProgressBar(GuiGraphics p4e5a22be_10_0) {
      double $$1 = this.uploadStatus.getPercentage();
      this.progress = String.format(Locale.ROOT, "%.1f", $$1 * 100.0);
      int $$2 = (this.width - 200) / 2;
      int $$3 = $$2 + (int)Math.round(200.0 * $$1);
      p4e5a22be_10_0.fill($$2 - 1, 79, $$3 + 1, 96, -1);
      p4e5a22be_10_0.fill($$2, 80, $$3, 95, -8355712);
      p4e5a22be_10_0.drawCenteredString(this.font, Component.translatable("mco.upload.percent", this.progress), this.width / 2, 84, -1);
   }

   private void drawUploadSpeed(GuiGraphics p4e5a22be_11_0) {
      this.drawUploadSpeed0(p4e5a22be_11_0, this.uploadStatus.getBytesPerSecond());
   }

   private void drawUploadSpeed0(GuiGraphics p4e5a22be_12_0, long p4e5a22be_13_1) {
      String $$2 = this.progress;
      if (p4e5a22be_13_1 > 0L && $$2 != null) {
         int $$3 = this.font.width($$2);
         String $$4 = "(" + Unit.humanReadable(p4e5a22be_13_1) + "/s)";
         p4e5a22be_12_0.drawString(this.font, $$4, this.width / 2 + $$3 / 2 + 15, 84, -1);
      }
   }

   @Override
   public void tick() {
      super.tick();
      this.tickCount++;
      this.uploadStatus.refreshBytesPerSecond();
      if (this.narrationRateLimiter.tryAcquire(1)) {
         Component $$0 = this.createProgressNarrationMessage();
         this.minecraft.getNarrator().saySystemNow($$0);
      }
   }

   private Component createProgressNarrationMessage() {
      List<Component> $$0 = Lists.newArrayList();
      $$0.add(this.status);
      if (this.progress != null) {
         $$0.add(Component.translatable("mco.upload.percent", this.progress));
      }

      Component[] $$1 = this.errorMessage;
      if ($$1 != null) {
         $$0.addAll(Arrays.asList($$1));
      }

      return CommonComponents.joinLines($$0);
   }

   private void upload() {
      Path $$0 = this.minecraft.gameDirectory.toPath().resolve("saves").resolve(this.selectedLevel.getLevelId());
      RealmsWorldOptions $$1 = RealmsWorldOptions.createFromSettings(this.selectedLevel.getSettings(), this.selectedLevel.levelVersion().minecraftVersionName());
      RealmsSlot $$2 = new RealmsSlot(this.slotId, $$1, List.of(RealmsSetting.hardcoreSetting(this.selectedLevel.getSettings().hardcore())));
      RealmsWorldUpload $$3 = new RealmsWorldUpload($$0, $$2, this.minecraft.getUser(), this.realmId, this);
      if (!this.currentUpload.compareAndSet(null, $$3)) {
         throw new IllegalStateException("Tried to start uploading but was already uploading");
      }

      $$3.packAndUpload().handleAsync((p4e5a22be_15_0, p4e5a22be_16_1) -> {
         if (p4e5a22be_16_1 != null) {
            if (p4e5a22be_16_1 instanceof CompletionException $$2x) {
               p4e5a22be_16_1 = $$2x.getCause();
            }

            if (p4e5a22be_16_1 instanceof RealmsUploadException $$3x) {
               if ($$3x.getStatusMessage() != null) {
                  this.status = $$3x.getStatusMessage();
               }

               this.setErrorMessage($$3x.getErrorMessages());
            } else {
               this.status = Component.translatable("mco.upload.failed", p4e5a22be_16_1.getMessage());
            }
         } else {
            this.status = Component.translatable("mco.upload.done");
            if (this.backButton != null) {
               this.backButton.setMessage(CommonComponents.GUI_DONE);
            }
         }

         this.uploadFinished = true;
         this.showDots = false;
         if (this.backButton != null) {
            this.backButton.visible = true;
         }

         if (this.cancelButton != null) {
            this.cancelButton.visible = false;
         }

         this.currentUpload.set(null);
         return null;
      }, this.minecraft);
   }

   private void setErrorMessage(Component @Nullable ... p4e5a22be_14_0) {
      this.errorMessage = p4e5a22be_14_0;
   }

   @Override
   public UploadStatus getUploadStatus() {
      return this.uploadStatus;
   }

   @Override
   public void setUploading() {
      this.status = Component.translatable("mco.upload.uploading", this.selectedLevel.getLevelName());
   }
}
