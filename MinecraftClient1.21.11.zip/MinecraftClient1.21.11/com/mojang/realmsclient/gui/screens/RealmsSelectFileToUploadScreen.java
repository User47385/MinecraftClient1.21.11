package com.mojang.realmsclient.gui.screens;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.task.RealmCreationTask;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.worldselection.WorldSelectionList;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.world.level.storage.LevelSummary;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsSelectFileToUploadScreen extends RealmsScreen {
   private static final Logger LOGGER = LogUtils.getLogger();
   public static final Component TITLE = Component.translatable("mco.upload.select.world.title");
   private static final Component UNABLE_TO_LOAD_WORLD = Component.translatable("selectWorld.unable_to_load");
   private final @Nullable RealmCreationTask realmCreationTask;
   private final RealmsResetWorldScreen lastScreen;
   private final long realmId;
   private final int slotId;
   private final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this, 8 + 9 + 8 + 20 + 4, 33);
   protected @Nullable EditBox searchBox;
   private @Nullable WorldSelectionList list;
   private @Nullable Button uploadButton;

   public RealmsSelectFileToUploadScreen(@Nullable RealmCreationTask p396f6611_0_0, long p396f6611_1_1, int p396f6611_2_2, RealmsResetWorldScreen p396f6611_3_3) {
      super(TITLE);
      this.realmCreationTask = p396f6611_0_0;
      this.lastScreen = p396f6611_3_3;
      this.realmId = p396f6611_1_1;
      this.slotId = p396f6611_2_2;
   }

   @Override
   public void init() {
      LinearLayout $$0 = this.layout.addToHeader(LinearLayout.vertical().spacing(4));
      $$0.defaultCellSetting().alignHorizontallyCenter();
      $$0.addChild(new StringWidget(this.title, this.font));
      this.searchBox = $$0.addChild(new EditBox(this.font, this.width / 2 - 100, 22, 200, 20, this.searchBox, Component.translatable("selectWorld.search")));
      this.searchBox.setResponder(p396f6611_10_0 -> {
         if (this.list != null) {
            this.list.updateFilter(p396f6611_10_0);
         }
      });

      try {
         this.list = this.layout
            .addToContents(
               new WorldSelectionList.Builder(this.minecraft, this)
                  .width(this.width)
                  .height(this.layout.getContentHeight())
                  .filter(this.searchBox.getValue())
                  .oldList(this.list)
                  .uploadWorld()
                  .onEntrySelect(this::updateButtonState)
                  .onEntryInteract(this::upload)
                  .build()
            );
      } catch (Exception $$1) {
         LOGGER.error("Couldn't load level list", $$1);
         this.minecraft.setScreen(new RealmsGenericErrorScreen(UNABLE_TO_LOAD_WORLD, Component.nullToEmpty($$1.getMessage()), this.lastScreen));
         return;
      }

      LinearLayout $$2 = this.layout.addToFooter(LinearLayout.horizontal().spacing(8));
      $$2.defaultCellSetting().alignHorizontallyCenter();
      this.uploadButton = $$2.addChild(
         Button.builder(Component.translatable("mco.upload.button.name"), p396f6611_9_0 -> this.list.getSelectedOpt().ifPresent(this::upload)).build()
      );
      $$2.addChild(Button.builder(CommonComponents.GUI_BACK, p396f6611_8_0 -> this.onClose()).build());
      this.updateButtonState(null);
      this.layout.visitWidgets(p396f6611_7_1 -> {
         AbstractWidget var10000 = this.addRenderableWidget(p396f6611_7_1);
      });
      this.repositionElements();
   }

   @Override
   protected void repositionElements() {
      if (this.list != null) {
         this.list.updateSize(this.width, this.layout);
      }

      this.layout.arrangeElements();
   }

   @Override
   protected void setInitialFocus() {
      this.setInitialFocus(this.searchBox);
   }

   private void updateButtonState(@Nullable LevelSummary p396f6611_4_0) {
      if (this.list != null && this.uploadButton != null) {
         this.uploadButton.active = this.list.getSelected() != null;
      }
   }

   private void upload(WorldSelectionList.WorldListEntry p396f6611_5_0) {
      this.minecraft.setScreen(new RealmsUploadScreen(this.realmCreationTask, this.realmId, this.slotId, this.lastScreen, p396f6611_5_0.getLevelSummary()));
   }

   @Override
   public Component getNarrationMessage() {
      return CommonComponents.joinForNarration(this.getTitle(), this.createLabelNarration());
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.lastScreen);
   }
}
