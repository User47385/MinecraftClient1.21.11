package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.RealmsAvailability;
import com.mojang.realmsclient.dto.RealmsNotification;
import com.mojang.realmsclient.gui.RealmsDataFetcher;
import com.mojang.realmsclient.gui.task.DataFetcher;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.GameNarrator;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;

public class RealmsNotificationsScreen extends RealmsScreen {
   private static final Identifier UNSEEN_NOTIFICATION_SPRITE = Identifier.withDefaultNamespace("icon/unseen_notification");
   private static final Identifier NEWS_SPRITE = Identifier.withDefaultNamespace("icon/news");
   private static final Identifier INVITE_SPRITE = Identifier.withDefaultNamespace("icon/invite");
   private static final Identifier TRIAL_AVAILABLE_SPRITE = Identifier.withDefaultNamespace("icon/trial_available");
   private final CompletableFuture<Boolean> validClient = RealmsAvailability.get()
      .thenApply(pb0e20563_18_0 -> pb0e20563_18_0.type() == RealmsAvailability.Type.SUCCESS);
   private DataFetcher.@Nullable Subscription realmsDataSubscription;
   private RealmsNotificationsScreen.@Nullable DataFetcherConfiguration currentConfiguration;
   private volatile int numberOfPendingInvites;
   private static boolean trialAvailable;
   private static boolean hasUnreadNews;
   private static boolean hasUnseenNotifications;
   private final RealmsNotificationsScreen.DataFetcherConfiguration showAll = new RealmsNotificationsScreen.DataFetcherConfiguration() {
      @Override
      public DataFetcher.Subscription initDataFetcher(RealmsDataFetcher p763d30_1_0) {
         DataFetcher.Subscription $$1 = p763d30_1_0.dataFetcher.createSubscription();
         RealmsNotificationsScreen.this.addNewsAndInvitesSubscriptions(p763d30_1_0, $$1);
         RealmsNotificationsScreen.this.addNotificationsSubscriptions(p763d30_1_0, $$1);
         return $$1;
      }

      @Override
      public boolean showOldNotifications() {
         return true;
      }
   };
   private final RealmsNotificationsScreen.DataFetcherConfiguration onlyNotifications = new RealmsNotificationsScreen.DataFetcherConfiguration() {
      @Override
      public DataFetcher.Subscription initDataFetcher(RealmsDataFetcher p763d31_1_0) {
         DataFetcher.Subscription $$1 = p763d31_1_0.dataFetcher.createSubscription();
         RealmsNotificationsScreen.this.addNotificationsSubscriptions(p763d31_1_0, $$1);
         return $$1;
      }

      @Override
      public boolean showOldNotifications() {
         return false;
      }
   };

   public RealmsNotificationsScreen() {
      super(GameNarrator.NO_TITLE);
   }

   @Override
   public void init() {
      if (this.realmsDataSubscription != null) {
         this.realmsDataSubscription.forceUpdate();
      }
   }

   @Override
   public void added() {
      super.added();
      this.minecraft.realmsDataFetcher().notificationsTask.reset();
   }

   private RealmsNotificationsScreen.@Nullable DataFetcherConfiguration getConfiguration() {
      boolean $$0 = this.inTitleScreen() && this.validClient.getNow(false);
      if (!$$0) {
         return null;
      } else {
         return this.getRealmsNotificationsEnabled() ? this.showAll : this.onlyNotifications;
      }
   }

   @Override
   public void tick() {
      RealmsNotificationsScreen.DataFetcherConfiguration $$0 = this.getConfiguration();
      if (!Objects.equals(this.currentConfiguration, $$0)) {
         this.currentConfiguration = $$0;
         if (this.currentConfiguration != null) {
            this.realmsDataSubscription = this.currentConfiguration.initDataFetcher(this.minecraft.realmsDataFetcher());
         } else {
            this.realmsDataSubscription = null;
         }
      }

      if (this.realmsDataSubscription != null) {
         this.realmsDataSubscription.tick();
      }
   }

   private boolean getRealmsNotificationsEnabled() {
      return this.minecraft.options.realmsNotifications().get();
   }

   private boolean inTitleScreen() {
      return this.minecraft.screen instanceof TitleScreen;
   }

   @Override
   public void render(GuiGraphics pb0e20563_0_0, int pb0e20563_1_1, int pb0e20563_2_2, float pb0e20563_3_3) {
      super.render(pb0e20563_0_0, pb0e20563_1_1, pb0e20563_2_2, pb0e20563_3_3);
      if (this.validClient.getNow(false)) {
         this.drawIcons(pb0e20563_0_0);
      }
   }

   @Override
   public void renderBackground(GuiGraphics pb0e20563_4_0, int pb0e20563_5_1, int pb0e20563_6_2, float pb0e20563_7_3) {
   }

   private void drawIcons(GuiGraphics pb0e20563_8_0) {
      int $$1 = this.numberOfPendingInvites;
      int $$2 = 24;
      int $$3 = this.height / 4 + 48;
      int $$4 = this.width / 2 + 100;
      int $$5 = $$3 + 48 + 2;
      int $$6 = $$4 - 3;
      if (hasUnseenNotifications) {
         pb0e20563_8_0.blitSprite(RenderPipelines.GUI_TEXTURED, UNSEEN_NOTIFICATION_SPRITE, $$6 - 12, $$5 + 3, 10, 10);
         $$6 -= 16;
      }

      if (this.currentConfiguration != null && this.currentConfiguration.showOldNotifications()) {
         if (hasUnreadNews) {
            pb0e20563_8_0.blitSprite(RenderPipelines.GUI_TEXTURED, NEWS_SPRITE, $$6 - 14, $$5 + 1, 14, 14);
            $$6 -= 16;
         }

         if ($$1 != 0) {
            pb0e20563_8_0.blitSprite(RenderPipelines.GUI_TEXTURED, INVITE_SPRITE, $$6 - 14, $$5 + 1, 14, 14);
            $$6 -= 16;
         }

         if (trialAvailable) {
            pb0e20563_8_0.blitSprite(RenderPipelines.GUI_TEXTURED, TRIAL_AVAILABLE_SPRITE, $$6 - 10, $$5 + 4, 8, 8);
         }
      }
   }

   void addNewsAndInvitesSubscriptions(RealmsDataFetcher pb0e20563_9_0, DataFetcher.Subscription pb0e20563_10_1) {
      pb0e20563_10_1.subscribe(pb0e20563_9_0.pendingInvitesTask, pb0e20563_17_0 -> this.numberOfPendingInvites = pb0e20563_17_0);
      pb0e20563_10_1.subscribe(pb0e20563_9_0.trialAvailabilityTask, pb0e20563_16_0 -> trialAvailable = pb0e20563_16_0);
      pb0e20563_10_1.subscribe(pb0e20563_9_0.newsTask, pb0e20563_15_1 -> {
         pb0e20563_9_0.newsManager.updateUnreadNews(pb0e20563_15_1);
         hasUnreadNews = pb0e20563_9_0.newsManager.hasUnreadNews();
      });
   }

   void addNotificationsSubscriptions(RealmsDataFetcher pb0e20563_11_0, DataFetcher.Subscription pb0e20563_12_1) {
      pb0e20563_12_1.subscribe(pb0e20563_11_0.notificationsTask, pb0e20563_13_0 -> {
         hasUnseenNotifications = false;

         for (RealmsNotification $$1 : pb0e20563_13_0) {
            if (!$$1.seen()) {
               hasUnseenNotifications = true;
               break;
            }
         }
      });
   }

   interface DataFetcherConfiguration {
      DataFetcher.Subscription initDataFetcher(RealmsDataFetcher var1);

      boolean showOldNotifications();
   }
}
