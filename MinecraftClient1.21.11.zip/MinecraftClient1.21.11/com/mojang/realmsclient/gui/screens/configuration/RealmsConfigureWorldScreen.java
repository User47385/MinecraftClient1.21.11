package com.mojang.realmsclient.gui.screens.configuration;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.client.RealmsError;
import com.mojang.realmsclient.dto.PlayerInfo;
import com.mojang.realmsclient.dto.PreferredRegionsDto;
import com.mojang.realmsclient.dto.RealmsRegion;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.RealmsSlot;
import com.mojang.realmsclient.dto.RegionDataDto;
import com.mojang.realmsclient.dto.RegionSelectionPreference;
import com.mojang.realmsclient.dto.RegionSelectionPreferenceDto;
import com.mojang.realmsclient.dto.ServiceQuality;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.gui.screens.RealmsGenericErrorScreen;
import com.mojang.realmsclient.gui.screens.RealmsLongRunningMcoTaskScreen;
import com.mojang.realmsclient.util.RealmsUtil;
import com.mojang.realmsclient.util.task.CloseServerTask;
import com.mojang.realmsclient.util.task.OpenServerTask;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.tabs.LoadingTab;
import net.minecraft.client.gui.components.tabs.Tab;
import net.minecraft.client.gui.components.tabs.TabManager;
import net.minecraft.client.gui.components.tabs.TabNavigationBar;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.worldselection.CreateWorldScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.util.StringUtil;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsConfigureWorldScreen extends RealmsScreen {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final Component PLAY_TEXT = Component.translatable("mco.selectServer.play");
   private final RealmsMainScreen lastScreen;
   private @Nullable RealmsServer serverData;
   private @Nullable PreferredRegionsDto regions;
   private final Map<RealmsRegion, ServiceQuality> regionServiceQuality = new LinkedHashMap<>();
   private final long serverId;
   private boolean stateChanged;
   private final TabManager tabManager = new TabManager(pe588e9c2_35_1 -> {
      AbstractWidget var10000 = this.addRenderableWidget(pe588e9c2_35_1);
   }, pe588e9c2_33_1 -> this.removeWidget(pe588e9c2_33_1), this::onTabSelected, this::onTabDeselected);
   private @Nullable Button playButton;
   private @Nullable TabNavigationBar tabNavigationBar;
   final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);

   public RealmsConfigureWorldScreen(
      RealmsMainScreen pe588e9c2_0_0, long pe588e9c2_1_1, @Nullable RealmsServer pe588e9c2_2_2, @Nullable PreferredRegionsDto pe588e9c2_3_3
   ) {
      super(Component.empty());
      this.lastScreen = pe588e9c2_0_0;
      this.serverId = pe588e9c2_1_1;
      this.serverData = pe588e9c2_2_2;
      this.regions = pe588e9c2_3_3;
   }

   public RealmsConfigureWorldScreen(RealmsMainScreen pe588e9c2_4_0, long pe588e9c2_5_1) {
      this(pe588e9c2_4_0, pe588e9c2_5_1, null, null);
   }

   @Override
   public void init() {
      if (this.serverData == null) {
         this.fetchServerData(this.serverId);
      }

      if (this.regions == null) {
         this.fetchRegionData();
      }

      Component $$0 = Component.translatable("mco.configure.world.loading");
      this.tabNavigationBar = TabNavigationBar.builder(this.tabManager, this.width)
         .addTabs(
            new LoadingTab(this.getFont(), RealmsWorldsTab.TITLE, $$0),
            new LoadingTab(this.getFont(), RealmsPlayersTab.TITLE, $$0),
            new LoadingTab(this.getFont(), RealmsSubscriptionTab.TITLE, $$0),
            new LoadingTab(this.getFont(), RealmsSettingsTab.TITLE, $$0)
         )
         .build();
      this.tabNavigationBar.setTabActiveState(3, false);
      this.addRenderableWidget(this.tabNavigationBar);
      LinearLayout $$1 = this.layout.addToFooter(LinearLayout.horizontal().spacing(8));
      this.playButton = $$1.addChild(Button.builder(PLAY_TEXT, pe588e9c2_31_0 -> {
         this.onClose();
         RealmsMainScreen.play(this.serverData, this);
      }).width(150).build());
      this.playButton.active = false;
      $$1.addChild(Button.builder(CommonComponents.GUI_BACK, pe588e9c2_30_0 -> this.onClose()).build());
      this.layout.visitWidgets(pe588e9c2_29_0 -> {
         pe588e9c2_29_0.setTabOrderGroup(1);
         this.addRenderableWidget(pe588e9c2_29_0);
      });
      this.tabNavigationBar.selectTab(0, false);
      this.repositionElements();
      if (this.serverData != null && this.regions != null) {
         this.onRealmsDataFetched();
      }
   }

   private void onTabSelected(Tab pe588e9c2_6_0) {
      if (this.serverData != null && pe588e9c2_6_0 instanceof RealmsConfigurationTab $$1) {
         $$1.onSelected(this.serverData);
      }
   }

   private void onTabDeselected(Tab pe588e9c2_7_0) {
      if (this.serverData != null && pe588e9c2_7_0 instanceof RealmsConfigurationTab $$1) {
         $$1.onDeselected(this.serverData);
      }
   }

   public int getContentHeight() {
      return this.layout.getContentHeight();
   }

   public int getHeaderHeight() {
      return this.layout.getHeaderHeight();
   }

   public Screen getLastScreen() {
      return this.lastScreen;
   }

   public Screen createErrorScreen(RealmsServiceException pe588e9c2_8_0) {
      return new RealmsGenericErrorScreen(pe588e9c2_8_0, this.lastScreen);
   }

   @Override
   public void repositionElements() {
      if (this.tabNavigationBar != null) {
         this.tabNavigationBar.setWidth(this.width);
         this.tabNavigationBar.arrangeElements();
         int $$0 = this.tabNavigationBar.getRectangle().bottom();
         ScreenRectangle $$1 = new ScreenRectangle(0, $$0, this.width, this.height - this.layout.getFooterHeight() - $$0);
         this.tabManager.setTabArea($$1);
         this.layout.setHeaderHeight($$0);
         this.layout.arrangeElements();
      }
   }

   private void updateButtonStates() {
      if (this.serverData != null && this.playButton != null) {
         this.playButton.active = this.serverData.shouldPlayButtonBeActive();
         if (!this.playButton.active && this.serverData.state == RealmsServer.State.CLOSED) {
            this.playButton.setTooltip(Tooltip.create(RealmsServer.WORLD_CLOSED_COMPONENT));
         }
      }
   }

   @Override
   public void render(GuiGraphics pe588e9c2_9_0, int pe588e9c2_10_1, int pe588e9c2_11_2, float pe588e9c2_12_3) {
      super.render(pe588e9c2_9_0, pe588e9c2_10_1, pe588e9c2_11_2, pe588e9c2_12_3);
      pe588e9c2_9_0.blit(
         RenderPipelines.GUI_TEXTURED, Screen.FOOTER_SEPARATOR, 0, this.height - this.layout.getFooterHeight() - 2, 0.0F, 0.0F, this.width, 2, 32, 2
      );
   }

   @Override
   public boolean keyPressed(KeyEvent pe588e9c2_13_0) {
      return this.tabNavigationBar.keyPressed(pe588e9c2_13_0) ? true : super.keyPressed(pe588e9c2_13_0);
   }

   @Override
   protected void renderMenuBackground(GuiGraphics pe588e9c2_14_0) {
      pe588e9c2_14_0.blit(
         RenderPipelines.GUI_TEXTURED, CreateWorldScreen.TAB_HEADER_BACKGROUND, 0, 0, 0.0F, 0.0F, this.width, this.layout.getHeaderHeight(), 16, 16
      );
      this.renderMenuBackground(pe588e9c2_14_0, 0, this.layout.getHeaderHeight(), this.width, this.height);
   }

   @Override
   public void onClose() {
      if (this.serverData != null && this.tabManager.getCurrentTab() instanceof RealmsConfigurationTab $$0) {
         $$0.onDeselected(this.serverData);
      }

      this.minecraft.setScreen(this.lastScreen);
      if (this.stateChanged) {
         this.lastScreen.resetScreen();
      }
   }

   public void fetchRegionData() {
      RealmsUtil.supplyAsync(
            RealmsClient::getPreferredRegionSelections, RealmsUtil.openScreenAndLogOnFailure(this::createErrorScreen, "Couldn't get realms region data")
         )
         .thenAcceptAsync(pe588e9c2_28_0 -> {
            this.regions = pe588e9c2_28_0;
            this.onRealmsDataFetched();
         }, this.minecraft);
   }

   public void fetchServerData(long pe588e9c2_15_0) {
      RealmsUtil.<RealmsServer>supplyAsync(
            pe588e9c2_27_1 -> pe588e9c2_27_1.getOwnRealm(pe588e9c2_15_0),
            RealmsUtil.openScreenAndLogOnFailure(this::createErrorScreen, "Couldn't get own world")
         )
         .thenAcceptAsync(pe588e9c2_25_0 -> {
            this.serverData = pe588e9c2_25_0;
            this.onRealmsDataFetched();
         }, this.minecraft);
   }

   private void onRealmsDataFetched() {
      if (this.serverData != null && this.regions != null) {
         this.regionServiceQuality.clear();

         for (RegionDataDto $$0 : this.regions.regionData()) {
            if ($$0.region() != RealmsRegion.INVALID_REGION) {
               this.regionServiceQuality.put($$0.region(), $$0.serviceQuality());
            }
         }

         int $$1 = -1;
         if (this.tabNavigationBar != null) {
            $$1 = this.tabNavigationBar.getTabs().indexOf(this.tabManager.getCurrentTab());
         }

         if (this.tabNavigationBar != null) {
            this.removeWidget(this.tabNavigationBar);
         }

         this.tabNavigationBar = this.addRenderableWidget(
            TabNavigationBar.builder(this.tabManager, this.width)
               .addTabs(
                  new RealmsWorldsTab(this, Objects.requireNonNull(this.minecraft), this.serverData),
                  new RealmsPlayersTab(this, this.minecraft, this.serverData),
                  new RealmsSubscriptionTab(this, this.minecraft, this.serverData),
                  new RealmsSettingsTab(this, this.minecraft, this.serverData, this.regionServiceQuality)
               )
               .build()
         );
         this.setFocused(this.tabNavigationBar);
         if ($$1 != -1) {
            this.tabNavigationBar.selectTab($$1, false);
         }

         this.tabNavigationBar.setTabActiveState(3, !this.serverData.expired);
         if (this.serverData.expired) {
            this.tabNavigationBar.setTabTooltip(3, Tooltip.create(Component.translatable("mco.configure.world.settings.expired")));
         } else {
            this.tabNavigationBar.setTabTooltip(3, null);
         }

         this.updateButtonStates();
         this.repositionElements();
      }
   }

   public void saveSlotSettings(RealmsSlot pe588e9c2_16_0) {
      RealmsSlot $$1 = this.serverData.slots.get(this.serverData.activeSlot);
      pe588e9c2_16_0.options.templateId = $$1.options.templateId;
      pe588e9c2_16_0.options.templateImage = $$1.options.templateImage;
      RealmsClient $$2 = RealmsClient.getOrCreate();

      try {
         if (this.serverData.activeSlot != pe588e9c2_16_0.slotId) {
            throw new RealmsServiceException(RealmsError.CustomError.configurationError());
         }

         $$2.updateSlot(this.serverData.id, pe588e9c2_16_0.slotId, pe588e9c2_16_0.options, pe588e9c2_16_0.settings);
         this.serverData.slots.put(this.serverData.activeSlot, pe588e9c2_16_0);
         if (pe588e9c2_16_0.options.gameMode != $$1.options.gameMode || pe588e9c2_16_0.isHardcore() != $$1.isHardcore()) {
            RealmsMainScreen.refreshServerList();
         }

         this.stateChanged();
      } catch (RealmsServiceException $$3) {
         LOGGER.error("Couldn't save slot settings", $$3);
         this.minecraft.setScreen(new RealmsGenericErrorScreen($$3, this));
         return;
      }

      this.minecraft.setScreen(this);
   }

   public void saveSettings(String pe588e9c2_17_0, String pe588e9c2_18_1, RegionSelectionPreference pe588e9c2_19_2, @Nullable RealmsRegion pe588e9c2_20_3) {
      String $$4 = StringUtil.isBlank(pe588e9c2_18_1) ? "" : pe588e9c2_18_1;
      String $$5 = StringUtil.isBlank(pe588e9c2_17_0) ? "" : pe588e9c2_17_0;
      RealmsClient $$6 = RealmsClient.getOrCreate();

      try {
         RealmsSlot $$7 = this.serverData.slots.get(this.serverData.activeSlot);
         RealmsRegion $$8 = pe588e9c2_19_2 == RegionSelectionPreference.MANUAL ? pe588e9c2_20_3 : null;
         RegionSelectionPreferenceDto $$9 = new RegionSelectionPreferenceDto(pe588e9c2_19_2, $$8);
         $$6.updateConfiguration(this.serverData.id, $$5, $$4, $$9, $$7.slotId, $$7.options, $$7.settings);
         this.serverData.regionSelectionPreference = $$9;
         this.serverData.name = pe588e9c2_17_0;
         this.serverData.motd = $$4;
         this.stateChanged();
      } catch (RealmsServiceException $$10) {
         LOGGER.error("Couldn't save settings", $$10);
         this.minecraft.setScreen(new RealmsGenericErrorScreen($$10, this));
         return;
      }

      this.minecraft.setScreen(this);
   }

   public void openTheWorld(boolean pe588e9c2_21_0) {
      RealmsConfigureWorldScreen $$1 = this.getNewScreenWithKnownData(this.serverData);
      this.minecraft
         .setScreen(new RealmsLongRunningMcoTaskScreen(this.getNewScreen(), new OpenServerTask(this.serverData, $$1, pe588e9c2_21_0, this.minecraft)));
   }

   public void closeTheWorld() {
      RealmsConfigureWorldScreen $$0 = this.getNewScreenWithKnownData(this.serverData);
      this.minecraft.setScreen(new RealmsLongRunningMcoTaskScreen(this.getNewScreen(), new CloseServerTask(this.serverData, $$0)));
   }

   public void stateChanged() {
      this.stateChanged = true;
      if (this.tabNavigationBar != null) {
         for (Tab $$0 : this.tabNavigationBar.getTabs()) {
            if ($$0 instanceof RealmsConfigurationTab $$1) {
               $$1.updateData(this.serverData);
            }
         }
      }
   }

   public boolean invitePlayer(long pe588e9c2_22_0, String pe588e9c2_23_1) {
      RealmsClient $$2 = RealmsClient.getOrCreate();

      try {
         List<PlayerInfo> $$3 = $$2.invite(pe588e9c2_22_0, pe588e9c2_23_1);
         if (this.serverData != null) {
            this.serverData.players = $$3;
         } else {
            this.serverData = $$2.getOwnRealm(pe588e9c2_22_0);
         }

         this.stateChanged();
         return true;
      } catch (RealmsServiceException $$4) {
         LOGGER.error("Couldn't invite user", $$4);
         return false;
      }
   }

   public RealmsConfigureWorldScreen getNewScreen() {
      RealmsConfigureWorldScreen $$0 = new RealmsConfigureWorldScreen(this.lastScreen, this.serverId);
      $$0.stateChanged = this.stateChanged;
      return $$0;
   }

   public RealmsConfigureWorldScreen getNewScreenWithKnownData(RealmsServer pe588e9c2_24_0) {
      RealmsConfigureWorldScreen $$1 = new RealmsConfigureWorldScreen(this.lastScreen, this.serverId, pe588e9c2_24_0, this.regions);
      $$1.stateChanged = this.stateChanged;
      return $$1;
   }
}
