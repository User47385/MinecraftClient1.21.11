package com.mojang.realmsclient.gui.screens.configuration;

import com.mojang.realmsclient.dto.Backup;
import com.mojang.realmsclient.dto.RealmsServer;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;

public class RealmsBackupInfoScreen extends RealmsScreen {
   private static final Component TITLE = Component.translatable("mco.backup.info.title");
   private static final Component UNKNOWN = Component.translatable("mco.backup.unknown");
   private final Screen lastScreen;
   final Backup backup;
   final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);
   private RealmsBackupInfoScreen.BackupInfoList backupInfoList;

   public RealmsBackupInfoScreen(Screen pb52a6106_0_0, Backup pb52a6106_1_1) {
      super(TITLE);
      this.lastScreen = pb52a6106_0_0;
      this.backup = pb52a6106_1_1;
   }

   @Override
   public void init() {
      this.layout.addTitleHeader(TITLE, this.font);
      this.backupInfoList = this.layout.addToContents(new RealmsBackupInfoScreen.BackupInfoList(this.minecraft));
      this.layout.addToFooter(Button.builder(CommonComponents.GUI_BACK, pb52a6106_9_0 -> this.onClose()).build());
      this.repositionElements();
      this.layout.visitWidgets(pb52a6106_8_1 -> {
         AbstractWidget var10000 = this.addRenderableWidget(pb52a6106_8_1);
      });
   }

   @Override
   protected void repositionElements() {
      this.backupInfoList.updateSize(this.width, this.layout);
      this.layout.arrangeElements();
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.lastScreen);
   }

   Component checkForSpecificMetadata(String pb52a6106_2_0, String pb52a6106_3_1) {
      String $$2 = pb52a6106_2_0.toLowerCase(Locale.ROOT);
      if ($$2.contains("game") && $$2.contains("mode")) {
         return this.gameModeMetadata(pb52a6106_3_1);
      } else if ($$2.contains("game") && $$2.contains("difficulty")) {
         return this.gameDifficultyMetadata(pb52a6106_3_1);
      } else {
         return pb52a6106_2_0.equals("world_type") ? this.parseWorldType(pb52a6106_3_1) : Component.literal(pb52a6106_3_1);
      }
   }

   private Component gameDifficultyMetadata(String pb52a6106_4_0) {
      try {
         return RealmsSlotOptionsScreen.DIFFICULTIES.get(Integer.parseInt(pb52a6106_4_0)).getDisplayName();
      } catch (Exception $$1) {
         return UNKNOWN;
      }
   }

   private Component gameModeMetadata(String pb52a6106_5_0) {
      try {
         return RealmsSlotOptionsScreen.GAME_MODES.get(Integer.parseInt(pb52a6106_5_0)).getShortDisplayName();
      } catch (Exception $$1) {
         return UNKNOWN;
      }
   }

   private Component parseWorldType(String pb52a6106_6_0) {
      try {
         return RealmsServer.WorldType.valueOf(pb52a6106_6_0.toUpperCase(Locale.ROOT)).getDisplayName();
      } catch (Exception $$1) {
         return RealmsServer.WorldType.UNKNOWN.getDisplayName();
      }
   }

   class BackupInfoList extends ObjectSelectionList<RealmsBackupInfoScreen.BackupInfoListEntry> {
      public BackupInfoList(final Minecraft pa4fde9cc_1_1) {
         super(
            pa4fde9cc_1_1,
            RealmsBackupInfoScreen.this.width,
            RealmsBackupInfoScreen.this.layout.getContentHeight(),
            RealmsBackupInfoScreen.this.layout.getHeaderHeight(),
            36
         );
         if (RealmsBackupInfoScreen.this.backup.changeList != null) {
            RealmsBackupInfoScreen.this.backup
               .changeList
               .forEach((pa4fde9cc_2_0, pa4fde9cc_3_1) -> this.addEntry(RealmsBackupInfoScreen.this.new BackupInfoListEntry(pa4fde9cc_2_0, pa4fde9cc_3_1)));
         }
      }
   }

   class BackupInfoListEntry extends ObjectSelectionList.Entry<RealmsBackupInfoScreen.BackupInfoListEntry> {
      private static final Component TEMPLATE_NAME = Component.translatable("mco.backup.entry.templateName");
      private static final Component GAME_DIFFICULTY = Component.translatable("mco.backup.entry.gameDifficulty");
      private static final Component NAME = Component.translatable("mco.backup.entry.name");
      private static final Component GAME_SERVER_VERSION = Component.translatable("mco.backup.entry.gameServerVersion");
      private static final Component UPLOADED = Component.translatable("mco.backup.entry.uploaded");
      private static final Component ENABLED_PACK = Component.translatable("mco.backup.entry.enabledPack");
      private static final Component DESCRIPTION = Component.translatable("mco.backup.entry.description");
      private static final Component GAME_MODE = Component.translatable("mco.backup.entry.gameMode");
      private static final Component SEED = Component.translatable("mco.backup.entry.seed");
      private static final Component WORLD_TYPE = Component.translatable("mco.backup.entry.worldType");
      private static final Component UNDEFINED = Component.translatable("mco.backup.entry.undefined");
      private final String key;
      private final String value;
      private final Component keyComponent;
      private final Component valueComponent;

      public BackupInfoListEntry(final String pea686e06_1_1, final String pea686e06_2_2) {
         this.key = pea686e06_1_1;
         this.value = pea686e06_2_2;
         this.keyComponent = this.translateKey(pea686e06_1_1);
         this.valueComponent = RealmsBackupInfoScreen.this.checkForSpecificMetadata(pea686e06_1_1, pea686e06_2_2);
      }

      @Override
      public void renderContent(GuiGraphics pea686e06_3_0, int pea686e06_4_1, int pea686e06_5_2, boolean pea686e06_6_3, float pea686e06_7_4) {
         pea686e06_3_0.drawString(RealmsBackupInfoScreen.this.font, this.keyComponent, this.getContentX(), this.getContentY(), -6250336);
         pea686e06_3_0.drawString(RealmsBackupInfoScreen.this.font, this.valueComponent, this.getContentX(), this.getContentY() + 12, -1);
      }

      private Component translateKey(String pea686e06_8_0) {
         return switch (pea686e06_8_0) {
            case "template_name" -> TEMPLATE_NAME;
            case "game_difficulty" -> GAME_DIFFICULTY;
            case "name" -> NAME;
            case "game_server_version" -> GAME_SERVER_VERSION;
            case "uploaded" -> UPLOADED;
            case "enabled_packs" -> ENABLED_PACK;
            case "description" -> DESCRIPTION;
            case "game_mode" -> GAME_MODE;
            case "seed" -> SEED;
            case "world_type" -> WORLD_TYPE;
            default -> UNDEFINED;
         };
      }

      @Override
      public Component getNarration() {
         return Component.translatable("narrator.select", this.key + " " + this.value);
      }
   }
}
