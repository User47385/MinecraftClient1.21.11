package com.mojang.realmsclient.gui.screens.configuration;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.Subscription;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.gui.screens.RealmsPopups;
import com.mojang.realmsclient.util.RealmsUtil;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.FormatStyle;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.FocusableTextWidget;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.tabs.GridLayoutTab;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.layouts.LayoutSettings;
import net.minecraft.client.gui.layouts.SpacerElement;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.util.CommonLinks;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

class RealmsSubscriptionTab extends GridLayoutTab implements RealmsConfigurationTab {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final int DEFAULT_COMPONENT_WIDTH = 200;
   private static final int EXTRA_SPACING = 2;
   private static final int DEFAULT_SPACING = 6;
   static final Component TITLE = Component.translatable("mco.configure.world.subscription.tab");
   private static final Component SUBSCRIPTION_START_LABEL = Component.translatable("mco.configure.world.subscription.start");
   private static final Component TIME_LEFT_LABEL = Component.translatable("mco.configure.world.subscription.timeleft");
   private static final Component DAYS_LEFT_LABEL = Component.translatable("mco.configure.world.subscription.recurring.daysleft");
   private static final Component SUBSCRIPTION_EXPIRED_TEXT = Component.translatable("mco.configure.world.subscription.expired").withStyle(ChatFormatting.GRAY);
   private static final Component SUBSCRIPTION_LESS_THAN_A_DAY_TEXT = Component.translatable("mco.configure.world.subscription.less_than_a_day")
      .withStyle(ChatFormatting.GRAY);
   private static final Component UNKNOWN = Component.translatable("mco.configure.world.subscription.unknown");
   private static final Component RECURRING_INFO = Component.translatable("mco.configure.world.subscription.recurring.info");
   private final RealmsConfigureWorldScreen configurationScreen;
   private final Minecraft minecraft;
   private final Button deleteButton;
   private final FocusableTextWidget subscriptionInfo;
   private final StringWidget startDateWidget;
   private final StringWidget daysLeftLabelWidget;
   private final StringWidget daysLeftWidget;
   private RealmsServer serverData;
   private Component daysLeft = UNKNOWN;
   private Component startDate = UNKNOWN;
   private Subscription.@Nullable SubscriptionType type;

   RealmsSubscriptionTab(RealmsConfigureWorldScreen p22e2f50e_0_0, Minecraft p22e2f50e_1_1, RealmsServer p22e2f50e_2_2) {
      super(TITLE);
      this.configurationScreen = p22e2f50e_0_0;
      this.minecraft = p22e2f50e_1_1;
      this.serverData = p22e2f50e_2_2;
      GridLayout.RowHelper $$3 = this.layout.rowSpacing(6).createRowHelper(1);
      Font $$4 = p22e2f50e_0_0.getFont();
      $$3.addChild(new StringWidget(200, 9, SUBSCRIPTION_START_LABEL, $$4));
      this.startDateWidget = $$3.addChild(new StringWidget(200, 9, this.startDate, $$4));
      $$3.addChild(SpacerElement.height(2));
      this.daysLeftLabelWidget = $$3.addChild(new StringWidget(200, 9, TIME_LEFT_LABEL, $$4));
      this.daysLeftWidget = $$3.addChild(new StringWidget(200, 9, this.daysLeft, $$4));
      $$3.addChild(SpacerElement.height(2));
      $$3.addChild(
         Button.builder(
               Component.translatable("mco.configure.world.subscription.extend"),
               p22e2f50e_15_3 -> ConfirmLinkScreen.confirmLinkNow(
                  p22e2f50e_0_0, CommonLinks.extendRealms(p22e2f50e_2_2.remoteSubscriptionId, p22e2f50e_1_1.getUser().getProfileId())
               )
            )
            .bounds(0, 0, 200, 20)
            .build()
      );
      $$3.addChild(SpacerElement.height(2));
      this.deleteButton = $$3.addChild(
         Button.builder(
               Component.translatable("mco.configure.world.delete.button"),
               p22e2f50e_10_2 -> p22e2f50e_1_1.setScreen(
                  RealmsPopups.warningPopupScreen(
                     p22e2f50e_0_0, Component.translatable("mco.configure.world.delete.question.line1"), p22e2f50e_11_0 -> this.deleteRealm()
                  )
               )
            )
            .bounds(0, 0, 200, 20)
            .build()
      );
      $$3.addChild(SpacerElement.height(2));
      this.subscriptionInfo = $$3.addChild(
         FocusableTextWidget.builder(Component.empty(), $$4).maxWidth(200).build(), LayoutSettings.defaults().alignHorizontallyCenter()
      );
      this.subscriptionInfo.setCentered(false);
      this.updateData(p22e2f50e_2_2);
   }

   private void deleteRealm() {
      RealmsUtil.runAsync(
            p22e2f50e_7_0 -> p22e2f50e_7_0.deleteRealm(this.serverData.id),
            RealmsUtil.openScreenAndLogOnFailure(this.configurationScreen::createErrorScreen, "Couldn't delete world")
         )
         .thenRunAsync(() -> this.minecraft.setScreen(this.configurationScreen.getLastScreen()), this.minecraft);
      this.minecraft.setScreen(this.configurationScreen);
   }

   private void getSubscription(long p22e2f50e_3_0) {
      RealmsClient $$1 = RealmsClient.getOrCreate();

      try {
         Subscription $$2 = $$1.subscriptionFor(p22e2f50e_3_0);
         this.daysLeft = this.daysLeftPresentation($$2.daysLeft());
         this.startDate = localPresentation($$2.startDate());
         this.type = $$2.type();
      } catch (RealmsServiceException $$3) {
         LOGGER.error("Couldn't get subscription", $$3);
         this.minecraft.setScreen(this.configurationScreen.createErrorScreen($$3));
      }
   }

   private static Component localPresentation(Instant p22e2f50e_4_0) {
      String $$1 = ZonedDateTime.ofInstant(p22e2f50e_4_0, ZoneId.systemDefault()).format(Util.localizedDateFormatter(FormatStyle.MEDIUM));
      return Component.literal($$1).withStyle(ChatFormatting.GRAY);
   }

   private Component daysLeftPresentation(int p22e2f50e_5_0) {
      if (p22e2f50e_5_0 < 0 && this.serverData.expired) {
         return SUBSCRIPTION_EXPIRED_TEXT;
      } else if (p22e2f50e_5_0 <= 1) {
         return SUBSCRIPTION_LESS_THAN_A_DAY_TEXT;
      } else {
         int $$1 = p22e2f50e_5_0 / 30;
         int $$2 = p22e2f50e_5_0 % 30;
         boolean $$3 = $$1 > 0;
         boolean $$4 = $$2 > 0;
         if ($$3 && $$4) {
            return Component.translatable("mco.configure.world.subscription.remaining.months.days", $$1, $$2).withStyle(ChatFormatting.GRAY);
         } else if ($$3) {
            return Component.translatable("mco.configure.world.subscription.remaining.months", $$1).withStyle(ChatFormatting.GRAY);
         } else {
            return $$4 ? Component.translatable("mco.configure.world.subscription.remaining.days", $$2).withStyle(ChatFormatting.GRAY) : Component.empty();
         }
      }
   }

   @Override
   public void updateData(RealmsServer p22e2f50e_6_0) {
      this.serverData = p22e2f50e_6_0;
      this.getSubscription(p22e2f50e_6_0.id);
      this.startDateWidget.setMessage(this.startDate);
      if (this.type == Subscription.SubscriptionType.NORMAL) {
         this.daysLeftLabelWidget.setMessage(TIME_LEFT_LABEL);
      } else if (this.type == Subscription.SubscriptionType.RECURRING) {
         this.daysLeftLabelWidget.setMessage(DAYS_LEFT_LABEL);
      }

      this.daysLeftWidget.setMessage(this.daysLeft);
      boolean $$1 = RealmsMainScreen.isSnapshot() && p22e2f50e_6_0.parentWorldName != null;
      this.deleteButton.active = p22e2f50e_6_0.expired;
      if ($$1) {
         this.subscriptionInfo.setMessage(Component.translatable("mco.snapshot.subscription.info", p22e2f50e_6_0.parentWorldName));
      } else {
         this.subscriptionInfo.setMessage(RECURRING_INFO);
      }

      this.layout.arrangeElements();
   }

   @Override
   public Component getTabExtraNarration() {
      return CommonComponents.joinLines(TITLE, SUBSCRIPTION_START_LABEL, this.startDate, TIME_LEFT_LABEL, this.daysLeft);
   }
}
