package com.mojang.realmsclient.gui.screens.configuration;

import com.google.common.collect.ImmutableList;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.dto.Ops;
import com.mojang.realmsclient.dto.PlayerInfo;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.gui.screens.RealmsConfirmScreen;
import com.mojang.realmsclient.util.RealmsUtil;
import java.util.List;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.FocusableTextWidget;
import net.minecraft.client.gui.components.SpriteIconButton;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.components.tabs.GridLayoutTab;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.layouts.LayoutSettings;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;

class RealmsPlayersTab extends GridLayoutTab implements RealmsConfigurationTab {
   static final Logger LOGGER = LogUtils.getLogger();
   static final Component TITLE = Component.translatable("mco.configure.world.players.title");
   static final Component QUESTION_TITLE = Component.translatable("mco.question");
   private static final int PADDING = 8;
   final RealmsConfigureWorldScreen configurationScreen;
   final Minecraft minecraft;
   final Font font;
   RealmsServer serverData;
   final RealmsPlayersTab.InvitedObjectSelectionList invitedList;

   RealmsPlayersTab(RealmsConfigureWorldScreen pd3a24aed_0_0, Minecraft pd3a24aed_1_1, RealmsServer pd3a24aed_2_2) {
      super(TITLE);
      this.configurationScreen = pd3a24aed_0_0;
      this.minecraft = pd3a24aed_1_1;
      this.font = pd3a24aed_0_0.getFont();
      this.serverData = pd3a24aed_2_2;
      GridLayout.RowHelper $$3 = this.layout.spacing(8).createRowHelper(1);
      this.invitedList = $$3.addChild(
         new RealmsPlayersTab.InvitedObjectSelectionList(pd3a24aed_0_0.width, this.calculateListHeight()),
         LayoutSettings.defaults().alignVerticallyTop().alignHorizontallyCenter()
      );
      $$3.addChild(
         Button.builder(
               Component.translatable("mco.configure.world.buttons.invite"),
               pd3a24aed_8_3 -> pd3a24aed_1_1.setScreen(new RealmsInviteScreen(pd3a24aed_0_0, pd3a24aed_2_2))
            )
            .build(),
         LayoutSettings.defaults().alignVerticallyBottom().alignHorizontallyCenter()
      );
      this.updateData(pd3a24aed_2_2);
   }

   public int calculateListHeight() {
      return this.configurationScreen.getContentHeight() - 20 - 16;
   }

   @Override
   public void doLayout(ScreenRectangle pd3a24aed_3_0) {
      this.invitedList.updateSizeAndPosition(this.configurationScreen.width, this.calculateListHeight(), this.configurationScreen.layout.getHeaderHeight());
      super.doLayout(pd3a24aed_3_0);
   }

   @Override
   public void updateData(RealmsServer pd3a24aed_4_0) {
      this.serverData = pd3a24aed_4_0;
      this.invitedList.updateList(pd3a24aed_4_0);
   }

   abstract static class Entry extends ContainerObjectSelectionList.Entry<RealmsPlayersTab.Entry> {
   }

   class HeaderEntry extends RealmsPlayersTab.Entry {
      private String cachedNumberOfInvites = "";
      private final FocusableTextWidget invitedWidget;

      public HeaderEntry() {
         Component $$0 = Component.translatable("mco.configure.world.invited.number", "").withStyle(ChatFormatting.UNDERLINE);
         this.invitedWidget = FocusableTextWidget.builder($$0, RealmsPlayersTab.this.font)
            .alwaysShowBorder(false)
            .backgroundFill(FocusableTextWidget.BackgroundFill.ON_FOCUS)
            .build();
      }

      @Override
      public void renderContent(GuiGraphics pdd58fe8e_1_0, int pdd58fe8e_2_1, int pdd58fe8e_3_2, boolean pdd58fe8e_4_3, float pdd58fe8e_5_4) {
         String $$5 = RealmsPlayersTab.this.serverData.players != null ? Integer.toString(RealmsPlayersTab.this.serverData.players.size()) : "0";
         if (!$$5.equals(this.cachedNumberOfInvites)) {
            this.cachedNumberOfInvites = $$5;
            Component $$6 = Component.translatable("mco.configure.world.invited.number", $$5).withStyle(ChatFormatting.UNDERLINE);
            this.invitedWidget.setMessage($$6);
         }

         this.invitedWidget
            .setPosition(
               RealmsPlayersTab.this.invitedList.getRowLeft() + RealmsPlayersTab.this.invitedList.getRowWidth() / 2 - this.invitedWidget.getWidth() / 2,
               this.getY() + this.getHeight() / 2 - this.invitedWidget.getHeight() / 2
            );
         this.invitedWidget.render(pdd58fe8e_1_0, pdd58fe8e_2_1, pdd58fe8e_3_2, pdd58fe8e_5_4);
      }

      int height(int pdd58fe8e_6_0) {
         return pdd58fe8e_6_0 + this.invitedWidget.getPadding() * 2;
      }

      @Override
      public List<? extends NarratableEntry> narratables() {
         return List.of(this.invitedWidget);
      }

      @Override
      public List<? extends GuiEventListener> children() {
         return List.of(this.invitedWidget);
      }
   }

   class InvitedObjectSelectionList extends ContainerObjectSelectionList<RealmsPlayersTab.Entry> {
      private static final int PLAYER_ENTRY_HEIGHT = 36;

      public InvitedObjectSelectionList(final int p59551107_1_1, final int p59551107_2_2) {
         super(Minecraft.getInstance(), p59551107_1_1, p59551107_2_2, RealmsPlayersTab.this.configurationScreen.getHeaderHeight(), 36);
      }

      void updateList(RealmsServer p59551107_3_0) {
         this.clearEntries();
         this.populateList(p59551107_3_0);
      }

      private void populateList(RealmsServer p59551107_4_0) {
         RealmsPlayersTab.HeaderEntry $$1 = RealmsPlayersTab.this.new HeaderEntry();
         this.addEntry($$1, $$1.height(9));

         for (RealmsPlayersTab.PlayerEntry $$2 : p59551107_4_0.players
            .stream()
            .map(p59551107_7_0 -> RealmsPlayersTab.this.new PlayerEntry(p59551107_7_0))
            .toList()) {
            this.addEntry($$2);
         }
      }

      @Override
      protected void renderListBackground(GuiGraphics p59551107_5_0) {
      }

      @Override
      protected void renderListSeparators(GuiGraphics p59551107_6_0) {
      }

      @Override
      public int getRowWidth() {
         return 300;
      }
   }

   class PlayerEntry extends RealmsPlayersTab.Entry {
      protected static final int SKIN_FACE_SIZE = 32;
      private static final Component NORMAL_USER_TEXT = Component.translatable("mco.configure.world.invites.normal.tooltip");
      private static final Component OP_TEXT = Component.translatable("mco.configure.world.invites.ops.tooltip");
      private static final Component REMOVE_TEXT = Component.translatable("mco.configure.world.invites.remove.tooltip");
      private static final Identifier MAKE_OP_SPRITE = Identifier.withDefaultNamespace("player_list/make_operator");
      private static final Identifier REMOVE_OP_SPRITE = Identifier.withDefaultNamespace("player_list/remove_operator");
      private static final Identifier REMOVE_PLAYER_SPRITE = Identifier.withDefaultNamespace("player_list/remove_player");
      private static final int ICON_WIDTH = 8;
      private static final int ICON_HEIGHT = 7;
      private final PlayerInfo playerInfo;
      private final Button removeButton;
      private final Button makeOpButton;
      private final Button removeOpButton;

      public PlayerEntry(final PlayerInfo pb7f95aba_1_1) {
         this.playerInfo = pb7f95aba_1_1;
         int $$1 = RealmsPlayersTab.this.serverData.players.indexOf(this.playerInfo);
         this.makeOpButton = SpriteIconButton.builder(NORMAL_USER_TEXT, pb7f95aba_36_1 -> this.op($$1), false)
            .sprite(MAKE_OP_SPRITE, 8, 7)
            .width(16 + RealmsPlayersTab.this.configurationScreen.getFont().width(NORMAL_USER_TEXT))
            .narration(
               pb7f95aba_34_1 -> CommonComponents.joinForNarration(
                  Component.translatable("mco.invited.player.narration", pb7f95aba_1_1.name),
                  pb7f95aba_34_1.get(),
                  Component.translatable("narration.cycle_button.usage.focused", OP_TEXT)
               )
            )
            .build();
         this.removeOpButton = SpriteIconButton.builder(OP_TEXT, pb7f95aba_32_1 -> this.deop($$1), false)
            .sprite(REMOVE_OP_SPRITE, 8, 7)
            .width(16 + RealmsPlayersTab.this.configurationScreen.getFont().width(OP_TEXT))
            .narration(
               pb7f95aba_30_1 -> CommonComponents.joinForNarration(
                  Component.translatable("mco.invited.player.narration", pb7f95aba_1_1.name),
                  pb7f95aba_30_1.get(),
                  Component.translatable("narration.cycle_button.usage.focused", NORMAL_USER_TEXT)
               )
            )
            .build();
         this.removeButton = SpriteIconButton.builder(REMOVE_TEXT, pb7f95aba_28_1 -> this.uninvite($$1), false)
            .sprite(REMOVE_PLAYER_SPRITE, 8, 7)
            .width(16 + RealmsPlayersTab.this.configurationScreen.getFont().width(REMOVE_TEXT))
            .narration(
               pb7f95aba_26_1 -> CommonComponents.joinForNarration(
                  Component.translatable("mco.invited.player.narration", pb7f95aba_1_1.name), pb7f95aba_26_1.get()
               )
            )
            .build();
         this.updateOpButtons();
      }

      private void op(int pb7f95aba_2_0) {
         UUID $$1 = RealmsPlayersTab.this.serverData.players.get(pb7f95aba_2_0).uuid;
         RealmsUtil.<Ops>supplyAsync(
               pb7f95aba_24_1 -> pb7f95aba_24_1.op(RealmsPlayersTab.this.serverData.id, $$1),
               pb7f95aba_22_0 -> RealmsPlayersTab.LOGGER.error("Couldn't op the user", pb7f95aba_22_0)
            )
            .thenAcceptAsync(pb7f95aba_21_0 -> {
               this.updateOps(pb7f95aba_21_0);
               this.updateOpButtons();
               this.setFocused(this.removeOpButton);
            }, RealmsPlayersTab.this.minecraft);
      }

      private void deop(int pb7f95aba_3_0) {
         UUID $$1 = RealmsPlayersTab.this.serverData.players.get(pb7f95aba_3_0).uuid;
         RealmsUtil.<Ops>supplyAsync(
               pb7f95aba_20_1 -> pb7f95aba_20_1.deop(RealmsPlayersTab.this.serverData.id, $$1),
               pb7f95aba_18_0 -> RealmsPlayersTab.LOGGER.error("Couldn't deop the user", pb7f95aba_18_0)
            )
            .thenAcceptAsync(pb7f95aba_17_0 -> {
               this.updateOps(pb7f95aba_17_0);
               this.updateOpButtons();
               this.setFocused(this.makeOpButton);
            }, RealmsPlayersTab.this.minecraft);
      }

      private void uninvite(int pb7f95aba_4_0) {
         if (pb7f95aba_4_0 >= 0 && pb7f95aba_4_0 < RealmsPlayersTab.this.serverData.players.size()) {
            PlayerInfo $$1 = RealmsPlayersTab.this.serverData.players.get(pb7f95aba_4_0);
            RealmsConfirmScreen $$2 = new RealmsConfirmScreen(
               pb7f95aba_13_2 -> {
                  if (pb7f95aba_13_2) {
                     RealmsUtil.runAsync(
                        pb7f95aba_16_1 -> pb7f95aba_16_1.uninvite(RealmsPlayersTab.this.serverData.id, $$1.uuid),
                        pb7f95aba_14_0 -> RealmsPlayersTab.LOGGER.error("Couldn't uninvite user", pb7f95aba_14_0)
                     );
                     RealmsPlayersTab.this.serverData.players.remove(pb7f95aba_4_0);
                     RealmsPlayersTab.this.updateData(RealmsPlayersTab.this.serverData);
                  }

                  RealmsPlayersTab.this.minecraft.setScreen(RealmsPlayersTab.this.configurationScreen);
               },
               RealmsPlayersTab.QUESTION_TITLE,
               Component.translatable("mco.configure.world.uninvite.player", $$1.name)
            );
            RealmsPlayersTab.this.minecraft.setScreen($$2);
         }
      }

      private void updateOps(Ops pb7f95aba_5_0) {
         for (PlayerInfo $$1 : RealmsPlayersTab.this.serverData.players) {
            $$1.operator = pb7f95aba_5_0.ops().contains($$1.name);
         }
      }

      private void updateOpButtons() {
         this.makeOpButton.visible = !this.playerInfo.operator;
         this.removeOpButton.visible = !this.makeOpButton.visible;
      }

      private Button activeOpButton() {
         return this.makeOpButton.visible ? this.makeOpButton : this.removeOpButton;
      }

      @Override
      public List<? extends GuiEventListener> children() {
         return ImmutableList.of(this.activeOpButton(), this.removeButton);
      }

      @Override
      public List<? extends NarratableEntry> narratables() {
         return ImmutableList.of(this.activeOpButton(), this.removeButton);
      }

      @Override
      public void renderContent(GuiGraphics pb7f95aba_6_0, int pb7f95aba_7_1, int pb7f95aba_8_2, boolean pb7f95aba_9_3, float pb7f95aba_10_4) {
         int $$5;
         if (!this.playerInfo.accepted) {
            $$5 = -6250336;
         } else if (this.playerInfo.online) {
            $$5 = -16711936;
         } else {
            $$5 = -1;
         }

         int $$8 = this.getContentYMiddle() - 16;
         RealmsUtil.renderPlayerFace(pb7f95aba_6_0, this.getContentX(), $$8, 32, this.playerInfo.uuid);
         int $$9 = this.getContentYMiddle() - 9 / 2;
         pb7f95aba_6_0.drawString(RealmsPlayersTab.this.font, this.playerInfo.name, this.getContentX() + 8 + 32, $$9, $$5);
         int $$10 = this.getContentYMiddle() - 10;
         int $$11 = this.getContentRight() - this.removeButton.getWidth();
         this.removeButton.setPosition($$11, $$10);
         this.removeButton.render(pb7f95aba_6_0, pb7f95aba_7_1, pb7f95aba_8_2, pb7f95aba_10_4);
         int $$12 = $$11 - this.activeOpButton().getWidth() - 8;
         this.makeOpButton.setPosition($$12, $$10);
         this.makeOpButton.render(pb7f95aba_6_0, pb7f95aba_7_1, pb7f95aba_8_2, pb7f95aba_10_4);
         this.removeOpButton.setPosition($$12, $$10);
         this.removeOpButton.render(pb7f95aba_6_0, pb7f95aba_7_1, pb7f95aba_8_2, pb7f95aba_10_4);
      }
   }
}
