package com.mojang.realmsclient.gui.screens.configuration;

import com.google.common.collect.Lists;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.WorldTemplate;
import com.mojang.realmsclient.gui.RealmsWorldSlotButton;
import com.mojang.realmsclient.gui.screens.RealmsLongRunningMcoTaskScreen;
import com.mojang.realmsclient.gui.screens.RealmsPopups;
import com.mojang.realmsclient.gui.screens.RealmsResetWorldScreen;
import com.mojang.realmsclient.gui.screens.RealmsSelectWorldTemplateScreen;
import com.mojang.realmsclient.util.task.SwitchMinigameTask;
import com.mojang.realmsclient.util.task.SwitchSlotTask;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.tabs.GridLayoutTab;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.layouts.LayoutSettings;
import net.minecraft.network.chat.Component;
import org.jspecify.annotations.Nullable;

class RealmsWorldsTab extends GridLayoutTab implements RealmsConfigurationTab {
   static final Component TITLE = Component.translatable("mco.configure.worlds.title");
   private final RealmsConfigureWorldScreen configurationScreen;
   private final Minecraft minecraft;
   private RealmsServer serverData;
   private final Button optionsButton;
   private final Button backupButton;
   private final Button resetWorldButton;
   private final List<RealmsWorldSlotButton> slotButtonList = Lists.newArrayList();

   RealmsWorldsTab(RealmsConfigureWorldScreen p3d84210a_0_0, Minecraft p3d84210a_1_1, RealmsServer p3d84210a_2_2) {
      super(TITLE);
      this.configurationScreen = p3d84210a_0_0;
      this.minecraft = p3d84210a_1_1;
      this.serverData = p3d84210a_2_2;
      GridLayout.RowHelper $$3 = this.layout.spacing(20).createRowHelper(1);
      GridLayout.RowHelper $$4 = new GridLayout().spacing(16).createRowHelper(4);
      this.slotButtonList.clear();

      for (int $$5 = 1; $$5 < 5; $$5++) {
         this.slotButtonList.add($$4.addChild(this.createSlotButton($$5), LayoutSettings.defaults().alignVerticallyBottom()));
      }

      $$3.addChild($$4.getGrid());
      GridLayout.RowHelper $$6 = new GridLayout().spacing(8).createRowHelper(1);
      this.optionsButton = $$6.addChild(
         Button.builder(
               Component.translatable("mco.configure.world.buttons.options"),
               p3d84210a_29_3 -> p3d84210a_1_1.setScreen(
                  new RealmsSlotOptionsScreen(
                     p3d84210a_0_0, p3d84210a_2_2.slots.get(p3d84210a_2_2.activeSlot).copy(), p3d84210a_2_2.worldType, p3d84210a_2_2.activeSlot
                  )
               )
            )
            .bounds(0, 0, 150, 20)
            .build()
      );
      this.backupButton = $$6.addChild(
         Button.builder(
               Component.translatable("mco.configure.world.backup"),
               p3d84210a_25_3 -> p3d84210a_1_1.setScreen(new RealmsBackupScreen(p3d84210a_0_0, p3d84210a_2_2.copy(), p3d84210a_2_2.activeSlot))
            )
            .bounds(0, 0, 150, 20)
            .build()
      );
      this.resetWorldButton = $$6.addChild(Button.builder(Component.empty(), p3d84210a_21_0 -> this.resetButtonPressed()).bounds(0, 0, 150, 20).build());
      $$3.addChild($$6.getGrid(), LayoutSettings.defaults().alignHorizontallyCenter());
      this.backupButton.active = true;
      this.updateData(p3d84210a_2_2);
   }

   private void resetButtonPressed() {
      if (this.isMinigame()) {
         this.minecraft
            .setScreen(
               new RealmsSelectWorldTemplateScreen(
                  Component.translatable("mco.template.title.minigame"), this::templateSelectionCallback, RealmsServer.WorldType.MINIGAME, null
               )
            );
      } else {
         this.minecraft
            .setScreen(
               RealmsResetWorldScreen.forResetSlot(
                  this.configurationScreen,
                  this.serverData.copy(),
                  () -> this.minecraft.execute(() -> this.minecraft.setScreen(this.configurationScreen.getNewScreen()))
               )
            );
      }
   }

   private void templateSelectionCallback(@Nullable WorldTemplate p3d84210a_3_0) {
      if (p3d84210a_3_0 != null && WorldTemplate.WorldTemplateType.MINIGAME == p3d84210a_3_0.type()) {
         this.configurationScreen.stateChanged();
         RealmsConfigureWorldScreen $$1 = this.configurationScreen.getNewScreen();
         this.minecraft.setScreen(new RealmsLongRunningMcoTaskScreen($$1, new SwitchMinigameTask(this.serverData.id, p3d84210a_3_0, $$1)));
      } else {
         this.minecraft.setScreen(this.configurationScreen);
      }
   }

   private boolean isMinigame() {
      return this.serverData.isMinigameActive();
   }

   @Override
   public void onSelected(RealmsServer p3d84210a_4_0) {
      this.updateData(p3d84210a_4_0);
   }

   @Override
   public void updateData(RealmsServer p3d84210a_5_0) {
      this.serverData = p3d84210a_5_0;
      this.optionsButton.active = !p3d84210a_5_0.expired && !this.isMinigame();
      this.resetWorldButton.active = !p3d84210a_5_0.expired;
      if (this.isMinigame()) {
         this.resetWorldButton.setMessage(Component.translatable("mco.configure.world.buttons.switchminigame"));
      } else {
         boolean $$1 = p3d84210a_5_0.slots.containsKey(p3d84210a_5_0.activeSlot) && p3d84210a_5_0.slots.get(p3d84210a_5_0.activeSlot).options.empty;
         if ($$1) {
            this.resetWorldButton.setMessage(Component.translatable("mco.configure.world.buttons.newworld"));
         } else {
            this.resetWorldButton.setMessage(Component.translatable("mco.configure.world.buttons.resetworld"));
         }
      }

      this.backupButton.active = !this.isMinigame();

      for (RealmsWorldSlotButton $$2 : this.slotButtonList) {
         RealmsWorldSlotButton.State $$3 = $$2.setServerData(p3d84210a_5_0);
         if ($$3.activeSlot) {
            $$2.setSize(80, 80);
         } else {
            $$2.setSize(50, 50);
         }
      }
   }

   private RealmsWorldSlotButton createSlotButton(int p3d84210a_6_0) {
      return new RealmsWorldSlotButton(0, 0, 80, 80, p3d84210a_6_0, this.serverData, p3d84210a_20_1 -> {
         RealmsWorldSlotButton.State $$2 = ((RealmsWorldSlotButton)p3d84210a_20_1).getState();
         switch ($$2.action) {
            case SWITCH_SLOT:
               if ($$2.minigame) {
                  this.switchToMinigame();
               } else if ($$2.empty) {
                  this.switchToEmptySlot(p3d84210a_6_0, this.serverData);
               } else {
                  this.switchToFullSlot(p3d84210a_6_0, this.serverData);
               }
            case NOTHING:
               return;
            default:
               throw new IllegalStateException("Unknown action " + $$2.action);
         }
      });
   }

   private void switchToMinigame() {
      RealmsSelectWorldTemplateScreen $$0 = new RealmsSelectWorldTemplateScreen(
         Component.translatable("mco.template.title.minigame"),
         this::templateSelectionCallback,
         RealmsServer.WorldType.MINIGAME,
         null,
         List.of(
            Component.translatable("mco.minigame.world.info.line1").withColor(-4539718),
            Component.translatable("mco.minigame.world.info.line2").withColor(-4539718)
         )
      );
      this.minecraft.setScreen($$0);
   }

   private void switchToFullSlot(int p3d84210a_7_0, RealmsServer p3d84210a_8_1) {
      this.minecraft
         .setScreen(
            RealmsPopups.infoPopupScreen(
               this.configurationScreen,
               Component.translatable("mco.configure.world.slot.switch.question.line1"),
               p3d84210a_16_2 -> {
                  RealmsConfigureWorldScreen $$3 = this.configurationScreen.getNewScreen();
                  this.configurationScreen.stateChanged();
                  this.minecraft
                     .setScreen(
                        new RealmsLongRunningMcoTaskScreen(
                           $$3, new SwitchSlotTask(p3d84210a_8_1.id, p3d84210a_7_0, () -> this.minecraft.execute(() -> this.minecraft.setScreen($$3)))
                        )
                     );
               }
            )
         );
   }

   private void switchToEmptySlot(int p3d84210a_9_0, RealmsServer p3d84210a_10_1) {
      this.minecraft
         .setScreen(
            RealmsPopups.infoPopupScreen(
               this.configurationScreen,
               Component.translatable("mco.configure.world.slot.switch.question.line1"),
               p3d84210a_13_2 -> {
                  this.configurationScreen.stateChanged();
                  RealmsResetWorldScreen $$3 = RealmsResetWorldScreen.forEmptySlot(
                     this.configurationScreen,
                     p3d84210a_9_0,
                     p3d84210a_10_1,
                     () -> this.minecraft.execute(() -> this.minecraft.setScreen(this.configurationScreen.getNewScreen()))
                  );
                  this.minecraft.setScreen($$3);
               }
            )
         );
   }
}
