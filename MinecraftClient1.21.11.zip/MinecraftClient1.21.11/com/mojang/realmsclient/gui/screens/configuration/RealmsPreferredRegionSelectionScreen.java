package com.mojang.realmsclient.gui.screens.configuration;

import com.mojang.realmsclient.dto.RealmsRegion;
import com.mojang.realmsclient.dto.RegionSelectionPreference;
import com.mojang.realmsclient.dto.ServiceQuality;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiConsumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import org.jspecify.annotations.Nullable;

public class RealmsPreferredRegionSelectionScreen extends Screen {
   private static final Component REGION_SELECTION_LABEL = Component.translatable("mco.configure.world.region_preference.title");
   private static final int SPACING = 8;
   private final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);
   private final Screen parent;
   private final BiConsumer<RegionSelectionPreference, RealmsRegion> applySettings;
   final Map<RealmsRegion, ServiceQuality> regionServiceQuality;
   private RealmsPreferredRegionSelectionScreen.@Nullable RegionSelectionList list;
   RealmsSettingsTab.RegionSelection selection;
   private @Nullable Button doneButton;

   public RealmsPreferredRegionSelectionScreen(
      Screen pc2d5feed_0_0,
      BiConsumer<RegionSelectionPreference, RealmsRegion> pc2d5feed_1_1,
      Map<RealmsRegion, ServiceQuality> pc2d5feed_2_2,
      RealmsSettingsTab.RegionSelection pc2d5feed_3_3
   ) {
      super(REGION_SELECTION_LABEL);
      this.parent = pc2d5feed_0_0;
      this.applySettings = pc2d5feed_1_1;
      this.regionServiceQuality = pc2d5feed_2_2;
      this.selection = pc2d5feed_3_3;
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.parent);
   }

   @Override
   protected void init() {
      LinearLayout $$0 = this.layout.addToHeader(LinearLayout.vertical().spacing(8));
      $$0.defaultCellSetting().alignHorizontallyCenter();
      $$0.addChild(new StringWidget(this.getTitle(), this.font));
      this.list = this.layout.addToContents(new RealmsPreferredRegionSelectionScreen.RegionSelectionList());
      LinearLayout $$1 = this.layout.addToFooter(LinearLayout.horizontal().spacing(8));
      this.doneButton = $$1.addChild(Button.builder(CommonComponents.GUI_DONE, pc2d5feed_8_0 -> this.onDone()).build());
      $$1.addChild(Button.builder(CommonComponents.GUI_CANCEL, pc2d5feed_7_0 -> this.onClose()).build());
      this.list
         .setSelected(
            this.list.children().stream().filter(pc2d5feed_6_0 -> Objects.equals(pc2d5feed_6_0.regionSelection, this.selection)).findFirst().orElse(null)
         );
      this.layout.visitWidgets(pc2d5feed_5_1 -> {
         AbstractWidget var10000 = this.addRenderableWidget(pc2d5feed_5_1);
      });
      this.repositionElements();
   }

   @Override
   protected void repositionElements() {
      this.layout.arrangeElements();
      if (this.list != null) {
         this.list.updateSize(this.width, this.layout);
      }
   }

   void onDone() {
      if (this.selection.region() != null) {
         this.applySettings.accept(this.selection.preference(), this.selection.region());
      }

      this.onClose();
   }

   void updateButtonValidity() {
      if (this.doneButton != null && this.list != null) {
         this.doneButton.active = this.list.getSelected() != null;
      }
   }

   class RegionSelectionList extends ObjectSelectionList<RealmsPreferredRegionSelectionScreen.RegionSelectionList.Entry> {
      RegionSelectionList() {
         super(
            RealmsPreferredRegionSelectionScreen.this.minecraft,
            RealmsPreferredRegionSelectionScreen.this.width,
            RealmsPreferredRegionSelectionScreen.this.height - 77,
            40,
            16
         );
         this.addEntry(new RealmsPreferredRegionSelectionScreen.RegionSelectionList.Entry(RegionSelectionPreference.AUTOMATIC_PLAYER, null));
         this.addEntry(new RealmsPreferredRegionSelectionScreen.RegionSelectionList.Entry(RegionSelectionPreference.AUTOMATIC_OWNER, null));
         RealmsPreferredRegionSelectionScreen.this.regionServiceQuality
            .keySet()
            .stream()
            .map(pde96195f_5_0 -> new RealmsPreferredRegionSelectionScreen.RegionSelectionList.Entry(RegionSelectionPreference.MANUAL, pde96195f_5_0))
            .forEach(pde96195f_4_1 -> this.addEntry(pde96195f_4_1));
      }

      public void setSelected(RealmsPreferredRegionSelectionScreen.RegionSelectionList.@Nullable Entry pde96195f_1_0) {
         super.setSelected(pde96195f_1_0);
         if (pde96195f_1_0 != null) {
            RealmsPreferredRegionSelectionScreen.this.selection = pde96195f_1_0.regionSelection;
         }

         RealmsPreferredRegionSelectionScreen.this.updateButtonValidity();
      }

      class Entry extends ObjectSelectionList.Entry<RealmsPreferredRegionSelectionScreen.RegionSelectionList.Entry> {
         final RealmsSettingsTab.RegionSelection regionSelection;
         private final Component name;

         public Entry(final RegionSelectionPreference p74bde4cd_1_1, final @Nullable RealmsRegion p74bde4cd_2_2) {
            this(new RealmsSettingsTab.RegionSelection(p74bde4cd_1_1, p74bde4cd_2_2));
         }

         public Entry(final RealmsSettingsTab.RegionSelection p74bde4cd_4_1) {
            this.regionSelection = p74bde4cd_4_1;
            if (p74bde4cd_4_1.preference() == RegionSelectionPreference.MANUAL) {
               if (p74bde4cd_4_1.region() != null) {
                  this.name = Component.translatable(p74bde4cd_4_1.region().translationKey);
               } else {
                  this.name = Component.empty();
               }
            } else {
               this.name = Component.translatable(p74bde4cd_4_1.preference().translationKey);
            }
         }

         @Override
         public Component getNarration() {
            return Component.translatable("narrator.select", this.name);
         }

         @Override
         public void renderContent(GuiGraphics p74bde4cd_5_0, int p74bde4cd_6_1, int p74bde4cd_7_2, boolean p74bde4cd_8_3, float p74bde4cd_9_4) {
            p74bde4cd_5_0.drawString(RealmsPreferredRegionSelectionScreen.this.font, this.name, this.getContentX() + 5, this.getContentY() + 2, -1);
            if (this.regionSelection.region() != null
               && RealmsPreferredRegionSelectionScreen.this.regionServiceQuality.containsKey(this.regionSelection.region())) {
               ServiceQuality $$5 = RealmsPreferredRegionSelectionScreen.this.regionServiceQuality
                  .getOrDefault(this.regionSelection.region(), ServiceQuality.UNKNOWN);
               p74bde4cd_5_0.blitSprite(RenderPipelines.GUI_TEXTURED, $$5.getIcon(), this.getContentRight() - 18, this.getContentY() + 2, 10, 8);
            }
         }

         @Override
         public boolean mouseClicked(MouseButtonEvent p74bde4cd_10_0, boolean p74bde4cd_11_1) {
            RegionSelectionList.this.setSelected(this);
            if (p74bde4cd_11_1) {
               RegionSelectionList.this.playDownSound(RegionSelectionList.this.minecraft.getSoundManager());
               RealmsPreferredRegionSelectionScreen.this.onDone();
               return true;
            } else {
               return super.mouseClicked(p74bde4cd_10_0, p74bde4cd_11_1);
            }
         }

         @Override
         public boolean keyPressed(KeyEvent p74bde4cd_12_0) {
            if (p74bde4cd_12_0.isSelection()) {
               RegionSelectionList.this.playDownSound(RegionSelectionList.this.minecraft.getSoundManager());
               RealmsPreferredRegionSelectionScreen.this.onDone();
               return true;
            } else {
               return super.keyPressed(p74bde4cd_12_0);
            }
         }
      }
   }
}
