package com.mojang.realmsclient.gui.screens.configuration;

import com.mojang.realmsclient.dto.RealmsRegion;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.RegionSelectionPreference;
import com.mojang.realmsclient.dto.RegionSelectionPreferenceDto;
import com.mojang.realmsclient.dto.ServiceQuality;
import com.mojang.realmsclient.gui.screens.RealmsPopups;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.ImageWidget;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.tabs.GridLayoutTab;
import net.minecraft.client.gui.layouts.EqualSpacingLayout;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.layouts.SpacerElement;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;

public class RealmsSettingsTab extends GridLayoutTab implements RealmsConfigurationTab {
   private static final int COMPONENT_WIDTH = 212;
   private static final int EXTRA_SPACING = 2;
   private static final int DEFAULT_SPACING = 6;
   static final Component TITLE = Component.translatable("mco.configure.world.settings.title");
   private static final Component NAME_LABEL = Component.translatable("mco.configure.world.name");
   private static final Component DESCRIPTION_LABEL = Component.translatable("mco.configure.world.description");
   private static final Component REGION_PREFERENCE_LABEL = Component.translatable("mco.configure.world.region_preference");
   private static final Tooltip REALM_NAME_VALIDATION_ERROR_TOOLTIP = Tooltip.create(Component.translatable("mco.configure.world.name.validation.whitespace"));
   private final RealmsConfigureWorldScreen configurationScreen;
   private final Minecraft minecraft;
   private RealmsServer serverData;
   private final Map<RealmsRegion, ServiceQuality> regionServiceQuality;
   final Button closeOpenButton;
   private final EditBox descEdit;
   private final EditBox nameEdit;
   private final StringWidget selectedRegionStringWidget;
   private final ImageWidget selectedRegionImageWidget;
   private RealmsSettingsTab.RegionSelection preferredRegionSelection;

   RealmsSettingsTab(
      RealmsConfigureWorldScreen p772bc748_0_0, Minecraft p772bc748_1_1, RealmsServer p772bc748_2_2, Map<RealmsRegion, ServiceQuality> p772bc748_3_3
   ) {
      super(TITLE);
      this.configurationScreen = p772bc748_0_0;
      this.minecraft = p772bc748_1_1;
      this.serverData = p772bc748_2_2;
      this.regionServiceQuality = p772bc748_3_3;
      GridLayout.RowHelper $$4 = this.layout.rowSpacing(6).createRowHelper(1);
      $$4.addChild(new StringWidget(NAME_LABEL, p772bc748_0_0.getFont()));
      this.nameEdit = new EditBox(p772bc748_1_1.font, 0, 0, 212, 20, Component.translatable("mco.configure.world.name"));
      this.nameEdit.setMaxLength(32);
      this.nameEdit.setResponder(p772bc748_21_0 -> {
         if (!this.isRealmNameValid()) {
            this.nameEdit.setTextColor(-2142128);
            this.nameEdit.setTooltip(REALM_NAME_VALIDATION_ERROR_TOOLTIP);
         } else {
            this.nameEdit.setTooltip(null);
            this.nameEdit.setTextColor(-2039584);
         }
      });
      $$4.addChild(this.nameEdit);
      $$4.addChild(SpacerElement.height(2));
      $$4.addChild(new StringWidget(DESCRIPTION_LABEL, p772bc748_0_0.getFont()));
      this.descEdit = new EditBox(p772bc748_1_1.font, 0, 0, 212, 20, Component.translatable("mco.configure.world.description"));
      this.descEdit.setMaxLength(32);
      $$4.addChild(this.descEdit);
      $$4.addChild(SpacerElement.height(2));
      $$4.addChild(new StringWidget(REGION_PREFERENCE_LABEL, p772bc748_0_0.getFont()));
      EqualSpacingLayout $$5 = new EqualSpacingLayout(0, 0, 212, 9, EqualSpacingLayout.Orientation.HORIZONTAL);
      this.selectedRegionStringWidget = $$5.addChild(new StringWidget(192, 9, Component.empty(), p772bc748_0_0.getFont()));
      this.selectedRegionImageWidget = $$5.addChild(ImageWidget.sprite(10, 8, ServiceQuality.UNKNOWN.getIcon()));
      $$4.addChild($$5);
      $$4.addChild(
         Button.builder(Component.translatable("mco.configure.world.buttons.region_preference"), p772bc748_20_0 -> this.openPreferenceSelector())
            .bounds(0, 0, 212, 20)
            .build()
      );
      $$4.addChild(SpacerElement.height(2));
      this.closeOpenButton = $$4.addChild(
         Button.builder(
               Component.empty(),
               p772bc748_17_3 -> {
                  if (p772bc748_2_2.state == RealmsServer.State.OPEN) {
                     p772bc748_1_1.setScreen(
                        RealmsPopups.customPopupScreen(
                           p772bc748_0_0,
                           Component.translatable("mco.configure.world.close.question.title"),
                           Component.translatable("mco.configure.world.close.question.line1"),
                           p772bc748_19_1 -> {
                              this.save();
                              p772bc748_0_0.closeTheWorld();
                           }
                        )
                     );
                  } else {
                     this.save();
                     p772bc748_0_0.openTheWorld(false);
                  }
               }
            )
            .bounds(0, 0, 212, 20)
            .build()
      );
      this.closeOpenButton.active = false;
      this.updateData(p772bc748_2_2);
   }

   private static MutableComponent getTranslatableFromPreference(RealmsSettingsTab.RegionSelection p772bc748_4_0) {
      return (p772bc748_4_0.preference().equals(RegionSelectionPreference.MANUAL) && p772bc748_4_0.region() != null
            ? Component.translatable(p772bc748_4_0.region().translationKey)
            : Component.translatable(p772bc748_4_0.preference().translationKey))
         .withStyle(ChatFormatting.GRAY);
   }

   private static Identifier getServiceQualityIcon(RealmsSettingsTab.RegionSelection p772bc748_5_0, Map<RealmsRegion, ServiceQuality> p772bc748_6_1) {
      if (p772bc748_5_0.region() != null && p772bc748_6_1.containsKey(p772bc748_5_0.region())) {
         ServiceQuality $$2 = p772bc748_6_1.getOrDefault(p772bc748_5_0.region(), ServiceQuality.UNKNOWN);
         return $$2.getIcon();
      } else {
         return ServiceQuality.UNKNOWN.getIcon();
      }
   }

   private boolean isRealmNameValid() {
      String $$0 = this.nameEdit.getValue();
      String $$1 = $$0.trim();
      return !$$1.isEmpty() && $$0.length() == $$1.length();
   }

   private void openPreferenceSelector() {
      this.minecraft
         .setScreen(
            new RealmsPreferredRegionSelectionScreen(
               this.configurationScreen, this::applyRegionPreferenceSelection, this.regionServiceQuality, this.preferredRegionSelection
            )
         );
   }

   private void applyRegionPreferenceSelection(RegionSelectionPreference p772bc748_7_0, RealmsRegion p772bc748_8_1) {
      this.preferredRegionSelection = new RealmsSettingsTab.RegionSelection(p772bc748_7_0, p772bc748_8_1);
      this.updateRegionPreferenceValues();
   }

   private void updateRegionPreferenceValues() {
      this.selectedRegionStringWidget.setMessage(getTranslatableFromPreference(this.preferredRegionSelection));
      this.selectedRegionImageWidget.updateResource(getServiceQualityIcon(this.preferredRegionSelection, this.regionServiceQuality));
      this.selectedRegionImageWidget.visible = this.preferredRegionSelection.preference == RegionSelectionPreference.MANUAL;
   }

   @Override
   public void onSelected(RealmsServer p772bc748_9_0) {
      this.updateData(p772bc748_9_0);
   }

   @Override
   public void updateData(RealmsServer p772bc748_10_0) {
      this.serverData = p772bc748_10_0;
      if (p772bc748_10_0.regionSelectionPreference == null) {
         p772bc748_10_0.regionSelectionPreference = RegionSelectionPreferenceDto.DEFAULT;
      }

      if (p772bc748_10_0.regionSelectionPreference.regionSelectionPreference == RegionSelectionPreference.MANUAL
         && p772bc748_10_0.regionSelectionPreference.preferredRegion == null) {
         Optional<RealmsRegion> $$1 = this.regionServiceQuality.keySet().stream().findFirst();
         $$1.ifPresent(p772bc748_13_1 -> p772bc748_10_0.regionSelectionPreference.preferredRegion = p772bc748_13_1);
      }

      String $$2 = p772bc748_10_0.state == RealmsServer.State.OPEN ? "mco.configure.world.buttons.close" : "mco.configure.world.buttons.open";
      this.closeOpenButton.setMessage(Component.translatable($$2));
      this.closeOpenButton.active = true;
      this.preferredRegionSelection = new RealmsSettingsTab.RegionSelection(
         p772bc748_10_0.regionSelectionPreference.regionSelectionPreference, p772bc748_10_0.regionSelectionPreference.preferredRegion
      );
      this.nameEdit.setValue(Objects.requireNonNullElse(p772bc748_10_0.getName(), ""));
      this.descEdit.setValue(p772bc748_10_0.getDescription());
      this.updateRegionPreferenceValues();
   }

   @Override
   public void onDeselected(RealmsServer p772bc748_11_0) {
      this.save();
   }

   public void save() {
      String $$0 = this.nameEdit.getValue().trim();
      if (this.serverData.regionSelectionPreference == null
         || !Objects.equals($$0, this.serverData.name)
         || !Objects.equals(this.descEdit.getValue(), this.serverData.motd)
         || this.preferredRegionSelection.preference() != this.serverData.regionSelectionPreference.regionSelectionPreference
         || this.preferredRegionSelection.region() != this.serverData.regionSelectionPreference.preferredRegion) {
         this.configurationScreen
            .saveSettings($$0, this.descEdit.getValue(), this.preferredRegionSelection.preference(), this.preferredRegionSelection.region());
      }
   }

   public record RegionSelection(RegionSelectionPreference preference, @Nullable RealmsRegion region) {
   }
}
