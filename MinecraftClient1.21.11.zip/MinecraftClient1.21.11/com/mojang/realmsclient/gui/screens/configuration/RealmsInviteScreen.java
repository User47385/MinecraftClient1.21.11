package com.mojang.realmsclient.gui.screens.configuration;

import com.mojang.realmsclient.dto.RealmsServer;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.layouts.CommonLayouts;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.util.StringUtil;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;

public class RealmsInviteScreen extends RealmsScreen {
   private static final Component TITLE = Component.translatable("mco.configure.world.buttons.invite");
   private static final Component NAME_LABEL = Component.translatable("mco.configure.world.invite.profile.name").withColor(-6250336);
   private static final Component INVITING_PLAYER_TEXT = Component.translatable("mco.configure.world.players.inviting").withColor(-6250336);
   private static final Component NO_SUCH_PLAYER_ERROR_TEXT = Component.translatable("mco.configure.world.players.error").withColor(-65536);
   private static final Component DUPLICATE_PLAYER_TEXT = Component.translatable("mco.configure.world.players.invite.duplicate").withColor(-65536);
   private final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);
   private @Nullable EditBox profileName;
   private @Nullable Button inviteButton;
   private final RealmsServer serverData;
   private final RealmsConfigureWorldScreen configureScreen;
   private @Nullable Component message;

   public RealmsInviteScreen(RealmsConfigureWorldScreen p5ea938bf_0_0, RealmsServer p5ea938bf_1_1) {
      super(TITLE);
      this.configureScreen = p5ea938bf_0_0;
      this.serverData = p5ea938bf_1_1;
   }

   @Override
   public void init() {
      this.layout.addTitleHeader(TITLE, this.font);
      LinearLayout $$0 = this.layout.addToContents(LinearLayout.vertical().spacing(8));
      this.profileName = new EditBox(this.minecraft.font, 200, 20, Component.translatable("mco.configure.world.invite.profile.name"));
      $$0.addChild(CommonLayouts.labeledElement(this.font, this.profileName, NAME_LABEL));
      this.inviteButton = $$0.addChild(Button.builder(TITLE, p5ea938bf_14_0 -> this.onInvite()).width(200).build());
      this.layout.addToFooter(Button.builder(CommonComponents.GUI_BACK, p5ea938bf_13_0 -> this.onClose()).width(200).build());
      this.layout.visitWidgets(p5ea938bf_12_1 -> {
         AbstractWidget var10000 = this.addRenderableWidget(p5ea938bf_12_1);
      });
      this.repositionElements();
   }

   @Override
   protected void repositionElements() {
      this.layout.arrangeElements();
   }

   @Override
   protected void setInitialFocus() {
      if (this.profileName != null) {
         this.setInitialFocus(this.profileName);
      }
   }

   private void onInvite() {
      if (this.inviteButton != null && this.profileName != null) {
         if (StringUtil.isBlank(this.profileName.getValue())) {
            this.showMessage(NO_SUCH_PLAYER_ERROR_TEXT);
         } else if (this.serverData.players.stream().anyMatch(p5ea938bf_10_0 -> p5ea938bf_10_0.name.equalsIgnoreCase(this.profileName.getValue()))) {
            this.showMessage(DUPLICATE_PLAYER_TEXT);
         } else {
            long $$0 = this.serverData.id;
            String $$1 = this.profileName.getValue().trim();
            this.inviteButton.active = false;
            this.profileName.setEditable(false);
            this.showMessage(INVITING_PLAYER_TEXT);
            CompletableFuture.<Boolean>supplyAsync(() -> this.configureScreen.invitePlayer($$0, $$1), Util.ioPool()).thenAcceptAsync(p5ea938bf_7_0 -> {
               if (p5ea938bf_7_0) {
                  this.minecraft.setScreen(this.configureScreen);
               } else {
                  this.showMessage(NO_SUCH_PLAYER_ERROR_TEXT);
               }

               this.profileName.setEditable(true);
               this.inviteButton.active = true;
            }, this.screenExecutor);
         }
      }
   }

   private void showMessage(Component p5ea938bf_2_0) {
      this.message = p5ea938bf_2_0;
      this.minecraft.getNarrator().saySystemNow(p5ea938bf_2_0);
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.configureScreen);
   }

   @Override
   public void render(GuiGraphics p5ea938bf_3_0, int p5ea938bf_4_1, int p5ea938bf_5_2, float p5ea938bf_6_3) {
      super.render(p5ea938bf_3_0, p5ea938bf_4_1, p5ea938bf_5_2, p5ea938bf_6_3);
      if (this.message != null && this.inviteButton != null) {
         p5ea938bf_3_0.drawCenteredString(this.font, this.message, this.width / 2, this.inviteButton.getY() + this.inviteButton.getHeight() + 8, -1);
      }
   }
}
