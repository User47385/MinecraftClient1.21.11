package com.mojang.realmsclient.gui.screens.configuration;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.Backup;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.gui.screens.RealmsLongRunningMcoTaskScreen;
import com.mojang.realmsclient.gui.screens.RealmsPopups;
import com.mojang.realmsclient.util.RealmsUtil;
import com.mojang.realmsclient.util.task.DownloadTask;
import com.mojang.realmsclient.util.task.RestoreTask;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsBackupScreen extends RealmsScreen {
   static final Logger LOGGER = LogUtils.getLogger();
   private static final Component TITLE = Component.translatable("mco.configure.world.backup");
   static final Component RESTORE_TOOLTIP = Component.translatable("mco.backup.button.restore");
   static final Component HAS_CHANGES_TOOLTIP = Component.translatable("mco.backup.changes.tooltip");
   private static final Component NO_BACKUPS_LABEL = Component.translatable("mco.backup.nobackups");
   private static final Component DOWNLOAD_LATEST = Component.translatable("mco.backup.button.download");
   private static final String UPLOADED_KEY = "uploaded";
   private static final int PADDING = 8;
   public static final DateTimeFormatter SHORT_DATE_FORMAT = Util.localizedDateFormatter(FormatStyle.SHORT);
   final RealmsConfigureWorldScreen lastScreen;
   List<Backup> backups = Collections.emptyList();
   RealmsBackupScreen.@Nullable BackupObjectSelectionList backupList;
   final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);
   private final int slotId;
   @Nullable Button downloadButton;
   final RealmsServer serverData;
   boolean noBackups = false;

   public RealmsBackupScreen(RealmsConfigureWorldScreen p4e0bd0b8_0_0, RealmsServer p4e0bd0b8_1_1, int p4e0bd0b8_2_2) {
      super(TITLE);
      this.lastScreen = p4e0bd0b8_0_0;
      this.serverData = p4e0bd0b8_1_1;
      this.slotId = p4e0bd0b8_2_2;
   }

   @Override
   public void init() {
      this.layout.addTitleHeader(TITLE, this.font);
      this.backupList = this.layout.addToContents(new RealmsBackupScreen.BackupObjectSelectionList());
      LinearLayout $$0 = this.layout.addToFooter(LinearLayout.horizontal().spacing(8));
      this.downloadButton = $$0.addChild(Button.builder(DOWNLOAD_LATEST, p4e0bd0b8_11_0 -> this.downloadClicked()).build());
      this.downloadButton.active = false;
      $$0.addChild(Button.builder(CommonComponents.GUI_BACK, p4e0bd0b8_10_0 -> this.onClose()).build());
      this.layout.visitWidgets(p4e0bd0b8_9_1 -> {
         AbstractWidget var10000 = this.addRenderableWidget(p4e0bd0b8_9_1);
      });
      this.repositionElements();
      this.fetchRealmsBackups();
   }

   @Override
   public void render(GuiGraphics p4e0bd0b8_3_0, int p4e0bd0b8_4_1, int p4e0bd0b8_5_2, float p4e0bd0b8_6_3) {
      super.render(p4e0bd0b8_3_0, p4e0bd0b8_4_1, p4e0bd0b8_5_2, p4e0bd0b8_6_3);
      if (this.noBackups && this.backupList != null) {
         p4e0bd0b8_3_0.drawString(
            this.font,
            NO_BACKUPS_LABEL,
            this.width / 2 - this.font.width(NO_BACKUPS_LABEL) / 2,
            this.backupList.getY() + this.backupList.getHeight() / 2 - 9 / 2,
            -1
         );
      }
   }

   @Override
   protected void repositionElements() {
      this.layout.arrangeElements();
      if (this.backupList != null) {
         this.backupList.updateSize(this.width, this.layout);
      }
   }

   private void fetchRealmsBackups() {
      (new Thread("Realms-fetch-backups") {
            @Override
            public void run() {
               RealmsClient $$0 = RealmsClient.getOrCreate();

               try {
                  List<Backup> $$1 = $$0.backupsFor(RealmsBackupScreen.this.serverData.id).backups();
                  RealmsBackupScreen.this.minecraft
                     .execute(
                        () -> {
                           RealmsBackupScreen.this.backups = $$1;
                           RealmsBackupScreen.this.noBackups = RealmsBackupScreen.this.backups.isEmpty();
                           if (!RealmsBackupScreen.this.noBackups && RealmsBackupScreen.this.downloadButton != null) {
                              RealmsBackupScreen.this.downloadButton.active = true;
                           }

                           if (RealmsBackupScreen.this.backupList != null) {
                              RealmsBackupScreen.this.backupList
                                 .replaceEntries(
                                    RealmsBackupScreen.this.backups.stream().map(pfa5a8745_3_0 -> RealmsBackupScreen.this.new Entry(pfa5a8745_3_0)).toList()
                                 );
                           }
                        }
                     );
               } catch (RealmsServiceException $$2) {
                  RealmsBackupScreen.LOGGER.error("Couldn't request backups", $$2);
               }
            }
         })
         .start();
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.lastScreen);
   }

   private void downloadClicked() {
      this.minecraft
         .setScreen(
            RealmsPopups.infoPopupScreen(
               this,
               Component.translatable("mco.configure.world.restore.download.question.line1"),
               p4e0bd0b8_7_0 -> this.minecraft
                  .setScreen(
                     new RealmsLongRunningMcoTaskScreen(
                        this.lastScreen.getNewScreen(),
                        new DownloadTask(
                           this.serverData.id,
                           this.slotId,
                           Objects.requireNonNullElse(this.serverData.name, "")
                              + " ("
                              + this.serverData.slots.get(this.serverData.activeSlot).options.getSlotName(this.serverData.activeSlot)
                              + ")",
                           this
                        )
                     )
                  )
            )
         );
   }

   class BackupObjectSelectionList extends ContainerObjectSelectionList<RealmsBackupScreen.Entry> {
      private static final int ITEM_HEIGHT = 36;

      public BackupObjectSelectionList() {
         super(
            Minecraft.getInstance(),
            RealmsBackupScreen.this.width,
            RealmsBackupScreen.this.layout.getContentHeight(),
            RealmsBackupScreen.this.layout.getHeaderHeight(),
            36
         );
      }

      @Override
      public int getRowWidth() {
         return 300;
      }
   }

   class Entry extends ContainerObjectSelectionList.Entry<RealmsBackupScreen.Entry> {
      private static final int Y_PADDING = 2;
      private final Backup backup;
      private @Nullable Button restoreButton;
      private @Nullable Button changesButton;
      private final List<AbstractWidget> children = new ArrayList<>();

      public Entry(final Backup pb0d8f566_1_1) {
         this.backup = pb0d8f566_1_1;
         this.populateChangeList(pb0d8f566_1_1);
         if (!pb0d8f566_1_1.changeList.isEmpty()) {
            this.changesButton = Button.builder(
                  RealmsBackupScreen.HAS_CHANGES_TOOLTIP,
                  pb0d8f566_12_0 -> RealmsBackupScreen.this.minecraft.setScreen(new RealmsBackupInfoScreen(RealmsBackupScreen.this, this.backup))
               )
               .width(8 + RealmsBackupScreen.this.font.width(RealmsBackupScreen.HAS_CHANGES_TOOLTIP))
               .createNarration(this::narrationForBackupEntry)
               .build();
            this.children.add(this.changesButton);
         }

         if (!RealmsBackupScreen.this.serverData.expired) {
            this.restoreButton = Button.builder(RealmsBackupScreen.RESTORE_TOOLTIP, pb0d8f566_11_0 -> this.restoreClicked())
               .width(8 + RealmsBackupScreen.this.font.width(RealmsBackupScreen.HAS_CHANGES_TOOLTIP))
               .createNarration(this::narrationForBackupEntry)
               .build();
            this.children.add(this.restoreButton);
         }
      }

      private MutableComponent narrationForBackupEntry(Supplier<MutableComponent> pb0d8f566_2_0) {
         return CommonComponents.joinForNarration(
            Component.translatable("mco.backup.narration", RealmsBackupScreen.SHORT_DATE_FORMAT.format(this.backup.lastModifiedDate())), pb0d8f566_2_0.get()
         );
      }

      private void populateChangeList(Backup pb0d8f566_3_0) {
         int $$1 = RealmsBackupScreen.this.backups.indexOf(pb0d8f566_3_0);
         if ($$1 != RealmsBackupScreen.this.backups.size() - 1) {
            Backup $$2 = RealmsBackupScreen.this.backups.get($$1 + 1);

            for (String $$3 : pb0d8f566_3_0.metadata.keySet()) {
               if (!$$3.contains("uploaded") && $$2.metadata.containsKey($$3)) {
                  if (!pb0d8f566_3_0.metadata.get($$3).equals($$2.metadata.get($$3))) {
                     this.addToChangeList($$3);
                  }
               } else {
                  this.addToChangeList($$3);
               }
            }
         }
      }

      private void addToChangeList(String pb0d8f566_4_0) {
         if (pb0d8f566_4_0.contains("uploaded")) {
            String $$1 = RealmsBackupScreen.SHORT_DATE_FORMAT.format(this.backup.lastModifiedDate());
            this.backup.changeList.put(pb0d8f566_4_0, $$1);
            this.backup.uploadedVersion = true;
         } else {
            this.backup.changeList.put(pb0d8f566_4_0, this.backup.metadata.get(pb0d8f566_4_0));
         }
      }

      private void restoreClicked() {
         Component $$0 = RealmsUtil.convertToAgePresentationFromInstant(this.backup.lastModified);
         String $$1 = RealmsBackupScreen.SHORT_DATE_FORMAT.format(this.backup.lastModifiedDate());
         Component $$2 = Component.translatable("mco.configure.world.restore.question.line1", $$1, $$0);
         RealmsBackupScreen.this.minecraft
            .setScreen(
               RealmsPopups.warningPopupScreen(
                  RealmsBackupScreen.this,
                  $$2,
                  pb0d8f566_10_0 -> {
                     RealmsConfigureWorldScreen $$1x = RealmsBackupScreen.this.lastScreen.getNewScreen();
                     RealmsBackupScreen.this.minecraft
                        .setScreen(new RealmsLongRunningMcoTaskScreen($$1x, new RestoreTask(this.backup, RealmsBackupScreen.this.serverData.id, $$1x)));
                  }
               )
            );
      }

      @Override
      public List<? extends GuiEventListener> children() {
         return this.children;
      }

      @Override
      public List<? extends NarratableEntry> narratables() {
         return this.children;
      }

      @Override
      public void renderContent(GuiGraphics pb0d8f566_5_0, int pb0d8f566_6_1, int pb0d8f566_7_2, boolean pb0d8f566_8_3, float pb0d8f566_9_4) {
         int $$5 = this.getContentYMiddle();
         int $$6 = $$5 - 9 - 2;
         int $$7 = $$5 + 2;
         int $$8 = this.backup.uploadedVersion ? -8388737 : -1;
         pb0d8f566_5_0.drawString(
            RealmsBackupScreen.this.font,
            Component.translatable("mco.backup.entry", RealmsUtil.convertToAgePresentationFromInstant(this.backup.lastModified)),
            this.getContentX(),
            $$6,
            $$8
         );
         pb0d8f566_5_0.drawString(
            RealmsBackupScreen.this.font, RealmsBackupScreen.SHORT_DATE_FORMAT.format(this.backup.lastModifiedDate()), this.getContentX(), $$7, -11776948
         );
         int $$9 = 0;
         int $$10 = this.getContentYMiddle() - 10;
         if (this.restoreButton != null) {
            $$9 += this.restoreButton.getWidth() + 8;
            this.restoreButton.setX(this.getContentRight() - $$9);
            this.restoreButton.setY($$10);
            this.restoreButton.render(pb0d8f566_5_0, pb0d8f566_6_1, pb0d8f566_7_2, pb0d8f566_9_4);
         }

         if (this.changesButton != null) {
            $$9 += this.changesButton.getWidth() + 8;
            this.changesButton.setX(this.getContentRight() - $$9);
            this.changesButton.setY($$10);
            this.changesButton.render(pb0d8f566_5_0, pb0d8f566_6_1, pb0d8f566_7_2, pb0d8f566_9_4);
         }
      }
   }
}
