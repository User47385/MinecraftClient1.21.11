package com.mojang.realmsclient.gui.screens.configuration;

import com.google.common.collect.ImmutableList;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.RealmsSlot;
import com.mojang.realmsclient.dto.RealmsWorldOptions;
import com.mojang.realmsclient.gui.screens.RealmsPopups;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsLabel;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.GameType;

public class RealmsSlotOptionsScreen extends RealmsScreen {
   private static final int DEFAULT_DIFFICULTY = 2;
   public static final List<Difficulty> DIFFICULTIES = ImmutableList.of(Difficulty.PEACEFUL, Difficulty.EASY, Difficulty.NORMAL, Difficulty.HARD);
   private static final int DEFAULT_GAME_MODE = 0;
   public static final List<GameType> GAME_MODES = ImmutableList.of(GameType.SURVIVAL, GameType.CREATIVE, GameType.ADVENTURE);
   private static final Component NAME_LABEL = Component.translatable("mco.configure.world.edit.slot.name");
   static final Component SPAWN_PROTECTION_TEXT = Component.translatable("mco.configure.world.spawnProtection");
   private EditBox nameEdit;
   protected final RealmsConfigureWorldScreen parentScreen;
   private int column1X;
   private int columnWidth;
   private final RealmsSlot slot;
   private final RealmsServer.WorldType worldType;
   private Difficulty difficulty;
   private GameType gameMode;
   private final String defaultSlotName;
   private String worldName;
   int spawnProtection;
   private boolean forceGameMode;
   RealmsSlotOptionsScreen.SettingsSlider spawnProtectionButton;

   public RealmsSlotOptionsScreen(RealmsConfigureWorldScreen p487e11a2_0_0, RealmsSlot p487e11a2_1_1, RealmsServer.WorldType p487e11a2_2_2, int p487e11a2_3_3) {
      super(Component.translatable("mco.configure.world.buttons.options"));
      this.parentScreen = p487e11a2_0_0;
      this.slot = p487e11a2_1_1;
      this.worldType = p487e11a2_2_2;
      this.difficulty = findByIndex(DIFFICULTIES, p487e11a2_1_1.options.difficulty, 2);
      this.gameMode = findByIndex(GAME_MODES, p487e11a2_1_1.options.gameMode, 0);
      this.defaultSlotName = p487e11a2_1_1.options.getDefaultSlotName(p487e11a2_3_3);
      this.setWorldName(p487e11a2_1_1.options.getSlotName(p487e11a2_3_3));
      if (p487e11a2_2_2 == RealmsServer.WorldType.NORMAL) {
         this.spawnProtection = p487e11a2_1_1.options.spawnProtection;
         this.forceGameMode = p487e11a2_1_1.options.forceGameMode;
      } else {
         this.spawnProtection = 0;
         this.forceGameMode = false;
      }
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.parentScreen);
   }

   private static <T> T findByIndex(List<T> p487e11a2_4_0, int p487e11a2_5_1, int p487e11a2_6_2) {
      try {
         return p487e11a2_4_0.get(p487e11a2_5_1);
      } catch (IndexOutOfBoundsException $$3) {
         return p487e11a2_4_0.get(p487e11a2_6_2);
      }
   }

   private static <T> int findIndex(List<T> p487e11a2_7_0, T p487e11a2_8_1, int p487e11a2_9_2) {
      int $$3 = p487e11a2_7_0.indexOf(p487e11a2_8_1);
      return $$3 == -1 ? p487e11a2_9_2 : $$3;
   }

   @Override
   public void init() {
      this.columnWidth = 170;
      this.column1X = this.width / 2 - this.columnWidth;
      int $$0 = this.width / 2 + 10;
      if (this.worldType != RealmsServer.WorldType.NORMAL) {
         Component $$1;
         if (this.worldType == RealmsServer.WorldType.ADVENTUREMAP) {
            $$1 = Component.translatable("mco.configure.world.edit.subscreen.adventuremap");
         } else if (this.worldType == RealmsServer.WorldType.INSPIRATION) {
            $$1 = Component.translatable("mco.configure.world.edit.subscreen.inspiration");
         } else {
            $$1 = Component.translatable("mco.configure.world.edit.subscreen.experience");
         }

         this.addLabel(new RealmsLabel($$1, this.width / 2, 26, -65536));
      }

      this.nameEdit = this.addWidget(
         new EditBox(this.minecraft.font, this.column1X, row(1), this.columnWidth, 20, null, Component.translatable("mco.configure.world.edit.slot.name"))
      );
      this.nameEdit.setValue(this.worldName);
      this.nameEdit.setResponder(this::setWorldName);
      CycleButton<Difficulty> $$4 = this.addRenderableWidget(
         CycleButton.builder(Difficulty::getDisplayName, this.difficulty)
            .withValues(DIFFICULTIES)
            .create(
               $$0,
               row(1),
               this.columnWidth,
               20,
               Component.translatable("options.difficulty"),
               (p487e11a2_29_0, p487e11a2_30_1) -> this.difficulty = p487e11a2_30_1
            )
      );
      CycleButton<GameType> $$5 = this.addRenderableWidget(
         CycleButton.builder(GameType::getShortDisplayName, this.gameMode)
            .withValues(GAME_MODES)
            .create(
               this.column1X,
               row(3),
               this.columnWidth,
               20,
               Component.translatable("selectWorld.gameMode"),
               (p487e11a2_27_0, p487e11a2_28_1) -> this.gameMode = p487e11a2_28_1
            )
      );
      CycleButton<Boolean> $$6 = this.addRenderableWidget(
         CycleButton.onOffBuilder(this.forceGameMode)
            .create(
               $$0,
               row(3),
               this.columnWidth,
               20,
               Component.translatable("mco.configure.world.forceGameMode"),
               (p487e11a2_25_0, p487e11a2_26_1) -> this.forceGameMode = p487e11a2_26_1
            )
      );
      this.spawnProtectionButton = this.addRenderableWidget(
         new RealmsSlotOptionsScreen.SettingsSlider(this.column1X, row(5), this.columnWidth, this.spawnProtection, 0.0F, 16.0F)
      );
      if (this.worldType != RealmsServer.WorldType.NORMAL) {
         this.spawnProtectionButton.active = false;
         $$6.active = false;
      }

      if (this.slot.isHardcore()) {
         $$4.active = false;
         $$5.active = false;
         $$6.active = false;
      }

      this.addRenderableWidget(
         Button.builder(Component.translatable("mco.configure.world.buttons.done"), p487e11a2_24_0 -> this.saveSettings())
            .bounds(this.column1X, row(13), this.columnWidth, 20)
            .build()
      );
      this.addRenderableWidget(Button.builder(CommonComponents.GUI_CANCEL, p487e11a2_23_0 -> this.onClose()).bounds($$0, row(13), this.columnWidth, 20).build());
   }

   private CycleButton.OnValueChange<Boolean> confirmDangerousOption(Component p487e11a2_10_0, Consumer<Boolean> p487e11a2_11_1) {
      return (p487e11a2_19_2, p487e11a2_20_3) -> {
         if (p487e11a2_20_3) {
            p487e11a2_11_1.accept(true);
         } else {
            this.minecraft.setScreen(RealmsPopups.warningPopupScreen(this, p487e11a2_10_0, p487e11a2_22_1 -> {
               p487e11a2_11_1.accept(false);
               p487e11a2_22_1.onClose();
            }));
         }
      };
   }

   @Override
   public Component getNarrationMessage() {
      return CommonComponents.joinForNarration(this.getTitle(), this.createLabelNarration());
   }

   @Override
   public void render(GuiGraphics p487e11a2_12_0, int p487e11a2_13_1, int p487e11a2_14_2, float p487e11a2_15_3) {
      super.render(p487e11a2_12_0, p487e11a2_13_1, p487e11a2_14_2, p487e11a2_15_3);
      p487e11a2_12_0.drawCenteredString(this.font, this.title, this.width / 2, 17, -1);
      p487e11a2_12_0.drawString(this.font, NAME_LABEL, this.column1X + this.columnWidth / 2 - this.font.width(NAME_LABEL) / 2, row(0) - 5, -1);
      this.nameEdit.render(p487e11a2_12_0, p487e11a2_13_1, p487e11a2_14_2, p487e11a2_15_3);
   }

   private void setWorldName(String p487e11a2_16_0) {
      if (p487e11a2_16_0.equals(this.defaultSlotName)) {
         this.worldName = "";
      } else {
         this.worldName = p487e11a2_16_0;
      }
   }

   private void saveSettings() {
      int $$0 = findIndex(DIFFICULTIES, this.difficulty, 2);
      int $$1 = findIndex(GAME_MODES, this.gameMode, 0);
      if (this.worldType != RealmsServer.WorldType.ADVENTUREMAP
         && this.worldType != RealmsServer.WorldType.EXPERIENCE
         && this.worldType != RealmsServer.WorldType.INSPIRATION) {
         this.parentScreen
            .saveSlotSettings(
               new RealmsSlot(
                  this.slot.slotId,
                  new RealmsWorldOptions(
                     this.spawnProtection, $$0, $$1, this.forceGameMode, this.worldName, this.slot.options.version, this.slot.options.compatibility
                  ),
                  this.slot.settings
               )
            );
      } else {
         this.parentScreen
            .saveSlotSettings(
               new RealmsSlot(
                  this.slot.slotId,
                  new RealmsWorldOptions(
                     this.slot.options.spawnProtection,
                     $$0,
                     $$1,
                     this.slot.options.forceGameMode,
                     this.worldName,
                     this.slot.options.version,
                     this.slot.options.compatibility
                  ),
                  this.slot.settings
               )
            );
      }
   }

   class SettingsSlider extends AbstractSliderButton {
      private final double minValue;
      private final double maxValue;

      public SettingsSlider(
         final int p4fb32e46_1_1,
         final int p4fb32e46_2_2,
         final int p4fb32e46_3_3,
         final int p4fb32e46_4_4,
         final float p4fb32e46_5_5,
         final float p4fb32e46_6_6
      ) {
         super(p4fb32e46_1_1, p4fb32e46_2_2, p4fb32e46_3_3, 20, CommonComponents.EMPTY, 0.0);
         this.minValue = p4fb32e46_5_5;
         this.maxValue = p4fb32e46_6_6;
         this.value = (Mth.clamp(p4fb32e46_4_4, p4fb32e46_5_5, p4fb32e46_6_6) - p4fb32e46_5_5) / (p4fb32e46_6_6 - p4fb32e46_5_5);
         this.updateMessage();
      }

      @Override
      public void applyValue() {
         if (RealmsSlotOptionsScreen.this.spawnProtectionButton.active) {
            RealmsSlotOptionsScreen.this.spawnProtection = (int)Mth.lerp(Mth.clamp(this.value, 0.0, 1.0), this.minValue, this.maxValue);
         }
      }

      @Override
      protected void updateMessage() {
         this.setMessage(
            CommonComponents.optionNameValue(
               RealmsSlotOptionsScreen.SPAWN_PROTECTION_TEXT,
               RealmsSlotOptionsScreen.this.spawnProtection == 0
                  ? CommonComponents.OPTION_OFF
                  : Component.literal(String.valueOf(RealmsSlotOptionsScreen.this.spawnProtection))
            )
         );
      }
   }
}
