package com.mojang.realmsclient.gui.screens.configuration;

import com.mojang.realmsclient.dto.RealmsServer;

public interface RealmsConfigurationTab {
   void updateData(RealmsServer var1);

   default void onSelected(RealmsServer p6952a9a9_0_0) {
   }

   default void onDeselected(RealmsServer p6952a9a9_1_0) {
   }
}
