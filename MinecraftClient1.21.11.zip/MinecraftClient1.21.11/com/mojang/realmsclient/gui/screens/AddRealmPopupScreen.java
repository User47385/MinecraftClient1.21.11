package com.mojang.realmsclient.gui.screens;

import java.util.Collection;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.FittingMultiLineTextWidget;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.CommonLinks;
import org.jspecify.annotations.Nullable;

public class AddRealmPopupScreen extends RealmsScreen {
   private static final Component POPUP_TEXT = Component.translatable("mco.selectServer.popup");
   private static final Component CLOSE_TEXT = Component.translatable("mco.selectServer.close");
   private static final Identifier BACKGROUND_SPRITE = Identifier.withDefaultNamespace("popup/background");
   private static final Identifier TRIAL_AVAILABLE_SPRITE = Identifier.withDefaultNamespace("icon/trial_available");
   private static final WidgetSprites CROSS_BUTTON_SPRITES = new WidgetSprites(
      Identifier.withDefaultNamespace("widget/cross_button"), Identifier.withDefaultNamespace("widget/cross_button_highlighted")
   );
   private static final int IMAGE_WIDTH = 195;
   private static final int IMAGE_HEIGHT = 152;
   private static final int BG_BORDER_SIZE = 6;
   private static final int BUTTON_SPACING = 4;
   private static final int PADDING = 10;
   private static final int WIDTH = 320;
   private static final int HEIGHT = 172;
   private static final int TEXT_WIDTH = 100;
   private static final int BUTTON_WIDTH = 99;
   private static final int CAROUSEL_SWITCH_INTERVAL = 100;
   private static List<Identifier> carouselImages = List.of();
   private final Screen backgroundScreen;
   private final boolean trialAvailable;
   private @Nullable Button createTrialButton;
   private int carouselIndex;
   private int carouselTick;

   public AddRealmPopupScreen(Screen pee5eaf7d_0_0, boolean pee5eaf7d_1_1) {
      super(POPUP_TEXT);
      this.backgroundScreen = pee5eaf7d_0_0;
      this.trialAvailable = pee5eaf7d_1_1;
   }

   public static void updateCarouselImages(ResourceManager pee5eaf7d_2_0) {
      Collection<Identifier> $$1 = pee5eaf7d_2_0.listResources("textures/gui/images", pee5eaf7d_15_0 -> pee5eaf7d_15_0.getPath().endsWith(".png")).keySet();
      carouselImages = $$1.stream().filter(pee5eaf7d_14_0 -> pee5eaf7d_14_0.getNamespace().equals("realms")).toList();
   }

   @Override
   protected void init() {
      this.backgroundScreen.resize(this.width, this.height);
      if (this.trialAvailable) {
         this.createTrialButton = this.addRenderableWidget(
            Button.builder(Component.translatable("mco.selectServer.trial"), ConfirmLinkScreen.confirmLink(this, CommonLinks.START_REALMS_TRIAL))
               .bounds(this.right() - 10 - 99, this.bottom() - 10 - 4 - 40, 99, 20)
               .build()
         );
      }

      this.addRenderableWidget(
         Button.builder(Component.translatable("mco.selectServer.buy"), ConfirmLinkScreen.confirmLink(this, CommonLinks.BUY_REALMS))
            .bounds(this.right() - 10 - 99, this.bottom() - 10 - 20, 99, 20)
            .build()
      );
      ImageButton $$0 = this.addRenderableWidget(
         new ImageButton(this.left() + 4, this.top() + 4, 14, 14, CROSS_BUTTON_SPRITES, pee5eaf7d_13_0 -> this.onClose(), CLOSE_TEXT)
      );
      $$0.setTooltip(Tooltip.create(CLOSE_TEXT));
      int $$1 = 142 - (this.trialAvailable ? 40 : 20);
      FittingMultiLineTextWidget $$2 = new FittingMultiLineTextWidget(this.right() - 10 - 100, this.top() + 10, 100, $$1, POPUP_TEXT, this.font);
      if ($$2.showingScrollBar()) {
         $$2.setWidth(94);
      }

      this.addRenderableWidget($$2);
   }

   @Override
   public void tick() {
      super.tick();
      if (++this.carouselTick > 100) {
         this.carouselTick = 0;
         this.carouselIndex = (this.carouselIndex + 1) % carouselImages.size();
      }
   }

   @Override
   public void render(GuiGraphics pee5eaf7d_3_0, int pee5eaf7d_4_1, int pee5eaf7d_5_2, float pee5eaf7d_6_3) {
      super.render(pee5eaf7d_3_0, pee5eaf7d_4_1, pee5eaf7d_5_2, pee5eaf7d_6_3);
      if (this.createTrialButton != null) {
         renderDiamond(pee5eaf7d_3_0, this.createTrialButton);
      }
   }

   public static void renderDiamond(GuiGraphics pee5eaf7d_7_0, Button pee5eaf7d_8_1) {
      int $$2 = 8;
      pee5eaf7d_7_0.blitSprite(
         RenderPipelines.GUI_TEXTURED,
         TRIAL_AVAILABLE_SPRITE,
         pee5eaf7d_8_1.getX() + pee5eaf7d_8_1.getWidth() - 8 - 4,
         pee5eaf7d_8_1.getY() + pee5eaf7d_8_1.getHeight() / 2 - 4,
         8,
         8
      );
   }

   @Override
   public void renderBackground(GuiGraphics pee5eaf7d_9_0, int pee5eaf7d_10_1, int pee5eaf7d_11_2, float pee5eaf7d_12_3) {
      this.backgroundScreen.renderBackground(pee5eaf7d_9_0, -1, -1, pee5eaf7d_12_3);
      pee5eaf7d_9_0.nextStratum();
      this.backgroundScreen.render(pee5eaf7d_9_0, -1, -1, pee5eaf7d_12_3);
      pee5eaf7d_9_0.nextStratum();
      this.renderTransparentBackground(pee5eaf7d_9_0);
      pee5eaf7d_9_0.blitSprite(RenderPipelines.GUI_TEXTURED, BACKGROUND_SPRITE, this.left(), this.top(), 320, 172);
      if (!carouselImages.isEmpty()) {
         pee5eaf7d_9_0.blit(
            RenderPipelines.GUI_TEXTURED, carouselImages.get(this.carouselIndex), this.left() + 10, this.top() + 10, 0.0F, 0.0F, 195, 152, 195, 152
         );
      }
   }

   private int left() {
      return (this.width - 320) / 2;
   }

   private int top() {
      return (this.height - 172) / 2;
   }

   private int right() {
      return this.left() + 320;
   }

   private int bottom() {
      return this.top() + 172;
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.backgroundScreen);
   }
}
