package com.mojang.realmsclient.gui.screens;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.util.task.GetServerDetailsTask;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.util.CommonLinks;
import net.minecraft.util.Util;
import org.slf4j.Logger;

public class RealmsTermsScreen extends RealmsScreen {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final Component TITLE = Component.translatable("mco.terms.title");
   private static final Component TERMS_STATIC_TEXT = Component.translatable("mco.terms.sentence.1");
   private static final Component TERMS_LINK_TEXT = CommonComponents.space()
      .append(Component.translatable("mco.terms.sentence.2").withStyle(Style.EMPTY.withUnderlined(true)));
   private final Screen lastScreen;
   private final RealmsServer realmsServer;
   private boolean onLink;

   public RealmsTermsScreen(Screen pd991e5c2_0_0, RealmsServer pd991e5c2_1_1) {
      super(TITLE);
      this.lastScreen = pd991e5c2_0_0;
      this.realmsServer = pd991e5c2_1_1;
   }

   @Override
   public void init() {
      int $$0 = this.width / 4 - 2;
      this.addRenderableWidget(
         Button.builder(Component.translatable("mco.terms.buttons.agree"), pd991e5c2_10_0 -> this.agreedToTos())
            .bounds(this.width / 4, row(12), $$0, 20)
            .build()
      );
      this.addRenderableWidget(
         Button.builder(Component.translatable("mco.terms.buttons.disagree"), pd991e5c2_9_0 -> this.minecraft.setScreen(this.lastScreen))
            .bounds(this.width / 2 + 4, row(12), $$0, 20)
            .build()
      );
   }

   @Override
   public boolean keyPressed(KeyEvent pd991e5c2_2_0) {
      if (pd991e5c2_2_0.key() == 256) {
         this.minecraft.setScreen(this.lastScreen);
         return true;
      } else {
         return super.keyPressed(pd991e5c2_2_0);
      }
   }

   private void agreedToTos() {
      RealmsClient $$0 = RealmsClient.getOrCreate();

      try {
         $$0.agreeToTos();
         this.minecraft.setScreen(new RealmsLongRunningMcoTaskScreen(this.lastScreen, new GetServerDetailsTask(this.lastScreen, this.realmsServer)));
      } catch (RealmsServiceException $$1) {
         LOGGER.error("Couldn't agree to TOS", $$1);
      }
   }

   @Override
   public boolean mouseClicked(MouseButtonEvent pd991e5c2_3_0, boolean pd991e5c2_4_1) {
      if (this.onLink) {
         this.minecraft.keyboardHandler.setClipboard(CommonLinks.REALMS_TERMS.toString());
         Util.getPlatform().openUri(CommonLinks.REALMS_TERMS);
         return true;
      } else {
         return super.mouseClicked(pd991e5c2_3_0, pd991e5c2_4_1);
      }
   }

   @Override
   public Component getNarrationMessage() {
      return CommonComponents.joinForNarration(super.getNarrationMessage(), TERMS_STATIC_TEXT).append(CommonComponents.SPACE).append(TERMS_LINK_TEXT);
   }

   @Override
   public void render(GuiGraphics pd991e5c2_5_0, int pd991e5c2_6_1, int pd991e5c2_7_2, float pd991e5c2_8_3) {
      super.render(pd991e5c2_5_0, pd991e5c2_6_1, pd991e5c2_7_2, pd991e5c2_8_3);
      pd991e5c2_5_0.drawCenteredString(this.font, this.title, this.width / 2, 17, -1);
      pd991e5c2_5_0.drawString(this.font, TERMS_STATIC_TEXT, this.width / 2 - 120, row(5), -1);
      int $$4 = this.font.width(TERMS_STATIC_TEXT);
      int $$5 = this.width / 2 - 121 + $$4;
      int $$6 = row(5);
      int $$7 = $$5 + this.font.width(TERMS_LINK_TEXT) + 1;
      int $$8 = $$6 + 1 + 9;
      this.onLink = $$5 <= pd991e5c2_6_1 && pd991e5c2_6_1 <= $$7 && $$6 <= pd991e5c2_7_2 && pd991e5c2_7_2 <= $$8;
      pd991e5c2_5_0.drawString(this.font, TERMS_LINK_TEXT, this.width / 2 - 120 + $$4, row(5), this.onLink ? -9670204 : -13408581);
   }
}
