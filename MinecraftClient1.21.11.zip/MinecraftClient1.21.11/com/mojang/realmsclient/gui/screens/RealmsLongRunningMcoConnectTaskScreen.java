package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.dto.RealmsJoinInformation;
import com.mojang.realmsclient.dto.ServiceQuality;
import com.mojang.realmsclient.util.task.LongRunningTask;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.ImageWidget;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.LayoutSettings;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public class RealmsLongRunningMcoConnectTaskScreen extends RealmsLongRunningMcoTaskScreen {
   private final LongRunningTask task;
   private final RealmsJoinInformation serverAddress;
   private final LinearLayout footer = LinearLayout.vertical();

   public RealmsLongRunningMcoConnectTaskScreen(Screen p3f808df4_0_0, RealmsJoinInformation p3f808df4_1_1, LongRunningTask p3f808df4_2_2) {
      super(p3f808df4_0_0, p3f808df4_2_2);
      this.task = p3f808df4_2_2;
      this.serverAddress = p3f808df4_1_1;
   }

   @Override
   public void init() {
      super.init();
      if (this.serverAddress.regionData() != null && this.serverAddress.regionData().region() != null) {
         LinearLayout $$0 = LinearLayout.horizontal().spacing(10);
         StringWidget $$1 = new StringWidget(
            Component.translatable("mco.connect.region", Component.translatable(this.serverAddress.regionData().region().translationKey)), this.font
         );
         $$0.addChild($$1);
         Identifier $$2 = this.serverAddress.regionData().serviceQuality() != null
            ? this.serverAddress.regionData().serviceQuality().getIcon()
            : ServiceQuality.UNKNOWN.getIcon();
         $$0.addChild(ImageWidget.sprite(10, 8, $$2), LayoutSettings::alignVerticallyTop);
         this.footer.addChild($$0, p3f808df4_5_0 -> p3f808df4_5_0.paddingTop(40));
         this.footer.visitWidgets(p3f808df4_4_1 -> {
            AbstractWidget var10000 = this.addRenderableWidget(p3f808df4_4_1);
         });
         this.repositionElements();
      }
   }

   @Override
   protected void repositionElements() {
      super.repositionElements();
      int $$0 = this.layout.getY() + this.layout.getHeight();
      ScreenRectangle $$1 = new ScreenRectangle(0, $$0, this.width, this.height - $$0);
      this.footer.arrangeElements();
      FrameLayout.alignInRectangle(this.footer, $$1, 0.5F, 0.0F);
   }

   @Override
   public void tick() {
      super.tick();
      this.task.tick();
   }

   @Override
   protected void cancel() {
      this.task.abortTask();
      super.cancel();
   }
}
