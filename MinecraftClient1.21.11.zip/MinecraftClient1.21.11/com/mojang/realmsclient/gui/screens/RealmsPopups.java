package com.mojang.realmsclient.gui.screens;

import java.util.function.Consumer;
import net.minecraft.client.gui.components.PopupScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

public class RealmsPopups {
   private static final int COLOR_INFO = 8226750;
   private static final Component INFO = Component.translatable("mco.info").withColor(8226750);
   private static final Component WARNING = Component.translatable("mco.warning").withColor(-65536);

   public static PopupScreen customPopupScreen(Screen p38141af8_0_0, Component p38141af8_1_1, Component p38141af8_2_2, Consumer<PopupScreen> p38141af8_3_3) {
      return new PopupScreen.Builder(p38141af8_0_0, p38141af8_1_1)
         .setMessage(p38141af8_2_2)
         .addButton(CommonComponents.GUI_CONTINUE, p38141af8_3_3)
         .addButton(CommonComponents.GUI_CANCEL, PopupScreen::onClose)
         .build();
   }

   public static PopupScreen infoPopupScreen(Screen p38141af8_4_0, Component p38141af8_5_1, Consumer<PopupScreen> p38141af8_6_2) {
      return new PopupScreen.Builder(p38141af8_4_0, INFO)
         .setMessage(p38141af8_5_1)
         .addButton(CommonComponents.GUI_CONTINUE, p38141af8_6_2)
         .addButton(CommonComponents.GUI_CANCEL, PopupScreen::onClose)
         .build();
   }

   public static PopupScreen warningPopupScreen(Screen p38141af8_7_0, Component p38141af8_8_1, Consumer<PopupScreen> p38141af8_9_2) {
      return new PopupScreen.Builder(p38141af8_7_0, WARNING)
         .setMessage(p38141af8_8_1)
         .addButton(CommonComponents.GUI_CONTINUE, p38141af8_9_2)
         .addButton(CommonComponents.GUI_CANCEL, PopupScreen::onClose)
         .build();
   }

   public static PopupScreen warningAcknowledgePopupScreen(Screen p38141af8_10_0, Component p38141af8_11_1, Consumer<PopupScreen> p38141af8_12_2) {
      return new PopupScreen.Builder(p38141af8_10_0, WARNING).setMessage(p38141af8_11_1).addButton(CommonComponents.GUI_OK, p38141af8_12_2).build();
   }
}
