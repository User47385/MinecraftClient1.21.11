package com.mojang.realmsclient.gui.screens;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.client.worldupload.RealmsCreateWorldFlow;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.WorldTemplate;
import com.mojang.realmsclient.dto.WorldTemplatePaginatedList;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.util.task.LongRunningTask;
import com.mojang.realmsclient.util.task.RealmCreationTask;
import com.mojang.realmsclient.util.task.ResettingTemplateWorldTask;
import com.mojang.realmsclient.util.task.SwitchSlotTask;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LayoutSettings;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.layouts.SpacerElement;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsResetWorldScreen extends RealmsScreen {
   static final Logger LOGGER = LogUtils.getLogger();
   private static final Component CREATE_REALM_TITLE = Component.translatable("mco.selectServer.create");
   private static final Component CREATE_REALM_SUBTITLE = Component.translatable("mco.selectServer.create.subtitle").withColor(-6250336);
   private static final Component CREATE_WORLD_TITLE = Component.translatable("mco.configure.world.switch.slot");
   private static final Component CREATE_WORLD_SUBTITLE = Component.translatable("mco.configure.world.switch.slot.subtitle").withColor(-6250336);
   private static final Component GENERATE_NEW_WORLD = Component.translatable("mco.reset.world.generate");
   private static final Component RESET_WORLD_TITLE = Component.translatable("mco.reset.world.title");
   private static final Component RESET_WORLD_SUBTITLE = Component.translatable("mco.reset.world.warning").withColor(-65536);
   public static final Component CREATE_WORLD_RESET_TASK_TITLE = Component.translatable("mco.create.world.reset.title");
   private static final Component RESET_WORLD_RESET_TASK_TITLE = Component.translatable("mco.reset.world.resetting.screen.title");
   private static final Component WORLD_TEMPLATES_TITLE = Component.translatable("mco.reset.world.template");
   private static final Component ADVENTURES_TITLE = Component.translatable("mco.reset.world.adventure");
   private static final Component EXPERIENCES_TITLE = Component.translatable("mco.reset.world.experience");
   private static final Component INSPIRATION_TITLE = Component.translatable("mco.reset.world.inspiration");
   private final Screen lastScreen;
   private final RealmsServer serverData;
   private final Component subtitle;
   private final Component resetTaskTitle;
   private static final Identifier UPLOAD_LOCATION = Identifier.withDefaultNamespace("textures/gui/realms/upload.png");
   private static final Identifier ADVENTURE_MAP_LOCATION = Identifier.withDefaultNamespace("textures/gui/realms/adventure.png");
   private static final Identifier SURVIVAL_SPAWN_LOCATION = Identifier.withDefaultNamespace("textures/gui/realms/survival_spawn.png");
   private static final Identifier NEW_WORLD_LOCATION = Identifier.withDefaultNamespace("textures/gui/realms/new_world.png");
   private static final Identifier EXPERIENCE_LOCATION = Identifier.withDefaultNamespace("textures/gui/realms/experience.png");
   private static final Identifier INSPIRATION_LOCATION = Identifier.withDefaultNamespace("textures/gui/realms/inspiration.png");
   WorldTemplatePaginatedList templates;
   WorldTemplatePaginatedList adventuremaps;
   WorldTemplatePaginatedList experiences;
   WorldTemplatePaginatedList inspirations;
   public final int slot;
   private final @Nullable RealmCreationTask realmCreationTask;
   private final Runnable resetWorldRunnable;
   private final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);

   private RealmsResetWorldScreen(
      Screen p7d109240_0_0,
      RealmsServer p7d109240_1_1,
      int p7d109240_2_2,
      Component p7d109240_3_3,
      Component p7d109240_4_4,
      Component p7d109240_5_5,
      Runnable p7d109240_6_6
   ) {
      this(p7d109240_0_0, p7d109240_1_1, p7d109240_2_2, p7d109240_3_3, p7d109240_4_4, p7d109240_5_5, null, p7d109240_6_6);
   }

   public RealmsResetWorldScreen(
      Screen p7d109240_7_0,
      RealmsServer p7d109240_8_1,
      int p7d109240_9_2,
      Component p7d109240_10_3,
      Component p7d109240_11_4,
      Component p7d109240_12_5,
      @Nullable RealmCreationTask p7d109240_13_6,
      Runnable p7d109240_14_7
   ) {
      super(p7d109240_10_3);
      this.lastScreen = p7d109240_7_0;
      this.serverData = p7d109240_8_1;
      this.slot = p7d109240_9_2;
      this.subtitle = p7d109240_11_4;
      this.resetTaskTitle = p7d109240_12_5;
      this.realmCreationTask = p7d109240_13_6;
      this.resetWorldRunnable = p7d109240_14_7;
   }

   public static RealmsResetWorldScreen forNewRealm(
      Screen p7d109240_15_0, RealmsServer p7d109240_16_1, RealmCreationTask p7d109240_17_2, Runnable p7d109240_18_3
   ) {
      return new RealmsResetWorldScreen(
         p7d109240_15_0,
         p7d109240_16_1,
         p7d109240_16_1.activeSlot,
         CREATE_REALM_TITLE,
         CREATE_REALM_SUBTITLE,
         CREATE_WORLD_RESET_TASK_TITLE,
         p7d109240_17_2,
         p7d109240_18_3
      );
   }

   public static RealmsResetWorldScreen forEmptySlot(Screen p7d109240_19_0, int p7d109240_20_1, RealmsServer p7d109240_21_2, Runnable p7d109240_22_3) {
      return new RealmsResetWorldScreen(
         p7d109240_19_0, p7d109240_21_2, p7d109240_20_1, CREATE_WORLD_TITLE, CREATE_WORLD_SUBTITLE, CREATE_WORLD_RESET_TASK_TITLE, p7d109240_22_3
      );
   }

   public static RealmsResetWorldScreen forResetSlot(Screen p7d109240_23_0, RealmsServer p7d109240_24_1, Runnable p7d109240_25_2) {
      return new RealmsResetWorldScreen(
         p7d109240_23_0, p7d109240_24_1, p7d109240_24_1.activeSlot, RESET_WORLD_TITLE, RESET_WORLD_SUBTITLE, RESET_WORLD_RESET_TASK_TITLE, p7d109240_25_2
      );
   }

   @Override
   public void init() {
      LinearLayout $$0 = this.layout.addToHeader(LinearLayout.vertical());
      $$0.defaultCellSetting().padding(9 / 3);
      $$0.addChild(new StringWidget(this.title, this.font), LayoutSettings::alignHorizontallyCenter);
      $$0.addChild(new StringWidget(this.subtitle, this.font), LayoutSettings::alignHorizontallyCenter);
      (new Thread("Realms-reset-world-fetcher") {
         @Override
         public void run() {
            RealmsClient $$0x = RealmsClient.getOrCreate();

            try {
               WorldTemplatePaginatedList $$1 = $$0x.fetchWorldTemplates(1, 10, RealmsServer.WorldType.NORMAL);
               WorldTemplatePaginatedList $$2 = $$0x.fetchWorldTemplates(1, 10, RealmsServer.WorldType.ADVENTUREMAP);
               WorldTemplatePaginatedList $$3 = $$0x.fetchWorldTemplates(1, 10, RealmsServer.WorldType.EXPERIENCE);
               WorldTemplatePaginatedList $$4 = $$0x.fetchWorldTemplates(1, 10, RealmsServer.WorldType.INSPIRATION);
               RealmsResetWorldScreen.this.minecraft.execute(() -> {
                  RealmsResetWorldScreen.this.templates = $$1;
                  RealmsResetWorldScreen.this.adventuremaps = $$2;
                  RealmsResetWorldScreen.this.experiences = $$3;
                  RealmsResetWorldScreen.this.inspirations = $$4;
               });
            } catch (RealmsServiceException $$5) {
               RealmsResetWorldScreen.LOGGER.error("Couldn't fetch templates in reset world", $$5);
            }
         }
      }).start();
      GridLayout $$1 = this.layout.addToContents(new GridLayout());
      GridLayout.RowHelper $$2 = $$1.createRowHelper(3);
      $$2.defaultCellSetting().paddingHorizontal(16);
      $$2.addChild(
         new RealmsResetWorldScreen.FrameButton(
            this.minecraft.font,
            GENERATE_NEW_WORLD,
            NEW_WORLD_LOCATION,
            p7d109240_36_0 -> RealmsCreateWorldFlow.createWorld(this.minecraft, this.lastScreen, this, this.slot, this.serverData, this.realmCreationTask)
         )
      );
      $$2.addChild(
         new RealmsResetWorldScreen.FrameButton(
            this.minecraft.font,
            RealmsSelectFileToUploadScreen.TITLE,
            UPLOAD_LOCATION,
            p7d109240_35_0 -> this.minecraft.setScreen(new RealmsSelectFileToUploadScreen(this.realmCreationTask, this.serverData.id, this.slot, this))
         )
      );
      $$2.addChild(
         new RealmsResetWorldScreen.FrameButton(
            this.minecraft.font,
            WORLD_TEMPLATES_TITLE,
            SURVIVAL_SPAWN_LOCATION,
            p7d109240_34_0 -> this.minecraft
               .setScreen(
                  new RealmsSelectWorldTemplateScreen(WORLD_TEMPLATES_TITLE, this::templateSelectionCallback, RealmsServer.WorldType.NORMAL, this.templates)
               )
         )
      );
      $$2.addChild(SpacerElement.height(16), 3);
      $$2.addChild(
         new RealmsResetWorldScreen.FrameButton(
            this.minecraft.font,
            ADVENTURES_TITLE,
            ADVENTURE_MAP_LOCATION,
            p7d109240_33_0 -> this.minecraft
               .setScreen(
                  new RealmsSelectWorldTemplateScreen(
                     ADVENTURES_TITLE, this::templateSelectionCallback, RealmsServer.WorldType.ADVENTUREMAP, this.adventuremaps
                  )
               )
         )
      );
      $$2.addChild(
         new RealmsResetWorldScreen.FrameButton(
            this.minecraft.font,
            EXPERIENCES_TITLE,
            EXPERIENCE_LOCATION,
            p7d109240_32_0 -> this.minecraft
               .setScreen(
                  new RealmsSelectWorldTemplateScreen(EXPERIENCES_TITLE, this::templateSelectionCallback, RealmsServer.WorldType.EXPERIENCE, this.experiences)
               )
         )
      );
      $$2.addChild(
         new RealmsResetWorldScreen.FrameButton(
            this.minecraft.font,
            INSPIRATION_TITLE,
            INSPIRATION_LOCATION,
            p7d109240_31_0 -> this.minecraft
               .setScreen(
                  new RealmsSelectWorldTemplateScreen(INSPIRATION_TITLE, this::templateSelectionCallback, RealmsServer.WorldType.INSPIRATION, this.inspirations)
               )
         )
      );
      this.layout.addToFooter(Button.builder(CommonComponents.GUI_BACK, p7d109240_30_0 -> this.onClose()).build());
      this.layout.visitWidgets(p7d109240_29_1 -> {
         AbstractWidget var10000 = this.addRenderableWidget(p7d109240_29_1);
      });
      this.repositionElements();
   }

   @Override
   protected void repositionElements() {
      this.layout.arrangeElements();
   }

   @Override
   public Component getNarrationMessage() {
      return CommonComponents.joinForNarration(this.getTitle(), this.subtitle);
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.lastScreen);
   }

   private void templateSelectionCallback(@Nullable WorldTemplate p7d109240_26_0) {
      this.minecraft.setScreen(this);
      if (p7d109240_26_0 != null) {
         this.runResetTasks(new ResettingTemplateWorldTask(p7d109240_26_0, this.serverData.id, this.resetTaskTitle, this.resetWorldRunnable));
      }

      RealmsMainScreen.refreshServerList();
   }

   private void runResetTasks(LongRunningTask p7d109240_27_0) {
      List<LongRunningTask> $$1 = new ArrayList<>();
      if (this.realmCreationTask != null) {
         $$1.add(this.realmCreationTask);
      }

      if (this.slot != this.serverData.activeSlot) {
         $$1.add(new SwitchSlotTask(this.serverData.id, this.slot, () -> {}));
      }

      $$1.add(p7d109240_27_0);
      this.minecraft.setScreen(new RealmsLongRunningMcoTaskScreen(this.lastScreen, $$1.toArray(new LongRunningTask[0])));
   }

   class FrameButton extends Button {
      private static final Identifier SLOT_FRAME_SPRITE = Identifier.withDefaultNamespace("widget/slot_frame");
      private static final int FRAME_SIZE = 60;
      private static final int FRAME_WIDTH = 2;
      private static final int IMAGE_SIZE = 56;
      private final Identifier image;

      FrameButton(final Font p12aa527b_1_1, final Component p12aa527b_2_2, final Identifier p12aa527b_3_3, final Button.OnPress p12aa527b_4_4) {
         super(0, 0, 60, 60 + 9, p12aa527b_2_2, p12aa527b_4_4, DEFAULT_NARRATION);
         this.image = p12aa527b_3_3;
      }

      @Override
      public void renderContents(GuiGraphics p12aa527b_5_0, int p12aa527b_6_1, int p12aa527b_7_2, float p12aa527b_8_3) {
         boolean $$4 = this.isHoveredOrFocused();
         int $$5 = -1;
         if ($$4) {
            $$5 = ARGB.colorFromFloat(1.0F, 0.56F, 0.56F, 0.56F);
         }

         int $$6 = this.getX();
         int $$7 = this.getY();
         p12aa527b_5_0.blit(RenderPipelines.GUI_TEXTURED, this.image, $$6 + 2, $$7 + 2, 0.0F, 0.0F, 56, 56, 56, 56, 56, 56, $$5);
         p12aa527b_5_0.blitSprite(RenderPipelines.GUI_TEXTURED, SLOT_FRAME_SPRITE, $$6, $$7, 60, 60, $$5);
         int $$8 = $$4 ? -6250336 : -1;
         p12aa527b_5_0.drawCenteredString(RealmsResetWorldScreen.this.font, this.getMessage(), $$6 + 28, $$7 - 14, $$8);
      }
   }
}
