package com.mojang.realmsclient.gui.screens;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.PendingInvite;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.gui.RealmsDataFetcher;
import com.mojang.realmsclient.util.RealmsUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.SpriteIconButton;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsPendingInvitesScreen extends RealmsScreen {
   static final Logger LOGGER = LogUtils.getLogger();
   private static final Component NO_PENDING_INVITES_TEXT = Component.translatable("mco.invites.nopending");
   private final Screen lastScreen;
   private final CompletableFuture<List<PendingInvite>> pendingInvites = CompletableFuture.supplyAsync(() -> {
      try {
         return RealmsClient.getOrCreate().pendingInvites().pendingInvites();
      } catch (RealmsServiceException $$0) {
         LOGGER.error("Couldn't list invites", $$0);
         return List.of();
      }
   }, Util.ioPool());
   final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);
   RealmsPendingInvitesScreen.@Nullable PendingInvitationSelectionList pendingInvitationSelectionList;

   public RealmsPendingInvitesScreen(Screen p881c2f30_0_0, Component p881c2f30_1_1) {
      super(p881c2f30_1_1);
      this.lastScreen = p881c2f30_0_0;
   }

   @Override
   public void init() {
      RealmsMainScreen.refreshPendingInvites();
      this.layout.addTitleHeader(this.title, this.font);
      this.pendingInvitationSelectionList = this.layout.addToContents(new RealmsPendingInvitesScreen.PendingInvitationSelectionList(this.minecraft));
      this.pendingInvites
         .thenAcceptAsync(
            p881c2f30_9_0 -> {
               List<RealmsPendingInvitesScreen.Entry> $$1 = p881c2f30_9_0.stream()
                  .map(p881c2f30_10_0 -> new RealmsPendingInvitesScreen.Entry(p881c2f30_10_0))
                  .toList();
               this.pendingInvitationSelectionList.replaceEntries($$1);
               if ($$1.isEmpty()) {
                  this.minecraft.getNarrator().saySystemQueued(NO_PENDING_INVITES_TEXT);
               }
            },
            this.screenExecutor
         );
      this.layout.addToFooter(Button.builder(CommonComponents.GUI_DONE, p881c2f30_8_0 -> this.onClose()).width(200).build());
      this.layout.visitWidgets(p881c2f30_7_1 -> {
         AbstractWidget var10000 = this.addRenderableWidget(p881c2f30_7_1);
      });
      this.repositionElements();
   }

   @Override
   protected void repositionElements() {
      this.layout.arrangeElements();
      if (this.pendingInvitationSelectionList != null) {
         this.pendingInvitationSelectionList.updateSize(this.width, this.layout);
      }
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.lastScreen);
   }

   @Override
   public void render(GuiGraphics p881c2f30_2_0, int p881c2f30_3_1, int p881c2f30_4_2, float p881c2f30_5_3) {
      super.render(p881c2f30_2_0, p881c2f30_3_1, p881c2f30_4_2, p881c2f30_5_3);
      if (this.pendingInvites.isDone() && this.pendingInvitationSelectionList.hasPendingInvites()) {
         p881c2f30_2_0.drawCenteredString(this.font, NO_PENDING_INVITES_TEXT, this.width / 2, this.height / 2 - 20, -1);
      }
   }

   class Entry extends ContainerObjectSelectionList.Entry<RealmsPendingInvitesScreen.Entry> {
      private static final Component ACCEPT_INVITE = Component.translatable("mco.invites.button.accept");
      private static final Component REJECT_INVITE = Component.translatable("mco.invites.button.reject");
      private static final WidgetSprites ACCEPT_SPRITE = new WidgetSprites(
         Identifier.withDefaultNamespace("pending_invite/accept"), Identifier.withDefaultNamespace("pending_invite/accept_highlighted")
      );
      private static final WidgetSprites REJECT_SPRITE = new WidgetSprites(
         Identifier.withDefaultNamespace("pending_invite/reject"), Identifier.withDefaultNamespace("pending_invite/reject_highlighted")
      );
      private static final int SPRITE_TEXTURE_SIZE = 18;
      private static final int SPRITE_SIZE = 21;
      private static final int TEXT_LEFT = 38;
      private final PendingInvite pendingInvite;
      private final List<AbstractWidget> children = new ArrayList<>();
      private final SpriteIconButton acceptButton;
      private final SpriteIconButton rejectButton;
      private final StringWidget realmName;
      private final StringWidget realmOwnerName;
      private final StringWidget inviteDate;

      Entry(final PendingInvite p749699de_1_1) {
         this.pendingInvite = p749699de_1_1;
         int $$1 = RealmsPendingInvitesScreen.this.pendingInvitationSelectionList.getRowWidth() - 32 - 32 - 42;
         this.realmName = new StringWidget(Component.literal(p749699de_1_1.realmName()), RealmsPendingInvitesScreen.this.font).setMaxWidth($$1);
         this.realmOwnerName = new StringWidget(Component.literal(p749699de_1_1.realmOwnerName()).withColor(-6250336), RealmsPendingInvitesScreen.this.font)
            .setMaxWidth($$1);
         this.inviteDate = new StringWidget(
               ComponentUtils.mergeStyles(RealmsUtil.convertToAgePresentationFromInstant(p749699de_1_1.date()), Style.EMPTY.withColor(-6250336)),
               RealmsPendingInvitesScreen.this.font
            )
            .setMaxWidth($$1);
         Button.CreateNarration $$2 = this.getCreateNarration(p749699de_1_1);
         this.acceptButton = SpriteIconButton.builder(ACCEPT_INVITE, p749699de_16_0 -> this.handleInvitation(true), false)
            .sprite(ACCEPT_SPRITE, 18, 18)
            .size(21, 21)
            .narration($$2)
            .withTootip()
            .build();
         this.rejectButton = SpriteIconButton.builder(REJECT_INVITE, p749699de_15_0 -> this.handleInvitation(false), false)
            .sprite(REJECT_SPRITE, 18, 18)
            .size(21, 21)
            .narration($$2)
            .withTootip()
            .build();
         this.children.addAll(List.of(this.acceptButton, this.rejectButton));
      }

      private Button.CreateNarration getCreateNarration(PendingInvite p749699de_2_0) {
         return p749699de_14_1 -> {
            MutableComponent $$2 = CommonComponents.joinForNarration(
               p749699de_14_1.get(),
               Component.literal(p749699de_2_0.realmName()),
               Component.literal(p749699de_2_0.realmOwnerName()),
               RealmsUtil.convertToAgePresentationFromInstant(p749699de_2_0.date())
            );
            return Component.translatable("narrator.select", $$2);
         };
      }

      @Override
      public List<? extends GuiEventListener> children() {
         return this.children;
      }

      @Override
      public List<? extends NarratableEntry> narratables() {
         return this.children;
      }

      @Override
      public void renderContent(GuiGraphics p749699de_3_0, int p749699de_4_1, int p749699de_5_2, boolean p749699de_6_3, float p749699de_7_4) {
         int $$5 = this.getContentX();
         int $$6 = this.getContentY();
         int $$7 = $$5 + 38;
         RealmsUtil.renderPlayerFace(p749699de_3_0, $$5, $$6, 32, this.pendingInvite.realmOwnerUuid());
         this.realmName.setPosition($$7, $$6 + 1);
         this.realmName.renderWidget(p749699de_3_0, p749699de_4_1, p749699de_5_2, $$5);
         this.realmOwnerName.setPosition($$7, $$6 + 12);
         this.realmOwnerName.renderWidget(p749699de_3_0, p749699de_4_1, p749699de_5_2, $$5);
         this.inviteDate.setPosition($$7, $$6 + 24);
         this.inviteDate.renderWidget(p749699de_3_0, p749699de_4_1, p749699de_5_2, $$5);
         int $$8 = $$6 + this.getContentHeight() / 2 - 10;
         this.acceptButton.setPosition($$5 + this.getContentWidth() - 16 - 42, $$8);
         this.acceptButton.render(p749699de_3_0, p749699de_4_1, p749699de_5_2, p749699de_7_4);
         this.rejectButton.setPosition($$5 + this.getContentWidth() - 8 - 21, $$8);
         this.rejectButton.render(p749699de_3_0, p749699de_4_1, p749699de_5_2, p749699de_7_4);
      }

      private void handleInvitation(boolean p749699de_8_0) {
         String $$1 = this.pendingInvite.invitationId();
         CompletableFuture.<Boolean>supplyAsync(() -> {
            try {
               RealmsClient $$2 = RealmsClient.getOrCreate();
               if (p749699de_8_0) {
                  $$2.acceptInvitation($$1);
               } else {
                  $$2.rejectInvitation($$1);
               }

               return true;
            } catch (RealmsServiceException $$3) {
               RealmsPendingInvitesScreen.LOGGER.error("Couldn't handle invite", $$3);
               return false;
            }
         }, Util.ioPool()).thenAcceptAsync(p749699de_10_1 -> {
            if (p749699de_10_1) {
               RealmsPendingInvitesScreen.this.pendingInvitationSelectionList.removeInvitation(this);
               RealmsDataFetcher $$2 = RealmsPendingInvitesScreen.this.minecraft.realmsDataFetcher();
               if (p749699de_8_0) {
                  $$2.serverListUpdateTask.reset();
               }

               $$2.pendingInvitesTask.reset();
            }
         }, RealmsPendingInvitesScreen.this.screenExecutor);
      }
   }

   class PendingInvitationSelectionList extends ContainerObjectSelectionList<RealmsPendingInvitesScreen.Entry> {
      public static final int ITEM_HEIGHT = 36;

      public PendingInvitationSelectionList(final Minecraft p12259dae_1_1) {
         super(
            p12259dae_1_1,
            RealmsPendingInvitesScreen.this.width,
            RealmsPendingInvitesScreen.this.layout.getContentHeight(),
            RealmsPendingInvitesScreen.this.layout.getHeaderHeight(),
            36
         );
      }

      @Override
      public int getRowWidth() {
         return 280;
      }

      public boolean hasPendingInvites() {
         return this.getItemCount() == 0;
      }

      public void removeInvitation(RealmsPendingInvitesScreen.Entry p12259dae_2_0) {
         this.removeEntry(p12259dae_2_0);
      }
   }
}
