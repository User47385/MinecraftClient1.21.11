package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.client.RealmsError;
import com.mojang.realmsclient.exception.RealmsServiceException;
import net.minecraft.client.gui.ActiveTextCollector;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.TextAlignment;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineLabel;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.network.chat.Style;
import net.minecraft.realms.RealmsScreen;

public class RealmsGenericErrorScreen extends RealmsScreen {
   private static final Component GENERIC_TITLE = Component.translatable("mco.errorMessage.generic");
   private final Screen nextScreen;
   private final Component detail;
   private MultiLineLabel splitDetail = MultiLineLabel.EMPTY;

   public RealmsGenericErrorScreen(RealmsServiceException p30a32e6e_0_0, Screen p30a32e6e_1_1) {
      this(RealmsGenericErrorScreen.ErrorMessage.forServiceError(p30a32e6e_0_0), p30a32e6e_1_1);
   }

   public RealmsGenericErrorScreen(Component p30a32e6e_2_0, Screen p30a32e6e_3_1) {
      this(new RealmsGenericErrorScreen.ErrorMessage(GENERIC_TITLE, p30a32e6e_2_0), p30a32e6e_3_1);
   }

   public RealmsGenericErrorScreen(Component p30a32e6e_4_0, Component p30a32e6e_5_1, Screen p30a32e6e_6_2) {
      this(new RealmsGenericErrorScreen.ErrorMessage(p30a32e6e_4_0, p30a32e6e_5_1), p30a32e6e_6_2);
   }

   private RealmsGenericErrorScreen(RealmsGenericErrorScreen.ErrorMessage p30a32e6e_7_0, Screen p30a32e6e_8_1) {
      super(p30a32e6e_7_0.title);
      this.nextScreen = p30a32e6e_8_1;
      this.detail = ComponentUtils.mergeStyles(p30a32e6e_7_0.detail, Style.EMPTY.withColor(-2142128));
   }

   @Override
   public void init() {
      this.addRenderableWidget(
         Button.builder(CommonComponents.GUI_OK, p30a32e6e_13_0 -> this.onClose()).bounds(this.width / 2 - 100, this.height - 52, 200, 20).build()
      );
      this.splitDetail = MultiLineLabel.create(this.font, this.detail, this.width * 3 / 4);
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.nextScreen);
   }

   @Override
   public Component getNarrationMessage() {
      return CommonComponents.joinForNarration(super.getNarrationMessage(), this.detail);
   }

   @Override
   public void render(GuiGraphics p30a32e6e_9_0, int p30a32e6e_10_1, int p30a32e6e_11_2, float p30a32e6e_12_3) {
      super.render(p30a32e6e_9_0, p30a32e6e_10_1, p30a32e6e_11_2, p30a32e6e_12_3);
      p30a32e6e_9_0.drawCenteredString(this.font, this.title, this.width / 2, 80, -1);
      ActiveTextCollector $$4 = p30a32e6e_9_0.textRenderer();
      this.splitDetail.visitLines(TextAlignment.CENTER, this.width / 2, 100, 9, $$4);
   }

   record ErrorMessage(Component title, Component detail) {

      static RealmsGenericErrorScreen.ErrorMessage forServiceError(RealmsServiceException pf3b45f75_2_0) {
         RealmsError $$1 = pf3b45f75_2_0.realmsError;
         return new RealmsGenericErrorScreen.ErrorMessage(
            Component.translatable("mco.errorMessage.realmsService.realmsError", $$1.errorCode()), $$1.errorMessage()
         );
      }
   }
}
