package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.util.task.RealmCreationTask;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.layouts.CommonLayouts;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.AlertScreen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.util.StringUtil;
import net.minecraft.util.Util;

public class RealmsCreateRealmScreen extends RealmsScreen {
   private static final Component CREATE_REALM_TEXT = Component.translatable("mco.selectServer.create");
   private static final Component NAME_LABEL = Component.translatable("mco.configure.world.name");
   private static final Component DESCRIPTION_LABEL = Component.translatable("mco.configure.world.description");
   private static final int BUTTON_SPACING = 10;
   private static final int CONTENT_WIDTH = 210;
   private final RealmsMainScreen lastScreen;
   private final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);
   private EditBox nameBox;
   private EditBox descriptionBox;
   private final Runnable createWorldRunnable;

   public RealmsCreateRealmScreen(RealmsMainScreen pb772b2ee_0_0, RealmsServer pb772b2ee_1_1, boolean pb772b2ee_2_2) {
      super(CREATE_REALM_TEXT);
      this.lastScreen = pb772b2ee_0_0;
      this.createWorldRunnable = () -> this.createWorld(pb772b2ee_1_1, pb772b2ee_2_2);
   }

   @Override
   public void init() {
      this.layout.addTitleHeader(this.title, this.font);
      LinearLayout $$0 = this.layout.addToContents(LinearLayout.vertical()).spacing(10);
      Button $$1 = Button.builder(CommonComponents.GUI_CONTINUE, pb772b2ee_17_0 -> this.createWorldRunnable.run()).build();
      $$1.active = false;
      this.nameBox = new EditBox(this.font, 210, 20, NAME_LABEL);
      this.nameBox.setResponder(pb772b2ee_16_1 -> $$1.active = !StringUtil.isBlank(pb772b2ee_16_1));
      this.descriptionBox = new EditBox(this.font, 210, 20, DESCRIPTION_LABEL);
      $$0.addChild(CommonLayouts.labeledElement(this.font, this.nameBox, NAME_LABEL));
      $$0.addChild(CommonLayouts.labeledElement(this.font, this.descriptionBox, DESCRIPTION_LABEL));
      LinearLayout $$2 = this.layout.addToFooter(LinearLayout.horizontal().spacing(10));
      $$2.addChild($$1);
      $$2.addChild(Button.builder(CommonComponents.GUI_BACK, pb772b2ee_14_0 -> this.onClose()).build());
      this.layout.visitWidgets(pb772b2ee_13_1 -> {
         AbstractWidget var10000 = this.addRenderableWidget(pb772b2ee_13_1);
      });
      this.repositionElements();
   }

   @Override
   protected void setInitialFocus() {
      this.setInitialFocus(this.nameBox);
   }

   @Override
   protected void repositionElements() {
      this.layout.arrangeElements();
   }

   private void createWorld(RealmsServer pb772b2ee_3_0, boolean pb772b2ee_4_1) {
      if (!pb772b2ee_3_0.isSnapshotRealm() && pb772b2ee_4_1) {
         AtomicBoolean $$2 = new AtomicBoolean();
         this.minecraft.setScreen(new AlertScreen(() -> {
            $$2.set(true);
            this.lastScreen.resetScreen();
            this.minecraft.setScreen(this.lastScreen);
         }, Component.translatable("mco.upload.preparing"), Component.empty()));
         CompletableFuture.<RealmsServer>supplyAsync(() -> createSnapshotRealm(pb772b2ee_3_0), Util.backgroundExecutor()).thenAcceptAsync(pb772b2ee_9_1 -> {
            if (!$$2.get()) {
               this.showResetWorldScreen(pb772b2ee_9_1);
            }
         }, this.minecraft).exceptionallyAsync(pb772b2ee_7_0 -> {
            this.lastScreen.resetScreen();
            Component $$3;
            if (pb772b2ee_7_0.getCause() instanceof RealmsServiceException $$2x) {
               $$3 = $$2x.realmsError.errorMessage();
            } else {
               $$3 = Component.translatable("mco.errorMessage.initialize.failed");
            }

            this.minecraft.setScreen(new RealmsGenericErrorScreen($$3, this.lastScreen));
            return null;
         }, this.minecraft);
      } else {
         this.showResetWorldScreen(pb772b2ee_3_0);
      }
   }

   private static RealmsServer createSnapshotRealm(RealmsServer pb772b2ee_5_0) {
      RealmsClient $$1 = RealmsClient.getOrCreate();

      try {
         return $$1.createSnapshotRealm(pb772b2ee_5_0.id);
      } catch (RealmsServiceException $$2) {
         throw new RuntimeException($$2);
      }
   }

   private void showResetWorldScreen(RealmsServer pb772b2ee_6_0) {
      RealmCreationTask $$1 = new RealmCreationTask(pb772b2ee_6_0.id, this.nameBox.getValue(), this.descriptionBox.getValue());
      RealmsResetWorldScreen $$2 = RealmsResetWorldScreen.forNewRealm(this, pb772b2ee_6_0, $$1, () -> this.minecraft.execute(() -> {
         RealmsMainScreen.refreshServerList();
         this.minecraft.setScreen(this.lastScreen);
      }));
      this.minecraft.setScreen($$2);
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.lastScreen);
   }
}
