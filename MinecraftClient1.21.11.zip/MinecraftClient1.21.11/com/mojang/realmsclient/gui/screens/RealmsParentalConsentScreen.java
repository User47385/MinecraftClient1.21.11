package com.mojang.realmsclient.gui.screens;

import net.minecraft.client.GameNarrator;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.util.CommonLinks;
import org.jspecify.annotations.Nullable;

public class RealmsParentalConsentScreen extends RealmsScreen {
   private static final Component MESSAGE = Component.translatable("mco.account.privacy.information");
   private static final int SPACING = 15;
   private final LinearLayout layout = LinearLayout.vertical();
   private final Screen lastScreen;
   private @Nullable MultiLineTextWidget textWidget;

   public RealmsParentalConsentScreen(Screen pd7859300_0_0) {
      super(GameNarrator.NO_TITLE);
      this.lastScreen = pd7859300_0_0;
   }

   @Override
   public void init() {
      this.layout.spacing(15).defaultCellSetting().alignHorizontallyCenter();
      this.textWidget = new MultiLineTextWidget(MESSAGE, this.font).setCentered(true);
      this.layout.addChild(this.textWidget);
      LinearLayout $$0 = this.layout.addChild(LinearLayout.horizontal().spacing(8));
      Component $$1 = Component.translatable("mco.account.privacy.info.button");
      $$0.addChild(Button.builder($$1, ConfirmLinkScreen.confirmLink(this, CommonLinks.GDPR)).build());
      $$0.addChild(Button.builder(CommonComponents.GUI_BACK, pd7859300_3_0 -> this.onClose()).build());
      this.layout.visitWidgets(pd7859300_2_1 -> {
         AbstractWidget var10000 = this.addRenderableWidget(pd7859300_2_1);
      });
      this.repositionElements();
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.lastScreen);
   }

   @Override
   protected void repositionElements() {
      if (this.textWidget != null) {
         this.textWidget.setMaxWidth(this.width - 15);
      }

      this.layout.arrangeElements();
      FrameLayout.centerInRectangle(this.layout, this.getRectangle());
   }

   @Override
   public Component getNarrationMessage() {
      return MESSAGE;
   }
}
