package com.mojang.realmsclient.gui.task;

import com.mojang.datafixers.util.Either;
import com.mojang.logging.LogUtils;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import net.minecraft.util.TimeSource;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class DataFetcher {
   static final Logger LOGGER = LogUtils.getLogger();
   final Executor executor;
   final TimeUnit resolution;
   final TimeSource timeSource;

   public DataFetcher(Executor pc019fd8_0_0, TimeUnit pc019fd8_1_1, TimeSource pc019fd8_2_2) {
      this.executor = pc019fd8_0_0;
      this.resolution = pc019fd8_1_1;
      this.timeSource = pc019fd8_2_2;
   }

   public <T> DataFetcher.Task<T> createTask(String pc019fd8_3_0, Callable<T> pc019fd8_4_1, Duration pc019fd8_5_2, RepeatedDelayStrategy pc019fd8_6_3) {
      long $$4 = this.resolution.convert(pc019fd8_5_2);
      if ($$4 == 0L) {
         throw new IllegalArgumentException("Period of " + pc019fd8_5_2 + " too short for selected resolution of " + this.resolution);
      } else {
         return new DataFetcher.Task<>(pc019fd8_3_0, pc019fd8_4_1, $$4, pc019fd8_6_3);
      }
   }

   public DataFetcher.Subscription createSubscription() {
      return new DataFetcher.Subscription();
   }

   record ComputationResult<T>(Either<T, Exception> value, long time) {
   }

   class SubscribedTask<T> {
      private final DataFetcher.Task<T> task;
      private final Consumer<T> output;
      private long lastCheckTime = -1L;

      SubscribedTask(final DataFetcher.Task<T> pfe832b6b_1_1, final Consumer<T> pfe832b6b_2_2) {
         this.task = pfe832b6b_1_1;
         this.output = pfe832b6b_2_2;
      }

      void update(long pfe832b6b_3_0) {
         this.task.updateIfNeeded(pfe832b6b_3_0);
         this.runCallbackIfNeeded();
      }

      void runCallbackIfNeeded() {
         DataFetcher.SuccessfulComputationResult<T> $$0 = this.task.lastResult;
         if ($$0 != null && this.lastCheckTime < $$0.time) {
            this.output.accept($$0.value);
            this.lastCheckTime = $$0.time;
         }
      }

      void runCallback() {
         DataFetcher.SuccessfulComputationResult<T> $$0 = this.task.lastResult;
         if ($$0 != null) {
            this.output.accept($$0.value);
            this.lastCheckTime = $$0.time;
         }
      }

      void reset() {
         this.task.reset();
         this.lastCheckTime = -1L;
      }
   }

   public class Subscription {
      private final List<DataFetcher.SubscribedTask<?>> subscriptions = new ArrayList<>();

      public <T> void subscribe(DataFetcher.Task<T> p39897689_1_0, Consumer<T> p39897689_2_1) {
         DataFetcher.SubscribedTask<T> $$2 = DataFetcher.this.new SubscribedTask<>(p39897689_1_0, p39897689_2_1);
         this.subscriptions.add($$2);
         $$2.runCallbackIfNeeded();
      }

      public void forceUpdate() {
         for (DataFetcher.SubscribedTask<?> $$0 : this.subscriptions) {
            $$0.runCallback();
         }
      }

      public void tick() {
         for (DataFetcher.SubscribedTask<?> $$0 : this.subscriptions) {
            $$0.update(DataFetcher.this.timeSource.get(DataFetcher.this.resolution));
         }
      }

      public void reset() {
         for (DataFetcher.SubscribedTask<?> $$0 : this.subscriptions) {
            $$0.reset();
         }
      }
   }

   record SuccessfulComputationResult<T>(T value, long time) {
   }

   public class Task<T> {
      private final String id;
      private final Callable<T> updater;
      private final long period;
      private final RepeatedDelayStrategy repeatStrategy;
      private @Nullable CompletableFuture<DataFetcher.ComputationResult<T>> pendingTask;
      DataFetcher.@Nullable SuccessfulComputationResult<T> lastResult;
      private long nextUpdate = -1L;

      Task(final String p11e37ef1_1_1, final Callable<T> p11e37ef1_2_2, final long p11e37ef1_3_3, final RepeatedDelayStrategy p11e37ef1_4_4) {
         this.id = p11e37ef1_1_1;
         this.updater = p11e37ef1_2_2;
         this.period = p11e37ef1_3_3;
         this.repeatStrategy = p11e37ef1_4_4;
      }

      void updateIfNeeded(long p11e37ef1_5_0) {
         if (this.pendingTask != null) {
            DataFetcher.ComputationResult<T> $$1 = this.pendingTask.getNow(null);
            if ($$1 == null) {
               return;
            }

            this.pendingTask = null;
            long $$2 = $$1.time;
            $$1.value().ifLeft(p11e37ef1_9_1 -> {
               this.lastResult = new DataFetcher.SuccessfulComputationResult<>((T)p11e37ef1_9_1, $$2);
               this.nextUpdate = $$2 + this.period * this.repeatStrategy.delayCyclesAfterSuccess();
            }).ifRight(p11e37ef1_7_1 -> {
               long $$2x = this.repeatStrategy.delayCyclesAfterFailure();
               DataFetcher.LOGGER.warn("Failed to process task {}, will repeat after {} cycles", this.id, $$2x, p11e37ef1_7_1);
               this.nextUpdate = $$2 + this.period * $$2x;
            });
         }

         if (this.nextUpdate <= p11e37ef1_5_0) {
            this.pendingTask = CompletableFuture.supplyAsync(() -> {
               try {
                  T $$0 = this.updater.call();
                  long $$1x = DataFetcher.this.timeSource.get(DataFetcher.this.resolution);
                  return new DataFetcher.ComputationResult<>(Either.left($$0), $$1x);
               } catch (Exception $$2) {
                  long $$3 = DataFetcher.this.timeSource.get(DataFetcher.this.resolution);
                  return new DataFetcher.ComputationResult<>(Either.right($$2), $$3);
               }
            }, DataFetcher.this.executor);
         }
      }

      public void reset() {
         this.pendingTask = null;
         this.lastResult = null;
         this.nextUpdate = -1L;
      }
   }
}
