package com.mojang.realmsclient.gui;

import com.mojang.realmsclient.dto.RealmsServer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;

public class RealmsServerList implements Iterable<RealmsServer> {
   private final Minecraft minecraft;
   private final Set<RealmsServer> removedServers = new HashSet<>();
   private List<RealmsServer> servers = List.of();

   public RealmsServerList(Minecraft p82ef512a_0_0) {
      this.minecraft = p82ef512a_0_0;
   }

   public void updateServersList(List<RealmsServer> p82ef512a_1_0) {
      List<RealmsServer> $$1 = new ArrayList<>(p82ef512a_1_0);
      $$1.sort(new RealmsServer.McoServerComparator(this.minecraft.getUser().getName()));
      boolean $$2 = $$1.removeAll(this.removedServers);
      if (!$$2) {
         this.removedServers.clear();
      }

      this.servers = $$1;
   }

   public void removeItem(RealmsServer p82ef512a_2_0) {
      this.servers.remove(p82ef512a_2_0);
      this.removedServers.add(p82ef512a_2_0);
   }

   @Override
   public Iterator<RealmsServer> iterator() {
      return this.servers.iterator();
   }

   public boolean isEmpty() {
      return this.servers.isEmpty();
   }
}
