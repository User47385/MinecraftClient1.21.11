package com.mojang.realmsclient.gui;

import com.mojang.realmsclient.dto.RealmsNews;
import com.mojang.realmsclient.util.RealmsPersistence;

public class RealmsNewsManager {
   private final RealmsPersistence newsLocalStorage;
   private boolean hasUnreadNews;
   private String newsLink;

   public RealmsNewsManager(RealmsPersistence p8f7957d1_0_0) {
      this.newsLocalStorage = p8f7957d1_0_0;
      RealmsPersistence.RealmsPersistenceData $$1 = p8f7957d1_0_0.read();
      this.hasUnreadNews = $$1.hasUnreadNews;
      this.newsLink = $$1.newsLink;
   }

   public boolean hasUnreadNews() {
      return this.hasUnreadNews;
   }

   public String newsLink() {
      return this.newsLink;
   }

   public void updateUnreadNews(RealmsNews p8f7957d1_1_0) {
      RealmsPersistence.RealmsPersistenceData $$1 = this.updateNewsStorage(p8f7957d1_1_0);
      this.hasUnreadNews = $$1.hasUnreadNews;
      this.newsLink = $$1.newsLink;
   }

   private RealmsPersistence.RealmsPersistenceData updateNewsStorage(RealmsNews p8f7957d1_2_0) {
      RealmsPersistence.RealmsPersistenceData $$1 = this.newsLocalStorage.read();
      if (p8f7957d1_2_0.newsLink() != null && !p8f7957d1_2_0.newsLink().equals($$1.newsLink)) {
         RealmsPersistence.RealmsPersistenceData $$2 = new RealmsPersistence.RealmsPersistenceData();
         $$2.newsLink = p8f7957d1_2_0.newsLink();
         $$2.hasUnreadNews = true;
         this.newsLocalStorage.save($$2);
         return $$2;
      } else {
         return $$1;
      }
   }
}
