package com.mojang.realmsclient.gui;

import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.RealmsSlot;
import com.mojang.realmsclient.util.RealmsTextureManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import org.jspecify.annotations.Nullable;

public class RealmsWorldSlotButton extends Button {
   private static final Identifier SLOT_FRAME_SPRITE = Identifier.withDefaultNamespace("widget/slot_frame");
   public static final Identifier EMPTY_SLOT_LOCATION = Identifier.withDefaultNamespace("textures/gui/realms/empty_frame.png");
   public static final Identifier DEFAULT_WORLD_SLOT_1 = Identifier.withDefaultNamespace("textures/gui/title/background/panorama_0.png");
   public static final Identifier DEFAULT_WORLD_SLOT_2 = Identifier.withDefaultNamespace("textures/gui/title/background/panorama_2.png");
   public static final Identifier DEFAULT_WORLD_SLOT_3 = Identifier.withDefaultNamespace("textures/gui/title/background/panorama_3.png");
   private static final Component SWITCH_TO_MINIGAME_SLOT_TOOLTIP = Component.translatable("mco.configure.world.slot.tooltip.minigame");
   private static final Component SWITCH_TO_WORLD_SLOT_TOOLTIP = Component.translatable("mco.configure.world.slot.tooltip");
   static final Component MINIGAME = Component.translatable("mco.worldSlot.minigame");
   private static final int WORLD_NAME_MAX_WIDTH = 64;
   private static final String DOTS = "...";
   private final int slotIndex;
   private RealmsWorldSlotButton.State state;

   public RealmsWorldSlotButton(
      int p1c149af9_0_0, int p1c149af9_1_1, int p1c149af9_2_2, int p1c149af9_3_3, int p1c149af9_4_4, RealmsServer p1c149af9_5_5, Button.OnPress p1c149af9_6_6
   ) {
      super(p1c149af9_0_0, p1c149af9_1_1, p1c149af9_2_2, p1c149af9_3_3, CommonComponents.EMPTY, p1c149af9_6_6, DEFAULT_NARRATION);
      this.slotIndex = p1c149af9_4_4;
      this.state = this.setServerData(p1c149af9_5_5);
   }

   public RealmsWorldSlotButton.State getState() {
      return this.state;
   }

   public RealmsWorldSlotButton.State setServerData(RealmsServer p1c149af9_7_0) {
      this.state = new RealmsWorldSlotButton.State(p1c149af9_7_0, this.slotIndex);
      this.setTooltipAndNarration(this.state, p1c149af9_7_0.minigameName);
      return this.state;
   }

   private void setTooltipAndNarration(RealmsWorldSlotButton.State p1c149af9_8_0, @Nullable String p1c149af9_9_1) {
      Component $$2 = switch (p1c149af9_8_0.action) {
         case SWITCH_SLOT -> p1c149af9_8_0.minigame ? SWITCH_TO_MINIGAME_SLOT_TOOLTIP : SWITCH_TO_WORLD_SLOT_TOOLTIP;
         default -> null;
      };
      if ($$2 != null) {
         this.setTooltip(Tooltip.create($$2));
      }

      MutableComponent $$3 = Component.literal(p1c149af9_8_0.slotName);
      if (p1c149af9_8_0.minigame && p1c149af9_9_1 != null) {
         $$3 = $$3.append(CommonComponents.SPACE).append(p1c149af9_9_1);
      }

      this.setMessage($$3);
   }

   static RealmsWorldSlotButton.Action getAction(boolean p1c149af9_10_0, boolean p1c149af9_11_1, boolean p1c149af9_12_2) {
      return p1c149af9_10_0 || p1c149af9_11_1 && p1c149af9_12_2 ? RealmsWorldSlotButton.Action.NOTHING : RealmsWorldSlotButton.Action.SWITCH_SLOT;
   }

   @Override
   public boolean isActive() {
      return this.state.action != RealmsWorldSlotButton.Action.NOTHING && super.isActive();
   }

   @Override
   public void renderContents(GuiGraphics p1c149af9_13_0, int p1c149af9_14_1, int p1c149af9_15_2, float p1c149af9_16_3) {
      int $$4 = this.getX();
      int $$5 = this.getY();
      boolean $$6 = this.isHoveredOrFocused();
      Identifier $$7;
      if (this.state.minigame) {
         $$7 = RealmsTextureManager.worldTemplate(String.valueOf(this.state.imageId), this.state.image);
      } else if (this.state.empty) {
         $$7 = EMPTY_SLOT_LOCATION;
      } else if (this.state.image != null && this.state.imageId != -1L) {
         $$7 = RealmsTextureManager.worldTemplate(String.valueOf(this.state.imageId), this.state.image);
      } else if (this.slotIndex == 1) {
         $$7 = DEFAULT_WORLD_SLOT_1;
      } else if (this.slotIndex == 2) {
         $$7 = DEFAULT_WORLD_SLOT_2;
      } else if (this.slotIndex == 3) {
         $$7 = DEFAULT_WORLD_SLOT_3;
      } else {
         $$7 = EMPTY_SLOT_LOCATION;
      }

      int $$14 = -1;
      if (!this.state.activeSlot) {
         $$14 = ARGB.colorFromFloat(1.0F, 0.56F, 0.56F, 0.56F);
      }

      p1c149af9_13_0.blit(RenderPipelines.GUI_TEXTURED, $$7, $$4 + 1, $$5 + 1, 0.0F, 0.0F, this.width - 2, this.height - 2, 74, 74, 74, 74, $$14);
      if ($$6 && this.state.action != RealmsWorldSlotButton.Action.NOTHING) {
         p1c149af9_13_0.blitSprite(RenderPipelines.GUI_TEXTURED, SLOT_FRAME_SPRITE, $$4, $$5, this.width, this.height);
      } else if (this.state.activeSlot) {
         p1c149af9_13_0.blitSprite(
            RenderPipelines.GUI_TEXTURED, SLOT_FRAME_SPRITE, $$4, $$5, this.width, this.height, ARGB.colorFromFloat(1.0F, 0.8F, 0.8F, 0.8F)
         );
      } else {
         p1c149af9_13_0.blitSprite(
            RenderPipelines.GUI_TEXTURED, SLOT_FRAME_SPRITE, $$4, $$5, this.width, this.height, ARGB.colorFromFloat(1.0F, 0.56F, 0.56F, 0.56F)
         );
      }

      if (this.state.hardcore) {
         p1c149af9_13_0.blitSprite(RenderPipelines.GUI_TEXTURED, RealmsMainScreen.HARDCORE_MODE_SPRITE, $$4 + 3, $$5 + 4, 9, 8);
      }

      Font $$15 = Minecraft.getInstance().font;
      String $$16 = this.state.slotName;
      if ($$15.width($$16) > 64) {
         $$16 = $$15.plainSubstrByWidth($$16, 64 - $$15.width("...")) + "...";
      }

      p1c149af9_13_0.drawCenteredString($$15, $$16, $$4 + this.width / 2, $$5 + this.height - 14, -1);
      if (this.state.activeSlot) {
         p1c149af9_13_0.drawCenteredString(
            $$15,
            RealmsMainScreen.getVersionComponent(this.state.slotVersion, this.state.compatibility.isCompatible()),
            $$4 + this.width / 2,
            $$5 + this.height + 2,
            -1
         );
      }
   }

   public enum Action {
      NOTHING,
      SWITCH_SLOT;
   }

   public static class State {
      final String slotName;
      final String slotVersion;
      final RealmsServer.Compatibility compatibility;
      final long imageId;
      final @Nullable String image;
      public final boolean empty;
      public final boolean minigame;
      public final RealmsWorldSlotButton.Action action;
      public final boolean hardcore;
      public final boolean activeSlot;

      public State(RealmsServer pf2df0706_0_0, int pf2df0706_1_1) {
         this.minigame = pf2df0706_1_1 == 4;
         if (this.minigame) {
            this.slotName = RealmsWorldSlotButton.MINIGAME.getString();
            this.imageId = pf2df0706_0_0.minigameId;
            this.image = pf2df0706_0_0.minigameImage;
            this.empty = pf2df0706_0_0.minigameId == -1;
            this.slotVersion = "";
            this.compatibility = RealmsServer.Compatibility.UNVERIFIABLE;
            this.hardcore = false;
            this.activeSlot = pf2df0706_0_0.isMinigameActive();
         } else {
            RealmsSlot $$2 = pf2df0706_0_0.slots.get(pf2df0706_1_1);
            this.slotName = $$2.options.getSlotName(pf2df0706_1_1);
            this.imageId = $$2.options.templateId;
            this.image = $$2.options.templateImage;
            this.empty = $$2.options.empty;
            this.slotVersion = $$2.options.version;
            this.compatibility = $$2.options.compatibility;
            this.hardcore = $$2.isHardcore();
            this.activeSlot = pf2df0706_0_0.activeSlot == pf2df0706_1_1 && !pf2df0706_0_0.isMinigameActive();
         }

         this.action = RealmsWorldSlotButton.getAction(this.activeSlot, this.empty, pf2df0706_0_0.expired);
      }
   }
}
