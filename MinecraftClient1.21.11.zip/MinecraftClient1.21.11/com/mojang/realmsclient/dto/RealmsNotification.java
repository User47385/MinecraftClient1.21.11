package com.mojang.realmsclient.dto;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.PopupScreen;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.LenientJsonParser;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsNotification {
   static final Logger LOGGER = LogUtils.getLogger();
   private static final String NOTIFICATION_UUID = "notificationUuid";
   private static final String DISMISSABLE = "dismissable";
   private static final String SEEN = "seen";
   private static final String TYPE = "type";
   private static final String VISIT_URL = "visitUrl";
   private static final String INFO_POPUP = "infoPopup";
   static final Component BUTTON_TEXT_FALLBACK = Component.translatable("mco.notification.visitUrl.buttonText.default");
   final UUID uuid;
   final boolean dismissable;
   final boolean seen;
   final String type;

   RealmsNotification(UUID p1028ba30_0_0, boolean p1028ba30_1_1, boolean p1028ba30_2_2, String p1028ba30_3_3) {
      this.uuid = p1028ba30_0_0;
      this.dismissable = p1028ba30_1_1;
      this.seen = p1028ba30_2_2;
      this.type = p1028ba30_3_3;
   }

   public boolean seen() {
      return this.seen;
   }

   public boolean dismissable() {
      return this.dismissable;
   }

   public UUID uuid() {
      return this.uuid;
   }

   public static List<RealmsNotification> parseList(String p1028ba30_4_0) {
      List<RealmsNotification> $$1 = new ArrayList<>();

      try {
         for (JsonElement $$3 : LenientJsonParser.parse(p1028ba30_4_0).getAsJsonObject().get("notifications").getAsJsonArray()) {
            $$1.add(parse($$3.getAsJsonObject()));
         }
      } catch (Exception $$4) {
         LOGGER.error("Could not parse list of RealmsNotifications", $$4);
      }

      return $$1;
   }

   private static RealmsNotification parse(JsonObject p1028ba30_5_0) {
      UUID $$1 = JsonUtils.getUuidOr("notificationUuid", p1028ba30_5_0, null);
      if ($$1 == null) {
         throw new IllegalStateException("Missing required property notificationUuid");
      }

      boolean $$2 = JsonUtils.getBooleanOr("dismissable", p1028ba30_5_0, true);
      boolean $$3 = JsonUtils.getBooleanOr("seen", p1028ba30_5_0, false);
      String $$4 = JsonUtils.getRequiredString("type", p1028ba30_5_0);
      RealmsNotification $$5 = new RealmsNotification($$1, $$2, $$3, $$4);

      return switch ($$4) {
         case "visitUrl" -> RealmsNotification.VisitUrl.parse($$5, p1028ba30_5_0);
         case "infoPopup" -> RealmsNotification.InfoPopup.parse($$5, p1028ba30_5_0);
         default -> $$5;
      };
   }

   public static class InfoPopup extends RealmsNotification {
      private static final String TITLE = "title";
      private static final String MESSAGE = "message";
      private static final String IMAGE = "image";
      private static final String URL_BUTTON = "urlButton";
      private final RealmsText title;
      private final RealmsText message;
      private final Identifier image;
      private final RealmsNotification.@Nullable UrlButton urlButton;

      private InfoPopup(
         RealmsNotification p2d439f0a_0_0,
         RealmsText p2d439f0a_1_1,
         RealmsText p2d439f0a_2_2,
         Identifier p2d439f0a_3_3,
         RealmsNotification.@Nullable UrlButton p2d439f0a_4_4
      ) {
         super(p2d439f0a_0_0.uuid, p2d439f0a_0_0.dismissable, p2d439f0a_0_0.seen, p2d439f0a_0_0.type);
         this.title = p2d439f0a_1_1;
         this.message = p2d439f0a_2_2;
         this.image = p2d439f0a_3_3;
         this.urlButton = p2d439f0a_4_4;
      }

      public static RealmsNotification.InfoPopup parse(RealmsNotification p2d439f0a_5_0, JsonObject p2d439f0a_6_1) {
         RealmsText $$2 = JsonUtils.getRequired("title", p2d439f0a_6_1, RealmsText::parse);
         RealmsText $$3 = JsonUtils.getRequired("message", p2d439f0a_6_1, RealmsText::parse);
         Identifier $$4 = Identifier.parse(JsonUtils.getRequiredString("image", p2d439f0a_6_1));
         RealmsNotification.UrlButton $$5 = JsonUtils.getOptional("urlButton", p2d439f0a_6_1, RealmsNotification.UrlButton::parse);
         return new RealmsNotification.InfoPopup(p2d439f0a_5_0, $$2, $$3, $$4, $$5);
      }

      public @Nullable PopupScreen buildScreen(Screen p2d439f0a_7_0, Consumer<UUID> p2d439f0a_8_1) {
         Component $$2 = this.title.createComponent();
         if ($$2 == null) {
            RealmsNotification.LOGGER.warn("Realms info popup had title with no available translation: {}", this.title);
            return null;
         }

         PopupScreen.Builder $$3 = new PopupScreen.Builder(p2d439f0a_7_0, $$2)
            .setImage(this.image)
            .setMessage(this.message.createComponent(CommonComponents.EMPTY));
         if (this.urlButton != null) {
            $$3.addButton(this.urlButton.urlText.createComponent(RealmsNotification.BUTTON_TEXT_FALLBACK), p2d439f0a_14_2 -> {
               Minecraft $$3x = Minecraft.getInstance();
               $$3x.setScreen(new ConfirmLinkScreen(p2d439f0a_18_3 -> {
                  if (p2d439f0a_18_3) {
                     Util.getPlatform().openUri(this.urlButton.url);
                     $$3x.setScreen(p2d439f0a_7_0);
                  } else {
                     $$3x.setScreen(p2d439f0a_14_2);
                  }
               }, this.urlButton.url, true));
               p2d439f0a_8_1.accept(this.uuid());
            });
         }

         $$3.addButton(CommonComponents.GUI_OK, p2d439f0a_11_1 -> {
            p2d439f0a_11_1.onClose();
            p2d439f0a_8_1.accept(this.uuid());
         });
         $$3.onClose(() -> p2d439f0a_8_1.accept(this.uuid()));
         return $$3.build();
      }
   }

   record UrlButton(String url, RealmsText urlText) {
      private static final String URL = "url";
      private static final String URL_TEXT = "urlText";

      public static RealmsNotification.UrlButton parse(JsonObject pb2a48fed_2_0) {
         String $$1 = JsonUtils.getRequiredString("url", pb2a48fed_2_0);
         RealmsText $$2 = JsonUtils.getRequired("urlText", pb2a48fed_2_0, RealmsText::parse);
         return new RealmsNotification.UrlButton($$1, $$2);
      }
   }

   public static class VisitUrl extends RealmsNotification {
      private static final String URL = "url";
      private static final String BUTTON_TEXT = "buttonText";
      private static final String MESSAGE = "message";
      private final String url;
      private final RealmsText buttonText;
      private final RealmsText message;

      private VisitUrl(RealmsNotification p2bbb438_0_0, String p2bbb438_1_1, RealmsText p2bbb438_2_2, RealmsText p2bbb438_3_3) {
         super(p2bbb438_0_0.uuid, p2bbb438_0_0.dismissable, p2bbb438_0_0.seen, p2bbb438_0_0.type);
         this.url = p2bbb438_1_1;
         this.buttonText = p2bbb438_2_2;
         this.message = p2bbb438_3_3;
      }

      public static RealmsNotification.VisitUrl parse(RealmsNotification p2bbb438_4_0, JsonObject p2bbb438_5_1) {
         String $$2 = JsonUtils.getRequiredString("url", p2bbb438_5_1);
         RealmsText $$3 = JsonUtils.getRequired("buttonText", p2bbb438_5_1, RealmsText::parse);
         RealmsText $$4 = JsonUtils.getRequired("message", p2bbb438_5_1, RealmsText::parse);
         return new RealmsNotification.VisitUrl(p2bbb438_4_0, $$2, $$3, $$4);
      }

      public Component getMessage() {
         return this.message.createComponent(Component.translatable("mco.notification.visitUrl.message.default"));
      }

      public Button buildOpenLinkButton(Screen p2bbb438_6_0) {
         Component $$1 = this.buttonText.createComponent(RealmsNotification.BUTTON_TEXT_FALLBACK);
         return Button.builder($$1, ConfirmLinkScreen.confirmLink(p2bbb438_6_0, this.url)).build();
      }
   }
}
