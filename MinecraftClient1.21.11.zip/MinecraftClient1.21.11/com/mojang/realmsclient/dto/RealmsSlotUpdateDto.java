package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import org.jspecify.annotations.Nullable;

public record RealmsSlotUpdateDto(
   @SerializedName("slotId") int slotId,
   @SerializedName("spawnProtection") int spawnProtection,
   @SerializedName("forceGameMode") boolean forceGameMode,
   @SerializedName("difficulty") int difficulty,
   @SerializedName("gameMode") int gameMode,
   @SerializedName("slotName") String slotName,
   @SerializedName("version") String version,
   @SerializedName("compatibility") RealmsServer.Compatibility compatibility,
   @SerializedName("worldTemplateId") long templateId,
   @SerializedName("worldTemplateImage") @Nullable String templateImage,
   @SerializedName("hardcore") boolean hardcore
) implements ReflectionBasedSerialization {
   public RealmsSlotUpdateDto(int p5099bf53_0_0, RealmsWorldOptions p5099bf53_1_1, boolean p5099bf53_2_2) {
      this(
         p5099bf53_0_0,
         p5099bf53_1_1.spawnProtection,
         p5099bf53_1_1.forceGameMode,
         p5099bf53_1_1.difficulty,
         p5099bf53_1_1.gameMode,
         p5099bf53_1_1.getSlotName(p5099bf53_0_0),
         p5099bf53_1_1.version,
         p5099bf53_1_1.compatibility,
         p5099bf53_1_1.templateId,
         p5099bf53_1_1.templateImage,
         p5099bf53_2_2
      );
   }
}
