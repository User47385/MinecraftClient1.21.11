package com.mojang.realmsclient.dto;

import com.google.gson.JsonElement;
import com.mojang.logging.LogUtils;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.LenientJsonParser;
import org.slf4j.Logger;

public record BackupList(List<Backup> backups) {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static BackupList parse(String p54c4c5e1_1_0) {
      List<Backup> $$1 = new ArrayList<>();

      try {
         JsonElement $$2 = LenientJsonParser.parse(p54c4c5e1_1_0).getAsJsonObject().get("backups");
         if ($$2.isJsonArray()) {
            for (JsonElement $$3 : $$2.getAsJsonArray()) {
               Backup $$4 = Backup.parse($$3);
               if ($$4 != null) {
                  $$1.add($$4);
               }
            }
         }
      } catch (Exception $$5) {
         LOGGER.error("Could not parse BackupList", $$5);
      }

      return new BackupList($$1);
   }
}
