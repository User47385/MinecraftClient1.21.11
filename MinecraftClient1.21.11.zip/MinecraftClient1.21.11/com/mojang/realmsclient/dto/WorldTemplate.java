package com.mojang.realmsclient.dto;

import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public record WorldTemplate(
   String id,
   String name,
   String version,
   String author,
   String link,
   @Nullable String image,
   String trailer,
   String recommendedPlayers,
   WorldTemplate.WorldTemplateType type
) {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static @Nullable WorldTemplate parse(JsonObject p44cc562b_9_0) {
      try {
         String $$1 = JsonUtils.getStringOr("type", p44cc562b_9_0, null);
         return new WorldTemplate(
            JsonUtils.getStringOr("id", p44cc562b_9_0, ""),
            JsonUtils.getStringOr("name", p44cc562b_9_0, ""),
            JsonUtils.getStringOr("version", p44cc562b_9_0, ""),
            JsonUtils.getStringOr("author", p44cc562b_9_0, ""),
            JsonUtils.getStringOr("link", p44cc562b_9_0, ""),
            JsonUtils.getStringOr("image", p44cc562b_9_0, null),
            JsonUtils.getStringOr("trailer", p44cc562b_9_0, ""),
            JsonUtils.getStringOr("recommendedPlayers", p44cc562b_9_0, ""),
            $$1 == null ? WorldTemplate.WorldTemplateType.WORLD_TEMPLATE : WorldTemplate.WorldTemplateType.valueOf($$1)
         );
      } catch (Exception $$2) {
         LOGGER.error("Could not parse WorldTemplate", $$2);
         return null;
      }
   }

   public enum WorldTemplateType {
      WORLD_TEMPLATE,
      MINIGAME,
      ADVENTUREMAP,
      EXPERIENCE,
      INSPIRATION;
   }
}
