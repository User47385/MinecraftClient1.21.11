package com.mojang.realmsclient.dto;

import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import net.minecraft.util.LenientJsonParser;
import org.slf4j.Logger;

public record WorldDownload(String downloadLink, String resourcePackUrl, String resourcePackHash) {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static WorldDownload parse(String pe8ac5239_3_0) {
      JsonObject $$1 = LenientJsonParser.parse(pe8ac5239_3_0).getAsJsonObject();

      try {
         return new WorldDownload(
            JsonUtils.getStringOr("downloadLink", $$1, ""),
            JsonUtils.getStringOr("resourcePackUrl", $$1, ""),
            JsonUtils.getStringOr("resourcePackHash", $$1, "")
         );
      } catch (Exception $$2) {
         LOGGER.error("Could not parse WorldDownload", $$2);
         return new WorldDownload("", "", "");
      }
   }
}
