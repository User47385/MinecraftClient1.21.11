package com.mojang.realmsclient.dto;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public enum ServiceQuality {
   GREAT(1, "icon/ping_5"),
   GOOD(2, "icon/ping_4"),
   OKAY(3, "icon/ping_3"),
   POOR(4, "icon/ping_2"),
   UNKNOWN(5, "icon/ping_unknown");

   final int value;
   private final Identifier icon;

   ServiceQuality(final int p14d506b_3_2, final String p14d506b_4_3) {
      this.value = p14d506b_3_2;
      this.icon = Identifier.withDefaultNamespace(p14d506b_4_3);
   }

   public static @Nullable ServiceQuality byValue(int p14d506b_5_0) {
      for (ServiceQuality $$1 : values()) {
         if ($$1.getValue() == p14d506b_5_0) {
            return $$1;
         }
      }

      return null;
   }

   public int getValue() {
      return this.value;
   }

   public Identifier getIcon() {
      return this.icon;
   }

   public static class RealmsServiceQualityJsonAdapter extends TypeAdapter<ServiceQuality> {
      private static final Logger LOGGER = LogUtils.getLogger();

      public void write(JsonWriter pfdf17ea0_0_0, ServiceQuality pfdf17ea0_1_1) throws IOException {
         pfdf17ea0_0_0.value(pfdf17ea0_1_1.value);
      }

      public ServiceQuality read(JsonReader pfdf17ea0_2_0) throws IOException {
         int $$1 = pfdf17ea0_2_0.nextInt();
         ServiceQuality $$2 = ServiceQuality.byValue($$1);
         if ($$2 == null) {
            LOGGER.warn("Unsupported ServiceQuality {}", $$1);
            return ServiceQuality.UNKNOWN;
         } else {
            return $$2;
         }
      }
   }
}
