package com.mojang.realmsclient.dto;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class Backup extends ValueObject {
   private static final Logger LOGGER = LogUtils.getLogger();
   public final String backupId;
   public final Instant lastModified;
   public final long size;
   public boolean uploadedVersion;
   public final Map<String, String> metadata;
   public final Map<String, String> changeList = new HashMap<>();

   private Backup(String pd60caaa3_0_0, Instant pd60caaa3_1_1, long pd60caaa3_2_2, Map<String, String> pd60caaa3_3_3) {
      this.backupId = pd60caaa3_0_0;
      this.lastModified = pd60caaa3_1_1;
      this.size = pd60caaa3_2_2;
      this.metadata = pd60caaa3_3_3;
   }

   public ZonedDateTime lastModifiedDate() {
      return ZonedDateTime.ofInstant(this.lastModified, ZoneId.systemDefault());
   }

   public static @Nullable Backup parse(JsonElement pd60caaa3_4_0) {
      JsonObject $$1 = pd60caaa3_4_0.getAsJsonObject();

      try {
         String $$2 = JsonUtils.getStringOr("backupId", $$1, "");
         Instant $$3 = JsonUtils.getDateOr("lastModifiedDate", $$1);
         long $$4 = JsonUtils.getLongOr("size", $$1, 0L);
         Map<String, String> $$5 = new HashMap<>();
         if ($$1.has("metadata")) {
            JsonObject $$6 = $$1.getAsJsonObject("metadata");

            for (Entry<String, JsonElement> $$8 : $$6.entrySet()) {
               if (!$$8.getValue().isJsonNull()) {
                  $$5.put($$8.getKey(), $$8.getValue().getAsString());
               }
            }
         }

         return new Backup($$2, $$3, $$4, $$5);
      } catch (Exception $$9) {
         LOGGER.error("Could not parse Backup", $$9);
         return null;
      }
   }
}
