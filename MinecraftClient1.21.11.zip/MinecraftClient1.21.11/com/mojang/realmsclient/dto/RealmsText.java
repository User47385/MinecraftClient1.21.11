package com.mojang.realmsclient.dto;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.realmsclient.util.JsonUtils;
import java.util.Objects;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;
import org.jspecify.annotations.Nullable;

public class RealmsText {
   private static final String TRANSLATION_KEY = "translationKey";
   private static final String ARGS = "args";
   private final String translationKey;
   private final String @Nullable [] args;

   private RealmsText(String p42188b72_0_0, String @Nullable [] p42188b72_1_1) {
      this.translationKey = p42188b72_0_0;
      this.args = p42188b72_1_1;
   }

   public Component createComponent(Component p42188b72_2_0) {
      return Objects.requireNonNullElse(this.createComponent(), p42188b72_2_0);
   }

   public @Nullable Component createComponent() {
      if (!I18n.exists(this.translationKey)) {
         return null;
      } else {
         return this.args == null ? Component.translatable(this.translationKey) : Component.translatable(this.translationKey, this.args);
      }
   }

   public static RealmsText parse(JsonObject p42188b72_3_0) {
      String $$1 = JsonUtils.getRequiredString("translationKey", p42188b72_3_0);
      JsonElement $$2 = p42188b72_3_0.get("args");
      String[] $$5;
      if ($$2 != null && !$$2.isJsonNull()) {
         JsonArray $$4 = $$2.getAsJsonArray();
         $$5 = new String[$$4.size()];

         for (int $$6 = 0; $$6 < $$4.size(); $$6++) {
            $$5[$$6] = $$4.get($$6).getAsString();
         }
      } else {
         $$5 = null;
      }

      return new RealmsText($$1, $$5);
   }

   @Override
   public String toString() {
      return this.translationKey;
   }
}
