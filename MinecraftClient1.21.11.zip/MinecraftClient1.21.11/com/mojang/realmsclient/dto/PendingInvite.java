package com.mojang.realmsclient.dto;

import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import java.time.Instant;
import java.util.UUID;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public record PendingInvite(String invitationId, String realmName, String realmOwnerName, UUID realmOwnerUuid, Instant date) {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static @Nullable PendingInvite parse(JsonObject p1ae3937f_5_0) {
      try {
         return new PendingInvite(
            JsonUtils.getStringOr("invitationId", p1ae3937f_5_0, ""),
            JsonUtils.getStringOr("worldName", p1ae3937f_5_0, ""),
            JsonUtils.getStringOr("worldOwnerName", p1ae3937f_5_0, ""),
            JsonUtils.getUuidOr("worldOwnerUuid", p1ae3937f_5_0, Util.NIL_UUID),
            JsonUtils.getDateOr("date", p1ae3937f_5_0)
         );
      } catch (Exception $$1) {
         LOGGER.error("Could not parse PendingInvite", $$1);
         return null;
      }
   }
}
