package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public abstract class ValueObject {
   @Override
   public String toString() {
      StringBuilder $$0 = new StringBuilder("{");

      for (Field $$1 : this.getClass().getFields()) {
         if (!isStatic($$1)) {
            try {
               $$0.append(getName($$1)).append("=").append($$1.get(this)).append(" ");
            } catch (IllegalAccessException var7) {
            }
         }
      }

      $$0.deleteCharAt($$0.length() - 1);
      $$0.append('}');
      return $$0.toString();
   }

   private static String getName(Field pa56837cf_0_0) {
      SerializedName $$1 = pa56837cf_0_0.getAnnotation(SerializedName.class);
      return $$1 != null ? $$1.value() : pa56837cf_0_0.getName();
   }

   private static boolean isStatic(Field pa56837cf_1_0) {
      return Modifier.isStatic(pa56837cf_1_0.getModifiers());
   }
}
