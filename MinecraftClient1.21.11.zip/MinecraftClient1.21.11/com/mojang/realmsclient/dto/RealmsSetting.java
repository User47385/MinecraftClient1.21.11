package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public record RealmsSetting(@SerializedName("name") String name, @SerializedName("value") String value) implements ReflectionBasedSerialization {
   public static RealmsSetting hardcoreSetting(boolean p712e65eb_2_0) {
      return new RealmsSetting("hardcore", Boolean.toString(p712e65eb_2_0));
   }

   public static boolean isHardcore(List<RealmsSetting> p712e65eb_3_0) {
      for (RealmsSetting $$1 : p712e65eb_3_0) {
         if ($$1.name().equals("hardcore")) {
            return Boolean.parseBoolean($$1.value());
         }
      }

      return false;
   }
}
