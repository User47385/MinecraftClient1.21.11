package com.mojang.realmsclient.dto;

import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.mojang.util.UUIDTypeAdapter;
import java.util.UUID;

public class PlayerInfo extends ValueObject implements ReflectionBasedSerialization {
   @SerializedName("name")
   public final String name;
   @SerializedName("uuid")
   @JsonAdapter(UUIDTypeAdapter.class)
   public final UUID uuid;
   @SerializedName("operator")
   public boolean operator;
   @SerializedName("accepted")
   public final boolean accepted;
   @SerializedName("online")
   public final boolean online;

   public PlayerInfo(String p95bf790_0_0, UUID p95bf790_1_1, boolean p95bf790_2_2, boolean p95bf790_3_3, boolean p95bf790_4_4) {
      this.name = p95bf790_0_0;
      this.uuid = p95bf790_1_1;
      this.operator = p95bf790_2_2;
      this.accepted = p95bf790_3_3;
      this.online = p95bf790_4_4;
   }
}
