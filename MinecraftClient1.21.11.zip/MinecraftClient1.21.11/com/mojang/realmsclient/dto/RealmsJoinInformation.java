package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import com.mojang.logging.LogUtils;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public record RealmsJoinInformation(
   @SerializedName("address") @Nullable String address,
   @SerializedName("resourcePackUrl") @Nullable String resourcePackUrl,
   @SerializedName("resourcePackHash") @Nullable String resourcePackHash,
   @SerializedName("sessionRegionData") RealmsJoinInformation.@Nullable RegionData regionData
) implements ReflectionBasedSerialization {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final RealmsJoinInformation EMPTY = new RealmsJoinInformation(null, null, null, null);

   public static RealmsJoinInformation parse(GuardedSerializer pe1cece3d_4_0, String pe1cece3d_5_1) {
      try {
         RealmsJoinInformation $$2 = pe1cece3d_4_0.fromJson(pe1cece3d_5_1, RealmsJoinInformation.class);
         if ($$2 == null) {
            LOGGER.error("Could not parse RealmsServerAddress: {}", pe1cece3d_5_1);
            return EMPTY;
         } else {
            return $$2;
         }
      } catch (Exception $$3) {
         LOGGER.error("Could not parse RealmsServerAddress", $$3);
         return EMPTY;
      }
   }

   public record RegionData(
      @SerializedName("regionName") @Nullable RealmsRegion region, @SerializedName("serviceQuality") @Nullable ServiceQuality serviceQuality
   ) implements ReflectionBasedSerialization {
   }
}
