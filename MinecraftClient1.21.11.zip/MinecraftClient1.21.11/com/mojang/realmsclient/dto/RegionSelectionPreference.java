package com.mojang.realmsclient.dto;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import org.slf4j.Logger;

public enum RegionSelectionPreference {
   AUTOMATIC_PLAYER(0, "realms.configuration.region_preference.automatic_player"),
   AUTOMATIC_OWNER(1, "realms.configuration.region_preference.automatic_owner"),
   MANUAL(2, "");

   public static final RegionSelectionPreference DEFAULT_SELECTION = AUTOMATIC_PLAYER;
   public final int id;
   public final String translationKey;

   RegionSelectionPreference(final int p3cfa7572_3_2, final String p3cfa7572_4_3) {
      this.id = p3cfa7572_3_2;
      this.translationKey = p3cfa7572_4_3;
   }

   public static class RegionSelectionPreferenceJsonAdapter extends TypeAdapter<RegionSelectionPreference> {
      private static final Logger LOGGER = LogUtils.getLogger();

      public void write(JsonWriter p38681766_0_0, RegionSelectionPreference p38681766_1_1) throws IOException {
         p38681766_0_0.value(p38681766_1_1.id);
      }

      public RegionSelectionPreference read(JsonReader p38681766_2_0) throws IOException {
         int $$1 = p38681766_2_0.nextInt();

         for (RegionSelectionPreference $$2 : RegionSelectionPreference.values()) {
            if ($$2.id == $$1) {
               return $$2;
            }
         }

         LOGGER.warn("Unsupported RegionSelectionPreference {}", $$1);
         return RegionSelectionPreference.DEFAULT_SELECTION;
      }
   }
}
