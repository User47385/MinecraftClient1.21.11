package com.mojang.realmsclient.dto;

import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import java.time.Instant;
import net.minecraft.util.LenientJsonParser;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public record Subscription(Instant startDate, int daysLeft, Subscription.SubscriptionType type) {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static Subscription parse(String p5705a13e_3_0) {
      try {
         JsonObject $$1 = LenientJsonParser.parse(p5705a13e_3_0).getAsJsonObject();
         return new Subscription(
            JsonUtils.getDateOr("startDate", $$1), JsonUtils.getIntOr("daysLeft", $$1, 0), typeFrom(JsonUtils.getStringOr("subscriptionType", $$1, null))
         );
      } catch (Exception $$2) {
         LOGGER.error("Could not parse Subscription", $$2);
         return new Subscription(Instant.EPOCH, 0, Subscription.SubscriptionType.NORMAL);
      }
   }

   private static Subscription.SubscriptionType typeFrom(@Nullable String p5705a13e_4_0) {
      try {
         if (p5705a13e_4_0 != null) {
            return Subscription.SubscriptionType.valueOf(p5705a13e_4_0);
         }
      } catch (Exception var2) {
      }

      return Subscription.SubscriptionType.NORMAL;
   }

   public enum SubscriptionType {
      NORMAL,
      RECURRING;
   }
}
