package com.mojang.realmsclient.dto;

import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.mojang.logging.LogUtils;
import com.mojang.util.UUIDTypeAdapter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class RealmsServer extends ValueObject implements ReflectionBasedSerialization {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final int NO_VALUE = -1;
   public static final Component WORLD_CLOSED_COMPONENT = Component.translatable("mco.play.button.realm.closed");
   @SerializedName("id")
   public long id = -1L;
   @SerializedName("remoteSubscriptionId")
   public @Nullable String remoteSubscriptionId;
   @SerializedName("name")
   public @Nullable String name;
   @SerializedName("motd")
   public String motd = "";
   @SerializedName("state")
   public RealmsServer.State state = RealmsServer.State.CLOSED;
   @SerializedName("owner")
   public @Nullable String owner;
   @SerializedName("ownerUUID")
   @JsonAdapter(UUIDTypeAdapter.class)
   public UUID ownerUUID = Util.NIL_UUID;
   @SerializedName("players")
   public List<PlayerInfo> players = Lists.newArrayList();
   @SerializedName("slots")
   private List<RealmsSlot> slotList = createEmptySlots();
   @Exclude
   public Map<Integer, RealmsSlot> slots = new HashMap<>();
   @SerializedName("expired")
   public boolean expired;
   @SerializedName("expiredTrial")
   public boolean expiredTrial = false;
   @SerializedName("daysLeft")
   public int daysLeft;
   @SerializedName("worldType")
   public RealmsServer.WorldType worldType = RealmsServer.WorldType.NORMAL;
   @SerializedName("isHardcore")
   public boolean isHardcore = false;
   @SerializedName("gameMode")
   public int gameMode = -1;
   @SerializedName("activeSlot")
   public int activeSlot = -1;
   @SerializedName("minigameName")
   public @Nullable String minigameName;
   @SerializedName("minigameId")
   public int minigameId = -1;
   @SerializedName("minigameImage")
   public @Nullable String minigameImage;
   @SerializedName("parentWorldId")
   public long parentRealmId = -1L;
   @SerializedName("parentWorldName")
   public @Nullable String parentWorldName;
   @SerializedName("activeVersion")
   public String activeVersion = "";
   @SerializedName("compatibility")
   public RealmsServer.Compatibility compatibility = RealmsServer.Compatibility.UNVERIFIABLE;
   @SerializedName("regionSelectionPreference")
   public @Nullable RegionSelectionPreferenceDto regionSelectionPreference;

   public String getDescription() {
      return this.motd;
   }

   public @Nullable String getName() {
      return this.name;
   }

   public @Nullable String getMinigameName() {
      return this.minigameName;
   }

   public void setName(String p1c6bf848_0_0) {
      this.name = p1c6bf848_0_0;
   }

   public void setDescription(String p1c6bf848_1_0) {
      this.motd = p1c6bf848_1_0;
   }

   public static RealmsServer parse(GuardedSerializer p1c6bf848_2_0, String p1c6bf848_3_1) {
      try {
         RealmsServer $$2 = p1c6bf848_2_0.fromJson(p1c6bf848_3_1, RealmsServer.class);
         if ($$2 == null) {
            LOGGER.error("Could not parse McoServer: {}", p1c6bf848_3_1);
            return new RealmsServer();
         } else {
            finalize($$2);
            return $$2;
         }
      } catch (Exception $$3) {
         LOGGER.error("Could not parse McoServer", $$3);
         return new RealmsServer();
      }
   }

   public static void finalize(RealmsServer p1c6bf848_4_0) {
      if (p1c6bf848_4_0.players == null) {
         p1c6bf848_4_0.players = Lists.newArrayList();
      }

      if (p1c6bf848_4_0.slotList == null) {
         p1c6bf848_4_0.slotList = createEmptySlots();
      }

      if (p1c6bf848_4_0.slots == null) {
         p1c6bf848_4_0.slots = new HashMap<>();
      }

      if (p1c6bf848_4_0.worldType == null) {
         p1c6bf848_4_0.worldType = RealmsServer.WorldType.NORMAL;
      }

      if (p1c6bf848_4_0.activeVersion == null) {
         p1c6bf848_4_0.activeVersion = "";
      }

      if (p1c6bf848_4_0.compatibility == null) {
         p1c6bf848_4_0.compatibility = RealmsServer.Compatibility.UNVERIFIABLE;
      }

      if (p1c6bf848_4_0.regionSelectionPreference == null) {
         p1c6bf848_4_0.regionSelectionPreference = RegionSelectionPreferenceDto.DEFAULT;
      }

      sortInvited(p1c6bf848_4_0);
      finalizeSlots(p1c6bf848_4_0);
   }

   private static void sortInvited(RealmsServer p1c6bf848_5_0) {
      p1c6bf848_5_0.players
         .sort(
            (p1c6bf848_13_0, p1c6bf848_14_1) -> ComparisonChain.start()
               .compareFalseFirst(p1c6bf848_14_1.accepted, p1c6bf848_13_0.accepted)
               .compare(p1c6bf848_13_0.name.toLowerCase(Locale.ROOT), p1c6bf848_14_1.name.toLowerCase(Locale.ROOT))
               .result()
         );
   }

   private static void finalizeSlots(RealmsServer p1c6bf848_6_0) {
      p1c6bf848_6_0.slotList.forEach(p1c6bf848_12_1 -> p1c6bf848_6_0.slots.put(p1c6bf848_12_1.slotId, p1c6bf848_12_1));

      for (int $$1 = 1; $$1 <= 3; $$1++) {
         if (!p1c6bf848_6_0.slots.containsKey($$1)) {
            p1c6bf848_6_0.slots.put($$1, RealmsSlot.defaults($$1));
         }
      }
   }

   private static List<RealmsSlot> createEmptySlots() {
      List<RealmsSlot> $$0 = new ArrayList<>();
      $$0.add(RealmsSlot.defaults(1));
      $$0.add(RealmsSlot.defaults(2));
      $$0.add(RealmsSlot.defaults(3));
      return $$0;
   }

   public boolean isCompatible() {
      return this.compatibility.isCompatible();
   }

   public boolean needsUpgrade() {
      return this.compatibility.needsUpgrade();
   }

   public boolean needsDowngrade() {
      return this.compatibility.needsDowngrade();
   }

   public boolean shouldPlayButtonBeActive() {
      boolean $$0 = !this.expired && this.state == RealmsServer.State.OPEN;
      return $$0 && (this.isCompatible() || this.needsUpgrade() || this.isSelfOwnedServer());
   }

   private boolean isSelfOwnedServer() {
      return Minecraft.getInstance().isLocalPlayer(this.ownerUUID);
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.id, this.name, this.motd, this.state, this.owner, this.expired);
   }

   @Override
   public boolean equals(Object p1c6bf848_7_0) {
      if (p1c6bf848_7_0 == null) {
         return false;
      }

      if (p1c6bf848_7_0 == this) {
         return true;
      }

      if (p1c6bf848_7_0.getClass() != this.getClass()) {
         return false;
      }

      RealmsServer $$1 = (RealmsServer)p1c6bf848_7_0;
      return new EqualsBuilder()
         .append(this.id, $$1.id)
         .append(this.name, $$1.name)
         .append(this.motd, $$1.motd)
         .append(this.state, $$1.state)
         .append(this.owner, $$1.owner)
         .append(this.expired, $$1.expired)
         .append(this.worldType, this.worldType)
         .isEquals();
   }

   public RealmsServer copy() {
      RealmsServer $$0 = new RealmsServer();
      $$0.id = this.id;
      $$0.remoteSubscriptionId = this.remoteSubscriptionId;
      $$0.name = this.name;
      $$0.motd = this.motd;
      $$0.state = this.state;
      $$0.owner = this.owner;
      $$0.players = this.players;
      $$0.slotList = this.slotList.stream().map(RealmsSlot::copy).toList();
      $$0.slots = this.cloneSlots(this.slots);
      $$0.expired = this.expired;
      $$0.expiredTrial = this.expiredTrial;
      $$0.daysLeft = this.daysLeft;
      $$0.worldType = this.worldType;
      $$0.isHardcore = this.isHardcore;
      $$0.gameMode = this.gameMode;
      $$0.ownerUUID = this.ownerUUID;
      $$0.minigameName = this.minigameName;
      $$0.activeSlot = this.activeSlot;
      $$0.minigameId = this.minigameId;
      $$0.minigameImage = this.minigameImage;
      $$0.parentWorldName = this.parentWorldName;
      $$0.parentRealmId = this.parentRealmId;
      $$0.activeVersion = this.activeVersion;
      $$0.compatibility = this.compatibility;
      $$0.regionSelectionPreference = this.regionSelectionPreference != null ? this.regionSelectionPreference.copy() : null;
      return $$0;
   }

   public Map<Integer, RealmsSlot> cloneSlots(Map<Integer, RealmsSlot> p1c6bf848_8_0) {
      Map<Integer, RealmsSlot> $$1 = Maps.newHashMap();

      for (Entry<Integer, RealmsSlot> $$2 : p1c6bf848_8_0.entrySet()) {
         $$1.put($$2.getKey(), new RealmsSlot($$2.getKey(), $$2.getValue().options.copy(), $$2.getValue().settings));
      }

      return $$1;
   }

   public boolean isSnapshotRealm() {
      return this.parentRealmId != -1L;
   }

   public boolean isMinigameActive() {
      return this.worldType == RealmsServer.WorldType.MINIGAME;
   }

   public String getWorldName(int p1c6bf848_9_0) {
      return this.name == null
         ? this.slots.get(p1c6bf848_9_0).options.getSlotName(p1c6bf848_9_0)
         : this.name + " (" + this.slots.get(p1c6bf848_9_0).options.getSlotName(p1c6bf848_9_0) + ")";
   }

   public ServerData toServerData(String p1c6bf848_10_0) {
      return new ServerData(Objects.requireNonNullElse(this.name, "unknown server"), p1c6bf848_10_0, ServerData.Type.REALM);
   }

   public enum Compatibility {
      UNVERIFIABLE,
      INCOMPATIBLE,
      RELEASE_TYPE_INCOMPATIBLE,
      NEEDS_DOWNGRADE,
      NEEDS_UPGRADE,
      COMPATIBLE;

      public boolean isCompatible() {
         return this == COMPATIBLE;
      }

      public boolean needsUpgrade() {
         return this == NEEDS_UPGRADE;
      }

      public boolean needsDowngrade() {
         return this == NEEDS_DOWNGRADE;
      }
   }

   public static class McoServerComparator implements Comparator<RealmsServer> {
      private final String refOwner;

      public McoServerComparator(String p9543e9b6_0_0) {
         this.refOwner = p9543e9b6_0_0;
      }

      public int compare(RealmsServer p9543e9b6_1_0, RealmsServer p9543e9b6_2_1) {
         return ComparisonChain.start()
            .compareTrueFirst(p9543e9b6_1_0.isSnapshotRealm(), p9543e9b6_2_1.isSnapshotRealm())
            .compareTrueFirst(p9543e9b6_1_0.state == RealmsServer.State.UNINITIALIZED, p9543e9b6_2_1.state == RealmsServer.State.UNINITIALIZED)
            .compareTrueFirst(p9543e9b6_1_0.expiredTrial, p9543e9b6_2_1.expiredTrial)
            .compareTrueFirst(Objects.equals(p9543e9b6_1_0.owner, this.refOwner), Objects.equals(p9543e9b6_2_1.owner, this.refOwner))
            .compareFalseFirst(p9543e9b6_1_0.expired, p9543e9b6_2_1.expired)
            .compareTrueFirst(p9543e9b6_1_0.state == RealmsServer.State.OPEN, p9543e9b6_2_1.state == RealmsServer.State.OPEN)
            .compare(p9543e9b6_1_0.id, p9543e9b6_2_1.id)
            .result();
      }
   }

   public enum State {
      CLOSED,
      OPEN,
      UNINITIALIZED;
   }

   public enum WorldType {
      NORMAL("normal"),
      MINIGAME("minigame"),
      ADVENTUREMAP("adventureMap"),
      EXPERIENCE("experience"),
      INSPIRATION("inspiration"),
      UNKNOWN("unknown");

      private static final String TRANSLATION_PREFIX = "mco.backup.entry.worldType.";
      private final Component displayName;

      WorldType(final String p54db4c70_3_2) {
         this.displayName = Component.translatable("mco.backup.entry.worldType." + p54db4c70_3_2);
      }

      public Component getDisplayName() {
         return this.displayName;
      }
   }
}
