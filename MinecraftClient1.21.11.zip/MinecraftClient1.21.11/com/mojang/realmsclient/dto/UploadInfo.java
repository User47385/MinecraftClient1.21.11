package com.mojang.realmsclient.dto;

import com.google.common.annotations.VisibleForTesting;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.util.LenientJsonParser;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public record UploadInfo(boolean worldClosed, @Nullable String token, URI uploadEndpoint) {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final String DEFAULT_SCHEMA = "http://";
   private static final int DEFAULT_PORT = 8080;
   private static final Pattern URI_SCHEMA_PATTERN = Pattern.compile("^[a-zA-Z][-a-zA-Z0-9+.]+:");

   public static @Nullable UploadInfo parse(String p7df2dab0_3_0) {
      try {
         JsonObject $$1 = LenientJsonParser.parse(p7df2dab0_3_0).getAsJsonObject();
         String $$2 = JsonUtils.getStringOr("uploadEndpoint", $$1, null);
         if ($$2 != null) {
            int $$3 = JsonUtils.getIntOr("port", $$1, -1);
            URI $$4 = assembleUri($$2, $$3);
            if ($$4 != null) {
               boolean $$5 = JsonUtils.getBooleanOr("worldClosed", $$1, false);
               String $$6 = JsonUtils.getStringOr("token", $$1, null);
               return new UploadInfo($$5, $$6, $$4);
            }
         }
      } catch (Exception $$7) {
         LOGGER.error("Could not parse UploadInfo", $$7);
      }

      return null;
   }

   @VisibleForTesting
   public static @Nullable URI assembleUri(String p7df2dab0_4_0, int p7df2dab0_5_1) {
      Matcher $$2 = URI_SCHEMA_PATTERN.matcher(p7df2dab0_4_0);
      String $$3 = ensureEndpointSchema(p7df2dab0_4_0, $$2);

      try {
         URI $$4 = new URI($$3);
         int $$5 = selectPortOrDefault(p7df2dab0_5_1, $$4.getPort());
         return $$5 != $$4.getPort() ? new URI($$4.getScheme(), $$4.getUserInfo(), $$4.getHost(), $$5, $$4.getPath(), $$4.getQuery(), $$4.getFragment()) : $$4;
      } catch (URISyntaxException $$6) {
         LOGGER.warn("Failed to parse URI {}", $$3, $$6);
         return null;
      }
   }

   private static int selectPortOrDefault(int p7df2dab0_6_0, int p7df2dab0_7_1) {
      if (p7df2dab0_6_0 != -1) {
         return p7df2dab0_6_0;
      } else {
         return p7df2dab0_7_1 != -1 ? p7df2dab0_7_1 : 8080;
      }
   }

   private static String ensureEndpointSchema(String p7df2dab0_8_0, Matcher p7df2dab0_9_1) {
      return p7df2dab0_9_1.find() ? p7df2dab0_8_0 : "http://" + p7df2dab0_8_0;
   }

   public static String createRequest(@Nullable String p7df2dab0_10_0) {
      JsonObject $$1 = new JsonObject();
      if (p7df2dab0_10_0 != null) {
         $$1.addProperty("token", p7df2dab0_10_0);
      }

      return $$1.toString();
   }
}
