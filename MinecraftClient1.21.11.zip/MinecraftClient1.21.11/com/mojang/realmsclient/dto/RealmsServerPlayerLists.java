package com.mojang.realmsclient.dto;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.LenientJsonParser;
import net.minecraft.world.item.component.ResolvableProfile;
import org.slf4j.Logger;

public record RealmsServerPlayerLists(Map<Long, List<ResolvableProfile>> servers) {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static RealmsServerPlayerLists parse(String p486dafcc_1_0) {
      Builder<Long, List<ResolvableProfile>> $$1 = ImmutableMap.builder();

      try {
         JsonObject $$2 = GsonHelper.parse(p486dafcc_1_0);
         if (GsonHelper.isArrayNode($$2, "lists")) {
            for (JsonElement $$4 : $$2.getAsJsonArray("lists")) {
               JsonObject $$5 = $$4.getAsJsonObject();
               String $$6 = JsonUtils.getStringOr("playerList", $$5, null);
               List<ResolvableProfile> $$8;
               if ($$6 != null) {
                  JsonElement $$7 = LenientJsonParser.parse($$6);
                  if ($$7.isJsonArray()) {
                     $$8 = parsePlayers($$7.getAsJsonArray());
                  } else {
                     $$8 = Lists.newArrayList();
                  }
               } else {
                  $$8 = Lists.newArrayList();
               }

               $$1.put(JsonUtils.getLongOr("serverId", $$5, -1L), $$8);
            }
         }
      } catch (Exception $$11) {
         LOGGER.error("Could not parse RealmsServerPlayerLists", $$11);
      }

      return new RealmsServerPlayerLists($$1.build());
   }

   private static List<ResolvableProfile> parsePlayers(JsonArray p486dafcc_2_0) {
      List<ResolvableProfile> $$1 = new ArrayList<>(p486dafcc_2_0.size());

      for (JsonElement $$2 : p486dafcc_2_0) {
         if ($$2.isJsonObject()) {
            UUID $$3 = JsonUtils.getUuidOr("playerId", $$2.getAsJsonObject(), null);
            if ($$3 != null && !Minecraft.getInstance().isLocalPlayer($$3)) {
               $$1.add(ResolvableProfile.createUnresolved($$3));
            }
         }
      }

      return $$1;
   }

   public List<ResolvableProfile> getProfileResultsFor(long p486dafcc_3_0) {
      List<ResolvableProfile> $$1 = this.servers.get(p486dafcc_3_0);
      return $$1 != null ? $$1 : List.of();
   }
}
