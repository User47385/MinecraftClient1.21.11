package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import com.mojang.logging.LogUtils;
import java.util.List;
import org.slf4j.Logger;

public record RealmsServerList(@SerializedName("servers") List<RealmsServer> servers) implements ReflectionBasedSerialization {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static RealmsServerList parse(GuardedSerializer p99cab906_1_0, String p99cab906_2_1) {
      try {
         RealmsServerList $$2 = p99cab906_1_0.fromJson(p99cab906_2_1, RealmsServerList.class);
         if ($$2 != null) {
            $$2.servers.forEach(RealmsServer::finalize);
            return $$2;
         }

         LOGGER.error("Could not parse McoServerList: {}", p99cab906_2_1);
      } catch (Exception $$3) {
         LOGGER.error("Could not parse McoServerList", $$3);
      }

      return new RealmsServerList(List.of());
   }
}
