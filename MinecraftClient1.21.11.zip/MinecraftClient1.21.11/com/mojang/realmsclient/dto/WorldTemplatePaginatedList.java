package com.mojang.realmsclient.dto;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.LenientJsonParser;
import org.slf4j.Logger;

public record WorldTemplatePaginatedList(List<WorldTemplate> templates, int page, int size, int total) {
   private static final Logger LOGGER = LogUtils.getLogger();

   public WorldTemplatePaginatedList(int pa220a0a0_0_0) {
      this(List.of(), 0, pa220a0a0_0_0, -1);
   }

   public boolean isLastPage() {
      return this.page * this.size >= this.total && this.page > 0 && this.total > 0 && this.size > 0;
   }

   public static WorldTemplatePaginatedList parse(String pa220a0a0_5_0) {
      List<WorldTemplate> $$1 = new ArrayList<>();
      int $$2 = 0;
      int $$3 = 0;
      int $$4 = 0;

      try {
         JsonObject $$5 = LenientJsonParser.parse(pa220a0a0_5_0).getAsJsonObject();
         if ($$5.get("templates").isJsonArray()) {
            for (JsonElement $$6 : $$5.get("templates").getAsJsonArray()) {
               WorldTemplate $$7 = WorldTemplate.parse($$6.getAsJsonObject());
               if ($$7 != null) {
                  $$1.add($$7);
               }
            }
         }

         $$2 = JsonUtils.getIntOr("page", $$5, 0);
         $$3 = JsonUtils.getIntOr("size", $$5, 0);
         $$4 = JsonUtils.getIntOr("total", $$5, 0);
      } catch (Exception $$8) {
         LOGGER.error("Could not parse WorldTemplatePaginatedList", $$8);
      }

      return new WorldTemplatePaginatedList($$1, $$2, $$3, $$4);
   }
}
