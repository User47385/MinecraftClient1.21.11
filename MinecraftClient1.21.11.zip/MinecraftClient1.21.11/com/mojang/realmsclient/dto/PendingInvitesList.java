package com.mojang.realmsclient.dto;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.LenientJsonParser;
import org.slf4j.Logger;

public record PendingInvitesList(List<PendingInvite> pendingInvites) {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static PendingInvitesList parse(String pf2907792_1_0) {
      List<PendingInvite> $$1 = new ArrayList<>();

      try {
         JsonObject $$2 = LenientJsonParser.parse(pf2907792_1_0).getAsJsonObject();
         if ($$2.get("invites").isJsonArray()) {
            for (JsonElement $$3 : $$2.get("invites").getAsJsonArray()) {
               PendingInvite $$4 = PendingInvite.parse($$3.getAsJsonObject());
               if ($$4 != null) {
                  $$1.add($$4);
               }
            }
         }
      } catch (Exception $$5) {
         LOGGER.error("Could not parse PendingInvitesList", $$5);
      }

      return new PendingInvitesList($$1);
   }
}
