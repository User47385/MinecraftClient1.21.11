package com.mojang.realmsclient.dto;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class RealmsSlot implements ReflectionBasedSerialization {
   @SerializedName("slotId")
   public int slotId;
   @SerializedName("options")
   @JsonAdapter(RealmsSlot.RealmsWorldOptionsJsonAdapter.class)
   public RealmsWorldOptions options;
   @SerializedName("settings")
   public List<RealmsSetting> settings;

   public RealmsSlot(int p42183043_0_0, RealmsWorldOptions p42183043_1_1, List<RealmsSetting> p42183043_2_2) {
      this.slotId = p42183043_0_0;
      this.options = p42183043_1_1;
      this.settings = p42183043_2_2;
   }

   public static RealmsSlot defaults(int p42183043_3_0) {
      return new RealmsSlot(p42183043_3_0, RealmsWorldOptions.createEmptyDefaults(), List.of(RealmsSetting.hardcoreSetting(false)));
   }

   public RealmsSlot copy() {
      return new RealmsSlot(this.slotId, this.options.copy(), new ArrayList<>(this.settings));
   }

   public boolean isHardcore() {
      return RealmsSetting.isHardcore(this.settings);
   }

   static class RealmsWorldOptionsJsonAdapter extends TypeAdapter<RealmsWorldOptions> {
      private RealmsWorldOptionsJsonAdapter() {
      }

      public void write(JsonWriter pe638d1d6_0_0, RealmsWorldOptions pe638d1d6_1_1) throws IOException {
         pe638d1d6_0_0.jsonValue(new GuardedSerializer().toJson(pe638d1d6_1_1));
      }

      public RealmsWorldOptions read(JsonReader pe638d1d6_2_0) throws IOException {
         String $$1 = pe638d1d6_2_0.nextString();
         return RealmsWorldOptions.parse(new GuardedSerializer(), $$1);
      }
   }
}
