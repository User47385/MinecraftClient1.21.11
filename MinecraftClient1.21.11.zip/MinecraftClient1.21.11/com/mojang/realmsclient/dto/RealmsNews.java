package com.mojang.realmsclient.dto;

import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import net.minecraft.util.LenientJsonParser;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public record RealmsNews(@Nullable String newsLink) {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static RealmsNews parse(String p4215d118_1_0) {
      String $$1 = null;

      try {
         JsonObject $$2 = LenientJsonParser.parse(p4215d118_1_0).getAsJsonObject();
         $$1 = JsonUtils.getStringOr("newsLink", $$2, null);
      } catch (Exception $$3) {
         LOGGER.error("Could not parse RealmsNews", $$3);
      }

      return new RealmsNews($$1);
   }
}
