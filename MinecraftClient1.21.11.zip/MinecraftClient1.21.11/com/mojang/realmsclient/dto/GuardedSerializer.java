package com.mojang.realmsclient.dto;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import org.jspecify.annotations.Nullable;

public class GuardedSerializer {
   ExclusionStrategy strategy = new ExclusionStrategy() {
      @Override
      public boolean shouldSkipClass(Class<?> p1b266282_1_0) {
         return false;
      }

      @Override
      public boolean shouldSkipField(FieldAttributes p1b266282_2_0) {
         return p1b266282_2_0.getAnnotation(Exclude.class) != null;
      }
   };
   private final Gson gson = new GsonBuilder().addSerializationExclusionStrategy(this.strategy).addDeserializationExclusionStrategy(this.strategy).create();

   public String toJson(ReflectionBasedSerialization p59f5735_0_0) {
      return this.gson.toJson(p59f5735_0_0);
   }

   public String toJson(JsonElement p59f5735_1_0) {
      return this.gson.toJson(p59f5735_1_0);
   }

   public <T extends ReflectionBasedSerialization> @Nullable T fromJson(String p59f5735_2_0, Class<T> p59f5735_3_1) {
      return this.gson.fromJson(p59f5735_2_0, p59f5735_3_1);
   }
}
