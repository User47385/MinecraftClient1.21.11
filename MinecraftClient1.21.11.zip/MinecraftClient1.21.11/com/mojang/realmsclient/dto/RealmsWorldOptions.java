package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.util.StringUtil;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.LevelSettings;
import org.jspecify.annotations.Nullable;

public class RealmsWorldOptions extends ValueObject implements ReflectionBasedSerialization {
   @SerializedName("spawnProtection")
   public int spawnProtection = 0;
   @SerializedName("forceGameMode")
   public boolean forceGameMode = false;
   @SerializedName("difficulty")
   public int difficulty = 2;
   @SerializedName("gameMode")
   public int gameMode = 0;
   @SerializedName("slotName")
   private String slotName = "";
   @SerializedName("version")
   public String version = "";
   @SerializedName("compatibility")
   public RealmsServer.Compatibility compatibility = RealmsServer.Compatibility.UNVERIFIABLE;
   @SerializedName("worldTemplateId")
   public long templateId = -1L;
   @SerializedName("worldTemplateImage")
   public @Nullable String templateImage = null;
   @Exclude
   public boolean empty;

   private RealmsWorldOptions() {
   }

   public RealmsWorldOptions(
      int p11b36bf1_0_0,
      int p11b36bf1_1_1,
      int p11b36bf1_2_2,
      boolean p11b36bf1_3_3,
      String p11b36bf1_4_4,
      String p11b36bf1_5_5,
      RealmsServer.Compatibility p11b36bf1_6_6
   ) {
      this.spawnProtection = p11b36bf1_0_0;
      this.difficulty = p11b36bf1_1_1;
      this.gameMode = p11b36bf1_2_2;
      this.forceGameMode = p11b36bf1_3_3;
      this.slotName = p11b36bf1_4_4;
      this.version = p11b36bf1_5_5;
      this.compatibility = p11b36bf1_6_6;
   }

   public static RealmsWorldOptions createDefaults() {
      return new RealmsWorldOptions();
   }

   public static RealmsWorldOptions createDefaultsWith(
      GameType p11b36bf1_7_0, Difficulty p11b36bf1_8_1, boolean p11b36bf1_9_2, String p11b36bf1_10_3, String p11b36bf1_11_4
   ) {
      RealmsWorldOptions $$5 = createDefaults();
      $$5.difficulty = p11b36bf1_8_1.getId();
      $$5.gameMode = p11b36bf1_7_0.getId();
      $$5.slotName = p11b36bf1_11_4;
      $$5.version = p11b36bf1_10_3;
      return $$5;
   }

   public static RealmsWorldOptions createFromSettings(LevelSettings p11b36bf1_12_0, String p11b36bf1_13_1) {
      return createDefaultsWith(p11b36bf1_12_0.gameType(), p11b36bf1_12_0.difficulty(), p11b36bf1_12_0.hardcore(), p11b36bf1_13_1, p11b36bf1_12_0.levelName());
   }

   public static RealmsWorldOptions createEmptyDefaults() {
      RealmsWorldOptions $$0 = createDefaults();
      $$0.setEmpty(true);
      return $$0;
   }

   public void setEmpty(boolean p11b36bf1_14_0) {
      this.empty = p11b36bf1_14_0;
   }

   public static RealmsWorldOptions parse(GuardedSerializer p11b36bf1_15_0, String p11b36bf1_16_1) {
      RealmsWorldOptions $$2 = p11b36bf1_15_0.fromJson(p11b36bf1_16_1, RealmsWorldOptions.class);
      if ($$2 == null) {
         return createDefaults();
      }

      finalize($$2);
      return $$2;
   }

   private static void finalize(RealmsWorldOptions p11b36bf1_17_0) {
      if (p11b36bf1_17_0.slotName == null) {
         p11b36bf1_17_0.slotName = "";
      }

      if (p11b36bf1_17_0.version == null) {
         p11b36bf1_17_0.version = "";
      }

      if (p11b36bf1_17_0.compatibility == null) {
         p11b36bf1_17_0.compatibility = RealmsServer.Compatibility.UNVERIFIABLE;
      }
   }

   public String getSlotName(int p11b36bf1_18_0) {
      if (StringUtil.isBlank(this.slotName)) {
         return this.empty ? I18n.get("mco.configure.world.slot.empty") : this.getDefaultSlotName(p11b36bf1_18_0);
      } else {
         return this.slotName;
      }
   }

   public String getDefaultSlotName(int p11b36bf1_19_0) {
      return I18n.get("mco.configure.world.slot", p11b36bf1_19_0);
   }

   public RealmsWorldOptions copy() {
      return new RealmsWorldOptions(this.spawnProtection, this.difficulty, this.gameMode, this.forceGameMode, this.slotName, this.version, this.compatibility);
   }
}
