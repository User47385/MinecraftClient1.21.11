package com.mojang.realmsclient.dto;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.util.LenientJsonParser;
import org.slf4j.Logger;

public record Ops(Set<String> ops) {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static Ops parse(String pafd78d71_1_0) {
      Set<String> $$1 = new HashSet<>();

      try {
         JsonObject $$2 = LenientJsonParser.parse(pafd78d71_1_0).getAsJsonObject();
         JsonElement $$3 = $$2.get("ops");
         if ($$3.isJsonArray()) {
            for (JsonElement $$4 : $$3.getAsJsonArray()) {
               $$1.add($$4.getAsString());
            }
         }
      } catch (Exception $$5) {
         LOGGER.error("Could not parse Ops", $$5);
      }

      return new Ops($$1);
   }
}
