package com.mojang.realmsclient.exception;

import com.mojang.realmsclient.client.RealmsError;

public class RealmsServiceException extends Exception {
   public final RealmsError realmsError;

   public RealmsServiceException(RealmsError pb2a172af_0_0) {
      this.realmsError = pb2a172af_0_0;
   }

   @Override
   public String getMessage() {
      return this.realmsError.logMessage();
   }
}
