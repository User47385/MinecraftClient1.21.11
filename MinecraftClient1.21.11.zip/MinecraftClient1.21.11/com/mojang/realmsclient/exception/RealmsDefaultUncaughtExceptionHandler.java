package com.mojang.realmsclient.exception;

import java.lang.Thread.UncaughtExceptionHandler;
import org.slf4j.Logger;

public class RealmsDefaultUncaughtExceptionHandler implements UncaughtExceptionHandler {
   private final Logger logger;

   public RealmsDefaultUncaughtExceptionHandler(Logger pcfe4d39c_0_0) {
      this.logger = pcfe4d39c_0_0;
   }

   @Override
   public void uncaughtException(Thread pcfe4d39c_1_0, Throwable pcfe4d39c_2_1) {
      this.logger.error("Caught previously unhandled exception", pcfe4d39c_2_1);
   }
}
