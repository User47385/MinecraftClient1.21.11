package com.mojang.realmsclient.exception;

import com.mojang.realmsclient.client.RealmsError;

public class RetryCallException extends RealmsServiceException {
   public static final int DEFAULT_DELAY = 5;
   public final int delaySeconds;

   public RetryCallException(int p68937fa_0_0, int p68937fa_1_1) {
      super(RealmsError.CustomError.retry(p68937fa_1_1));
      if (p68937fa_0_0 >= 0 && p68937fa_0_0 <= 120) {
         this.delaySeconds = p68937fa_0_0;
      } else {
         this.delaySeconds = 5;
      }
   }
}
