package com.mojang.realmsclient.exception;

public class RealmsHttpException extends RuntimeException {
   public RealmsHttpException(String pc9326332_0_0, Exception pc9326332_1_1) {
      super(pc9326332_0_0, pc9326332_1_1);
   }
}
