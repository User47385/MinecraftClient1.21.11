package com.mojang.math;

import com.google.common.annotations.VisibleForTesting;
import it.unimi.dsi.fastutil.ints.IntIterator;
import java.util.NoSuchElementException;

public class Divisor implements IntIterator {
   private final int denominator;
   private final int quotient;
   private final int mod;
   private int returnedParts;
   private int remainder;

   public Divisor(int p52b65406_0_0, int p52b65406_1_1) {
      this.denominator = p52b65406_1_1;
      if (p52b65406_1_1 > 0) {
         this.quotient = p52b65406_0_0 / p52b65406_1_1;
         this.mod = p52b65406_0_0 % p52b65406_1_1;
      } else {
         this.quotient = 0;
         this.mod = 0;
      }
   }

   @Override
   public boolean hasNext() {
      return this.returnedParts < this.denominator;
   }

   @Override
   public int nextInt() {
      if (!this.hasNext()) {
         throw new NoSuchElementException();
      }

      int $$0 = this.quotient;
      this.remainder = this.remainder + this.mod;
      if (this.remainder >= this.denominator) {
         this.remainder = this.remainder - this.denominator;
         $$0++;
      }

      this.returnedParts++;
      return $$0;
   }

   @VisibleForTesting
   public static Iterable<Integer> asIterable(int p52b65406_2_0, int p52b65406_3_1) {
      return () -> new Divisor(p52b65406_2_0, p52b65406_3_1);
   }
}
