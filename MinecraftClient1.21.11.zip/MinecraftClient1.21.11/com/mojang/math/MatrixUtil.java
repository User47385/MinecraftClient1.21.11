package com.mojang.math;

import org.apache.commons.lang3.tuple.Triple;
import org.joml.Math;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class MatrixUtil {
   private static final float G = 3.0F + 2.0F * Math.sqrt(2.0F);
   private static final GivensParameters PI_4 = GivensParameters.fromPositiveAngle((float) (java.lang.Math.PI / 4));

   private MatrixUtil() {
   }

   public static Matrix4f mulComponentWise(Matrix4f p3fe612fb_0_0, float p3fe612fb_1_1) {
      return p3fe612fb_0_0.set(
         p3fe612fb_0_0.m00() * p3fe612fb_1_1,
         p3fe612fb_0_0.m01() * p3fe612fb_1_1,
         p3fe612fb_0_0.m02() * p3fe612fb_1_1,
         p3fe612fb_0_0.m03() * p3fe612fb_1_1,
         p3fe612fb_0_0.m10() * p3fe612fb_1_1,
         p3fe612fb_0_0.m11() * p3fe612fb_1_1,
         p3fe612fb_0_0.m12() * p3fe612fb_1_1,
         p3fe612fb_0_0.m13() * p3fe612fb_1_1,
         p3fe612fb_0_0.m20() * p3fe612fb_1_1,
         p3fe612fb_0_0.m21() * p3fe612fb_1_1,
         p3fe612fb_0_0.m22() * p3fe612fb_1_1,
         p3fe612fb_0_0.m23() * p3fe612fb_1_1,
         p3fe612fb_0_0.m30() * p3fe612fb_1_1,
         p3fe612fb_0_0.m31() * p3fe612fb_1_1,
         p3fe612fb_0_0.m32() * p3fe612fb_1_1,
         p3fe612fb_0_0.m33() * p3fe612fb_1_1
      );
   }

   private static GivensParameters approxGivensQuat(float p3fe612fb_2_0, float p3fe612fb_3_1, float p3fe612fb_4_2) {
      float $$3 = 2.0F * (p3fe612fb_2_0 - p3fe612fb_4_2);
      float $$4 = p3fe612fb_3_1;
      return G * $$4 * $$4 < $$3 * $$3 ? GivensParameters.fromUnnormalized($$4, $$3) : PI_4;
   }

   private static GivensParameters qrGivensQuat(float p3fe612fb_5_0, float p3fe612fb_6_1) {
      float $$2 = (float)java.lang.Math.hypot(p3fe612fb_5_0, p3fe612fb_6_1);
      float $$3 = $$2 > 1.0E-6F ? p3fe612fb_6_1 : 0.0F;
      float $$4 = Math.abs(p3fe612fb_5_0) + Math.max($$2, 1.0E-6F);
      if (p3fe612fb_5_0 < 0.0F) {
         float $$5 = $$3;
         $$3 = $$4;
         $$4 = $$5;
      }

      return GivensParameters.fromUnnormalized($$3, $$4);
   }

   private static void similarityTransform(Matrix3f p3fe612fb_7_0, Matrix3f p3fe612fb_8_1) {
      p3fe612fb_7_0.mul(p3fe612fb_8_1);
      p3fe612fb_8_1.transpose();
      p3fe612fb_8_1.mul(p3fe612fb_7_0);
      p3fe612fb_7_0.set(p3fe612fb_8_1);
   }

   private static void stepJacobi(Matrix3f p3fe612fb_9_0, Matrix3f p3fe612fb_10_1, Quaternionf p3fe612fb_11_2, Quaternionf p3fe612fb_12_3) {
      if (p3fe612fb_9_0.m01 * p3fe612fb_9_0.m01 + p3fe612fb_9_0.m10 * p3fe612fb_9_0.m10 > 1.0E-6F) {
         GivensParameters $$4 = approxGivensQuat(p3fe612fb_9_0.m00, 0.5F * (p3fe612fb_9_0.m01 + p3fe612fb_9_0.m10), p3fe612fb_9_0.m11);
         Quaternionf $$5 = $$4.aroundZ(p3fe612fb_11_2);
         p3fe612fb_12_3.mul($$5);
         $$4.aroundZ(p3fe612fb_10_1);
         similarityTransform(p3fe612fb_9_0, p3fe612fb_10_1);
      }

      if (p3fe612fb_9_0.m02 * p3fe612fb_9_0.m02 + p3fe612fb_9_0.m20 * p3fe612fb_9_0.m20 > 1.0E-6F) {
         GivensParameters $$6 = approxGivensQuat(p3fe612fb_9_0.m00, 0.5F * (p3fe612fb_9_0.m02 + p3fe612fb_9_0.m20), p3fe612fb_9_0.m22).inverse();
         Quaternionf $$7 = $$6.aroundY(p3fe612fb_11_2);
         p3fe612fb_12_3.mul($$7);
         $$6.aroundY(p3fe612fb_10_1);
         similarityTransform(p3fe612fb_9_0, p3fe612fb_10_1);
      }

      if (p3fe612fb_9_0.m12 * p3fe612fb_9_0.m12 + p3fe612fb_9_0.m21 * p3fe612fb_9_0.m21 > 1.0E-6F) {
         GivensParameters $$8 = approxGivensQuat(p3fe612fb_9_0.m11, 0.5F * (p3fe612fb_9_0.m12 + p3fe612fb_9_0.m21), p3fe612fb_9_0.m22);
         Quaternionf $$9 = $$8.aroundX(p3fe612fb_11_2);
         p3fe612fb_12_3.mul($$9);
         $$8.aroundX(p3fe612fb_10_1);
         similarityTransform(p3fe612fb_9_0, p3fe612fb_10_1);
      }
   }

   public static Quaternionf eigenvalueJacobi(Matrix3f p3fe612fb_13_0, int p3fe612fb_14_1) {
      Quaternionf $$2 = new Quaternionf();
      Matrix3f $$3 = new Matrix3f();
      Quaternionf $$4 = new Quaternionf();

      for (int $$5 = 0; $$5 < p3fe612fb_14_1; $$5++) {
         stepJacobi(p3fe612fb_13_0, $$3, $$4, $$2);
      }

      $$2.normalize();
      return $$2;
   }

   public static Triple<Quaternionf, Vector3f, Quaternionf> svdDecompose(Matrix3f p3fe612fb_15_0) {
      Matrix3f $$1 = new Matrix3f(p3fe612fb_15_0);
      $$1.transpose();
      $$1.mul(p3fe612fb_15_0);
      Quaternionf $$2 = eigenvalueJacobi($$1, 5);
      float $$3 = $$1.m00;
      float $$4 = $$1.m11;
      boolean $$5 = $$3 < 1.0E-6;
      boolean $$6 = $$4 < 1.0E-6;
      Matrix3f $$7 = $$1;
      Matrix3f $$8 = p3fe612fb_15_0.rotate($$2);
      Quaternionf $$9 = new Quaternionf();
      Quaternionf $$10 = new Quaternionf();
      GivensParameters $$11;
      if ($$5) {
         $$11 = qrGivensQuat($$8.m11, -$$8.m10);
      } else {
         $$11 = qrGivensQuat($$8.m00, $$8.m01);
      }

      Quaternionf $$13 = $$11.aroundZ($$10);
      Matrix3f $$14 = $$11.aroundZ($$7);
      $$9.mul($$13);
      $$14.transpose().mul($$8);
      $$7 = $$8;
      if ($$5) {
         $$11 = qrGivensQuat($$14.m22, -$$14.m20);
      } else {
         $$11 = qrGivensQuat($$14.m00, $$14.m02);
      }

      $$11 = $$11.inverse();
      Quaternionf $$15 = $$11.aroundY($$10);
      Matrix3f $$16 = $$11.aroundY($$7);
      $$9.mul($$15);
      $$16.transpose().mul($$14);
      $$7 = $$14;
      if ($$6) {
         $$11 = qrGivensQuat($$16.m22, -$$16.m21);
      } else {
         $$11 = qrGivensQuat($$16.m11, $$16.m12);
      }

      Quaternionf $$17 = $$11.aroundX($$10);
      Matrix3f $$18 = $$11.aroundX($$7);
      $$9.mul($$17);
      $$18.transpose().mul($$16);
      Vector3f $$19 = new Vector3f($$18.m00, $$18.m11, $$18.m22);
      return Triple.of($$9, $$19, $$2.conjugate());
   }

   private static boolean checkPropertyRaw(Matrix4fc p3fe612fb_16_0, int p3fe612fb_17_1) {
      return (p3fe612fb_16_0.properties() & p3fe612fb_17_1) != 0;
   }

   public static boolean checkProperty(Matrix4fc p3fe612fb_18_0, int p3fe612fb_19_1) {
      if (checkPropertyRaw(p3fe612fb_18_0, p3fe612fb_19_1)) {
         return true;
      } else if (p3fe612fb_18_0 instanceof Matrix4f $$2) {
         $$2.determineProperties();
         return checkPropertyRaw(p3fe612fb_18_0, p3fe612fb_19_1);
      } else {
         return false;
      }
   }

   public static boolean isIdentity(Matrix4fc p3fe612fb_20_0) {
      return checkProperty(p3fe612fb_20_0, 4);
   }

   public static boolean isPureTranslation(Matrix4fc p3fe612fb_21_0) {
      return checkProperty(p3fe612fb_21_0, 8);
   }

   public static boolean isOrthonormal(Matrix4fc p3fe612fb_22_0) {
      return checkProperty(p3fe612fb_22_0, 16);
   }
}
