package com.mojang.math;

import com.google.gson.JsonParseException;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import net.minecraft.util.Mth;

public enum Quadrant {
   R0(0, OctahedralGroup.IDENTITY, OctahedralGroup.IDENTITY, OctahedralGroup.IDENTITY),
   R90(1, OctahedralGroup.BLOCK_ROT_X_90, OctahedralGroup.BLOCK_ROT_Y_90, OctahedralGroup.BLOCK_ROT_Z_90),
   R180(2, OctahedralGroup.BLOCK_ROT_X_180, OctahedralGroup.BLOCK_ROT_Y_180, OctahedralGroup.BLOCK_ROT_Z_180),
   R270(3, OctahedralGroup.BLOCK_ROT_X_270, OctahedralGroup.BLOCK_ROT_Y_270, OctahedralGroup.BLOCK_ROT_Z_270);

   public static final Codec<Quadrant> CODEC = Codec.INT.comapFlatMap(pa1315794_15_0 -> {
      return switch (Mth.positiveModulo(pa1315794_15_0, 360)) {
         case 0 -> DataResult.success(R0);
         case 90 -> DataResult.success(R90);
         case 180 -> DataResult.success(R180);
         case 270 -> DataResult.success(R270);
         default -> DataResult.error(() -> "Invalid rotation " + pa1315794_15_0 + " found, only 0/90/180/270 allowed");
      };
   }, pa1315794_14_0 -> {
      return switch (pa1315794_14_0) {
         case R0 -> 0;
         case R90 -> 90;
         case R180 -> 180;
         case R270 -> 270;
      };
   });
   public final int shift;
   public final OctahedralGroup rotationX;
   public final OctahedralGroup rotationY;
   public final OctahedralGroup rotationZ;

   Quadrant(final int pa1315794_3_2, final OctahedralGroup pa1315794_4_3, final OctahedralGroup pa1315794_5_4, final OctahedralGroup pa1315794_6_5) {
      this.shift = pa1315794_3_2;
      this.rotationX = pa1315794_4_3;
      this.rotationY = pa1315794_5_4;
      this.rotationZ = pa1315794_6_5;
   }

   @Deprecated
   public static Quadrant parseJson(int pa1315794_7_0) {
      return switch (Mth.positiveModulo(pa1315794_7_0, 360)) {
         case 0 -> R0;
         case 90 -> R90;
         case 180 -> R180;
         case 270 -> R270;
         default -> throw new JsonParseException("Invalid rotation " + pa1315794_7_0 + " found, only 0/90/180/270 allowed");
      };
   }

   public static OctahedralGroup fromXYAngles(Quadrant pa1315794_8_0, Quadrant pa1315794_9_1) {
      return pa1315794_9_1.rotationY.compose(pa1315794_8_0.rotationX);
   }

   public static OctahedralGroup fromXYZAngles(Quadrant pa1315794_10_0, Quadrant pa1315794_11_1, Quadrant pa1315794_12_2) {
      return pa1315794_12_2.rotationZ.compose(pa1315794_11_1.rotationY.compose(pa1315794_10_0.rotationX));
   }

   public int rotateVertexIndex(int pa1315794_13_0) {
      return (pa1315794_13_0 + this.shift) % 4;
   }
}
