package com.mojang.math;

import org.joml.Quaternionf;
import org.joml.Vector3f;

@FunctionalInterface
public interface Axis {
   Axis XN = p62475939_9_0 -> new Quaternionf().rotationX(-p62475939_9_0);
   Axis XP = p62475939_8_0 -> new Quaternionf().rotationX(p62475939_8_0);
   Axis YN = p62475939_7_0 -> new Quaternionf().rotationY(-p62475939_7_0);
   Axis YP = p62475939_6_0 -> new Quaternionf().rotationY(p62475939_6_0);
   Axis ZN = p62475939_5_0 -> new Quaternionf().rotationZ(-p62475939_5_0);
   Axis ZP = p62475939_4_0 -> new Quaternionf().rotationZ(p62475939_4_0);

   static Axis of(Vector3f p62475939_0_0) {
      return p62475939_3_1 -> new Quaternionf().rotationAxis(p62475939_3_1, p62475939_0_0);
   }

   Quaternionf rotation(float var1);

   default Quaternionf rotationDegrees(float p62475939_1_0) {
      return this.rotation(p62475939_1_0 * (float) (Math.PI / 180.0));
   }
}
