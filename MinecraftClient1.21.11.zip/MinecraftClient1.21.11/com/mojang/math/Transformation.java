package com.mojang.math;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Objects;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.Util;
import org.apache.commons.lang3.tuple.Triple;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.jspecify.annotations.Nullable;

public final class Transformation {
   private final Matrix4fc matrix;
   public static final Codec<Transformation> CODEC = RecordCodecBuilder.create(
      p4def66a1_13_0 -> p4def66a1_13_0.group(
            ExtraCodecs.VECTOR3F.fieldOf("translation").forGetter(p4def66a1_17_0 -> p4def66a1_17_0.translation),
            ExtraCodecs.QUATERNIONF.fieldOf("left_rotation").forGetter(p4def66a1_16_0 -> p4def66a1_16_0.leftRotation),
            ExtraCodecs.VECTOR3F.fieldOf("scale").forGetter(p4def66a1_15_0 -> p4def66a1_15_0.scale),
            ExtraCodecs.QUATERNIONF.fieldOf("right_rotation").forGetter(p4def66a1_14_0 -> p4def66a1_14_0.rightRotation)
         )
         .apply(p4def66a1_13_0, Transformation::new)
   );
   public static final Codec<Transformation> EXTENDED_CODEC = Codec.withAlternative(
      CODEC, ExtraCodecs.MATRIX4F.xmap(Transformation::new, Transformation::getMatrix)
   );
   private boolean decomposed;
   private @Nullable Vector3fc translation;
   private @Nullable Quaternionfc leftRotation;
   private @Nullable Vector3fc scale;
   private @Nullable Quaternionfc rightRotation;
   private static final Transformation IDENTITY = Util.make(() -> {
      Transformation $$0 = new Transformation(new Matrix4f());
      $$0.translation = new Vector3f();
      $$0.leftRotation = new Quaternionf();
      $$0.scale = new Vector3f(1.0F, 1.0F, 1.0F);
      $$0.rightRotation = new Quaternionf();
      $$0.decomposed = true;
      return $$0;
   });

   public Transformation(@Nullable Matrix4fc p4def66a1_0_0) {
      if (p4def66a1_0_0 == null) {
         this.matrix = new Matrix4f();
      } else {
         this.matrix = p4def66a1_0_0;
      }
   }

   public Transformation(
      @Nullable Vector3fc p4def66a1_1_0, @Nullable Quaternionfc p4def66a1_2_1, @Nullable Vector3fc p4def66a1_3_2, @Nullable Quaternionfc p4def66a1_4_3
   ) {
      this.matrix = compose(p4def66a1_1_0, p4def66a1_2_1, p4def66a1_3_2, p4def66a1_4_3);
      this.translation = p4def66a1_1_0 != null ? p4def66a1_1_0 : new Vector3f();
      this.leftRotation = p4def66a1_2_1 != null ? p4def66a1_2_1 : new Quaternionf();
      this.scale = p4def66a1_3_2 != null ? p4def66a1_3_2 : new Vector3f(1.0F, 1.0F, 1.0F);
      this.rightRotation = p4def66a1_4_3 != null ? p4def66a1_4_3 : new Quaternionf();
      this.decomposed = true;
   }

   public static Transformation identity() {
      return IDENTITY;
   }

   public Transformation compose(Transformation p4def66a1_5_0) {
      Matrix4f $$1 = this.getMatrixCopy();
      $$1.mul(p4def66a1_5_0.getMatrix());
      return new Transformation($$1);
   }

   public @Nullable Transformation inverse() {
      if (this == IDENTITY) {
         return this;
      }

      Matrix4f $$0 = this.getMatrixCopy().invertAffine();
      return $$0.isFinite() ? new Transformation($$0) : null;
   }

   private void ensureDecomposed() {
      if (!this.decomposed) {
         float $$0 = 1.0F / this.matrix.m33();
         Triple<Quaternionf, Vector3f, Quaternionf> $$1 = MatrixUtil.svdDecompose(new Matrix3f(this.matrix).scale($$0));
         this.translation = this.matrix.getTranslation(new Vector3f()).mul($$0);
         this.leftRotation = new Quaternionf($$1.getLeft());
         this.scale = new Vector3f($$1.getMiddle());
         this.rightRotation = new Quaternionf($$1.getRight());
         this.decomposed = true;
      }
   }

   private static Matrix4f compose(
      @Nullable Vector3fc p4def66a1_6_0, @Nullable Quaternionfc p4def66a1_7_1, @Nullable Vector3fc p4def66a1_8_2, @Nullable Quaternionfc p4def66a1_9_3
   ) {
      Matrix4f $$4 = new Matrix4f();
      if (p4def66a1_6_0 != null) {
         $$4.translation(p4def66a1_6_0);
      }

      if (p4def66a1_7_1 != null) {
         $$4.rotate(p4def66a1_7_1);
      }

      if (p4def66a1_8_2 != null) {
         $$4.scale(p4def66a1_8_2);
      }

      if (p4def66a1_9_3 != null) {
         $$4.rotate(p4def66a1_9_3);
      }

      return $$4;
   }

   public Matrix4fc getMatrix() {
      return this.matrix;
   }

   public Matrix4f getMatrixCopy() {
      return new Matrix4f(this.matrix);
   }

   public Vector3fc getTranslation() {
      this.ensureDecomposed();
      return this.translation;
   }

   public Quaternionfc getLeftRotation() {
      this.ensureDecomposed();
      return this.leftRotation;
   }

   public Vector3fc getScale() {
      this.ensureDecomposed();
      return this.scale;
   }

   public Quaternionfc getRightRotation() {
      this.ensureDecomposed();
      return this.rightRotation;
   }

   @Override
   public boolean equals(Object p4def66a1_10_0) {
      if (this == p4def66a1_10_0) {
         return true;
      } else if (p4def66a1_10_0 != null && this.getClass() == p4def66a1_10_0.getClass()) {
         Transformation $$1 = (Transformation)p4def66a1_10_0;
         return Objects.equals(this.matrix, $$1.matrix);
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.matrix);
   }

   public Transformation slerp(Transformation p4def66a1_11_0, float p4def66a1_12_1) {
      return new Transformation(
         this.getTranslation().lerp(p4def66a1_11_0.getTranslation(), p4def66a1_12_1, new Vector3f()),
         this.getLeftRotation().slerp(p4def66a1_11_0.getLeftRotation(), p4def66a1_12_1, new Quaternionf()),
         this.getScale().lerp(p4def66a1_11_0.getScale(), p4def66a1_12_1, new Vector3f()),
         this.getRightRotation().slerp(p4def66a1_11_0.getRightRotation(), p4def66a1_12_1, new Quaternionf())
      );
   }
}
