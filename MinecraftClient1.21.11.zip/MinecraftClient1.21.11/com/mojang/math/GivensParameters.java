package com.mojang.math;

import org.joml.Math;
import org.joml.Matrix3f;
import org.joml.Quaternionf;

public record GivensParameters(float sinHalf, float cosHalf) {
   public static GivensParameters fromUnnormalized(float pe1a20b8_2_0, float pe1a20b8_3_1) {
      float $$2 = Math.invsqrt(pe1a20b8_2_0 * pe1a20b8_2_0 + pe1a20b8_3_1 * pe1a20b8_3_1);
      return new GivensParameters($$2 * pe1a20b8_2_0, $$2 * pe1a20b8_3_1);
   }

   public static GivensParameters fromPositiveAngle(float pe1a20b8_4_0) {
      float $$1 = Math.sin(pe1a20b8_4_0 / 2.0F);
      float $$2 = Math.cosFromSin($$1, pe1a20b8_4_0 / 2.0F);
      return new GivensParameters($$1, $$2);
   }

   public GivensParameters inverse() {
      return new GivensParameters(-this.sinHalf, this.cosHalf);
   }

   public Quaternionf aroundX(Quaternionf pe1a20b8_5_0) {
      return pe1a20b8_5_0.set(this.sinHalf, 0.0F, 0.0F, this.cosHalf);
   }

   public Quaternionf aroundY(Quaternionf pe1a20b8_6_0) {
      return pe1a20b8_6_0.set(0.0F, this.sinHalf, 0.0F, this.cosHalf);
   }

   public Quaternionf aroundZ(Quaternionf pe1a20b8_7_0) {
      return pe1a20b8_7_0.set(0.0F, 0.0F, this.sinHalf, this.cosHalf);
   }

   public float cos() {
      return this.cosHalf * this.cosHalf - this.sinHalf * this.sinHalf;
   }

   public float sin() {
      return 2.0F * this.sinHalf * this.cosHalf;
   }

   public Matrix3f aroundX(Matrix3f pe1a20b8_8_0) {
      pe1a20b8_8_0.m01 = 0.0F;
      pe1a20b8_8_0.m02 = 0.0F;
      pe1a20b8_8_0.m10 = 0.0F;
      pe1a20b8_8_0.m20 = 0.0F;
      float $$1 = this.cos();
      float $$2 = this.sin();
      pe1a20b8_8_0.m11 = $$1;
      pe1a20b8_8_0.m22 = $$1;
      pe1a20b8_8_0.m12 = $$2;
      pe1a20b8_8_0.m21 = -$$2;
      pe1a20b8_8_0.m00 = 1.0F;
      return pe1a20b8_8_0;
   }

   public Matrix3f aroundY(Matrix3f pe1a20b8_9_0) {
      pe1a20b8_9_0.m01 = 0.0F;
      pe1a20b8_9_0.m10 = 0.0F;
      pe1a20b8_9_0.m12 = 0.0F;
      pe1a20b8_9_0.m21 = 0.0F;
      float $$1 = this.cos();
      float $$2 = this.sin();
      pe1a20b8_9_0.m00 = $$1;
      pe1a20b8_9_0.m22 = $$1;
      pe1a20b8_9_0.m02 = -$$2;
      pe1a20b8_9_0.m20 = $$2;
      pe1a20b8_9_0.m11 = 1.0F;
      return pe1a20b8_9_0;
   }

   public Matrix3f aroundZ(Matrix3f pe1a20b8_10_0) {
      pe1a20b8_10_0.m02 = 0.0F;
      pe1a20b8_10_0.m12 = 0.0F;
      pe1a20b8_10_0.m20 = 0.0F;
      pe1a20b8_10_0.m21 = 0.0F;
      float $$1 = this.cos();
      float $$2 = this.sin();
      pe1a20b8_10_0.m00 = $$1;
      pe1a20b8_10_0.m11 = $$1;
      pe1a20b8_10_0.m01 = $$2;
      pe1a20b8_10_0.m10 = -$$2;
      pe1a20b8_10_0.m22 = 1.0F;
      return pe1a20b8_10_0;
   }
}
