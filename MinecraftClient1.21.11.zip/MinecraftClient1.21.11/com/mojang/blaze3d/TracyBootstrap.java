package com.mojang.blaze3d;

import com.mojang.jtracy.TracyClient;
import com.mojang.logging.LogListeners;
import org.slf4j.event.Level;

public class TracyBootstrap {
   private static boolean setup;

   public static void setup() {
      if (!setup) {
         TracyClient.load();
         if (TracyClient.isAvailable()) {
            LogListeners.addListener("Tracy", (p1b4b7ac0_1_0, p1b4b7ac0_2_1) -> TracyClient.message(p1b4b7ac0_1_0, messageColor(p1b4b7ac0_2_1)));
            setup = true;
         }
      }
   }

   private static int messageColor(Level p1b4b7ac0_0_0) {
      return switch (p1b4b7ac0_0_0) {
         case DEBUG -> 11184810;
         case WARN -> 16777130;
         case ERROR -> 16755370;
         default -> 16777215;
      };
   }
}
