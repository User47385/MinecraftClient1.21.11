package com.mojang.blaze3d.vertex;

import org.joml.Vector3f;
import org.joml.Vector3fc;

public class CompactVectorArray {
   private final float[] contents;

   public CompactVectorArray(int p6d423bb3_0_0) {
      this.contents = new float[3 * p6d423bb3_0_0];
   }

   public int size() {
      return this.contents.length / 3;
   }

   public void set(int p6d423bb3_1_0, Vector3fc p6d423bb3_2_1) {
      this.set(p6d423bb3_1_0, p6d423bb3_2_1.x(), p6d423bb3_2_1.y(), p6d423bb3_2_1.z());
   }

   public void set(int p6d423bb3_3_0, float p6d423bb3_4_1, float p6d423bb3_5_2, float p6d423bb3_6_3) {
      this.contents[3 * p6d423bb3_3_0 + 0] = p6d423bb3_4_1;
      this.contents[3 * p6d423bb3_3_0 + 1] = p6d423bb3_5_2;
      this.contents[3 * p6d423bb3_3_0 + 2] = p6d423bb3_6_3;
   }

   public Vector3f get(int p6d423bb3_7_0, Vector3f p6d423bb3_8_1) {
      return p6d423bb3_8_1.set(this.contents[3 * p6d423bb3_7_0 + 0], this.contents[3 * p6d423bb3_7_0 + 1], this.contents[3 * p6d423bb3_7_0 + 2]);
   }

   public float getX(int p6d423bb3_9_0) {
      return this.contents[3 * p6d423bb3_9_0 + 0];
   }

   public float getY(int p6d423bb3_10_0) {
      return this.contents[3 * p6d423bb3_10_0 + 1];
   }

   public float getZ(int p6d423bb3_11_0) {
      return this.contents[3 * p6d423bb3_11_0 + 1];
   }
}
