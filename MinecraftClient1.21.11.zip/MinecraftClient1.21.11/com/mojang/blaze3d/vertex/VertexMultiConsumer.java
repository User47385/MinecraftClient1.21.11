package com.mojang.blaze3d.vertex;

import java.util.function.Consumer;

public class VertexMultiConsumer {
   public static VertexConsumer create() {
      throw new IllegalArgumentException();
   }

   public static VertexConsumer create(VertexConsumer p31609d0b_0_0) {
      return p31609d0b_0_0;
   }

   public static VertexConsumer create(VertexConsumer p31609d0b_1_0, VertexConsumer p31609d0b_2_1) {
      return new VertexMultiConsumer.Double(p31609d0b_1_0, p31609d0b_2_1);
   }

   public static VertexConsumer create(VertexConsumer... p31609d0b_3_0) {
      return new VertexMultiConsumer.Multiple(p31609d0b_3_0);
   }

   static class Double implements VertexConsumer {
      private final VertexConsumer first;
      private final VertexConsumer second;

      public Double(VertexConsumer pfc8e6daa_0_0, VertexConsumer pfc8e6daa_1_1) {
         if (pfc8e6daa_0_0 == pfc8e6daa_1_1) {
            throw new IllegalArgumentException("Duplicate delegates");
         }

         this.first = pfc8e6daa_0_0;
         this.second = pfc8e6daa_1_1;
      }

      @Override
      public VertexConsumer addVertex(float pfc8e6daa_2_0, float pfc8e6daa_3_1, float pfc8e6daa_4_2) {
         this.first.addVertex(pfc8e6daa_2_0, pfc8e6daa_3_1, pfc8e6daa_4_2);
         this.second.addVertex(pfc8e6daa_2_0, pfc8e6daa_3_1, pfc8e6daa_4_2);
         return this;
      }

      @Override
      public VertexConsumer setColor(int pfc8e6daa_5_0, int pfc8e6daa_6_1, int pfc8e6daa_7_2, int pfc8e6daa_8_3) {
         this.first.setColor(pfc8e6daa_5_0, pfc8e6daa_6_1, pfc8e6daa_7_2, pfc8e6daa_8_3);
         this.second.setColor(pfc8e6daa_5_0, pfc8e6daa_6_1, pfc8e6daa_7_2, pfc8e6daa_8_3);
         return this;
      }

      @Override
      public VertexConsumer setColor(int pfc8e6daa_9_0) {
         this.first.setColor(pfc8e6daa_9_0);
         this.second.setColor(pfc8e6daa_9_0);
         return this;
      }

      @Override
      public VertexConsumer setUv(float pfc8e6daa_10_0, float pfc8e6daa_11_1) {
         this.first.setUv(pfc8e6daa_10_0, pfc8e6daa_11_1);
         this.second.setUv(pfc8e6daa_10_0, pfc8e6daa_11_1);
         return this;
      }

      @Override
      public VertexConsumer setUv1(int pfc8e6daa_12_0, int pfc8e6daa_13_1) {
         this.first.setUv1(pfc8e6daa_12_0, pfc8e6daa_13_1);
         this.second.setUv1(pfc8e6daa_12_0, pfc8e6daa_13_1);
         return this;
      }

      @Override
      public VertexConsumer setUv2(int pfc8e6daa_14_0, int pfc8e6daa_15_1) {
         this.first.setUv2(pfc8e6daa_14_0, pfc8e6daa_15_1);
         this.second.setUv2(pfc8e6daa_14_0, pfc8e6daa_15_1);
         return this;
      }

      @Override
      public VertexConsumer setNormal(float pfc8e6daa_16_0, float pfc8e6daa_17_1, float pfc8e6daa_18_2) {
         this.first.setNormal(pfc8e6daa_16_0, pfc8e6daa_17_1, pfc8e6daa_18_2);
         this.second.setNormal(pfc8e6daa_16_0, pfc8e6daa_17_1, pfc8e6daa_18_2);
         return this;
      }

      @Override
      public VertexConsumer setLineWidth(float pfc8e6daa_19_0) {
         this.first.setLineWidth(pfc8e6daa_19_0);
         this.second.setLineWidth(pfc8e6daa_19_0);
         return this;
      }

      @Override
      public void addVertex(
         float pfc8e6daa_20_0,
         float pfc8e6daa_21_1,
         float pfc8e6daa_22_2,
         int pfc8e6daa_23_3,
         float pfc8e6daa_24_4,
         float pfc8e6daa_25_5,
         int pfc8e6daa_26_6,
         int pfc8e6daa_27_7,
         float pfc8e6daa_28_8,
         float pfc8e6daa_29_9,
         float pfc8e6daa_30_10
      ) {
         this.first
            .addVertex(
               pfc8e6daa_20_0,
               pfc8e6daa_21_1,
               pfc8e6daa_22_2,
               pfc8e6daa_23_3,
               pfc8e6daa_24_4,
               pfc8e6daa_25_5,
               pfc8e6daa_26_6,
               pfc8e6daa_27_7,
               pfc8e6daa_28_8,
               pfc8e6daa_29_9,
               pfc8e6daa_30_10
            );
         this.second
            .addVertex(
               pfc8e6daa_20_0,
               pfc8e6daa_21_1,
               pfc8e6daa_22_2,
               pfc8e6daa_23_3,
               pfc8e6daa_24_4,
               pfc8e6daa_25_5,
               pfc8e6daa_26_6,
               pfc8e6daa_27_7,
               pfc8e6daa_28_8,
               pfc8e6daa_29_9,
               pfc8e6daa_30_10
            );
      }
   }

   record Multiple(VertexConsumer[] delegates) implements VertexConsumer {
      Multiple(VertexConsumer[] delegates) {
         for (int $$1 = 0; $$1 < delegates.length; $$1++) {
            for (int $$2 = $$1 + 1; $$2 < delegates.length; $$2++) {
               if (delegates[$$1] == delegates[$$2]) {
                  throw new IllegalArgumentException("Duplicate delegates");
               }
            }
         }

         this.delegates = delegates;
      }

      private void forEach(Consumer<VertexConsumer> pe89a85a9_1_0) {
         for (VertexConsumer $$1 : this.delegates) {
            pe89a85a9_1_0.accept($$1);
         }
      }

      @Override
      public VertexConsumer addVertex(float pe89a85a9_2_0, float pe89a85a9_3_1, float pe89a85a9_4_2) {
         this.forEach(pe89a85a9_69_3 -> pe89a85a9_69_3.addVertex(pe89a85a9_2_0, pe89a85a9_3_1, pe89a85a9_4_2));
         return this;
      }

      @Override
      public VertexConsumer setColor(int pe89a85a9_5_0, int pe89a85a9_6_1, int pe89a85a9_7_2, int pe89a85a9_8_3) {
         this.forEach(pe89a85a9_65_4 -> pe89a85a9_65_4.setColor(pe89a85a9_5_0, pe89a85a9_6_1, pe89a85a9_7_2, pe89a85a9_8_3));
         return this;
      }

      @Override
      public VertexConsumer setColor(int pe89a85a9_9_0) {
         this.forEach(pe89a85a9_60_1 -> pe89a85a9_60_1.setColor(pe89a85a9_9_0));
         return this;
      }

      @Override
      public VertexConsumer setUv(float pe89a85a9_10_0, float pe89a85a9_11_1) {
         this.forEach(pe89a85a9_58_2 -> pe89a85a9_58_2.setUv(pe89a85a9_10_0, pe89a85a9_11_1));
         return this;
      }

      @Override
      public VertexConsumer setUv1(int pe89a85a9_12_0, int pe89a85a9_13_1) {
         this.forEach(pe89a85a9_55_2 -> pe89a85a9_55_2.setUv1(pe89a85a9_12_0, pe89a85a9_13_1));
         return this;
      }

      @Override
      public VertexConsumer setUv2(int pe89a85a9_14_0, int pe89a85a9_15_1) {
         this.forEach(pe89a85a9_52_2 -> pe89a85a9_52_2.setUv2(pe89a85a9_14_0, pe89a85a9_15_1));
         return this;
      }

      @Override
      public VertexConsumer setNormal(float pe89a85a9_16_0, float pe89a85a9_17_1, float pe89a85a9_18_2) {
         this.forEach(pe89a85a9_49_3 -> pe89a85a9_49_3.setNormal(pe89a85a9_16_0, pe89a85a9_17_1, pe89a85a9_18_2));
         return this;
      }

      @Override
      public VertexConsumer setLineWidth(float pe89a85a9_19_0) {
         this.forEach(pe89a85a9_45_1 -> pe89a85a9_45_1.setLineWidth(pe89a85a9_19_0));
         return this;
      }

      @Override
      public void addVertex(
         float pe89a85a9_20_0,
         float pe89a85a9_21_1,
         float pe89a85a9_22_2,
         int pe89a85a9_23_3,
         float pe89a85a9_24_4,
         float pe89a85a9_25_5,
         int pe89a85a9_26_6,
         int pe89a85a9_27_7,
         float pe89a85a9_28_8,
         float pe89a85a9_29_9,
         float pe89a85a9_30_10
      ) {
         this.forEach(
            pe89a85a9_43_11 -> pe89a85a9_43_11.addVertex(
               pe89a85a9_20_0,
               pe89a85a9_21_1,
               pe89a85a9_22_2,
               pe89a85a9_23_3,
               pe89a85a9_24_4,
               pe89a85a9_25_5,
               pe89a85a9_26_6,
               pe89a85a9_27_7,
               pe89a85a9_28_8,
               pe89a85a9_29_9,
               pe89a85a9_30_10
            )
         );
      }
   }
}
