package com.mojang.blaze3d.vertex;

import com.mojang.jtracy.MemoryPool;
import com.mojang.jtracy.TracyClient;
import com.mojang.logging.LogUtils;
import java.nio.ByteBuffer;
import net.minecraft.util.Mth;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.system.MemoryUtil.MemoryAllocator;
import org.slf4j.Logger;

public class ByteBufferBuilder implements AutoCloseable {
   private static final MemoryPool MEMORY_POOL = TracyClient.createMemoryPool("ByteBufferBuilder");
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final MemoryAllocator ALLOCATOR = MemoryUtil.getAllocator(false);
   private static final long DEFAULT_MAX_CAPACITY = 4294967295L;
   private static final int MAX_GROWTH_SIZE = 2097152;
   private static final int BUFFER_FREED_GENERATION = -1;
   long pointer;
   private long capacity;
   private final long maxCapacity;
   private long writeOffset;
   private long nextResultOffset;
   private int resultCount;
   private int generation;

   public ByteBufferBuilder(int pef8e4713_0_0, long pef8e4713_1_1) {
      this.capacity = pef8e4713_0_0;
      this.maxCapacity = pef8e4713_1_1;
      this.pointer = ALLOCATOR.malloc(pef8e4713_0_0);
      MEMORY_POOL.malloc(this.pointer, pef8e4713_0_0);
      if (this.pointer == 0L) {
         throw new OutOfMemoryError("Failed to allocate " + pef8e4713_0_0 + " bytes");
      }
   }

   public ByteBufferBuilder(int pef8e4713_2_0) {
      this(pef8e4713_2_0, 4294967295L);
   }

   public static ByteBufferBuilder exactlySized(int pef8e4713_3_0) {
      return new ByteBufferBuilder(pef8e4713_3_0, pef8e4713_3_0);
   }

   public long reserve(int pef8e4713_4_0) {
      long $$1 = this.writeOffset;
      long $$2 = Math.addExact($$1, pef8e4713_4_0);
      this.ensureCapacity($$2);
      this.writeOffset = $$2;
      return Math.addExact(this.pointer, $$1);
   }

   private void ensureCapacity(long pef8e4713_5_0) {
      if (pef8e4713_5_0 > this.capacity) {
         if (pef8e4713_5_0 > this.maxCapacity) {
            throw new IllegalArgumentException("Maximum capacity of ByteBufferBuilder (" + this.maxCapacity + ") exceeded, required " + pef8e4713_5_0);
         }

         long $$1 = Math.min(this.capacity, 2097152L);
         long $$2 = Mth.clamp(this.capacity + $$1, pef8e4713_5_0, this.maxCapacity);
         this.resize($$2);
      }
   }

   private void resize(long pef8e4713_6_0) {
      MEMORY_POOL.free(this.pointer);
      this.pointer = ALLOCATOR.realloc(this.pointer, pef8e4713_6_0);
      MEMORY_POOL.malloc(this.pointer, (int)Math.min(pef8e4713_6_0, 2147483647L));
      LOGGER.debug("Needed to grow BufferBuilder buffer: Old size {} bytes, new size {} bytes.", this.capacity, pef8e4713_6_0);
      if (this.pointer == 0L) {
         throw new OutOfMemoryError("Failed to resize buffer from " + this.capacity + " bytes to " + pef8e4713_6_0 + " bytes");
      }

      this.capacity = pef8e4713_6_0;
   }

   public ByteBufferBuilder.@Nullable Result build() {
      this.checkOpen();
      long $$0 = this.nextResultOffset;
      long $$1 = this.writeOffset - $$0;
      if ($$1 == 0L) {
         return null;
      }

      if ($$1 > 2147483647L) {
         throw new IllegalStateException("Cannot build buffer larger than 2147483647 bytes (was " + $$1 + ")");
      }

      this.nextResultOffset = this.writeOffset;
      this.resultCount++;
      return new ByteBufferBuilder.Result($$0, (int)$$1, this.generation);
   }

   public void clear() {
      if (this.resultCount > 0) {
         LOGGER.warn("Clearing BufferBuilder with unused batches");
      }

      this.discard();
   }

   public void discard() {
      this.checkOpen();
      if (this.resultCount > 0) {
         this.discardResults();
         this.resultCount = 0;
      }
   }

   boolean isValid(int pef8e4713_7_0) {
      return pef8e4713_7_0 == this.generation;
   }

   void freeResult() {
      if (--this.resultCount <= 0) {
         this.discardResults();
      }
   }

   private void discardResults() {
      long $$0 = this.writeOffset - this.nextResultOffset;
      if ($$0 > 0L) {
         MemoryUtil.memCopy(this.pointer + this.nextResultOffset, this.pointer, $$0);
      }

      this.writeOffset = $$0;
      this.nextResultOffset = 0L;
      this.generation++;
   }

   @Override
   public void close() {
      if (this.pointer != 0L) {
         MEMORY_POOL.free(this.pointer);
         ALLOCATOR.free(this.pointer);
         this.pointer = 0L;
         this.generation = -1;
      }
   }

   private void checkOpen() {
      if (this.pointer == 0L) {
         throw new IllegalStateException("Buffer has been freed");
      }
   }

   public class Result implements AutoCloseable {
      private final long offset;
      private final int capacity;
      private final int generation;
      private boolean closed;

      Result(final long p3fed36ee_1_1, final int p3fed36ee_2_2, final int p3fed36ee_3_3) {
         this.offset = p3fed36ee_1_1;
         this.capacity = p3fed36ee_2_2;
         this.generation = p3fed36ee_3_3;
      }

      public ByteBuffer byteBuffer() {
         if (!ByteBufferBuilder.this.isValid(this.generation)) {
            throw new IllegalStateException("Buffer is no longer valid");
         } else {
            return MemoryUtil.memByteBuffer(ByteBufferBuilder.this.pointer + this.offset, this.capacity);
         }
      }

      @Override
      public void close() {
         if (!this.closed) {
            this.closed = true;
            if (ByteBufferBuilder.this.isValid(this.generation)) {
               ByteBufferBuilder.this.freeResult();
            }
         }
      }
   }
}
