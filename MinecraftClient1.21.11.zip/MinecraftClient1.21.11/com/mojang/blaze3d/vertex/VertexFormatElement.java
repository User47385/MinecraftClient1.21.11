package com.mojang.blaze3d.vertex;

import com.mojang.blaze3d.DontObfuscate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.jspecify.annotations.Nullable;

@DontObfuscate
public record VertexFormatElement(int id, int index, VertexFormatElement.Type type, VertexFormatElement.Usage usage, int count) {
   public static final int MAX_COUNT = 32;
   private static final @Nullable VertexFormatElement[] BY_ID = new VertexFormatElement[32];
   private static final List<VertexFormatElement> ELEMENTS = new ArrayList<>(32);
   public static final VertexFormatElement POSITION = register(0, 0, VertexFormatElement.Type.FLOAT, VertexFormatElement.Usage.POSITION, 3);
   public static final VertexFormatElement COLOR = register(1, 0, VertexFormatElement.Type.UBYTE, VertexFormatElement.Usage.COLOR, 4);
   public static final VertexFormatElement UV0 = register(2, 0, VertexFormatElement.Type.FLOAT, VertexFormatElement.Usage.UV, 2);
   public static final VertexFormatElement UV = UV0;
   public static final VertexFormatElement UV1 = register(3, 1, VertexFormatElement.Type.SHORT, VertexFormatElement.Usage.UV, 2);
   public static final VertexFormatElement UV2 = register(4, 2, VertexFormatElement.Type.SHORT, VertexFormatElement.Usage.UV, 2);
   public static final VertexFormatElement NORMAL = register(5, 0, VertexFormatElement.Type.BYTE, VertexFormatElement.Usage.NORMAL, 3);
   public static final VertexFormatElement LINE_WIDTH = register(6, 0, VertexFormatElement.Type.FLOAT, VertexFormatElement.Usage.GENERIC, 1);

   public VertexFormatElement {
      if (id < 0 || id >= BY_ID.length) {
         throw new IllegalArgumentException("Element ID must be in range [0; " + BY_ID.length + ")");
      }

      if (!this.supportsUsage(index, usage)) {
         throw new IllegalStateException("Multiple vertex elements of the same type other than UVs are not supported");
      }
   }

   public static VertexFormatElement register(
      int pdaf953c1_5_0, int pdaf953c1_6_1, VertexFormatElement.Type pdaf953c1_7_2, VertexFormatElement.Usage pdaf953c1_8_3, int pdaf953c1_9_4
   ) {
      VertexFormatElement $$5 = new VertexFormatElement(pdaf953c1_5_0, pdaf953c1_6_1, pdaf953c1_7_2, pdaf953c1_8_3, pdaf953c1_9_4);
      if (BY_ID[pdaf953c1_5_0] != null) {
         throw new IllegalArgumentException("Duplicate element registration for: " + pdaf953c1_5_0);
      }

      BY_ID[pdaf953c1_5_0] = $$5;
      ELEMENTS.add($$5);
      return $$5;
   }

   private boolean supportsUsage(int pdaf953c1_10_0, VertexFormatElement.Usage pdaf953c1_11_1) {
      return pdaf953c1_10_0 == 0 || pdaf953c1_11_1 == VertexFormatElement.Usage.UV;
   }

   @Override
   public String toString() {
      return this.count + "," + this.usage + "," + this.type + " (" + this.id + ")";
   }

   public int mask() {
      return 1 << this.id;
   }

   public int byteSize() {
      return this.type.size() * this.count;
   }

   public static @Nullable VertexFormatElement byId(int pdaf953c1_12_0) {
      return BY_ID[pdaf953c1_12_0];
   }

   public static Stream<VertexFormatElement> elementsFromMask(int pdaf953c1_13_0) {
      return ELEMENTS.stream().filter(pdaf953c1_16_1 -> (pdaf953c1_13_0 & pdaf953c1_16_1.mask()) != 0);
   }

   @DontObfuscate
   public enum Type {
      FLOAT(4, "Float"),
      UBYTE(1, "Unsigned Byte"),
      BYTE(1, "Byte"),
      USHORT(2, "Unsigned Short"),
      SHORT(2, "Short"),
      UINT(4, "Unsigned Int"),
      INT(4, "Int");

      private final int size;
      private final String name;

      Type(final int p65d2e5d_3_2, final String p65d2e5d_4_3) {
         this.size = p65d2e5d_3_2;
         this.name = p65d2e5d_4_3;
      }

      public int size() {
         return this.size;
      }

      @Override
      public String toString() {
         return this.name;
      }
   }

   @DontObfuscate
   public enum Usage {
      POSITION("Position"),
      NORMAL("Normal"),
      COLOR("Vertex Color"),
      UV("UV"),
      GENERIC("Generic");

      private final String name;

      Usage(final String pc553c2de_3_2) {
         this.name = pc553c2de_3_2;
      }

      @Override
      public String toString() {
         return this.name;
      }
   }
}
