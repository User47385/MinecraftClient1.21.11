package com.mojang.blaze3d.vertex;

import net.minecraft.client.model.geom.builders.UVPair;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.util.ARGB;
import org.joml.Matrix3x2fc;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public interface VertexConsumer {
   VertexConsumer addVertex(float var1, float var2, float var3);

   VertexConsumer setColor(int var1, int var2, int var3, int var4);

   VertexConsumer setColor(int var1);

   VertexConsumer setUv(float var1, float var2);

   VertexConsumer setUv1(int var1, int var2);

   VertexConsumer setUv2(int var1, int var2);

   VertexConsumer setNormal(float var1, float var2, float var3);

   VertexConsumer setLineWidth(float var1);

   default void addVertex(
      float p9c39d5ba_0_0,
      float p9c39d5ba_1_1,
      float p9c39d5ba_2_2,
      int p9c39d5ba_3_3,
      float p9c39d5ba_4_4,
      float p9c39d5ba_5_5,
      int p9c39d5ba_6_6,
      int p9c39d5ba_7_7,
      float p9c39d5ba_8_8,
      float p9c39d5ba_9_9,
      float p9c39d5ba_10_10
   ) {
      this.addVertex(p9c39d5ba_0_0, p9c39d5ba_1_1, p9c39d5ba_2_2);
      this.setColor(p9c39d5ba_3_3);
      this.setUv(p9c39d5ba_4_4, p9c39d5ba_5_5);
      this.setOverlay(p9c39d5ba_6_6);
      this.setLight(p9c39d5ba_7_7);
      this.setNormal(p9c39d5ba_8_8, p9c39d5ba_9_9, p9c39d5ba_10_10);
   }

   default VertexConsumer setColor(float p9c39d5ba_11_0, float p9c39d5ba_12_1, float p9c39d5ba_13_2, float p9c39d5ba_14_3) {
      return this.setColor((int)(p9c39d5ba_11_0 * 255.0F), (int)(p9c39d5ba_12_1 * 255.0F), (int)(p9c39d5ba_13_2 * 255.0F), (int)(p9c39d5ba_14_3 * 255.0F));
   }

   default VertexConsumer setLight(int p9c39d5ba_15_0) {
      return this.setUv2(p9c39d5ba_15_0 & 65535, p9c39d5ba_15_0 >> 16 & 65535);
   }

   default VertexConsumer setOverlay(int p9c39d5ba_16_0) {
      return this.setUv1(p9c39d5ba_16_0 & 65535, p9c39d5ba_16_0 >> 16 & 65535);
   }

   default void putBulkData(
      PoseStack.Pose p9c39d5ba_17_0,
      BakedQuad p9c39d5ba_18_1,
      float p9c39d5ba_19_2,
      float p9c39d5ba_20_3,
      float p9c39d5ba_21_4,
      float p9c39d5ba_22_5,
      int p9c39d5ba_23_6,
      int p9c39d5ba_24_7
   ) {
      this.putBulkData(
         p9c39d5ba_17_0,
         p9c39d5ba_18_1,
         new float[]{1.0F, 1.0F, 1.0F, 1.0F},
         p9c39d5ba_19_2,
         p9c39d5ba_20_3,
         p9c39d5ba_21_4,
         p9c39d5ba_22_5,
         new int[]{p9c39d5ba_23_6, p9c39d5ba_23_6, p9c39d5ba_23_6, p9c39d5ba_23_6},
         p9c39d5ba_24_7
      );
   }

   default void putBulkData(
      PoseStack.Pose p9c39d5ba_25_0,
      BakedQuad p9c39d5ba_26_1,
      float[] p9c39d5ba_27_2,
      float p9c39d5ba_28_3,
      float p9c39d5ba_29_4,
      float p9c39d5ba_30_5,
      float p9c39d5ba_31_6,
      int[] p9c39d5ba_32_7,
      int p9c39d5ba_33_8
   ) {
      Vector3fc $$9 = p9c39d5ba_26_1.direction().getUnitVec3f();
      Matrix4f $$10 = p9c39d5ba_25_0.pose();
      Vector3f $$11 = p9c39d5ba_25_0.transformNormal($$9, new Vector3f());
      int $$12 = p9c39d5ba_26_1.lightEmission();

      for (int $$13 = 0; $$13 < 4; $$13++) {
         Vector3fc $$14 = p9c39d5ba_26_1.position($$13);
         long $$15 = p9c39d5ba_26_1.packedUV($$13);
         float $$16 = p9c39d5ba_27_2[$$13];
         int $$17 = ARGB.colorFromFloat(p9c39d5ba_31_6, $$16 * p9c39d5ba_28_3, $$16 * p9c39d5ba_29_4, $$16 * p9c39d5ba_30_5);
         int $$18 = LightTexture.lightCoordsWithEmission(p9c39d5ba_32_7[$$13], $$12);
         Vector3f $$19 = $$10.transformPosition($$14, new Vector3f());
         float $$20 = UVPair.unpackU($$15);
         float $$21 = UVPair.unpackV($$15);
         this.addVertex($$19.x(), $$19.y(), $$19.z(), $$17, $$20, $$21, p9c39d5ba_33_8, $$18, $$11.x(), $$11.y(), $$11.z());
      }
   }

   default VertexConsumer addVertex(Vector3fc p9c39d5ba_34_0) {
      return this.addVertex(p9c39d5ba_34_0.x(), p9c39d5ba_34_0.y(), p9c39d5ba_34_0.z());
   }

   default VertexConsumer addVertex(PoseStack.Pose p9c39d5ba_35_0, Vector3f p9c39d5ba_36_1) {
      return this.addVertex(p9c39d5ba_35_0, p9c39d5ba_36_1.x(), p9c39d5ba_36_1.y(), p9c39d5ba_36_1.z());
   }

   default VertexConsumer addVertex(PoseStack.Pose p9c39d5ba_37_0, float p9c39d5ba_38_1, float p9c39d5ba_39_2, float p9c39d5ba_40_3) {
      return this.addVertex(p9c39d5ba_37_0.pose(), p9c39d5ba_38_1, p9c39d5ba_39_2, p9c39d5ba_40_3);
   }

   default VertexConsumer addVertex(Matrix4fc p9c39d5ba_41_0, float p9c39d5ba_42_1, float p9c39d5ba_43_2, float p9c39d5ba_44_3) {
      Vector3f $$4 = p9c39d5ba_41_0.transformPosition(p9c39d5ba_42_1, p9c39d5ba_43_2, p9c39d5ba_44_3, new Vector3f());
      return this.addVertex($$4.x(), $$4.y(), $$4.z());
   }

   default VertexConsumer addVertexWith2DPose(Matrix3x2fc p9c39d5ba_45_0, float p9c39d5ba_46_1, float p9c39d5ba_47_2) {
      Vector2f $$3 = p9c39d5ba_45_0.transformPosition(p9c39d5ba_46_1, p9c39d5ba_47_2, new Vector2f());
      return this.addVertex($$3.x(), $$3.y(), 0.0F);
   }

   default VertexConsumer setNormal(PoseStack.Pose p9c39d5ba_48_0, float p9c39d5ba_49_1, float p9c39d5ba_50_2, float p9c39d5ba_51_3) {
      Vector3f $$4 = p9c39d5ba_48_0.transformNormal(p9c39d5ba_49_1, p9c39d5ba_50_2, p9c39d5ba_51_3, new Vector3f());
      return this.setNormal($$4.x(), $$4.y(), $$4.z());
   }

   default VertexConsumer setNormal(PoseStack.Pose p9c39d5ba_52_0, Vector3f p9c39d5ba_53_1) {
      return this.setNormal(p9c39d5ba_52_0, p9c39d5ba_53_1.x(), p9c39d5ba_53_1.y(), p9c39d5ba_53_1.z());
   }
}
