package com.mojang.blaze3d.vertex;

import com.google.common.primitives.Floats;
import it.unimi.dsi.fastutil.ints.IntArrays;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public interface VertexSorting {
   VertexSorting DISTANCE_TO_ORIGIN = byDistance(0.0F, 0.0F, 0.0F);
   VertexSorting ORTHOGRAPHIC_Z = byDistance(p74aebb40_10_0 -> -p74aebb40_10_0.z());

   static VertexSorting byDistance(float p74aebb40_0_0, float p74aebb40_1_1, float p74aebb40_2_2) {
      return byDistance(new Vector3f(p74aebb40_0_0, p74aebb40_1_1, p74aebb40_2_2));
   }

   static VertexSorting byDistance(Vector3fc p74aebb40_3_0) {
      return byDistance(p74aebb40_3_0::distanceSquared);
   }

   static VertexSorting byDistance(VertexSorting.DistanceFunction p74aebb40_4_0) {
      return p74aebb40_6_1 -> {
         Vector3f $$2 = new Vector3f();
         float[] $$3 = new float[p74aebb40_6_1.size()];
         int[] $$4 = new int[p74aebb40_6_1.size()];

         for (int $$5 = 0; $$5 < p74aebb40_6_1.size(); $$4[$$5] = $$5++) {
            $$3[$$5] = p74aebb40_4_0.apply(p74aebb40_6_1.get($$5, $$2));
         }

         IntArrays.mergeSort($$4, (p74aebb40_8_1, p74aebb40_9_2) -> Floats.compare($$3[p74aebb40_9_2], $$3[p74aebb40_8_1]));
         return $$4;
      };
   }

   int[] sort(CompactVectorArray var1);

   @FunctionalInterface
   interface DistanceFunction {
      float apply(Vector3f var1);
   }
}
