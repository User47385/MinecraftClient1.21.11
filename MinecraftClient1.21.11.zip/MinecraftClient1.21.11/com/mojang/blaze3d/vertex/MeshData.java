package com.mojang.blaze3d.vertex;

import it.unimi.dsi.fastutil.ints.IntConsumer;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import org.apache.commons.lang3.mutable.MutableLong;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.MemoryUtil;

public class MeshData implements AutoCloseable {
   private final ByteBufferBuilder.Result vertexBuffer;
   private ByteBufferBuilder.@Nullable Result indexBuffer;
   private final MeshData.DrawState drawState;

   public MeshData(ByteBufferBuilder.Result pce4db37_0_0, MeshData.DrawState pce4db37_1_1) {
      this.vertexBuffer = pce4db37_0_0;
      this.drawState = pce4db37_1_1;
   }

   private static CompactVectorArray unpackQuadCentroids(ByteBuffer pce4db37_2_0, int pce4db37_3_1, VertexFormat pce4db37_4_2) {
      int $$3 = pce4db37_4_2.getOffset(VertexFormatElement.POSITION);
      if ($$3 == -1) {
         throw new IllegalArgumentException("Cannot identify quad centers with no position element");
      }

      FloatBuffer $$4 = pce4db37_2_0.asFloatBuffer();
      int $$5 = pce4db37_4_2.getVertexSize() / 4;
      int $$6 = $$5 * 4;
      int $$7 = pce4db37_3_1 / 4;
      CompactVectorArray $$8 = new CompactVectorArray($$7);

      for (int $$9 = 0; $$9 < $$7; $$9++) {
         int $$10 = $$9 * $$6 + $$3;
         int $$11 = $$10 + $$5 * 2;
         float $$12 = $$4.get($$10 + 0);
         float $$13 = $$4.get($$10 + 1);
         float $$14 = $$4.get($$10 + 2);
         float $$15 = $$4.get($$11 + 0);
         float $$16 = $$4.get($$11 + 1);
         float $$17 = $$4.get($$11 + 2);
         float $$18 = ($$12 + $$15) / 2.0F;
         float $$19 = ($$13 + $$16) / 2.0F;
         float $$20 = ($$14 + $$17) / 2.0F;
         $$8.set($$9, $$18, $$19, $$20);
      }

      return $$8;
   }

   public ByteBuffer vertexBuffer() {
      return this.vertexBuffer.byteBuffer();
   }

   public @Nullable ByteBuffer indexBuffer() {
      return this.indexBuffer != null ? this.indexBuffer.byteBuffer() : null;
   }

   public MeshData.DrawState drawState() {
      return this.drawState;
   }

   public MeshData.@Nullable SortState sortQuads(ByteBufferBuilder pce4db37_5_0, VertexSorting pce4db37_6_1) {
      if (this.drawState.mode() != VertexFormat.Mode.QUADS) {
         return null;
      }

      CompactVectorArray $$2 = unpackQuadCentroids(this.vertexBuffer.byteBuffer(), this.drawState.vertexCount(), this.drawState.format());
      MeshData.SortState $$3 = new MeshData.SortState($$2, this.drawState.indexType());
      this.indexBuffer = $$3.buildSortedIndexBuffer(pce4db37_5_0, pce4db37_6_1);
      return $$3;
   }

   @Override
   public void close() {
      this.vertexBuffer.close();
      if (this.indexBuffer != null) {
         this.indexBuffer.close();
      }
   }

   public record DrawState(VertexFormat format, int vertexCount, int indexCount, VertexFormat.Mode mode, VertexFormat.IndexType indexType) {
   }

   public record SortState(CompactVectorArray centroids, VertexFormat.IndexType indexType) {
      public ByteBufferBuilder.@Nullable Result buildSortedIndexBuffer(ByteBufferBuilder pb2583c46_2_0, VertexSorting pb2583c46_3_1) {
         int[] $$2 = pb2583c46_3_1.sort(this.centroids);
         long $$3 = pb2583c46_2_0.reserve($$2.length * 6 * this.indexType.bytes);
         IntConsumer $$4 = this.indexWriter($$3, this.indexType);

         for (int $$5 : $$2) {
            $$4.accept($$5 * 4 + 0);
            $$4.accept($$5 * 4 + 1);
            $$4.accept($$5 * 4 + 2);
            $$4.accept($$5 * 4 + 2);
            $$4.accept($$5 * 4 + 3);
            $$4.accept($$5 * 4 + 0);
         }

         return pb2583c46_2_0.build();
      }

      private IntConsumer indexWriter(long pb2583c46_4_0, VertexFormat.IndexType pb2583c46_5_1) {
         MutableLong $$2 = new MutableLong(pb2583c46_4_0);

         return switch (pb2583c46_5_1) {
            case SHORT -> pb2583c46_10_1 -> MemoryUtil.memPutShort($$2.getAndAdd(2L), (short)pb2583c46_10_1);
            case INT -> pb2583c46_8_1 -> MemoryUtil.memPutInt($$2.getAndAdd(4L), pb2583c46_8_1);
         };
      }
   }
}
