package com.mojang.blaze3d.vertex;

import org.jspecify.annotations.Nullable;

public class Tesselator {
   private static final int MAX_BYTES = 786432;
   private final ByteBufferBuilder buffer;
   private static @Nullable Tesselator instance;

   public static void init() {
      if (instance != null) {
         throw new IllegalStateException("Tesselator has already been initialized");
      }

      instance = new Tesselator();
   }

   public static Tesselator getInstance() {
      if (instance == null) {
         throw new IllegalStateException("Tesselator has not been initialized");
      } else {
         return instance;
      }
   }

   public Tesselator(int p93e42e4e_0_0) {
      this.buffer = new ByteBufferBuilder(p93e42e4e_0_0);
   }

   public Tesselator() {
      this(786432);
   }

   public BufferBuilder begin(VertexFormat.Mode p93e42e4e_1_0, VertexFormat p93e42e4e_2_1) {
      return new BufferBuilder(this.buffer, p93e42e4e_1_0, p93e42e4e_2_1);
   }

   public void clear() {
      this.buffer.clear();
   }
}
