package com.mojang.blaze3d.vertex;

import com.mojang.math.MatrixUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public class PoseStack {
   private final List<PoseStack.Pose> poses = new ArrayList<>(16);
   private int lastIndex;

   public PoseStack() {
      this.poses.add(new PoseStack.Pose());
   }

   public void translate(double p570ccc77_0_0, double p570ccc77_1_1, double p570ccc77_2_2) {
      this.translate((float)p570ccc77_0_0, (float)p570ccc77_1_1, (float)p570ccc77_2_2);
   }

   public void translate(float p570ccc77_3_0, float p570ccc77_4_1, float p570ccc77_5_2) {
      this.last().translate(p570ccc77_3_0, p570ccc77_4_1, p570ccc77_5_2);
   }

   public void translate(Vec3 p570ccc77_6_0) {
      this.translate(p570ccc77_6_0.x, p570ccc77_6_0.y, p570ccc77_6_0.z);
   }

   public void scale(float p570ccc77_7_0, float p570ccc77_8_1, float p570ccc77_9_2) {
      this.last().scale(p570ccc77_7_0, p570ccc77_8_1, p570ccc77_9_2);
   }

   public void mulPose(Quaternionfc p570ccc77_10_0) {
      this.last().rotate(p570ccc77_10_0);
   }

   public void rotateAround(Quaternionfc p570ccc77_11_0, float p570ccc77_12_1, float p570ccc77_13_2, float p570ccc77_14_3) {
      this.last().rotateAround(p570ccc77_11_0, p570ccc77_12_1, p570ccc77_13_2, p570ccc77_14_3);
   }

   public void pushPose() {
      PoseStack.Pose $$0 = this.last();
      this.lastIndex++;
      if (this.lastIndex >= this.poses.size()) {
         this.poses.add($$0.copy());
      } else {
         this.poses.get(this.lastIndex).set($$0);
      }
   }

   public void popPose() {
      if (this.lastIndex == 0) {
         throw new NoSuchElementException();
      }

      this.lastIndex--;
   }

   public PoseStack.Pose last() {
      return this.poses.get(this.lastIndex);
   }

   public boolean isEmpty() {
      return this.lastIndex == 0;
   }

   public void setIdentity() {
      this.last().setIdentity();
   }

   public void mulPose(Matrix4fc p570ccc77_15_0) {
      this.last().mulPose(p570ccc77_15_0);
   }

   public static final class Pose {
      private final Matrix4f pose = new Matrix4f();
      private final Matrix3f normal = new Matrix3f();
      private boolean trustedNormals = true;

      private void computeNormalMatrix() {
         this.normal.set(this.pose).invert().transpose();
         this.trustedNormals = false;
      }

      public void set(PoseStack.Pose p1a44c0be_0_0) {
         this.pose.set(p1a44c0be_0_0.pose);
         this.normal.set(p1a44c0be_0_0.normal);
         this.trustedNormals = p1a44c0be_0_0.trustedNormals;
      }

      public Matrix4f pose() {
         return this.pose;
      }

      public Matrix3f normal() {
         return this.normal;
      }

      public Vector3f transformNormal(Vector3fc p1a44c0be_1_0, Vector3f p1a44c0be_2_1) {
         return this.transformNormal(p1a44c0be_1_0.x(), p1a44c0be_1_0.y(), p1a44c0be_1_0.z(), p1a44c0be_2_1);
      }

      public Vector3f transformNormal(float p1a44c0be_3_0, float p1a44c0be_4_1, float p1a44c0be_5_2, Vector3f p1a44c0be_6_3) {
         Vector3f $$4 = this.normal.transform(p1a44c0be_3_0, p1a44c0be_4_1, p1a44c0be_5_2, p1a44c0be_6_3);
         return this.trustedNormals ? $$4 : $$4.normalize();
      }

      public Matrix4f translate(float p1a44c0be_7_0, float p1a44c0be_8_1, float p1a44c0be_9_2) {
         return this.pose.translate(p1a44c0be_7_0, p1a44c0be_8_1, p1a44c0be_9_2);
      }

      public void scale(float p1a44c0be_10_0, float p1a44c0be_11_1, float p1a44c0be_12_2) {
         this.pose.scale(p1a44c0be_10_0, p1a44c0be_11_1, p1a44c0be_12_2);
         if (Math.abs(p1a44c0be_10_0) == Math.abs(p1a44c0be_11_1) && Math.abs(p1a44c0be_11_1) == Math.abs(p1a44c0be_12_2)) {
            if (p1a44c0be_10_0 < 0.0F || p1a44c0be_11_1 < 0.0F || p1a44c0be_12_2 < 0.0F) {
               this.normal.scale(Math.signum(p1a44c0be_10_0), Math.signum(p1a44c0be_11_1), Math.signum(p1a44c0be_12_2));
            }
         } else {
            this.normal.scale(1.0F / p1a44c0be_10_0, 1.0F / p1a44c0be_11_1, 1.0F / p1a44c0be_12_2);
            this.trustedNormals = false;
         }
      }

      public void rotate(Quaternionfc p1a44c0be_13_0) {
         this.pose.rotate(p1a44c0be_13_0);
         this.normal.rotate(p1a44c0be_13_0);
      }

      public void rotateAround(Quaternionfc p1a44c0be_14_0, float p1a44c0be_15_1, float p1a44c0be_16_2, float p1a44c0be_17_3) {
         this.pose.rotateAround(p1a44c0be_14_0, p1a44c0be_15_1, p1a44c0be_16_2, p1a44c0be_17_3);
         this.normal.rotate(p1a44c0be_14_0);
      }

      public void setIdentity() {
         this.pose.identity();
         this.normal.identity();
         this.trustedNormals = true;
      }

      public void mulPose(Matrix4fc p1a44c0be_18_0) {
         this.pose.mul(p1a44c0be_18_0);
         if (!MatrixUtil.isPureTranslation(p1a44c0be_18_0)) {
            if (MatrixUtil.isOrthonormal(p1a44c0be_18_0)) {
               this.normal.mul(new Matrix3f(p1a44c0be_18_0));
            } else {
               this.computeNormalMatrix();
            }
         }
      }

      public PoseStack.Pose copy() {
         PoseStack.Pose $$0 = new PoseStack.Pose();
         $$0.set(this);
         return $$0;
      }
   }
}
