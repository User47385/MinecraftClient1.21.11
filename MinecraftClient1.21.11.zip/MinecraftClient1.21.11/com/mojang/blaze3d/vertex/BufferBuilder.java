package com.mojang.blaze3d.vertex;

import java.nio.ByteOrder;
import java.util.stream.Collectors;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.MemoryUtil;

public class BufferBuilder implements VertexConsumer {
   private static final int MAX_VERTEX_COUNT = 16777215;
   private static final long NOT_BUILDING = -1L;
   private static final long UNKNOWN_ELEMENT = -1L;
   private static final boolean IS_LITTLE_ENDIAN = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN;
   private final ByteBufferBuilder buffer;
   private long vertexPointer = -1L;
   private int vertices;
   private final VertexFormat format;
   private final VertexFormat.Mode mode;
   private final boolean fastFormat;
   private final boolean fullFormat;
   private final int vertexSize;
   private final int initialElementsToFill;
   private final int[] offsetsByElement;
   private int elementsToFill;
   private boolean building = true;

   public BufferBuilder(ByteBufferBuilder pdf98b3b_0_0, VertexFormat.Mode pdf98b3b_1_1, VertexFormat pdf98b3b_2_2) {
      if (!pdf98b3b_2_2.contains(VertexFormatElement.POSITION)) {
         throw new IllegalArgumentException("Cannot build mesh with no position element");
      }

      this.buffer = pdf98b3b_0_0;
      this.mode = pdf98b3b_1_1;
      this.format = pdf98b3b_2_2;
      this.vertexSize = pdf98b3b_2_2.getVertexSize();
      this.initialElementsToFill = pdf98b3b_2_2.getElementsMask() & ~VertexFormatElement.POSITION.mask();
      this.offsetsByElement = pdf98b3b_2_2.getOffsetsByElement();
      boolean $$3 = pdf98b3b_2_2 == DefaultVertexFormat.NEW_ENTITY;
      boolean $$4 = pdf98b3b_2_2 == DefaultVertexFormat.BLOCK;
      this.fastFormat = $$3 || $$4;
      this.fullFormat = $$3;
   }

   public @Nullable MeshData build() {
      this.ensureBuilding();
      this.endLastVertex();
      MeshData $$0 = this.storeMesh();
      this.building = false;
      this.vertexPointer = -1L;
      return $$0;
   }

   public MeshData buildOrThrow() {
      MeshData $$0 = this.build();
      if ($$0 == null) {
         throw new IllegalStateException("BufferBuilder was empty");
      } else {
         return $$0;
      }
   }

   private void ensureBuilding() {
      if (!this.building) {
         throw new IllegalStateException("Not building!");
      }
   }

   private @Nullable MeshData storeMesh() {
      if (this.vertices == 0) {
         return null;
      }

      ByteBufferBuilder.Result $$0 = this.buffer.build();
      if ($$0 == null) {
         return null;
      }

      int $$1 = this.mode.indexCount(this.vertices);
      VertexFormat.IndexType $$2 = VertexFormat.IndexType.least(this.vertices);
      return new MeshData($$0, new MeshData.DrawState(this.format, this.vertices, $$1, this.mode, $$2));
   }

   private long beginVertex() {
      this.ensureBuilding();
      this.endLastVertex();
      if (this.vertices >= 16777215) {
         throw new IllegalStateException("Trying to write too many vertices (>16777215) into BufferBuilder");
      }

      this.vertices++;
      long $$0 = this.buffer.reserve(this.vertexSize);
      this.vertexPointer = $$0;
      return $$0;
   }

   private long beginElement(VertexFormatElement pdf98b3b_3_0) {
      int $$1 = this.elementsToFill;
      int $$2 = $$1 & ~pdf98b3b_3_0.mask();
      if ($$2 == $$1) {
         return -1L;
      } else {
         this.elementsToFill = $$2;
         long $$3 = this.vertexPointer;
         if ($$3 == -1L) {
            throw new IllegalArgumentException("Not currently building vertex");
         } else {
            return $$3 + this.offsetsByElement[pdf98b3b_3_0.id()];
         }
      }
   }

   private void endLastVertex() {
      if (this.vertices != 0) {
         if (this.elementsToFill != 0) {
            String $$0 = VertexFormatElement.elementsFromMask(this.elementsToFill).map(this.format::getElementName).collect(Collectors.joining(", "));
            throw new IllegalStateException("Missing elements in vertex: " + $$0);
         }

         if (this.mode == VertexFormat.Mode.LINES) {
            long $$1 = this.buffer.reserve(this.vertexSize);
            MemoryUtil.memCopy($$1 - this.vertexSize, $$1, this.vertexSize);
            this.vertices++;
         }
      }
   }

   private static void putRgba(long pdf98b3b_4_0, int pdf98b3b_5_1) {
      int $$2 = ARGB.toABGR(pdf98b3b_5_1);
      MemoryUtil.memPutInt(pdf98b3b_4_0, IS_LITTLE_ENDIAN ? $$2 : Integer.reverseBytes($$2));
   }

   private static void putPackedUv(long pdf98b3b_6_0, int pdf98b3b_7_1) {
      if (IS_LITTLE_ENDIAN) {
         MemoryUtil.memPutInt(pdf98b3b_6_0, pdf98b3b_7_1);
      } else {
         MemoryUtil.memPutShort(pdf98b3b_6_0, (short)(pdf98b3b_7_1 & 65535));
         MemoryUtil.memPutShort(pdf98b3b_6_0 + 2L, (short)(pdf98b3b_7_1 >> 16 & 65535));
      }
   }

   @Override
   public VertexConsumer addVertex(float pdf98b3b_8_0, float pdf98b3b_9_1, float pdf98b3b_10_2) {
      long $$3 = this.beginVertex() + this.offsetsByElement[VertexFormatElement.POSITION.id()];
      this.elementsToFill = this.initialElementsToFill;
      MemoryUtil.memPutFloat($$3, pdf98b3b_8_0);
      MemoryUtil.memPutFloat($$3 + 4L, pdf98b3b_9_1);
      MemoryUtil.memPutFloat($$3 + 8L, pdf98b3b_10_2);
      return this;
   }

   @Override
   public VertexConsumer setColor(int pdf98b3b_11_0, int pdf98b3b_12_1, int pdf98b3b_13_2, int pdf98b3b_14_3) {
      long $$4 = this.beginElement(VertexFormatElement.COLOR);
      if ($$4 != -1L) {
         MemoryUtil.memPutByte($$4, (byte)pdf98b3b_11_0);
         MemoryUtil.memPutByte($$4 + 1L, (byte)pdf98b3b_12_1);
         MemoryUtil.memPutByte($$4 + 2L, (byte)pdf98b3b_13_2);
         MemoryUtil.memPutByte($$4 + 3L, (byte)pdf98b3b_14_3);
      }

      return this;
   }

   @Override
   public VertexConsumer setColor(int pdf98b3b_15_0) {
      long $$1 = this.beginElement(VertexFormatElement.COLOR);
      if ($$1 != -1L) {
         putRgba($$1, pdf98b3b_15_0);
      }

      return this;
   }

   @Override
   public VertexConsumer setUv(float pdf98b3b_16_0, float pdf98b3b_17_1) {
      long $$2 = this.beginElement(VertexFormatElement.UV0);
      if ($$2 != -1L) {
         MemoryUtil.memPutFloat($$2, pdf98b3b_16_0);
         MemoryUtil.memPutFloat($$2 + 4L, pdf98b3b_17_1);
      }

      return this;
   }

   @Override
   public VertexConsumer setUv1(int pdf98b3b_18_0, int pdf98b3b_19_1) {
      return this.uvShort((short)pdf98b3b_18_0, (short)pdf98b3b_19_1, VertexFormatElement.UV1);
   }

   @Override
   public VertexConsumer setOverlay(int pdf98b3b_20_0) {
      long $$1 = this.beginElement(VertexFormatElement.UV1);
      if ($$1 != -1L) {
         putPackedUv($$1, pdf98b3b_20_0);
      }

      return this;
   }

   @Override
   public VertexConsumer setUv2(int pdf98b3b_21_0, int pdf98b3b_22_1) {
      return this.uvShort((short)pdf98b3b_21_0, (short)pdf98b3b_22_1, VertexFormatElement.UV2);
   }

   @Override
   public VertexConsumer setLight(int pdf98b3b_23_0) {
      long $$1 = this.beginElement(VertexFormatElement.UV2);
      if ($$1 != -1L) {
         putPackedUv($$1, pdf98b3b_23_0);
      }

      return this;
   }

   private VertexConsumer uvShort(short pdf98b3b_24_0, short pdf98b3b_25_1, VertexFormatElement pdf98b3b_26_2) {
      long $$3 = this.beginElement(pdf98b3b_26_2);
      if ($$3 != -1L) {
         MemoryUtil.memPutShort($$3, pdf98b3b_24_0);
         MemoryUtil.memPutShort($$3 + 2L, pdf98b3b_25_1);
      }

      return this;
   }

   @Override
   public VertexConsumer setNormal(float pdf98b3b_27_0, float pdf98b3b_28_1, float pdf98b3b_29_2) {
      long $$3 = this.beginElement(VertexFormatElement.NORMAL);
      if ($$3 != -1L) {
         MemoryUtil.memPutByte($$3, normalIntValue(pdf98b3b_27_0));
         MemoryUtil.memPutByte($$3 + 1L, normalIntValue(pdf98b3b_28_1));
         MemoryUtil.memPutByte($$3 + 2L, normalIntValue(pdf98b3b_29_2));
      }

      return this;
   }

   @Override
   public VertexConsumer setLineWidth(float pdf98b3b_30_0) {
      long $$1 = this.beginElement(VertexFormatElement.LINE_WIDTH);
      if ($$1 != -1L) {
         MemoryUtil.memPutFloat($$1, pdf98b3b_30_0);
      }

      return this;
   }

   private static byte normalIntValue(float pdf98b3b_31_0) {
      return (byte)((int)(Mth.clamp(pdf98b3b_31_0, -1.0F, 1.0F) * 127.0F) & 0xFF);
   }

   @Override
   public void addVertex(
      float pdf98b3b_32_0,
      float pdf98b3b_33_1,
      float pdf98b3b_34_2,
      int pdf98b3b_35_3,
      float pdf98b3b_36_4,
      float pdf98b3b_37_5,
      int pdf98b3b_38_6,
      int pdf98b3b_39_7,
      float pdf98b3b_40_8,
      float pdf98b3b_41_9,
      float pdf98b3b_42_10
   ) {
      if (this.fastFormat) {
         long $$11 = this.beginVertex();
         MemoryUtil.memPutFloat($$11 + 0L, pdf98b3b_32_0);
         MemoryUtil.memPutFloat($$11 + 4L, pdf98b3b_33_1);
         MemoryUtil.memPutFloat($$11 + 8L, pdf98b3b_34_2);
         putRgba($$11 + 12L, pdf98b3b_35_3);
         MemoryUtil.memPutFloat($$11 + 16L, pdf98b3b_36_4);
         MemoryUtil.memPutFloat($$11 + 20L, pdf98b3b_37_5);
         long $$12;
         if (this.fullFormat) {
            putPackedUv($$11 + 24L, pdf98b3b_38_6);
            $$12 = $$11 + 28L;
         } else {
            $$12 = $$11 + 24L;
         }

         putPackedUv($$12 + 0L, pdf98b3b_39_7);
         MemoryUtil.memPutByte($$12 + 4L, normalIntValue(pdf98b3b_40_8));
         MemoryUtil.memPutByte($$12 + 5L, normalIntValue(pdf98b3b_41_9));
         MemoryUtil.memPutByte($$12 + 6L, normalIntValue(pdf98b3b_42_10));
      } else {
         VertexConsumer.super.addVertex(
            pdf98b3b_32_0,
            pdf98b3b_33_1,
            pdf98b3b_34_2,
            pdf98b3b_35_3,
            pdf98b3b_36_4,
            pdf98b3b_37_5,
            pdf98b3b_38_6,
            pdf98b3b_39_7,
            pdf98b3b_40_8,
            pdf98b3b_41_9,
            pdf98b3b_42_10
         );
      }
   }
}
