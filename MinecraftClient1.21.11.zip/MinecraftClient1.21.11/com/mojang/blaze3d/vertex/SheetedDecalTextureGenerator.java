package com.mojang.blaze3d.vertex;

import net.minecraft.core.Direction;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class SheetedDecalTextureGenerator implements VertexConsumer {
   private final VertexConsumer delegate;
   private final Matrix4f cameraInversePose;
   private final Matrix3f normalInversePose;
   private final float textureScale;
   private final Vector3f worldPos = new Vector3f();
   private final Vector3f normal = new Vector3f();
   private float x;
   private float y;
   private float z;

   public SheetedDecalTextureGenerator(VertexConsumer p148d2a27_0_0, PoseStack.Pose p148d2a27_1_1, float p148d2a27_2_2) {
      this.delegate = p148d2a27_0_0;
      this.cameraInversePose = new Matrix4f(p148d2a27_1_1.pose()).invert();
      this.normalInversePose = new Matrix3f(p148d2a27_1_1.normal()).invert();
      this.textureScale = p148d2a27_2_2;
   }

   @Override
   public VertexConsumer addVertex(float p148d2a27_3_0, float p148d2a27_4_1, float p148d2a27_5_2) {
      this.x = p148d2a27_3_0;
      this.y = p148d2a27_4_1;
      this.z = p148d2a27_5_2;
      this.delegate.addVertex(p148d2a27_3_0, p148d2a27_4_1, p148d2a27_5_2);
      return this;
   }

   @Override
   public VertexConsumer setColor(int p148d2a27_6_0, int p148d2a27_7_1, int p148d2a27_8_2, int p148d2a27_9_3) {
      this.delegate.setColor(-1);
      return this;
   }

   @Override
   public VertexConsumer setColor(int p148d2a27_10_0) {
      this.delegate.setColor(-1);
      return this;
   }

   @Override
   public VertexConsumer setUv(float p148d2a27_11_0, float p148d2a27_12_1) {
      return this;
   }

   @Override
   public VertexConsumer setUv1(int p148d2a27_13_0, int p148d2a27_14_1) {
      this.delegate.setUv1(p148d2a27_13_0, p148d2a27_14_1);
      return this;
   }

   @Override
   public VertexConsumer setUv2(int p148d2a27_15_0, int p148d2a27_16_1) {
      this.delegate.setUv2(p148d2a27_15_0, p148d2a27_16_1);
      return this;
   }

   @Override
   public VertexConsumer setNormal(float p148d2a27_17_0, float p148d2a27_18_1, float p148d2a27_19_2) {
      this.delegate.setNormal(p148d2a27_17_0, p148d2a27_18_1, p148d2a27_19_2);
      Vector3f $$3 = this.normalInversePose.transform(p148d2a27_17_0, p148d2a27_18_1, p148d2a27_19_2, this.normal);
      Direction $$4 = Direction.getApproximateNearest($$3.x(), $$3.y(), $$3.z());
      Vector3f $$5 = this.cameraInversePose.transformPosition(this.x, this.y, this.z, this.worldPos);
      $$5.rotateY((float) Math.PI);
      $$5.rotateX((float) (-Math.PI / 2));
      $$5.rotate($$4.getRotation());
      this.delegate.setUv(-$$5.x() * this.textureScale, -$$5.y() * this.textureScale);
      return this;
   }

   @Override
   public VertexConsumer setLineWidth(float p148d2a27_20_0) {
      this.delegate.setLineWidth(p148d2a27_20_0);
      return this;
   }
}
