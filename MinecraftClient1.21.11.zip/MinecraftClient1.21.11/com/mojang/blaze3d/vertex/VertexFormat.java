package com.mojang.blaze3d.vertex;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.mojang.blaze3d.DontObfuscate;
import com.mojang.blaze3d.GraphicsWorkarounds;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import org.jspecify.annotations.Nullable;

@DontObfuscate
public class VertexFormat {
   public static final int UNKNOWN_ELEMENT = -1;
   private final List<VertexFormatElement> elements;
   private final List<String> names;
   private final int vertexSize;
   private final int elementsMask;
   private final int[] offsetsByElement = new int[32];
   private @Nullable GpuBuffer immediateDrawVertexBuffer;
   private @Nullable GpuBuffer immediateDrawIndexBuffer;

   VertexFormat(List<VertexFormatElement> p2762eabb_0_0, List<String> p2762eabb_1_1, IntList p2762eabb_2_2, int p2762eabb_3_3) {
      this.elements = p2762eabb_0_0;
      this.names = p2762eabb_1_1;
      this.vertexSize = p2762eabb_3_3;
      this.elementsMask = p2762eabb_0_0.stream()
         .mapToInt(VertexFormatElement::mask)
         .reduce(0, (p2762eabb_14_0, p2762eabb_15_1) -> p2762eabb_14_0 | p2762eabb_15_1);

      for (int $$4 = 0; $$4 < this.offsetsByElement.length; $$4++) {
         VertexFormatElement $$5 = VertexFormatElement.byId($$4);
         int $$6 = $$5 != null ? p2762eabb_0_0.indexOf($$5) : -1;
         this.offsetsByElement[$$4] = $$6 != -1 ? p2762eabb_2_2.getInt($$6) : -1;
      }
   }

   public static VertexFormat.Builder builder() {
      return new VertexFormat.Builder();
   }

   @Override
   public String toString() {
      return "VertexFormat" + this.names;
   }

   public int getVertexSize() {
      return this.vertexSize;
   }

   public List<VertexFormatElement> getElements() {
      return this.elements;
   }

   public List<String> getElementAttributeNames() {
      return this.names;
   }

   public int[] getOffsetsByElement() {
      return this.offsetsByElement;
   }

   public int getOffset(VertexFormatElement p2762eabb_4_0) {
      return this.offsetsByElement[p2762eabb_4_0.id()];
   }

   public boolean contains(VertexFormatElement p2762eabb_5_0) {
      return (this.elementsMask & p2762eabb_5_0.mask()) != 0;
   }

   public int getElementsMask() {
      return this.elementsMask;
   }

   public String getElementName(VertexFormatElement p2762eabb_6_0) {
      int $$1 = this.elements.indexOf(p2762eabb_6_0);
      if ($$1 == -1) {
         throw new IllegalArgumentException(p2762eabb_6_0 + " is not contained in format");
      } else {
         return this.names.get($$1);
      }
   }

   @Override
   public boolean equals(Object p2762eabb_7_0) {
      return this == p2762eabb_7_0
         ? true
         : p2762eabb_7_0 instanceof VertexFormat $$1
            && this.elementsMask == $$1.elementsMask
            && this.vertexSize == $$1.vertexSize
            && this.names.equals($$1.names)
            && Arrays.equals(this.offsetsByElement, $$1.offsetsByElement);
   }

   @Override
   public int hashCode() {
      return this.elementsMask * 31 + Arrays.hashCode(this.offsetsByElement);
   }

   private static GpuBuffer uploadToBuffer(
      @Nullable GpuBuffer p2762eabb_8_0, ByteBuffer p2762eabb_9_1, @GpuBuffer.Usage int p2762eabb_10_2, Supplier<String> p2762eabb_11_3
   ) {
      GpuDevice $$4 = RenderSystem.getDevice();
      if (GraphicsWorkarounds.get($$4).alwaysCreateFreshImmediateBuffer()) {
         if (p2762eabb_8_0 != null) {
            p2762eabb_8_0.close();
         }

         return $$4.createBuffer(p2762eabb_11_3, p2762eabb_10_2, p2762eabb_9_1);
      } else {
         if (p2762eabb_8_0 == null) {
            p2762eabb_8_0 = $$4.createBuffer(p2762eabb_11_3, p2762eabb_10_2, p2762eabb_9_1);
         } else {
            CommandEncoder $$5 = $$4.createCommandEncoder();
            if (p2762eabb_8_0.size() < p2762eabb_9_1.remaining()) {
               p2762eabb_8_0.close();
               p2762eabb_8_0 = $$4.createBuffer(p2762eabb_11_3, p2762eabb_10_2, p2762eabb_9_1);
            } else {
               $$5.writeToBuffer(p2762eabb_8_0.slice(), p2762eabb_9_1);
            }
         }

         return p2762eabb_8_0;
      }
   }

   public GpuBuffer uploadImmediateVertexBuffer(ByteBuffer p2762eabb_12_0) {
      this.immediateDrawVertexBuffer = uploadToBuffer(this.immediateDrawVertexBuffer, p2762eabb_12_0, 40, () -> "Immediate vertex buffer for " + this);
      return this.immediateDrawVertexBuffer;
   }

   public GpuBuffer uploadImmediateIndexBuffer(ByteBuffer p2762eabb_13_0) {
      this.immediateDrawIndexBuffer = uploadToBuffer(this.immediateDrawIndexBuffer, p2762eabb_13_0, 72, () -> "Immediate index buffer for " + this);
      return this.immediateDrawIndexBuffer;
   }

   @DontObfuscate
   public static class Builder {
      private final ImmutableMap.Builder<String, VertexFormatElement> elements = ImmutableMap.builder();
      private final IntList offsets = new IntArrayList();
      private int offset;

      Builder() {
      }

      public VertexFormat.Builder add(String p8d7cd692_0_0, VertexFormatElement p8d7cd692_1_1) {
         this.elements.put(p8d7cd692_0_0, p8d7cd692_1_1);
         this.offsets.add(this.offset);
         this.offset = this.offset + p8d7cd692_1_1.byteSize();
         return this;
      }

      public VertexFormat.Builder padding(int p8d7cd692_2_0) {
         this.offset += p8d7cd692_2_0;
         return this;
      }

      public VertexFormat build() {
         ImmutableMap<String, VertexFormatElement> $$0 = this.elements.buildOrThrow();
         ImmutableList<VertexFormatElement> $$1 = $$0.values().asList();
         ImmutableList<String> $$2 = $$0.keySet().asList();
         return new VertexFormat($$1, $$2, this.offsets, this.offset);
      }
   }

   public enum IndexType {
      SHORT(2),
      INT(4);

      public final int bytes;

      IndexType(final int p44f97863_3_2) {
         this.bytes = p44f97863_3_2;
      }

      public static VertexFormat.IndexType least(int p44f97863_4_0) {
         return (p44f97863_4_0 & -65536) != 0 ? INT : SHORT;
      }
   }

   public enum Mode {
      LINES(2, 2, false),
      DEBUG_LINES(2, 2, false),
      DEBUG_LINE_STRIP(2, 1, true),
      POINTS(1, 1, false),
      TRIANGLES(3, 3, false),
      TRIANGLE_STRIP(3, 1, true),
      TRIANGLE_FAN(3, 1, true),
      QUADS(4, 4, false);

      public final int primitiveLength;
      public final int primitiveStride;
      public final boolean connectedPrimitives;

      Mode(final int pb5198e0c_3_2, final int pb5198e0c_4_3, final boolean pb5198e0c_5_4) {
         this.primitiveLength = pb5198e0c_3_2;
         this.primitiveStride = pb5198e0c_4_3;
         this.connectedPrimitives = pb5198e0c_5_4;
      }

      public int indexCount(int pb5198e0c_6_0) {
         return switch (this) {
            case LINES, QUADS -> pb5198e0c_6_0 / 4 * 6;
            case DEBUG_LINES, DEBUG_LINE_STRIP, POINTS, TRIANGLES, TRIANGLE_STRIP, TRIANGLE_FAN -> pb5198e0c_6_0;
            default -> 0;
         };
      }
   }
}
