package com.mojang.blaze3d.textures;

import com.mojang.blaze3d.DontObfuscate;

@DontObfuscate
public abstract class GpuTextureView implements AutoCloseable {
   private final GpuTexture texture;
   private final int baseMipLevel;
   private final int mipLevels;

   public GpuTextureView(GpuTexture p64e5b940_0_0, int p64e5b940_1_1, int p64e5b940_2_2) {
      this.texture = p64e5b940_0_0;
      this.baseMipLevel = p64e5b940_1_1;
      this.mipLevels = p64e5b940_2_2;
   }

   @Override
   public abstract void close();

   public GpuTexture texture() {
      return this.texture;
   }

   public int baseMipLevel() {
      return this.baseMipLevel;
   }

   public int mipLevels() {
      return this.mipLevels;
   }

   public int getWidth(int p64e5b940_3_0) {
      return this.texture.getWidth(p64e5b940_3_0 + this.baseMipLevel);
   }

   public int getHeight(int p64e5b940_4_0) {
      return this.texture.getHeight(p64e5b940_4_0 + this.baseMipLevel);
   }

   public abstract boolean isClosed();
}
