package com.mojang.blaze3d.textures;

import com.mojang.blaze3d.DontObfuscate;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@DontObfuscate
public abstract class GpuTexture implements AutoCloseable {
   public static final int USAGE_COPY_DST = 1;
   public static final int USAGE_COPY_SRC = 2;
   public static final int USAGE_TEXTURE_BINDING = 4;
   public static final int USAGE_RENDER_ATTACHMENT = 8;
   public static final int USAGE_CUBEMAP_COMPATIBLE = 16;
   private final TextureFormat format;
   private final int width;
   private final int height;
   private final int depthOrLayers;
   private final int mipLevels;
   @GpuTexture.Usage
   private final int usage;
   private final String label;

   public GpuTexture(
      @GpuTexture.Usage int p72c37ffb_0_0,
      String p72c37ffb_1_1,
      TextureFormat p72c37ffb_2_2,
      int p72c37ffb_3_3,
      int p72c37ffb_4_4,
      int p72c37ffb_5_5,
      int p72c37ffb_6_6
   ) {
      this.usage = p72c37ffb_0_0;
      this.label = p72c37ffb_1_1;
      this.format = p72c37ffb_2_2;
      this.width = p72c37ffb_3_3;
      this.height = p72c37ffb_4_4;
      this.depthOrLayers = p72c37ffb_5_5;
      this.mipLevels = p72c37ffb_6_6;
   }

   public int getWidth(int p72c37ffb_7_0) {
      return this.width >> p72c37ffb_7_0;
   }

   public int getHeight(int p72c37ffb_8_0) {
      return this.height >> p72c37ffb_8_0;
   }

   public int getDepthOrLayers() {
      return this.depthOrLayers;
   }

   public int getMipLevels() {
      return this.mipLevels;
   }

   public TextureFormat getFormat() {
      return this.format;
   }

   @GpuTexture.Usage
   public int usage() {
      return this.usage;
   }

   public String getLabel() {
      return this.label;
   }

   @Override
   public abstract void close();

   public abstract boolean isClosed();

   @Retention(RetentionPolicy.CLASS)
   @Target({ElementType.FIELD, ElementType.PARAMETER, ElementType.LOCAL_VARIABLE, ElementType.METHOD, ElementType.TYPE_USE})
   public @interface Usage {
   }
}
