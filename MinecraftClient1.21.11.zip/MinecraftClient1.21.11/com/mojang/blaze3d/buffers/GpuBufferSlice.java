package com.mojang.blaze3d.buffers;

import com.mojang.blaze3d.DontObfuscate;

@DontObfuscate
public record GpuBufferSlice(GpuBuffer buffer, long offset, long length) {
   public GpuBufferSlice slice(long pa6de24ed_3_0, long pa6de24ed_4_1) {
      if (pa6de24ed_3_0 >= 0L && pa6de24ed_4_1 >= 0L && pa6de24ed_3_0 + pa6de24ed_4_1 <= this.length) {
         return new GpuBufferSlice(this.buffer, this.offset + pa6de24ed_3_0, pa6de24ed_4_1);
      } else {
         throw new IllegalArgumentException(
            "Offset of "
               + pa6de24ed_3_0
               + " and length "
               + pa6de24ed_4_1
               + " would put new slice outside existing slice's range (of "
               + this.offset
               + ","
               + this.length
               + ")"
         );
      }
   }
}
