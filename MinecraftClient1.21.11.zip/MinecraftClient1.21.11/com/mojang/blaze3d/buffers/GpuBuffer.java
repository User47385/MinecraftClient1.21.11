package com.mojang.blaze3d.buffers;

import com.mojang.blaze3d.DontObfuscate;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.nio.ByteBuffer;

@DontObfuscate
public abstract class GpuBuffer implements AutoCloseable {
   public static final int USAGE_MAP_READ = 1;
   public static final int USAGE_MAP_WRITE = 2;
   public static final int USAGE_HINT_CLIENT_STORAGE = 4;
   public static final int USAGE_COPY_DST = 8;
   public static final int USAGE_COPY_SRC = 16;
   public static final int USAGE_VERTEX = 32;
   public static final int USAGE_INDEX = 64;
   public static final int USAGE_UNIFORM = 128;
   public static final int USAGE_UNIFORM_TEXEL_BUFFER = 256;
   @GpuBuffer.Usage
   private final int usage;
   private final long size;

   public GpuBuffer(@GpuBuffer.Usage int p763627a5_0_0, long p763627a5_1_1) {
      this.size = p763627a5_1_1;
      this.usage = p763627a5_0_0;
   }

   public long size() {
      return this.size;
   }

   @GpuBuffer.Usage
   public int usage() {
      return this.usage;
   }

   public abstract boolean isClosed();

   @Override
   public abstract void close();

   public GpuBufferSlice slice(long p763627a5_2_0, long p763627a5_3_1) {
      if (p763627a5_2_0 >= 0L && p763627a5_3_1 >= 0L && p763627a5_2_0 + p763627a5_3_1 <= this.size) {
         return new GpuBufferSlice(this, p763627a5_2_0, p763627a5_3_1);
      } else {
         throw new IllegalArgumentException(
            "Offset of " + p763627a5_2_0 + " and length " + p763627a5_3_1 + " would put new slice outside buffer's range (of 0," + p763627a5_3_1 + ")"
         );
      }
   }

   public GpuBufferSlice slice() {
      return new GpuBufferSlice(this, 0L, this.size);
   }

   @DontObfuscate
   public interface MappedView extends AutoCloseable {
      ByteBuffer data();

      @Override
      void close();
   }

   @Retention(RetentionPolicy.CLASS)
   @Target({ElementType.FIELD, ElementType.PARAMETER, ElementType.LOCAL_VARIABLE, ElementType.METHOD, ElementType.TYPE_USE})
   public @interface Usage {
   }
}
