package com.mojang.blaze3d.buffers;

import com.mojang.blaze3d.DontObfuscate;
import java.nio.ByteBuffer;
import net.minecraft.util.Mth;
import org.joml.Matrix4fc;
import org.joml.Vector2fc;
import org.joml.Vector2ic;
import org.joml.Vector3fc;
import org.joml.Vector3ic;
import org.joml.Vector4fc;
import org.joml.Vector4ic;
import org.lwjgl.system.MemoryStack;

@DontObfuscate
public class Std140Builder {
   private final ByteBuffer buffer;
   private final int start;

   private Std140Builder(ByteBuffer pe67ba5ea_0_0) {
      this.buffer = pe67ba5ea_0_0;
      this.start = pe67ba5ea_0_0.position();
   }

   public static Std140Builder intoBuffer(ByteBuffer pe67ba5ea_1_0) {
      return new Std140Builder(pe67ba5ea_1_0);
   }

   public static Std140Builder onStack(MemoryStack pe67ba5ea_2_0, int pe67ba5ea_3_1) {
      return new Std140Builder(pe67ba5ea_2_0.malloc(pe67ba5ea_3_1));
   }

   public ByteBuffer get() {
      return this.buffer.flip();
   }

   public Std140Builder align(int pe67ba5ea_4_0) {
      int $$1 = this.buffer.position();
      this.buffer.position(this.start + Mth.roundToward($$1 - this.start, pe67ba5ea_4_0));
      return this;
   }

   public Std140Builder putFloat(float pe67ba5ea_5_0) {
      this.align(4);
      this.buffer.putFloat(pe67ba5ea_5_0);
      return this;
   }

   public Std140Builder putInt(int pe67ba5ea_6_0) {
      this.align(4);
      this.buffer.putInt(pe67ba5ea_6_0);
      return this;
   }

   public Std140Builder putVec2(float pe67ba5ea_7_0, float pe67ba5ea_8_1) {
      this.align(8);
      this.buffer.putFloat(pe67ba5ea_7_0);
      this.buffer.putFloat(pe67ba5ea_8_1);
      return this;
   }

   public Std140Builder putVec2(Vector2fc pe67ba5ea_9_0) {
      this.align(8);
      pe67ba5ea_9_0.get(this.buffer);
      this.buffer.position(this.buffer.position() + 8);
      return this;
   }

   public Std140Builder putIVec2(int pe67ba5ea_10_0, int pe67ba5ea_11_1) {
      this.align(8);
      this.buffer.putInt(pe67ba5ea_10_0);
      this.buffer.putInt(pe67ba5ea_11_1);
      return this;
   }

   public Std140Builder putIVec2(Vector2ic pe67ba5ea_12_0) {
      this.align(8);
      pe67ba5ea_12_0.get(this.buffer);
      this.buffer.position(this.buffer.position() + 8);
      return this;
   }

   public Std140Builder putVec3(float pe67ba5ea_13_0, float pe67ba5ea_14_1, float pe67ba5ea_15_2) {
      this.align(16);
      this.buffer.putFloat(pe67ba5ea_13_0);
      this.buffer.putFloat(pe67ba5ea_14_1);
      this.buffer.putFloat(pe67ba5ea_15_2);
      this.buffer.position(this.buffer.position() + 4);
      return this;
   }

   public Std140Builder putVec3(Vector3fc pe67ba5ea_16_0) {
      this.align(16);
      pe67ba5ea_16_0.get(this.buffer);
      this.buffer.position(this.buffer.position() + 16);
      return this;
   }

   public Std140Builder putIVec3(int pe67ba5ea_17_0, int pe67ba5ea_18_1, int pe67ba5ea_19_2) {
      this.align(16);
      this.buffer.putInt(pe67ba5ea_17_0);
      this.buffer.putInt(pe67ba5ea_18_1);
      this.buffer.putInt(pe67ba5ea_19_2);
      this.buffer.position(this.buffer.position() + 4);
      return this;
   }

   public Std140Builder putIVec3(Vector3ic pe67ba5ea_20_0) {
      this.align(16);
      pe67ba5ea_20_0.get(this.buffer);
      this.buffer.position(this.buffer.position() + 16);
      return this;
   }

   public Std140Builder putVec4(float pe67ba5ea_21_0, float pe67ba5ea_22_1, float pe67ba5ea_23_2, float pe67ba5ea_24_3) {
      this.align(16);
      this.buffer.putFloat(pe67ba5ea_21_0);
      this.buffer.putFloat(pe67ba5ea_22_1);
      this.buffer.putFloat(pe67ba5ea_23_2);
      this.buffer.putFloat(pe67ba5ea_24_3);
      return this;
   }

   public Std140Builder putVec4(Vector4fc pe67ba5ea_25_0) {
      this.align(16);
      pe67ba5ea_25_0.get(this.buffer);
      this.buffer.position(this.buffer.position() + 16);
      return this;
   }

   public Std140Builder putIVec4(int pe67ba5ea_26_0, int pe67ba5ea_27_1, int pe67ba5ea_28_2, int pe67ba5ea_29_3) {
      this.align(16);
      this.buffer.putInt(pe67ba5ea_26_0);
      this.buffer.putInt(pe67ba5ea_27_1);
      this.buffer.putInt(pe67ba5ea_28_2);
      this.buffer.putInt(pe67ba5ea_29_3);
      return this;
   }

   public Std140Builder putIVec4(Vector4ic pe67ba5ea_30_0) {
      this.align(16);
      pe67ba5ea_30_0.get(this.buffer);
      this.buffer.position(this.buffer.position() + 16);
      return this;
   }

   public Std140Builder putMat4f(Matrix4fc pe67ba5ea_31_0) {
      this.align(16);
      pe67ba5ea_31_0.get(this.buffer);
      this.buffer.position(this.buffer.position() + 64);
      return this;
   }
}
