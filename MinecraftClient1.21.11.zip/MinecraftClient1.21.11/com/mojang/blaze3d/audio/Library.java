package com.mojang.blaze3d.audio;

import com.google.common.collect.Sets;
import com.mojang.logging.LogUtils;
import java.nio.IntBuffer;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.OptionalLong;
import java.util.Set;
import net.minecraft.SharedConstants;
import net.minecraft.util.Mth;
import org.jspecify.annotations.Nullable;
import org.lwjgl.openal.AL;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.ALC;
import org.lwjgl.openal.ALC10;
import org.lwjgl.openal.ALC11;
import org.lwjgl.openal.ALCCapabilities;
import org.lwjgl.openal.ALCapabilities;
import org.lwjgl.openal.ALUtil;
import org.lwjgl.system.MemoryStack;
import org.slf4j.Logger;

public class Library {
   static final Logger LOGGER = LogUtils.getLogger();
   private static final int NO_DEVICE = 0;
   private static final int DEFAULT_CHANNEL_COUNT = 30;
   private long currentDevice;
   private long context;
   private boolean supportsDisconnections;
   private @Nullable String defaultDeviceName;
   private static final Library.ChannelPool EMPTY = new Library.ChannelPool() {
      @Override
      public @Nullable Channel acquire() {
         return null;
      }

      @Override
      public boolean release(Channel p1b9f8744_0_0) {
         return false;
      }

      @Override
      public void cleanup() {
      }

      @Override
      public int getMaxCount() {
         return 0;
      }

      @Override
      public int getUsedCount() {
         return 0;
      }
   };
   private Library.ChannelPool staticChannels = EMPTY;
   private Library.ChannelPool streamingChannels = EMPTY;
   private final Listener listener = new Listener();

   public Library() {
      this.defaultDeviceName = getDefaultDeviceName();
   }

   public void init(@Nullable String p303ec477_0_0, boolean p303ec477_1_1) {
      this.currentDevice = openDeviceOrFallback(p303ec477_0_0);
      this.supportsDisconnections = false;
      ALCCapabilities $$2 = ALC.createCapabilities(this.currentDevice);
      if (OpenAlUtil.checkALCError(this.currentDevice, "Get capabilities")) {
         throw new IllegalStateException("Failed to get OpenAL capabilities");
      }

      if (!$$2.OpenALC11) {
         throw new IllegalStateException("OpenAL 1.1 not supported");
      }

      try (MemoryStack $$3 = MemoryStack.stackPush()) {
         IntBuffer $$4 = this.createAttributes($$3, $$2.ALC_SOFT_HRTF && p303ec477_1_1);
         this.context = ALC10.alcCreateContext(this.currentDevice, $$4);
      }

      if (OpenAlUtil.checkALCError(this.currentDevice, "Create context")) {
         throw new IllegalStateException("Unable to create OpenAL context");
      }

      ALC10.alcMakeContextCurrent(this.context);
      int $$5 = this.getChannelCount();
      int $$6 = Mth.clamp((int)Mth.sqrt($$5), 2, 8);
      int $$7 = Mth.clamp($$5 - $$6, 8, 255);
      this.staticChannels = new Library.CountingChannelPool($$7);
      this.streamingChannels = new Library.CountingChannelPool($$6);
      ALCapabilities $$8 = AL.createCapabilities($$2);
      OpenAlUtil.checkALError("Initialization");
      if (!$$8.AL_EXT_source_distance_model) {
         throw new IllegalStateException("AL_EXT_source_distance_model is not supported");
      }

      AL10.alEnable(512);
      if (!$$8.AL_EXT_LINEAR_DISTANCE) {
         throw new IllegalStateException("AL_EXT_LINEAR_DISTANCE is not supported");
      }

      OpenAlUtil.checkALError("Enable per-source distance models");
      LOGGER.info("OpenAL initialized on device {}", this.getCurrentDeviceName());
      this.supportsDisconnections = ALC10.alcIsExtensionPresent(this.currentDevice, "ALC_EXT_disconnect");
   }

   private IntBuffer createAttributes(MemoryStack p303ec477_2_0, boolean p303ec477_3_1) {
      int $$2 = 5;
      IntBuffer $$3 = p303ec477_2_0.callocInt(11);
      int $$4 = ALC10.alcGetInteger(this.currentDevice, 6548);
      if ($$4 > 0) {
         $$3.put(6546).put(p303ec477_3_1 ? 1 : 0);
         $$3.put(6550).put(0);
      }

      $$3.put(6554).put(1);
      return $$3.put(0).flip();
   }

   private int getChannelCount() {
      try (MemoryStack $$0 = MemoryStack.stackPush()) {
         int $$1 = ALC10.alcGetInteger(this.currentDevice, 4098);
         if (OpenAlUtil.checkALCError(this.currentDevice, "Get attributes size")) {
            throw new IllegalStateException("Failed to get OpenAL attributes");
         }

         IntBuffer $$2 = $$0.mallocInt($$1);
         ALC10.alcGetIntegerv(this.currentDevice, 4099, $$2);
         if (OpenAlUtil.checkALCError(this.currentDevice, "Get attributes")) {
            throw new IllegalStateException("Failed to get OpenAL attributes");
         }

         int $$3 = 0;

         while ($$3 < $$1) {
            int $$4 = $$2.get($$3++);
            if ($$4 == 0) {
               break;
            }

            int $$5 = $$2.get($$3++);
            if ($$4 == 4112) {
               return $$5;
            }
         }
      }

      return 30;
   }

   public static @Nullable String getDefaultDeviceName() {
      if (!ALC10.alcIsExtensionPresent(0L, "ALC_ENUMERATE_ALL_EXT")) {
         return null;
      }

      ALUtil.getStringList(0L, 4115);
      return ALC10.alcGetString(0L, 4114);
   }

   public String getCurrentDeviceName() {
      String $$0 = ALC10.alcGetString(this.currentDevice, 4115);
      if ($$0 == null) {
         $$0 = ALC10.alcGetString(this.currentDevice, 4101);
      }

      if ($$0 == null) {
         $$0 = "Unknown";
      }

      return $$0;
   }

   public synchronized boolean hasDefaultDeviceChanged() {
      String $$0 = getDefaultDeviceName();
      if (Objects.equals(this.defaultDeviceName, $$0)) {
         return false;
      }

      this.defaultDeviceName = $$0;
      return true;
   }

   private static long openDeviceOrFallback(@Nullable String p303ec477_4_0) {
      OptionalLong $$1 = OptionalLong.empty();
      if (p303ec477_4_0 != null) {
         $$1 = tryOpenDevice(p303ec477_4_0);
      }

      if ($$1.isEmpty()) {
         $$1 = tryOpenDevice(getDefaultDeviceName());
      }

      if ($$1.isEmpty()) {
         $$1 = tryOpenDevice(null);
      }

      if ($$1.isEmpty()) {
         throw new IllegalStateException("Failed to open OpenAL device");
      } else {
         return $$1.getAsLong();
      }
   }

   private static OptionalLong tryOpenDevice(@Nullable String p303ec477_5_0) {
      long $$1 = ALC10.alcOpenDevice(p303ec477_5_0);
      return $$1 != 0L && !OpenAlUtil.checkALCError($$1, "Open device") ? OptionalLong.of($$1) : OptionalLong.empty();
   }

   public void cleanup() {
      this.staticChannels.cleanup();
      this.streamingChannels.cleanup();
      ALC10.alcDestroyContext(this.context);
      if (this.currentDevice != 0L) {
         ALC10.alcCloseDevice(this.currentDevice);
      }
   }

   public Listener getListener() {
      return this.listener;
   }

   public @Nullable Channel acquireChannel(Library.Pool p303ec477_6_0) {
      return (p303ec477_6_0 == Library.Pool.STREAMING ? this.streamingChannels : this.staticChannels).acquire();
   }

   public void releaseChannel(Channel p303ec477_7_0) {
      if (!this.staticChannels.release(p303ec477_7_0) && !this.streamingChannels.release(p303ec477_7_0)) {
         throw new IllegalStateException("Tried to release unknown channel");
      }
   }

   public String getDebugString() {
      return String.format(
         Locale.ROOT,
         "Sounds: %d/%d + %d/%d",
         this.staticChannels.getUsedCount(),
         this.staticChannels.getMaxCount(),
         this.streamingChannels.getUsedCount(),
         this.streamingChannels.getMaxCount()
      );
   }

   public List<String> getAvailableSoundDevices() {
      List<String> $$0 = ALUtil.getStringList(0L, 4115);
      return $$0 == null ? Collections.emptyList() : $$0;
   }

   public boolean isCurrentDeviceDisconnected() {
      return this.supportsDisconnections && ALC11.alcGetInteger(this.currentDevice, 787) == 0;
   }

   interface ChannelPool {
      @Nullable Channel acquire();

      boolean release(Channel var1);

      void cleanup();

      int getMaxCount();

      int getUsedCount();
   }

   static class CountingChannelPool implements Library.ChannelPool {
      private final int limit;
      private final Set<Channel> activeChannels = Sets.newIdentityHashSet();

      public CountingChannelPool(int p6c22997f_0_0) {
         this.limit = p6c22997f_0_0;
      }

      @Override
      public @Nullable Channel acquire() {
         if (this.activeChannels.size() >= this.limit) {
            if (SharedConstants.IS_RUNNING_IN_IDE) {
               Library.LOGGER.warn("Maximum sound pool size {} reached", this.limit);
            }

            return null;
         } else {
            Channel $$0 = Channel.create();
            if ($$0 != null) {
               this.activeChannels.add($$0);
            }

            return $$0;
         }
      }

      @Override
      public boolean release(Channel p6c22997f_1_0) {
         if (!this.activeChannels.remove(p6c22997f_1_0)) {
            return false;
         }

         p6c22997f_1_0.destroy();
         return true;
      }

      @Override
      public void cleanup() {
         this.activeChannels.forEach(Channel::destroy);
         this.activeChannels.clear();
      }

      @Override
      public int getMaxCount() {
         return this.limit;
      }

      @Override
      public int getUsedCount() {
         return this.activeChannels.size();
      }
   }

   public enum Pool {
      STATIC,
      STREAMING;
   }
}
