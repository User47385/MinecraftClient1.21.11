package com.mojang.blaze3d.audio;

import net.minecraft.world.phys.Vec3;
import org.lwjgl.openal.AL10;

public class Listener {
   private ListenerTransform transform = ListenerTransform.INITIAL;

   public void setTransform(ListenerTransform pf4ba1c78_0_0) {
      this.transform = pf4ba1c78_0_0;
      Vec3 $$1 = pf4ba1c78_0_0.position();
      Vec3 $$2 = pf4ba1c78_0_0.forward();
      Vec3 $$3 = pf4ba1c78_0_0.up();
      AL10.alListener3f(4100, (float)$$1.x, (float)$$1.y, (float)$$1.z);
      AL10.alListenerfv(4111, new float[]{(float)$$2.x, (float)$$2.y, (float)$$2.z, (float)$$3.x(), (float)$$3.y(), (float)$$3.z()});
   }

   public void reset() {
      this.setTransform(ListenerTransform.INITIAL);
   }

   public ListenerTransform getTransform() {
      return this.transform;
   }
}
