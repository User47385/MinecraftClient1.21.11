package com.mojang.blaze3d.audio;

import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.sound.sampled.AudioFormat;
import net.minecraft.client.sounds.AudioStream;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;
import org.lwjgl.openal.AL10;
import org.slf4j.Logger;

public class Channel {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final int QUEUED_BUFFER_COUNT = 4;
   public static final int BUFFER_DURATION_SECONDS = 1;
   private final int source;
   private final AtomicBoolean initialized = new AtomicBoolean(true);
   private int streamingBufferSize = 16384;
   private @Nullable AudioStream stream;

   static @Nullable Channel create() {
      int[] $$0 = new int[1];
      AL10.alGenSources($$0);
      return OpenAlUtil.checkALError("Allocate new source") ? null : new Channel($$0[0]);
   }

   private Channel(int p52621cbf_0_0) {
      this.source = p52621cbf_0_0;
   }

   public void destroy() {
      if (this.initialized.compareAndSet(true, false)) {
         AL10.alSourceStop(this.source);
         OpenAlUtil.checkALError("Stop");
         if (this.stream != null) {
            try {
               this.stream.close();
            } catch (IOException $$0) {
               LOGGER.error("Failed to close audio stream", $$0);
            }

            this.removeProcessedBuffers();
            this.stream = null;
         }

         AL10.alDeleteSources(new int[]{this.source});
         OpenAlUtil.checkALError("Cleanup");
      }
   }

   public void play() {
      AL10.alSourcePlay(this.source);
   }

   private int getState() {
      return !this.initialized.get() ? 4116 : AL10.alGetSourcei(this.source, 4112);
   }

   public void pause() {
      if (this.getState() == 4114) {
         AL10.alSourcePause(this.source);
      }
   }

   public void unpause() {
      if (this.getState() == 4115) {
         AL10.alSourcePlay(this.source);
      }
   }

   public void stop() {
      if (this.initialized.get()) {
         AL10.alSourceStop(this.source);
         OpenAlUtil.checkALError("Stop");
      }
   }

   public boolean playing() {
      return this.getState() == 4114;
   }

   public boolean stopped() {
      return this.getState() == 4116;
   }

   public void setSelfPosition(Vec3 p52621cbf_1_0) {
      AL10.alSourcefv(this.source, 4100, new float[]{(float)p52621cbf_1_0.x, (float)p52621cbf_1_0.y, (float)p52621cbf_1_0.z});
   }

   public void setPitch(float p52621cbf_2_0) {
      AL10.alSourcef(this.source, 4099, p52621cbf_2_0);
   }

   public void setLooping(boolean p52621cbf_3_0) {
      AL10.alSourcei(this.source, 4103, p52621cbf_3_0 ? 1 : 0);
   }

   public void setVolume(float p52621cbf_4_0) {
      AL10.alSourcef(this.source, 4106, p52621cbf_4_0);
   }

   public void disableAttenuation() {
      AL10.alSourcei(this.source, 53248, 0);
   }

   public void linearAttenuation(float p52621cbf_5_0) {
      AL10.alSourcei(this.source, 53248, 53251);
      AL10.alSourcef(this.source, 4131, p52621cbf_5_0);
      AL10.alSourcef(this.source, 4129, 1.0F);
      AL10.alSourcef(this.source, 4128, 0.0F);
   }

   public void setRelative(boolean p52621cbf_6_0) {
      AL10.alSourcei(this.source, 514, p52621cbf_6_0 ? 1 : 0);
   }

   public void attachStaticBuffer(SoundBuffer p52621cbf_7_0) {
      p52621cbf_7_0.getAlBuffer().ifPresent(p52621cbf_13_0 -> AL10.alSourcei(this.source, 4105, p52621cbf_13_0));
   }

   public void attachBufferStream(AudioStream p52621cbf_8_0) {
      this.stream = p52621cbf_8_0;
      AudioFormat $$1 = p52621cbf_8_0.getFormat();
      this.streamingBufferSize = calculateBufferSize($$1, 1);
      this.pumpBuffers(4);
   }

   private static int calculateBufferSize(AudioFormat p52621cbf_9_0, int p52621cbf_10_1) {
      return (int)(p52621cbf_10_1 * p52621cbf_9_0.getSampleSizeInBits() / 8.0F * p52621cbf_9_0.getChannels() * p52621cbf_9_0.getSampleRate());
   }

   private void pumpBuffers(int p52621cbf_11_0) {
      if (this.stream != null) {
         try {
            for (int $$1 = 0; $$1 < p52621cbf_11_0; $$1++) {
               ByteBuffer $$2 = this.stream.read(this.streamingBufferSize);
               if ($$2 != null) {
                  new SoundBuffer($$2, this.stream.getFormat())
                     .releaseAlBuffer()
                     .ifPresent(p52621cbf_12_0 -> AL10.alSourceQueueBuffers(this.source, new int[]{p52621cbf_12_0}));
               }
            }
         } catch (IOException $$3) {
            LOGGER.error("Failed to read from audio stream", $$3);
         }
      }
   }

   public void updateStream() {
      if (this.stream != null) {
         int $$0 = this.removeProcessedBuffers();
         this.pumpBuffers($$0);
      }
   }

   private int removeProcessedBuffers() {
      int $$0 = AL10.alGetSourcei(this.source, 4118);
      if ($$0 > 0) {
         int[] $$1 = new int[$$0];
         AL10.alSourceUnqueueBuffers(this.source, $$1);
         OpenAlUtil.checkALError("Unqueue buffers");
         AL10.alDeleteBuffers($$1);
         OpenAlUtil.checkALError("Remove processed buffers");
      }

      return $$0;
   }
}
