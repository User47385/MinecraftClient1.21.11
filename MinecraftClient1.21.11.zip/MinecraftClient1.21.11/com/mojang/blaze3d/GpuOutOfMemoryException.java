package com.mojang.blaze3d;

public class GpuOutOfMemoryException extends RuntimeException {
   public GpuOutOfMemoryException(String p7e97594a_0_0) {
      super(p7e97594a_0_0);
   }
}
