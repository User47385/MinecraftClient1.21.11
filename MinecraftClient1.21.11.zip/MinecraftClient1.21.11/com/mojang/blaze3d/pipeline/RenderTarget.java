package com.mojang.blaze3d.pipeline;

import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import java.util.OptionalInt;
import net.minecraft.client.renderer.RenderPipelines;
import org.jspecify.annotations.Nullable;

public abstract class RenderTarget {
   private static int UNNAMED_RENDER_TARGETS = 0;
   public int width;
   public int height;
   protected final String label;
   public final boolean useDepth;
   protected @Nullable GpuTexture colorTexture;
   protected @Nullable GpuTextureView colorTextureView;
   protected @Nullable GpuTexture depthTexture;
   protected @Nullable GpuTextureView depthTextureView;

   public RenderTarget(@Nullable String p649cc949_0_0, boolean p649cc949_1_1) {
      this.label = p649cc949_0_0 == null ? "FBO " + UNNAMED_RENDER_TARGETS++ : p649cc949_0_0;
      this.useDepth = p649cc949_1_1;
   }

   public void resize(int p649cc949_2_0, int p649cc949_3_1) {
      RenderSystem.assertOnRenderThread();
      this.destroyBuffers();
      this.createBuffers(p649cc949_2_0, p649cc949_3_1);
   }

   public void destroyBuffers() {
      RenderSystem.assertOnRenderThread();
      if (this.depthTexture != null) {
         this.depthTexture.close();
         this.depthTexture = null;
      }

      if (this.depthTextureView != null) {
         this.depthTextureView.close();
         this.depthTextureView = null;
      }

      if (this.colorTexture != null) {
         this.colorTexture.close();
         this.colorTexture = null;
      }

      if (this.colorTextureView != null) {
         this.colorTextureView.close();
         this.colorTextureView = null;
      }
   }

   public void copyDepthFrom(RenderTarget p649cc949_4_0) {
      RenderSystem.assertOnRenderThread();
      if (this.depthTexture == null) {
         throw new IllegalStateException("Trying to copy depth texture to a RenderTarget without a depth texture");
      }

      if (p649cc949_4_0.depthTexture == null) {
         throw new IllegalStateException("Trying to copy depth texture from a RenderTarget without a depth texture");
      }

      RenderSystem.getDevice()
         .createCommandEncoder()
         .copyTextureToTexture(p649cc949_4_0.depthTexture, this.depthTexture, 0, 0, 0, 0, 0, this.width, this.height);
   }

   public void createBuffers(int p649cc949_5_0, int p649cc949_6_1) {
      RenderSystem.assertOnRenderThread();
      GpuDevice $$2 = RenderSystem.getDevice();
      int $$3 = $$2.getMaxTextureSize();
      if (p649cc949_5_0 > 0 && p649cc949_5_0 <= $$3 && p649cc949_6_1 > 0 && p649cc949_6_1 <= $$3) {
         this.width = p649cc949_5_0;
         this.height = p649cc949_6_1;
         if (this.useDepth) {
            this.depthTexture = $$2.createTexture(() -> this.label + " / Depth", 15, TextureFormat.DEPTH32, p649cc949_5_0, p649cc949_6_1, 1, 1);
            this.depthTextureView = $$2.createTextureView(this.depthTexture);
         }

         this.colorTexture = $$2.createTexture(() -> this.label + " / Color", 15, TextureFormat.RGBA8, p649cc949_5_0, p649cc949_6_1, 1, 1);
         this.colorTextureView = $$2.createTextureView(this.colorTexture);
      } else {
         throw new IllegalArgumentException("Window " + p649cc949_5_0 + "x" + p649cc949_6_1 + " size out of bounds (max. size: " + $$3 + ")");
      }
   }

   public void blitToScreen() {
      if (this.colorTexture == null) {
         throw new IllegalStateException("Can't blit to screen, color texture doesn't exist yet");
      }

      RenderSystem.getDevice().createCommandEncoder().presentTexture(this.colorTextureView);
   }

   public void blitAndBlendToTexture(GpuTextureView p649cc949_7_0) {
      RenderSystem.assertOnRenderThread();

      try (RenderPass $$1 = RenderSystem.getDevice().createCommandEncoder().createRenderPass(() -> "Blit render target", p649cc949_7_0, OptionalInt.empty())) {
         $$1.setPipeline(RenderPipelines.ENTITY_OUTLINE_BLIT);
         RenderSystem.bindDefaultUniforms($$1);
         $$1.bindTexture("InSampler", this.colorTextureView, RenderSystem.getSamplerCache().getClampToEdge(FilterMode.NEAREST));
         $$1.draw(0, 3);
      }
   }

   public @Nullable GpuTexture getColorTexture() {
      return this.colorTexture;
   }

   public @Nullable GpuTextureView getColorTextureView() {
      return this.colorTextureView;
   }

   public @Nullable GpuTexture getDepthTexture() {
      return this.depthTexture;
   }

   public @Nullable GpuTextureView getDepthTextureView() {
      return this.depthTextureView;
   }
}
