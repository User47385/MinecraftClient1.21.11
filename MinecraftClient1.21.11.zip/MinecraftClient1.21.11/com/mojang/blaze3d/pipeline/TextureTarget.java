package com.mojang.blaze3d.pipeline;

import com.mojang.blaze3d.systems.RenderSystem;
import org.jspecify.annotations.Nullable;

public class TextureTarget extends RenderTarget {
   public TextureTarget(@Nullable String pd1ffd04a_0_0, int pd1ffd04a_1_1, int pd1ffd04a_2_2, boolean pd1ffd04a_3_3) {
      super(pd1ffd04a_0_0, pd1ffd04a_3_3);
      RenderSystem.assertOnRenderThread();
      this.resize(pd1ffd04a_1_1, pd1ffd04a_2_2);
   }
}
