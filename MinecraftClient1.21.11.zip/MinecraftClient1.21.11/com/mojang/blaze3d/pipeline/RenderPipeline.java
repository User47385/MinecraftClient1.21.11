package com.mojang.blaze3d.pipeline;

import com.mojang.blaze3d.DontObfuscate;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.LogicOp;
import com.mojang.blaze3d.platform.PolygonMode;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Map.Entry;
import net.minecraft.SharedConstants;
import net.minecraft.client.renderer.ShaderDefines;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;

@DontObfuscate
public class RenderPipeline {
   private final Identifier location;
   private final Identifier vertexShader;
   private final Identifier fragmentShader;
   private final ShaderDefines shaderDefines;
   private final List<String> samplers;
   private final List<RenderPipeline.UniformDescription> uniforms;
   private final DepthTestFunction depthTestFunction;
   private final PolygonMode polygonMode;
   private final boolean cull;
   private final LogicOp colorLogic;
   private final Optional<BlendFunction> blendFunction;
   private final boolean writeColor;
   private final boolean writeAlpha;
   private final boolean writeDepth;
   private final VertexFormat vertexFormat;
   private final VertexFormat.Mode vertexFormatMode;
   private final float depthBiasScaleFactor;
   private final float depthBiasConstant;
   private final int sortKey;
   private static int sortKeySeed;

   protected RenderPipeline(
      Identifier pb4b9f45a_0_0,
      Identifier pb4b9f45a_1_1,
      Identifier pb4b9f45a_2_2,
      ShaderDefines pb4b9f45a_3_3,
      List<String> pb4b9f45a_4_4,
      List<RenderPipeline.UniformDescription> pb4b9f45a_5_5,
      Optional<BlendFunction> pb4b9f45a_6_6,
      DepthTestFunction pb4b9f45a_7_7,
      PolygonMode pb4b9f45a_8_8,
      boolean pb4b9f45a_9_9,
      boolean pb4b9f45a_10_10,
      boolean pb4b9f45a_11_11,
      boolean pb4b9f45a_12_12,
      LogicOp pb4b9f45a_13_13,
      VertexFormat pb4b9f45a_14_14,
      VertexFormat.Mode pb4b9f45a_15_15,
      float pb4b9f45a_16_16,
      float pb4b9f45a_17_17,
      int pb4b9f45a_18_18
   ) {
      this.location = pb4b9f45a_0_0;
      this.vertexShader = pb4b9f45a_1_1;
      this.fragmentShader = pb4b9f45a_2_2;
      this.shaderDefines = pb4b9f45a_3_3;
      this.samplers = pb4b9f45a_4_4;
      this.uniforms = pb4b9f45a_5_5;
      this.depthTestFunction = pb4b9f45a_7_7;
      this.polygonMode = pb4b9f45a_8_8;
      this.cull = pb4b9f45a_9_9;
      this.blendFunction = pb4b9f45a_6_6;
      this.writeColor = pb4b9f45a_10_10;
      this.writeAlpha = pb4b9f45a_11_11;
      this.writeDepth = pb4b9f45a_12_12;
      this.colorLogic = pb4b9f45a_13_13;
      this.vertexFormat = pb4b9f45a_14_14;
      this.vertexFormatMode = pb4b9f45a_15_15;
      this.depthBiasScaleFactor = pb4b9f45a_16_16;
      this.depthBiasConstant = pb4b9f45a_17_17;
      this.sortKey = pb4b9f45a_18_18;
   }

   public int getSortKey() {
      return SharedConstants.DEBUG_SHUFFLE_UI_RENDERING_ORDER ? super.hashCode() * (sortKeySeed + 1) : this.sortKey;
   }

   public static void updateSortKeySeed() {
      sortKeySeed = Math.round(100000.0F * (float)Math.random());
   }

   @Override
   public String toString() {
      return this.location.toString();
   }

   public DepthTestFunction getDepthTestFunction() {
      return this.depthTestFunction;
   }

   public PolygonMode getPolygonMode() {
      return this.polygonMode;
   }

   public boolean isCull() {
      return this.cull;
   }

   public LogicOp getColorLogic() {
      return this.colorLogic;
   }

   public Optional<BlendFunction> getBlendFunction() {
      return this.blendFunction;
   }

   public boolean isWriteColor() {
      return this.writeColor;
   }

   public boolean isWriteAlpha() {
      return this.writeAlpha;
   }

   public boolean isWriteDepth() {
      return this.writeDepth;
   }

   public float getDepthBiasScaleFactor() {
      return this.depthBiasScaleFactor;
   }

   public float getDepthBiasConstant() {
      return this.depthBiasConstant;
   }

   public Identifier getLocation() {
      return this.location;
   }

   public VertexFormat getVertexFormat() {
      return this.vertexFormat;
   }

   public VertexFormat.Mode getVertexFormatMode() {
      return this.vertexFormatMode;
   }

   public Identifier getVertexShader() {
      return this.vertexShader;
   }

   public Identifier getFragmentShader() {
      return this.fragmentShader;
   }

   public ShaderDefines getShaderDefines() {
      return this.shaderDefines;
   }

   public List<String> getSamplers() {
      return this.samplers;
   }

   public List<RenderPipeline.UniformDescription> getUniforms() {
      return this.uniforms;
   }

   public boolean wantsDepthTexture() {
      return this.depthTestFunction != DepthTestFunction.NO_DEPTH_TEST
         || this.depthBiasConstant != 0.0F
         || this.depthBiasScaleFactor != 0.0F
         || this.writeDepth;
   }

   public static RenderPipeline.Builder builder(RenderPipeline.Snippet... pb4b9f45a_19_0) {
      RenderPipeline.Builder $$1 = new RenderPipeline.Builder();

      for (RenderPipeline.Snippet $$2 : pb4b9f45a_19_0) {
         $$1.withSnippet($$2);
      }

      return $$1;
   }

   @DontObfuscate
   public static class Builder {
      private static int nextPipelineSortKey;
      private Optional<Identifier> location = Optional.empty();
      private Optional<Identifier> fragmentShader = Optional.empty();
      private Optional<Identifier> vertexShader = Optional.empty();
      private Optional<ShaderDefines.Builder> definesBuilder = Optional.empty();
      private Optional<List<String>> samplers = Optional.empty();
      private Optional<List<RenderPipeline.UniformDescription>> uniforms = Optional.empty();
      private Optional<DepthTestFunction> depthTestFunction = Optional.empty();
      private Optional<PolygonMode> polygonMode = Optional.empty();
      private Optional<Boolean> cull = Optional.empty();
      private Optional<Boolean> writeColor = Optional.empty();
      private Optional<Boolean> writeAlpha = Optional.empty();
      private Optional<Boolean> writeDepth = Optional.empty();
      private Optional<LogicOp> colorLogic = Optional.empty();
      private Optional<BlendFunction> blendFunction = Optional.empty();
      private Optional<VertexFormat> vertexFormat = Optional.empty();
      private Optional<VertexFormat.Mode> vertexFormatMode = Optional.empty();
      private float depthBiasScaleFactor;
      private float depthBiasConstant;

      Builder() {
      }

      public RenderPipeline.Builder withLocation(String p523bd131_0_0) {
         this.location = Optional.of(Identifier.withDefaultNamespace(p523bd131_0_0));
         return this;
      }

      public RenderPipeline.Builder withLocation(Identifier p523bd131_1_0) {
         this.location = Optional.of(p523bd131_1_0);
         return this;
      }

      public RenderPipeline.Builder withFragmentShader(String p523bd131_2_0) {
         this.fragmentShader = Optional.of(Identifier.withDefaultNamespace(p523bd131_2_0));
         return this;
      }

      public RenderPipeline.Builder withFragmentShader(Identifier p523bd131_3_0) {
         this.fragmentShader = Optional.of(p523bd131_3_0);
         return this;
      }

      public RenderPipeline.Builder withVertexShader(String p523bd131_4_0) {
         this.vertexShader = Optional.of(Identifier.withDefaultNamespace(p523bd131_4_0));
         return this;
      }

      public RenderPipeline.Builder withVertexShader(Identifier p523bd131_5_0) {
         this.vertexShader = Optional.of(p523bd131_5_0);
         return this;
      }

      public RenderPipeline.Builder withShaderDefine(String p523bd131_6_0) {
         if (this.definesBuilder.isEmpty()) {
            this.definesBuilder = Optional.of(ShaderDefines.builder());
         }

         this.definesBuilder.get().define(p523bd131_6_0);
         return this;
      }

      public RenderPipeline.Builder withShaderDefine(String p523bd131_7_0, int p523bd131_8_1) {
         if (this.definesBuilder.isEmpty()) {
            this.definesBuilder = Optional.of(ShaderDefines.builder());
         }

         this.definesBuilder.get().define(p523bd131_7_0, p523bd131_8_1);
         return this;
      }

      public RenderPipeline.Builder withShaderDefine(String p523bd131_9_0, float p523bd131_10_1) {
         if (this.definesBuilder.isEmpty()) {
            this.definesBuilder = Optional.of(ShaderDefines.builder());
         }

         this.definesBuilder.get().define(p523bd131_9_0, p523bd131_10_1);
         return this;
      }

      public RenderPipeline.Builder withSampler(String p523bd131_11_0) {
         if (this.samplers.isEmpty()) {
            this.samplers = Optional.of(new ArrayList<>());
         }

         this.samplers.get().add(p523bd131_11_0);
         return this;
      }

      public RenderPipeline.Builder withUniform(String p523bd131_12_0, UniformType p523bd131_13_1) {
         if (this.uniforms.isEmpty()) {
            this.uniforms = Optional.of(new ArrayList<>());
         }

         if (p523bd131_13_1 == UniformType.TEXEL_BUFFER) {
            throw new IllegalArgumentException("Cannot use texel buffer without specifying texture format");
         }

         this.uniforms.get().add(new RenderPipeline.UniformDescription(p523bd131_12_0, p523bd131_13_1));
         return this;
      }

      public RenderPipeline.Builder withUniform(String p523bd131_14_0, UniformType p523bd131_15_1, TextureFormat p523bd131_16_2) {
         if (this.uniforms.isEmpty()) {
            this.uniforms = Optional.of(new ArrayList<>());
         }

         if (p523bd131_15_1 != UniformType.TEXEL_BUFFER) {
            throw new IllegalArgumentException("Only texel buffer can specify texture format");
         }

         this.uniforms.get().add(new RenderPipeline.UniformDescription(p523bd131_14_0, p523bd131_16_2));
         return this;
      }

      public RenderPipeline.Builder withDepthTestFunction(DepthTestFunction p523bd131_17_0) {
         this.depthTestFunction = Optional.of(p523bd131_17_0);
         return this;
      }

      public RenderPipeline.Builder withPolygonMode(PolygonMode p523bd131_18_0) {
         this.polygonMode = Optional.of(p523bd131_18_0);
         return this;
      }

      public RenderPipeline.Builder withCull(boolean p523bd131_19_0) {
         this.cull = Optional.of(p523bd131_19_0);
         return this;
      }

      public RenderPipeline.Builder withBlend(BlendFunction p523bd131_20_0) {
         this.blendFunction = Optional.of(p523bd131_20_0);
         return this;
      }

      public RenderPipeline.Builder withoutBlend() {
         this.blendFunction = Optional.empty();
         return this;
      }

      public RenderPipeline.Builder withColorWrite(boolean p523bd131_21_0) {
         this.writeColor = Optional.of(p523bd131_21_0);
         this.writeAlpha = Optional.of(p523bd131_21_0);
         return this;
      }

      public RenderPipeline.Builder withColorWrite(boolean p523bd131_22_0, boolean p523bd131_23_1) {
         this.writeColor = Optional.of(p523bd131_22_0);
         this.writeAlpha = Optional.of(p523bd131_23_1);
         return this;
      }

      public RenderPipeline.Builder withDepthWrite(boolean p523bd131_24_0) {
         this.writeDepth = Optional.of(p523bd131_24_0);
         return this;
      }

      @Deprecated
      public RenderPipeline.Builder withColorLogic(LogicOp p523bd131_25_0) {
         this.colorLogic = Optional.of(p523bd131_25_0);
         return this;
      }

      public RenderPipeline.Builder withVertexFormat(VertexFormat p523bd131_26_0, VertexFormat.Mode p523bd131_27_1) {
         this.vertexFormat = Optional.of(p523bd131_26_0);
         this.vertexFormatMode = Optional.of(p523bd131_27_1);
         return this;
      }

      public RenderPipeline.Builder withDepthBias(float p523bd131_28_0, float p523bd131_29_1) {
         this.depthBiasScaleFactor = p523bd131_28_0;
         this.depthBiasConstant = p523bd131_29_1;
         return this;
      }

      void withSnippet(RenderPipeline.Snippet p523bd131_30_0) {
         if (p523bd131_30_0.vertexShader.isPresent()) {
            this.vertexShader = p523bd131_30_0.vertexShader;
         }

         if (p523bd131_30_0.fragmentShader.isPresent()) {
            this.fragmentShader = p523bd131_30_0.fragmentShader;
         }

         if (p523bd131_30_0.shaderDefines.isPresent()) {
            if (this.definesBuilder.isEmpty()) {
               this.definesBuilder = Optional.of(ShaderDefines.builder());
            }

            ShaderDefines $$1 = p523bd131_30_0.shaderDefines.get();

            for (Entry<String, String> $$2 : $$1.values().entrySet()) {
               this.definesBuilder.get().define($$2.getKey(), $$2.getValue());
            }

            for (String $$3 : $$1.flags()) {
               this.definesBuilder.get().define($$3);
            }
         }

         p523bd131_30_0.samplers.ifPresent(p523bd131_32_0 -> {
            if (this.samplers.isPresent()) {
               this.samplers.get().addAll((Collection<? extends String>)p523bd131_32_0);
            } else {
               this.samplers = Optional.of(new ArrayList<>((Collection<? extends String>)p523bd131_32_0));
            }
         });
         p523bd131_30_0.uniforms.ifPresent(p523bd131_31_0 -> {
            if (this.uniforms.isPresent()) {
               this.uniforms.get().addAll((Collection<? extends RenderPipeline.UniformDescription>)p523bd131_31_0);
            } else {
               this.uniforms = Optional.of(new ArrayList<>((Collection<? extends RenderPipeline.UniformDescription>)p523bd131_31_0));
            }
         });
         if (p523bd131_30_0.depthTestFunction.isPresent()) {
            this.depthTestFunction = p523bd131_30_0.depthTestFunction;
         }

         if (p523bd131_30_0.cull.isPresent()) {
            this.cull = p523bd131_30_0.cull;
         }

         if (p523bd131_30_0.writeColor.isPresent()) {
            this.writeColor = p523bd131_30_0.writeColor;
         }

         if (p523bd131_30_0.writeAlpha.isPresent()) {
            this.writeAlpha = p523bd131_30_0.writeAlpha;
         }

         if (p523bd131_30_0.writeDepth.isPresent()) {
            this.writeDepth = p523bd131_30_0.writeDepth;
         }

         if (p523bd131_30_0.colorLogic.isPresent()) {
            this.colorLogic = p523bd131_30_0.colorLogic;
         }

         if (p523bd131_30_0.blendFunction.isPresent()) {
            this.blendFunction = p523bd131_30_0.blendFunction;
         }

         if (p523bd131_30_0.vertexFormat.isPresent()) {
            this.vertexFormat = p523bd131_30_0.vertexFormat;
         }

         if (p523bd131_30_0.vertexFormatMode.isPresent()) {
            this.vertexFormatMode = p523bd131_30_0.vertexFormatMode;
         }
      }

      public RenderPipeline.Snippet buildSnippet() {
         return new RenderPipeline.Snippet(
            this.vertexShader,
            this.fragmentShader,
            this.definesBuilder.map(ShaderDefines.Builder::build),
            this.samplers.map(Collections::unmodifiableList),
            this.uniforms.map(Collections::unmodifiableList),
            this.blendFunction,
            this.depthTestFunction,
            this.polygonMode,
            this.cull,
            this.writeColor,
            this.writeAlpha,
            this.writeDepth,
            this.colorLogic,
            this.vertexFormat,
            this.vertexFormatMode
         );
      }

      public RenderPipeline build() {
         if (this.location.isEmpty()) {
            throw new IllegalStateException("Missing location");
         } else if (this.vertexShader.isEmpty()) {
            throw new IllegalStateException("Missing vertex shader");
         } else if (this.fragmentShader.isEmpty()) {
            throw new IllegalStateException("Missing fragment shader");
         } else if (this.vertexFormat.isEmpty()) {
            throw new IllegalStateException("Missing vertex buffer format");
         } else if (this.vertexFormatMode.isEmpty()) {
            throw new IllegalStateException("Missing vertex mode");
         } else {
            return new RenderPipeline(
               this.location.get(),
               this.vertexShader.get(),
               this.fragmentShader.get(),
               this.definesBuilder.orElse(ShaderDefines.builder()).build(),
               List.copyOf(this.samplers.orElse(new ArrayList<>())),
               this.uniforms.orElse(Collections.emptyList()),
               this.blendFunction,
               this.depthTestFunction.orElse(DepthTestFunction.LEQUAL_DEPTH_TEST),
               this.polygonMode.orElse(PolygonMode.FILL),
               this.cull.orElse(true),
               this.writeColor.orElse(true),
               this.writeAlpha.orElse(true),
               this.writeDepth.orElse(true),
               this.colorLogic.orElse(LogicOp.NONE),
               this.vertexFormat.get(),
               this.vertexFormatMode.get(),
               this.depthBiasScaleFactor,
               this.depthBiasConstant,
               nextPipelineSortKey++
            );
         }
      }
   }

   @DontObfuscate
   public record Snippet(
      Optional<Identifier> vertexShader,
      Optional<Identifier> fragmentShader,
      Optional<ShaderDefines> shaderDefines,
      Optional<List<String>> samplers,
      Optional<List<RenderPipeline.UniformDescription>> uniforms,
      Optional<BlendFunction> blendFunction,
      Optional<DepthTestFunction> depthTestFunction,
      Optional<PolygonMode> polygonMode,
      Optional<Boolean> cull,
      Optional<Boolean> writeColor,
      Optional<Boolean> writeAlpha,
      Optional<Boolean> writeDepth,
      Optional<LogicOp> colorLogic,
      Optional<VertexFormat> vertexFormat,
      Optional<VertexFormat.Mode> vertexFormatMode
   ) {
   }

   @DontObfuscate
   public record UniformDescription(String name, UniformType type, @Nullable TextureFormat textureFormat) {
      public UniformDescription(String pfa485e52_0_0, UniformType pfa485e52_1_1) {
         this(pfa485e52_0_0, pfa485e52_1_1, null);
         if (pfa485e52_1_1 == UniformType.TEXEL_BUFFER) {
            throw new IllegalArgumentException("Texel buffer needs a texture format");
         }
      }

      public UniformDescription(String pfa485e52_2_0, TextureFormat pfa485e52_3_1) {
         this(pfa485e52_2_0, UniformType.TEXEL_BUFFER, pfa485e52_3_1);
      }
   }
}
