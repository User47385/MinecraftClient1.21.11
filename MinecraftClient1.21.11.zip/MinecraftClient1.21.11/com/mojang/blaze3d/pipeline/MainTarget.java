package com.mojang.blaze3d.pipeline;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.GpuOutOfMemoryException;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.TextureFormat;
import java.util.List;
import java.util.Objects;
import org.jspecify.annotations.Nullable;

public class MainTarget extends RenderTarget {
   public static final int DEFAULT_WIDTH = 854;
   public static final int DEFAULT_HEIGHT = 480;
   static final MainTarget.Dimension DEFAULT_DIMENSIONS = new MainTarget.Dimension(854, 480);

   public MainTarget(int pdb2a5fac_0_0, int pdb2a5fac_1_1) {
      super("Main", true);
      this.createFrameBuffer(pdb2a5fac_0_0, pdb2a5fac_1_1);
   }

   private void createFrameBuffer(int pdb2a5fac_2_0, int pdb2a5fac_3_1) {
      MainTarget.Dimension $$2 = this.allocateAttachments(pdb2a5fac_2_0, pdb2a5fac_3_1);
      if (this.colorTexture != null && this.depthTexture != null) {
         this.width = $$2.width;
         this.height = $$2.height;
      } else {
         throw new IllegalStateException("Missing color and/or depth textures");
      }
   }

   private MainTarget.Dimension allocateAttachments(int pdb2a5fac_4_0, int pdb2a5fac_5_1) {
      RenderSystem.assertOnRenderThread();

      for (MainTarget.Dimension $$2 : MainTarget.Dimension.listWithFallback(pdb2a5fac_4_0, pdb2a5fac_5_1)) {
         if (this.colorTexture != null) {
            this.colorTexture.close();
            this.colorTexture = null;
         }

         if (this.colorTextureView != null) {
            this.colorTextureView.close();
            this.colorTextureView = null;
         }

         if (this.depthTexture != null) {
            this.depthTexture.close();
            this.depthTexture = null;
         }

         if (this.depthTextureView != null) {
            this.depthTextureView.close();
            this.depthTextureView = null;
         }

         this.colorTexture = this.allocateColorAttachment($$2);
         this.depthTexture = this.allocateDepthAttachment($$2);
         if (this.colorTexture != null && this.depthTexture != null) {
            this.colorTextureView = RenderSystem.getDevice().createTextureView(this.colorTexture);
            this.depthTextureView = RenderSystem.getDevice().createTextureView(this.depthTexture);
            return $$2;
         }
      }

      throw new RuntimeException(
         "Unrecoverable GL_OUT_OF_MEMORY ("
            + (this.colorTexture == null ? "missing color" : "have color")
            + ", "
            + (this.depthTexture == null ? "missing depth" : "have depth")
            + ")"
      );
   }

   private @Nullable GpuTexture allocateColorAttachment(MainTarget.Dimension pdb2a5fac_6_0) {
      try {
         return RenderSystem.getDevice().createTexture(() -> this.label + " / Color", 15, TextureFormat.RGBA8, pdb2a5fac_6_0.width, pdb2a5fac_6_0.height, 1, 1);
      } catch (GpuOutOfMemoryException $$1) {
         return null;
      }
   }

   private @Nullable GpuTexture allocateDepthAttachment(MainTarget.Dimension pdb2a5fac_7_0) {
      try {
         return RenderSystem.getDevice()
            .createTexture(() -> this.label + " / Depth", 15, TextureFormat.DEPTH32, pdb2a5fac_7_0.width, pdb2a5fac_7_0.height, 1, 1);
      } catch (GpuOutOfMemoryException $$1) {
         return null;
      }
   }

   static class Dimension {
      public final int width;
      public final int height;

      Dimension(int pe7292e4e_0_0, int pe7292e4e_1_1) {
         this.width = pe7292e4e_0_0;
         this.height = pe7292e4e_1_1;
      }

      static List<MainTarget.Dimension> listWithFallback(int pe7292e4e_2_0, int pe7292e4e_3_1) {
         RenderSystem.assertOnRenderThread();
         int $$2 = RenderSystem.getDevice().getMaxTextureSize();
         return pe7292e4e_2_0 > 0 && pe7292e4e_2_0 <= $$2 && pe7292e4e_3_1 > 0 && pe7292e4e_3_1 <= $$2
            ? ImmutableList.of(new MainTarget.Dimension(pe7292e4e_2_0, pe7292e4e_3_1), MainTarget.DEFAULT_DIMENSIONS)
            : ImmutableList.of(MainTarget.DEFAULT_DIMENSIONS);
      }

      @Override
      public boolean equals(Object pe7292e4e_4_0) {
         if (this == pe7292e4e_4_0) {
            return true;
         } else if (pe7292e4e_4_0 != null && this.getClass() == pe7292e4e_4_0.getClass()) {
            MainTarget.Dimension $$1 = (MainTarget.Dimension)pe7292e4e_4_0;
            return this.width == $$1.width && this.height == $$1.height;
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         return Objects.hash(this.width, this.height);
      }

      @Override
      public String toString() {
         return this.width + "x" + this.height;
      }
   }
}
