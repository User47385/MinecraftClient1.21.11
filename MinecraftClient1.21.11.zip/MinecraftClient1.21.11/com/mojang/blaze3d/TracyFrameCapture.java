package com.mojang.blaze3d;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.jtracy.TracyClient;
import java.util.OptionalInt;
import net.minecraft.client.renderer.RenderPipelines;

public class TracyFrameCapture implements AutoCloseable {
   private static final int MAX_WIDTH = 320;
   private static final int MAX_HEIGHT = 180;
   private static final long BYTES_PER_PIXEL = 4L;
   private int targetWidth;
   private int targetHeight;
   private int width;
   private int height;
   private GpuTexture frameBuffer;
   private GpuTextureView frameBufferView;
   private GpuBuffer pixelbuffer;
   private int lastCaptureDelay;
   private boolean capturedThisFrame;
   private TracyFrameCapture.Status status = TracyFrameCapture.Status.WAITING_FOR_CAPTURE;

   public TracyFrameCapture() {
      this.width = 320;
      this.height = 180;
      GpuDevice $$0 = RenderSystem.getDevice();
      this.frameBuffer = $$0.createTexture("Tracy Frame Capture", 10, TextureFormat.RGBA8, this.width, this.height, 1, 1);
      this.frameBufferView = $$0.createTextureView(this.frameBuffer);
      this.pixelbuffer = $$0.createBuffer(() -> "Tracy Frame Capture buffer", 9, this.width * this.height * 4L);
   }

   private void resize(int pdda5cb87_0_0, int pdda5cb87_1_1) {
      float $$2 = (float)pdda5cb87_0_0 / pdda5cb87_1_1;
      if (pdda5cb87_0_0 > 320) {
         pdda5cb87_0_0 = 320;
         pdda5cb87_1_1 = (int)(320.0F / $$2);
      }

      if (pdda5cb87_1_1 > 180) {
         pdda5cb87_0_0 = (int)(180.0F * $$2);
         pdda5cb87_1_1 = 180;
      }

      pdda5cb87_0_0 = pdda5cb87_0_0 / 4 * 4;
      pdda5cb87_1_1 = pdda5cb87_1_1 / 4 * 4;
      if (this.width != pdda5cb87_0_0 || this.height != pdda5cb87_1_1) {
         this.width = pdda5cb87_0_0;
         this.height = pdda5cb87_1_1;
         GpuDevice $$3 = RenderSystem.getDevice();
         this.frameBuffer.close();
         this.frameBuffer = $$3.createTexture("Tracy Frame Capture", 10, TextureFormat.RGBA8, pdda5cb87_0_0, pdda5cb87_1_1, 1, 1);
         this.frameBufferView.close();
         this.frameBufferView = $$3.createTextureView(this.frameBuffer);
         this.pixelbuffer.close();
         this.pixelbuffer = $$3.createBuffer(() -> "Tracy Frame Capture buffer", 9, pdda5cb87_0_0 * pdda5cb87_1_1 * 4L);
      }
   }

   public void capture(RenderTarget pdda5cb87_2_0) {
      if (this.status == TracyFrameCapture.Status.WAITING_FOR_CAPTURE && !this.capturedThisFrame && pdda5cb87_2_0.getColorTexture() != null) {
         this.capturedThisFrame = true;
         if (pdda5cb87_2_0.width != this.targetWidth || pdda5cb87_2_0.height != this.targetHeight) {
            this.targetWidth = pdda5cb87_2_0.width;
            this.targetHeight = pdda5cb87_2_0.height;
            this.resize(this.targetWidth, this.targetHeight);
         }

         this.status = TracyFrameCapture.Status.WAITING_FOR_COPY;
         CommandEncoder $$1 = RenderSystem.getDevice().createCommandEncoder();

         try (RenderPass $$2 = RenderSystem.getDevice().createCommandEncoder().createRenderPass(() -> "Tracy blit", this.frameBufferView, OptionalInt.empty())) {
            $$2.setPipeline(RenderPipelines.TRACY_BLIT);
            $$2.bindTexture("InSampler", pdda5cb87_2_0.getColorTextureView(), RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR));
            $$2.draw(0, 3);
         }

         $$1.copyTextureToBuffer(this.frameBuffer, this.pixelbuffer, 0L, () -> this.status = TracyFrameCapture.Status.WAITING_FOR_UPLOAD, 0);
         this.lastCaptureDelay = 0;
      }
   }

   public void upload() {
      if (this.status == TracyFrameCapture.Status.WAITING_FOR_UPLOAD) {
         this.status = TracyFrameCapture.Status.WAITING_FOR_CAPTURE;

         try (GpuBuffer.MappedView $$0 = RenderSystem.getDevice().createCommandEncoder().mapBuffer(this.pixelbuffer, true, false)) {
            TracyClient.frameImage($$0.data(), this.width, this.height, this.lastCaptureDelay, true);
         }
      }
   }

   public void endFrame() {
      this.lastCaptureDelay++;
      this.capturedThisFrame = false;
      TracyClient.markFrame();
   }

   @Override
   public void close() {
      this.frameBuffer.close();
      this.frameBufferView.close();
      this.pixelbuffer.close();
   }

   enum Status {
      WAITING_FOR_CAPTURE,
      WAITING_FOR_COPY,
      WAITING_FOR_UPLOAD;
   }
}
