package com.mojang.blaze3d.font;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.ints.IntSet;
import it.unimi.dsi.fastutil.ints.IntSets;
import java.util.Map;
import net.minecraft.client.gui.font.glyphs.EmptyGlyph;
import net.minecraft.client.gui.font.providers.GlyphProviderDefinition;
import net.minecraft.client.gui.font.providers.GlyphProviderType;
import net.minecraft.util.ExtraCodecs;
import org.jspecify.annotations.Nullable;

public class SpaceProvider implements GlyphProvider {
   private final Int2ObjectMap<EmptyGlyph> glyphs;

   public SpaceProvider(Map<Integer, Float> p23b67f42_0_0) {
      this.glyphs = new Int2ObjectOpenHashMap<>(p23b67f42_0_0.size());
      p23b67f42_0_0.forEach((p23b67f42_2_0, p23b67f42_3_1) -> this.glyphs.put(p23b67f42_2_0.intValue(), new EmptyGlyph(p23b67f42_3_1)));
   }

   @Override
   public @Nullable UnbakedGlyph getGlyph(int p23b67f42_1_0) {
      return this.glyphs.get(p23b67f42_1_0);
   }

   @Override
   public IntSet getSupportedGlyphs() {
      return IntSets.unmodifiable(this.glyphs.keySet());
   }

   public record Definition(Map<Integer, Float> advances) implements GlyphProviderDefinition {
      public static final MapCodec<SpaceProvider.Definition> CODEC = RecordCodecBuilder.mapCodec(
         pd5e4f815_3_0 -> pd5e4f815_3_0.group(
               Codec.unboundedMap(ExtraCodecs.CODEPOINT, Codec.FLOAT).fieldOf("advances").forGetter(SpaceProvider.Definition::advances)
            )
            .apply(pd5e4f815_3_0, SpaceProvider.Definition::new)
      );

      @Override
      public GlyphProviderType type() {
         return GlyphProviderType.SPACE;
      }

      @Override
      public Either<GlyphProviderDefinition.Loader, GlyphProviderDefinition.Reference> unpack() {
         GlyphProviderDefinition.Loader $$0 = pd5e4f815_2_0 -> new SpaceProvider(this.advances);
         return Either.left($$0);
      }
   }
}
