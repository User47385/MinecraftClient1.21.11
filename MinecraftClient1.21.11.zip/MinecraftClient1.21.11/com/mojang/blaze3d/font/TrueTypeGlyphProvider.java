package com.mojang.blaze3d.font;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import it.unimi.dsi.fastutil.ints.IntArraySet;
import it.unimi.dsi.fastutil.ints.IntSet;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.Locale;
import net.minecraft.client.gui.font.CodepointMap;
import net.minecraft.client.gui.font.glyphs.BakedGlyph;
import net.minecraft.client.gui.font.glyphs.EmptyGlyph;
import net.minecraft.client.gui.font.providers.FreeTypeUtil;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.freetype.FT_Bitmap;
import org.lwjgl.util.freetype.FT_Face;
import org.lwjgl.util.freetype.FT_GlyphSlot;
import org.lwjgl.util.freetype.FT_Vector;
import org.lwjgl.util.freetype.FreeType;

public class TrueTypeGlyphProvider implements GlyphProvider {
   private @Nullable ByteBuffer fontMemory;
   private @Nullable FT_Face face;
   final float oversample;
   private final CodepointMap<TrueTypeGlyphProvider.GlyphEntry> glyphs = new CodepointMap<>(
      TrueTypeGlyphProvider.GlyphEntry[]::new, TrueTypeGlyphProvider.GlyphEntry[][]::new
   );

   public TrueTypeGlyphProvider(
      ByteBuffer pf0b39560_0_0, FT_Face pf0b39560_1_1, float pf0b39560_2_2, float pf0b39560_3_3, float pf0b39560_4_4, float pf0b39560_5_5, String pf0b39560_6_6
   ) {
      this.fontMemory = pf0b39560_0_0;
      this.face = pf0b39560_1_1;
      this.oversample = pf0b39560_3_3;
      IntSet $$7 = new IntArraySet();
      pf0b39560_6_6.codePoints().forEach($$7::add);
      int $$8 = Math.round(pf0b39560_2_2 * pf0b39560_3_3);
      FreeType.FT_Set_Pixel_Sizes(pf0b39560_1_1, $$8, $$8);
      float $$9 = pf0b39560_4_4 * pf0b39560_3_3;
      float $$10 = -pf0b39560_5_5 * pf0b39560_3_3;

      try (MemoryStack $$11 = MemoryStack.stackPush()) {
         FT_Vector $$12 = FreeTypeUtil.setVector(FT_Vector.malloc($$11), $$9, $$10);
         FreeType.FT_Set_Transform(pf0b39560_1_1, null, $$12);
         IntBuffer $$13 = $$11.mallocInt(1);
         int $$14 = (int)FreeType.FT_Get_First_Char(pf0b39560_1_1, $$13);

         while (true) {
            int $$15 = $$13.get(0);
            if ($$15 == 0) {
               return;
            }

            if (!$$7.contains($$14)) {
               this.glyphs.put($$14, new TrueTypeGlyphProvider.GlyphEntry($$15));
            }

            $$14 = (int)FreeType.FT_Get_Next_Char(pf0b39560_1_1, $$14, $$13);
         }
      }
   }

   @Override
   public @Nullable UnbakedGlyph getGlyph(int pf0b39560_7_0) {
      TrueTypeGlyphProvider.GlyphEntry $$1 = this.glyphs.get(pf0b39560_7_0);
      return $$1 != null ? this.getOrLoadGlyphInfo(pf0b39560_7_0, $$1) : null;
   }

   private UnbakedGlyph getOrLoadGlyphInfo(int pf0b39560_8_0, TrueTypeGlyphProvider.GlyphEntry pf0b39560_9_1) {
      UnbakedGlyph $$2 = pf0b39560_9_1.glyph;
      if ($$2 == null) {
         FT_Face $$3 = this.validateFontOpen();
         synchronized ($$3) {
            $$2 = pf0b39560_9_1.glyph;
            if ($$2 == null) {
               $$2 = this.loadGlyph(pf0b39560_8_0, $$3, pf0b39560_9_1.index);
               pf0b39560_9_1.glyph = $$2;
            }
         }
      }

      return $$2;
   }

   private UnbakedGlyph loadGlyph(int pf0b39560_10_0, FT_Face pf0b39560_11_1, int pf0b39560_12_2) {
      int $$3 = FreeType.FT_Load_Glyph(pf0b39560_11_1, pf0b39560_12_2, 4194312);
      if ($$3 != 0) {
         FreeTypeUtil.assertError($$3, String.format(Locale.ROOT, "Loading glyph U+%06X", pf0b39560_10_0));
      }

      FT_GlyphSlot $$4 = pf0b39560_11_1.glyph();
      if ($$4 == null) {
         throw new NullPointerException(String.format(Locale.ROOT, "Glyph U+%06X not initialized", pf0b39560_10_0));
      }

      float $$5 = FreeTypeUtil.x($$4.advance());
      FT_Bitmap $$6 = $$4.bitmap();
      int $$7 = $$4.bitmap_left();
      int $$8 = $$4.bitmap_top();
      int $$9 = $$6.width();
      int $$10 = $$6.rows();
      return $$9 > 0 && $$10 > 0 ? new TrueTypeGlyphProvider.Glyph($$7, $$8, $$9, $$10, $$5, pf0b39560_12_2) : new EmptyGlyph($$5 / this.oversample);
   }

   FT_Face validateFontOpen() {
      if (this.fontMemory != null && this.face != null) {
         return this.face;
      } else {
         throw new IllegalStateException("Provider already closed");
      }
   }

   @Override
   public void close() {
      if (this.face != null) {
         synchronized (FreeTypeUtil.LIBRARY_LOCK) {
            FreeTypeUtil.checkError(FreeType.FT_Done_Face(this.face), "Deleting face");
         }

         this.face = null;
      }

      MemoryUtil.memFree(this.fontMemory);
      this.fontMemory = null;
   }

   @Override
   public IntSet getSupportedGlyphs() {
      return this.glyphs.keySet();
   }

   class Glyph implements UnbakedGlyph {
      final int width;
      final int height;
      final float bearingX;
      final float bearingY;
      private final GlyphInfo info;
      final int index;

      Glyph(
         final float p76cff4c8_1_1,
         final float p76cff4c8_2_2,
         final int p76cff4c8_3_3,
         final int p76cff4c8_4_4,
         final float p76cff4c8_5_5,
         final int p76cff4c8_6_6
      ) {
         this.width = p76cff4c8_3_3;
         this.height = p76cff4c8_4_4;
         this.info = GlyphInfo.simple(p76cff4c8_5_5 / TrueTypeGlyphProvider.this.oversample);
         this.bearingX = p76cff4c8_1_1 / TrueTypeGlyphProvider.this.oversample;
         this.bearingY = p76cff4c8_2_2 / TrueTypeGlyphProvider.this.oversample;
         this.index = p76cff4c8_6_6;
      }

      @Override
      public GlyphInfo info() {
         return this.info;
      }

      @Override
      public BakedGlyph bake(UnbakedGlyph.Stitcher p76cff4c8_7_0) {
         return p76cff4c8_7_0.stitch(
            this.info,
            new GlyphBitmap() {
               @Override
               public int getPixelWidth() {
                  return Glyph.this.width;
               }

               @Override
               public int getPixelHeight() {
                  return Glyph.this.height;
               }

               @Override
               public float getOversample() {
                  return TrueTypeGlyphProvider.this.oversample;
               }

               @Override
               public float getBearingLeft() {
                  return Glyph.this.bearingX;
               }

               @Override
               public float getBearingTop() {
                  return Glyph.this.bearingY;
               }

               @Override
               public void upload(int p2a5e755_1_0, int p2a5e755_2_1, GpuTexture p2a5e755_3_2) {
                  FT_Face $$3 = TrueTypeGlyphProvider.this.validateFontOpen();

                  try (NativeImage $$4 = new NativeImage(NativeImage.Format.LUMINANCE, Glyph.this.width, Glyph.this.height, false)) {
                     if ($$4.copyFromFont($$3, Glyph.this.index)) {
                        RenderSystem.getDevice()
                           .createCommandEncoder()
                           .writeToTexture(p2a5e755_3_2, $$4, 0, 0, p2a5e755_1_0, p2a5e755_2_1, Glyph.this.width, Glyph.this.height, 0, 0);
                     }
                  }
               }

               @Override
               public boolean isColored() {
                  return false;
               }
            }
         );
      }
   }

   static class GlyphEntry {
      final int index;
      volatile @Nullable UnbakedGlyph glyph;

      GlyphEntry(int p2a51e08a_0_0) {
         this.index = p2a51e08a_0_0;
      }
   }
}
