package com.mojang.blaze3d.font;

public interface GlyphInfo {
   float getAdvance();

   default float getAdvance(boolean p92841ba5_0_0) {
      return this.getAdvance() + (p92841ba5_0_0 ? this.getBoldOffset() : 0.0F);
   }

   default float getBoldOffset() {
      return 1.0F;
   }

   default float getShadowOffset() {
      return 1.0F;
   }

   static GlyphInfo simple(float p92841ba5_1_0) {
      return () -> p92841ba5_1_0;
   }
}
