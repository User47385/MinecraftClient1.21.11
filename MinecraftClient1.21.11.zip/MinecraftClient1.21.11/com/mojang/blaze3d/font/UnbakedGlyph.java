package com.mojang.blaze3d.font;

import net.minecraft.client.gui.font.glyphs.BakedGlyph;

public interface UnbakedGlyph {
   GlyphInfo info();

   BakedGlyph bake(UnbakedGlyph.Stitcher var1);

   interface Stitcher {
      BakedGlyph stitch(GlyphInfo var1, GlyphBitmap var2);

      BakedGlyph getMissing();
   }
}
