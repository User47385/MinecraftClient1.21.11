package com.mojang.blaze3d.framegraph;

import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import com.mojang.blaze3d.resource.ResourceDescriptor;
import com.mojang.blaze3d.resource.ResourceHandle;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collection;
import java.util.Deque;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.jspecify.annotations.Nullable;

public class FrameGraphBuilder {
   private final List<FrameGraphBuilder.InternalVirtualResource<?>> internalResources = new ArrayList<>();
   private final List<FrameGraphBuilder.ExternalResource<?>> externalResources = new ArrayList<>();
   private final List<FrameGraphBuilder.Pass> passes = new ArrayList<>();

   public FramePass addPass(String p2701dc17_0_0) {
      FrameGraphBuilder.Pass $$1 = new FrameGraphBuilder.Pass(this.passes.size(), p2701dc17_0_0);
      this.passes.add($$1);
      return $$1;
   }

   public <T> ResourceHandle<T> importExternal(String p2701dc17_1_0, T p2701dc17_2_1) {
      FrameGraphBuilder.ExternalResource<T> $$2 = new FrameGraphBuilder.ExternalResource<>(p2701dc17_1_0, null, p2701dc17_2_1);
      this.externalResources.add($$2);
      return $$2.handle;
   }

   public <T> ResourceHandle<T> createInternal(String p2701dc17_3_0, ResourceDescriptor<T> p2701dc17_4_1) {
      return this.createInternalResource(p2701dc17_3_0, p2701dc17_4_1, null).handle;
   }

   <T> FrameGraphBuilder.InternalVirtualResource<T> createInternalResource(
      String p2701dc17_5_0, ResourceDescriptor<T> p2701dc17_6_1, FrameGraphBuilder.@Nullable Pass p2701dc17_7_2
   ) {
      int $$3 = this.internalResources.size();
      FrameGraphBuilder.InternalVirtualResource<T> $$4 = new FrameGraphBuilder.InternalVirtualResource<>($$3, p2701dc17_5_0, p2701dc17_7_2, p2701dc17_6_1);
      this.internalResources.add($$4);
      return $$4;
   }

   public void execute(GraphicsResourceAllocator p2701dc17_8_0) {
      this.execute(p2701dc17_8_0, FrameGraphBuilder.Inspector.NONE);
   }

   public void execute(GraphicsResourceAllocator p2701dc17_9_0, FrameGraphBuilder.Inspector p2701dc17_10_1) {
      BitSet $$2 = this.identifyPassesToKeep();
      List<FrameGraphBuilder.Pass> $$3 = new ArrayList<>($$2.cardinality());
      BitSet $$4 = new BitSet(this.passes.size());

      for (FrameGraphBuilder.Pass $$5 : this.passes) {
         this.resolvePassOrder($$5, $$2, $$4, $$3);
      }

      this.assignResourceLifetimes($$3);

      for (FrameGraphBuilder.Pass $$6 : $$3) {
         for (FrameGraphBuilder.InternalVirtualResource<?> $$7 : $$6.resourcesToAcquire) {
            p2701dc17_10_1.acquireResource($$7.name);
            $$7.acquire(p2701dc17_9_0);
         }

         p2701dc17_10_1.beforeExecutePass($$6.name);
         $$6.task.run();
         p2701dc17_10_1.afterExecutePass($$6.name);

         for (int $$8 = $$6.resourcesToRelease.nextSetBit(0); $$8 >= 0; $$8 = $$6.resourcesToRelease.nextSetBit($$8 + 1)) {
            FrameGraphBuilder.InternalVirtualResource<?> $$9 = this.internalResources.get($$8);
            p2701dc17_10_1.releaseResource($$9.name);
            $$9.release(p2701dc17_9_0);
         }
      }
   }

   private BitSet identifyPassesToKeep() {
      Deque<FrameGraphBuilder.Pass> $$0 = new ArrayDeque<>(this.passes.size());
      BitSet $$1 = new BitSet(this.passes.size());

      for (FrameGraphBuilder.VirtualResource<?> $$2 : this.externalResources) {
         FrameGraphBuilder.Pass $$3 = $$2.handle.createdBy;
         if ($$3 != null) {
            this.discoverAllRequiredPasses($$3, $$1, $$0);
         }
      }

      for (FrameGraphBuilder.Pass $$4 : this.passes) {
         if ($$4.disableCulling) {
            this.discoverAllRequiredPasses($$4, $$1, $$0);
         }
      }

      return $$1;
   }

   private void discoverAllRequiredPasses(FrameGraphBuilder.Pass p2701dc17_11_0, BitSet p2701dc17_12_1, Deque<FrameGraphBuilder.Pass> p2701dc17_13_2) {
      p2701dc17_13_2.add(p2701dc17_11_0);

      while (!p2701dc17_13_2.isEmpty()) {
         FrameGraphBuilder.Pass $$3 = p2701dc17_13_2.poll();
         if (!p2701dc17_12_1.get($$3.id)) {
            p2701dc17_12_1.set($$3.id);

            for (int $$4 = $$3.requiredPassIds.nextSetBit(0); $$4 >= 0; $$4 = $$3.requiredPassIds.nextSetBit($$4 + 1)) {
               p2701dc17_13_2.add(this.passes.get($$4));
            }
         }
      }
   }

   private void resolvePassOrder(
      FrameGraphBuilder.Pass p2701dc17_14_0, BitSet p2701dc17_15_1, BitSet p2701dc17_16_2, List<FrameGraphBuilder.Pass> p2701dc17_17_3
   ) {
      if (p2701dc17_16_2.get(p2701dc17_14_0.id)) {
         String $$4 = p2701dc17_16_2.stream().mapToObj(p2701dc17_19_0 -> this.passes.get(p2701dc17_19_0).name).collect(Collectors.joining(", "));
         throw new IllegalStateException("Frame graph cycle detected between " + $$4);
      }

      if (p2701dc17_15_1.get(p2701dc17_14_0.id)) {
         p2701dc17_16_2.set(p2701dc17_14_0.id);
         p2701dc17_15_1.clear(p2701dc17_14_0.id);

         for (int $$5 = p2701dc17_14_0.requiredPassIds.nextSetBit(0); $$5 >= 0; $$5 = p2701dc17_14_0.requiredPassIds.nextSetBit($$5 + 1)) {
            this.resolvePassOrder(this.passes.get($$5), p2701dc17_15_1, p2701dc17_16_2, p2701dc17_17_3);
         }

         for (FrameGraphBuilder.Handle<?> $$6 : p2701dc17_14_0.writesFrom) {
            for (int $$7 = $$6.readBy.nextSetBit(0); $$7 >= 0; $$7 = $$6.readBy.nextSetBit($$7 + 1)) {
               if ($$7 != p2701dc17_14_0.id) {
                  this.resolvePassOrder(this.passes.get($$7), p2701dc17_15_1, p2701dc17_16_2, p2701dc17_17_3);
               }
            }
         }

         p2701dc17_17_3.add(p2701dc17_14_0);
         p2701dc17_16_2.clear(p2701dc17_14_0.id);
      }
   }

   private void assignResourceLifetimes(Collection<FrameGraphBuilder.Pass> p2701dc17_18_0) {
      FrameGraphBuilder.Pass[] $$1 = new FrameGraphBuilder.Pass[this.internalResources.size()];

      for (FrameGraphBuilder.Pass $$2 : p2701dc17_18_0) {
         for (int $$3 = $$2.requiredResourceIds.nextSetBit(0); $$3 >= 0; $$3 = $$2.requiredResourceIds.nextSetBit($$3 + 1)) {
            FrameGraphBuilder.InternalVirtualResource<?> $$4 = this.internalResources.get($$3);
            FrameGraphBuilder.Pass $$5 = $$1[$$3];
            $$1[$$3] = $$2;
            if ($$5 == null) {
               $$2.resourcesToAcquire.add($$4);
            } else {
               $$5.resourcesToRelease.clear($$3);
            }

            $$2.resourcesToRelease.set($$3);
         }
      }
   }

   static class ExternalResource<T> extends FrameGraphBuilder.VirtualResource<T> {
      private final T resource;

      public ExternalResource(String pcb650206_0_0, FrameGraphBuilder.@Nullable Pass pcb650206_1_1, T pcb650206_2_2) {
         super(pcb650206_0_0, pcb650206_1_1);
         this.resource = pcb650206_2_2;
      }

      @Override
      public T get() {
         return this.resource;
      }
   }

   static class Handle<T> implements ResourceHandle<T> {
      final FrameGraphBuilder.VirtualResource<T> holder;
      private final int version;
      final FrameGraphBuilder.@Nullable Pass createdBy;
      final BitSet readBy = new BitSet();
      private FrameGraphBuilder.@Nullable Handle<T> aliasedBy;

      Handle(FrameGraphBuilder.VirtualResource<T> pee715b75_0_0, int pee715b75_1_1, FrameGraphBuilder.@Nullable Pass pee715b75_2_2) {
         this.holder = pee715b75_0_0;
         this.version = pee715b75_1_1;
         this.createdBy = pee715b75_2_2;
      }

      @Override
      public T get() {
         return this.holder.get();
      }

      FrameGraphBuilder.Handle<T> writeAndAlias(FrameGraphBuilder.Pass pee715b75_3_0) {
         if (this.holder.handle != this) {
            throw new IllegalStateException("Handle " + this + " is no longer valid, as its contents were moved into " + this.aliasedBy);
         }

         FrameGraphBuilder.Handle<T> $$1 = new FrameGraphBuilder.Handle<>(this.holder, this.version + 1, pee715b75_3_0);
         this.holder.handle = $$1;
         this.aliasedBy = $$1;
         return $$1;
      }

      @Override
      public String toString() {
         return this.createdBy != null ? this.holder + "#" + this.version + " (from " + this.createdBy + ")" : this.holder + "#" + this.version;
      }
   }

   public interface Inspector {
      FrameGraphBuilder.Inspector NONE = new FrameGraphBuilder.Inspector() {};

      default void acquireResource(String pd0cd2e8a_0_0) {
      }

      default void releaseResource(String pd0cd2e8a_1_0) {
      }

      default void beforeExecutePass(String pd0cd2e8a_2_0) {
      }

      default void afterExecutePass(String pd0cd2e8a_3_0) {
      }
   }

   static class InternalVirtualResource<T> extends FrameGraphBuilder.VirtualResource<T> {
      final int id;
      private final ResourceDescriptor<T> descriptor;
      private @Nullable T physicalResource;

      public InternalVirtualResource(
         int pba39c20f_0_0, String pba39c20f_1_1, FrameGraphBuilder.@Nullable Pass pba39c20f_2_2, ResourceDescriptor<T> pba39c20f_3_3
      ) {
         super(pba39c20f_1_1, pba39c20f_2_2);
         this.id = pba39c20f_0_0;
         this.descriptor = pba39c20f_3_3;
      }

      @Override
      public T get() {
         return Objects.requireNonNull(this.physicalResource, "Resource is not currently available");
      }

      public void acquire(GraphicsResourceAllocator pba39c20f_4_0) {
         if (this.physicalResource != null) {
            throw new IllegalStateException("Tried to acquire physical resource, but it was already assigned");
         }

         this.physicalResource = pba39c20f_4_0.acquire(this.descriptor);
      }

      public void release(GraphicsResourceAllocator pba39c20f_5_0) {
         if (this.physicalResource == null) {
            throw new IllegalStateException("Tried to release physical resource that was not allocated");
         }

         pba39c20f_5_0.release(this.descriptor, this.physicalResource);
         this.physicalResource = null;
      }
   }

   class Pass implements FramePass {
      final int id;
      final String name;
      final List<FrameGraphBuilder.Handle<?>> writesFrom = new ArrayList<>();
      final BitSet requiredResourceIds = new BitSet();
      final BitSet requiredPassIds = new BitSet();
      Runnable task = () -> {};
      final List<FrameGraphBuilder.InternalVirtualResource<?>> resourcesToAcquire = new ArrayList<>();
      final BitSet resourcesToRelease = new BitSet();
      boolean disableCulling;

      public Pass(final int pa528409e_1_1, final String pa528409e_2_2) {
         this.id = pa528409e_1_1;
         this.name = pa528409e_2_2;
      }

      private <T> void markResourceRequired(FrameGraphBuilder.Handle<T> pa528409e_3_0) {
         if (pa528409e_3_0.holder instanceof FrameGraphBuilder.InternalVirtualResource<?> $$1) {
            this.requiredResourceIds.set($$1.id);
         }
      }

      private void markPassRequired(FrameGraphBuilder.Pass pa528409e_4_0) {
         this.requiredPassIds.set(pa528409e_4_0.id);
      }

      @Override
      public <T> ResourceHandle<T> createsInternal(String pa528409e_5_0, ResourceDescriptor<T> pa528409e_6_1) {
         FrameGraphBuilder.InternalVirtualResource<T> $$2 = FrameGraphBuilder.this.createInternalResource(pa528409e_5_0, pa528409e_6_1, this);
         this.requiredResourceIds.set($$2.id);
         return $$2.handle;
      }

      @Override
      public <T> void reads(ResourceHandle<T> pa528409e_7_0) {
         this._reads((FrameGraphBuilder.Handle<T>)pa528409e_7_0);
      }

      private <T> void _reads(FrameGraphBuilder.Handle<T> pa528409e_8_0) {
         this.markResourceRequired(pa528409e_8_0);
         if (pa528409e_8_0.createdBy != null) {
            this.markPassRequired(pa528409e_8_0.createdBy);
         }

         pa528409e_8_0.readBy.set(this.id);
      }

      @Override
      public <T> ResourceHandle<T> readsAndWrites(ResourceHandle<T> pa528409e_9_0) {
         return this._readsAndWrites((FrameGraphBuilder.Handle<T>)pa528409e_9_0);
      }

      @Override
      public void requires(FramePass pa528409e_10_0) {
         this.requiredPassIds.set(((FrameGraphBuilder.Pass)pa528409e_10_0).id);
      }

      @Override
      public void disableCulling() {
         this.disableCulling = true;
      }

      private <T> FrameGraphBuilder.Handle<T> _readsAndWrites(FrameGraphBuilder.Handle<T> pa528409e_11_0) {
         this.writesFrom.add(pa528409e_11_0);
         this._reads(pa528409e_11_0);
         return pa528409e_11_0.writeAndAlias(this);
      }

      @Override
      public void executes(Runnable pa528409e_12_0) {
         this.task = pa528409e_12_0;
      }

      @Override
      public String toString() {
         return this.name;
      }
   }

   abstract static class VirtualResource<T> {
      public final String name;
      public FrameGraphBuilder.Handle<T> handle;

      public VirtualResource(String p96d3c58c_0_0, FrameGraphBuilder.@Nullable Pass p96d3c58c_1_1) {
         this.name = p96d3c58c_0_0;
         this.handle = new FrameGraphBuilder.Handle<>(this, 0, p96d3c58c_1_1);
      }

      public abstract T get();

      @Override
      public String toString() {
         return this.name;
      }
   }
}
