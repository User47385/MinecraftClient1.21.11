package com.mojang.blaze3d.platform;

import java.util.OptionalInt;

public record DisplayData(int width, int height, OptionalInt fullscreenWidth, OptionalInt fullscreenHeight, boolean isFullscreen) {
   public DisplayData withSize(int pec694d1b_5_0, int pec694d1b_6_1) {
      return new DisplayData(pec694d1b_5_0, pec694d1b_6_1, this.fullscreenWidth, this.fullscreenHeight, this.isFullscreen);
   }

   public DisplayData withFullscreen(boolean pec694d1b_7_0) {
      return new DisplayData(this.width, this.height, this.fullscreenWidth, this.fullscreenHeight, pec694d1b_7_0);
   }
}
