package com.mojang.blaze3d.platform;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import org.jspecify.annotations.Nullable;
import org.lwjgl.PointerBuffer;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWMonitorCallback;
import org.slf4j.Logger;

public class ScreenManager {
   private static final Logger LOGGER = LogUtils.getLogger();
   private final Long2ObjectMap<Monitor> monitors = new Long2ObjectOpenHashMap<>();
   private final MonitorCreator monitorCreator;

   public ScreenManager(MonitorCreator p81eaaf70_0_0) {
      this.monitorCreator = p81eaaf70_0_0;
      GLFW.glfwSetMonitorCallback(this::onMonitorChange);
      PointerBuffer $$1 = GLFW.glfwGetMonitors();
      if ($$1 != null) {
         for (int $$2 = 0; $$2 < $$1.limit(); $$2++) {
            long $$3 = $$1.get($$2);
            this.monitors.put($$3, p81eaaf70_0_0.createMonitor($$3));
         }
      }
   }

   private void onMonitorChange(long p81eaaf70_1_0, int p81eaaf70_2_1) {
      RenderSystem.assertOnRenderThread();
      if (p81eaaf70_2_1 == 262145) {
         this.monitors.put(p81eaaf70_1_0, this.monitorCreator.createMonitor(p81eaaf70_1_0));
         LOGGER.debug("Monitor {} connected. Current monitors: {}", p81eaaf70_1_0, this.monitors);
      } else if (p81eaaf70_2_1 == 262146) {
         this.monitors.remove(p81eaaf70_1_0);
         LOGGER.debug("Monitor {} disconnected. Current monitors: {}", p81eaaf70_1_0, this.monitors);
      }
   }

   public @Nullable Monitor getMonitor(long p81eaaf70_3_0) {
      return this.monitors.get(p81eaaf70_3_0);
   }

   public @Nullable Monitor findBestMonitor(Window p81eaaf70_4_0) {
      long $$1 = GLFW.glfwGetWindowMonitor(p81eaaf70_4_0.handle());
      if ($$1 != 0L) {
         return this.getMonitor($$1);
      }

      int $$2 = p81eaaf70_4_0.getX();
      int $$3 = $$2 + p81eaaf70_4_0.getScreenWidth();
      int $$4 = p81eaaf70_4_0.getY();
      int $$5 = $$4 + p81eaaf70_4_0.getScreenHeight();
      int $$6 = -1;
      Monitor $$7 = null;
      long $$8 = GLFW.glfwGetPrimaryMonitor();
      LOGGER.debug("Selecting monitor - primary: {}, current monitors: {}", $$8, this.monitors);

      for (Monitor $$9 : this.monitors.values()) {
         int $$10 = $$9.getX();
         int $$11 = $$10 + $$9.getCurrentMode().getWidth();
         int $$12 = $$9.getY();
         int $$13 = $$12 + $$9.getCurrentMode().getHeight();
         int $$14 = clamp($$2, $$10, $$11);
         int $$15 = clamp($$3, $$10, $$11);
         int $$16 = clamp($$4, $$12, $$13);
         int $$17 = clamp($$5, $$12, $$13);
         int $$18 = Math.max(0, $$15 - $$14);
         int $$19 = Math.max(0, $$17 - $$16);
         int $$20 = $$18 * $$19;
         if ($$20 > $$6) {
            $$7 = $$9;
            $$6 = $$20;
         } else if ($$20 == $$6 && $$8 == $$9.getMonitor()) {
            LOGGER.debug("Primary monitor {} is preferred to monitor {}", $$9, $$7);
            $$7 = $$9;
         }
      }

      LOGGER.debug("Selected monitor: {}", $$7);
      return $$7;
   }

   public static int clamp(int p81eaaf70_5_0, int p81eaaf70_6_1, int p81eaaf70_7_2) {
      if (p81eaaf70_5_0 < p81eaaf70_6_1) {
         return p81eaaf70_6_1;
      } else {
         return p81eaaf70_5_0 > p81eaaf70_7_2 ? p81eaaf70_7_2 : p81eaaf70_5_0;
      }
   }

   public void shutdown() {
      RenderSystem.assertOnRenderThread();
      GLFWMonitorCallback $$0 = GLFW.glfwSetMonitorCallback(null);
      if ($$0 != null) {
         $$0.free();
      }
   }
}
