package com.mojang.blaze3d.platform;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.mojang.blaze3d.DontObfuscate;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.LongSupplier;
import java.util.function.Supplier;
import org.jspecify.annotations.Nullable;
import org.lwjgl.Version;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWErrorCallbackI;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.system.MemoryUtil;
import org.slf4j.Logger;
import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;

@DontObfuscate
public class GLX {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static @Nullable String cpuInfo;

   public static int _getRefreshRate(Window p3c098cc2_0_0) {
      RenderSystem.assertOnRenderThread();
      long $$1 = GLFW.glfwGetWindowMonitor(p3c098cc2_0_0.handle());
      if ($$1 == 0L) {
         $$1 = GLFW.glfwGetPrimaryMonitor();
      }

      GLFWVidMode $$2 = $$1 == 0L ? null : GLFW.glfwGetVideoMode($$1);
      return $$2 == null ? 0 : $$2.refreshRate();
   }

   public static String _getLWJGLVersion() {
      return Version.getVersion();
   }

   public static LongSupplier _initGlfw() {
      Window.checkGlfwError((p3c098cc2_9_0, p3c098cc2_10_1) -> {
         throw new IllegalStateException(String.format(Locale.ROOT, "GLFW error before init: [0x%X]%s", p3c098cc2_9_0, p3c098cc2_10_1));
      });
      List<String> $$0 = Lists.newArrayList();
      GLFWErrorCallback $$1 = GLFW.glfwSetErrorCallback((p3c098cc2_7_1, p3c098cc2_8_2) -> {
         String $$3x = p3c098cc2_8_2 == 0L ? "" : MemoryUtil.memUTF8(p3c098cc2_8_2);
         $$0.add(String.format(Locale.ROOT, "GLFW error during init: [0x%X]%s", p3c098cc2_7_1, $$3x));
      });
      if (!GLFW.glfwInit()) {
         throw new IllegalStateException("Failed to initialize GLFW, errors: " + Joiner.on(",").join($$0));
      }

      LongSupplier $$2 = () -> (long)(GLFW.glfwGetTime() * 1.0E9);

      for (String $$3 : $$0) {
         LOGGER.error("GLFW error collected during initialization: {}", $$3);
      }

      RenderSystem.setErrorCallback($$1);
      return $$2;
   }

   public static void _setGlfwErrorCallback(GLFWErrorCallbackI p3c098cc2_1_0) {
      GLFWErrorCallback $$1 = GLFW.glfwSetErrorCallback(p3c098cc2_1_0);
      if ($$1 != null) {
         $$1.free();
      }
   }

   public static boolean _shouldClose(Window p3c098cc2_2_0) {
      return GLFW.glfwWindowShouldClose(p3c098cc2_2_0.handle());
   }

   public static String _getCpuInfo() {
      if (cpuInfo == null) {
         cpuInfo = "<unknown>";

         try {
            CentralProcessor $$0 = new SystemInfo().getHardware().getProcessor();
            cpuInfo = String.format(Locale.ROOT, "%dx %s", $$0.getLogicalProcessorCount(), $$0.getProcessorIdentifier().getName()).replaceAll("\\s+", " ");
         } catch (Throwable var1) {
         }
      }

      return cpuInfo;
   }

   public static <T> T make(Supplier<T> p3c098cc2_3_0) {
      return p3c098cc2_3_0.get();
   }

   public static <T> T make(T p3c098cc2_4_0, Consumer<T> p3c098cc2_5_1) {
      p3c098cc2_5_1.accept(p3c098cc2_4_0);
      return p3c098cc2_4_0;
   }
}
