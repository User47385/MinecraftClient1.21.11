package com.mojang.blaze3d.platform;

import ca.weblite.objc.Client;
import ca.weblite.objc.NSObject;
import com.sun.jna.Pointer;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.server.packs.resources.IoSupplier;
import org.lwjgl.glfw.GLFWNativeCocoa;

public class MacosUtil {
   public static final boolean IS_MACOS = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("mac");
   private static final int NS_RESIZABLE_WINDOW_MASK = 8;
   private static final int NS_FULL_SCREEN_WINDOW_MASK = 16384;

   public static void exitNativeFullscreen(Window p59082764_0_0) {
      getNsWindow(p59082764_0_0).filter(MacosUtil::isInNativeFullscreen).ifPresent(MacosUtil::toggleNativeFullscreen);
   }

   public static void clearResizableBit(Window p59082764_1_0) {
      getNsWindow(p59082764_1_0).ifPresent(p59082764_7_0 -> {
         long $$1 = getStyleMask(p59082764_7_0);
         p59082764_7_0.send("setStyleMask:", $$1 & -9L);
      });
   }

   private static Optional<NSObject> getNsWindow(Window p59082764_2_0) {
      long $$1 = GLFWNativeCocoa.glfwGetCocoaWindow(p59082764_2_0.handle());
      return $$1 != 0L ? Optional.of(new NSObject(new Pointer($$1))) : Optional.empty();
   }

   private static boolean isInNativeFullscreen(NSObject p59082764_3_0) {
      return (getStyleMask(p59082764_3_0) & 16384L) != 0L;
   }

   private static long getStyleMask(NSObject p59082764_4_0) {
      return (Long)p59082764_4_0.sendRaw("styleMask");
   }

   private static void toggleNativeFullscreen(NSObject p59082764_5_0) {
      p59082764_5_0.send("toggleFullScreen:", Pointer.NULL);
   }

   public static void loadIcon(IoSupplier<InputStream> p59082764_6_0) throws IOException {
      try (InputStream $$1 = p59082764_6_0.get()) {
         String $$2 = Base64.getEncoder().encodeToString($$1.readAllBytes());
         Client $$3 = Client.getInstance();
         Object $$4 = $$3.sendProxy("NSData", "alloc").send("initWithBase64Encoding:", $$2);
         Object $$5 = $$3.sendProxy("NSImage", "alloc").send("initWithData:", $$4);
         $$3.sendProxy("NSApplication", "sharedApplication").send("setApplicationIconImage:", $$5);
      }
   }
}
