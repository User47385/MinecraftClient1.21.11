package com.mojang.blaze3d.platform.cursor;

import com.mojang.blaze3d.platform.Window;
import org.lwjgl.glfw.GLFW;

public class CursorType {
   public static final CursorType DEFAULT = new CursorType("default", 0L);
   private final String name;
   private final long handle;

   private CursorType(String p4278de98_0_0, long p4278de98_1_1) {
      this.name = p4278de98_0_0;
      this.handle = p4278de98_1_1;
   }

   public void select(Window p4278de98_2_0) {
      GLFW.glfwSetCursor(p4278de98_2_0.handle(), this.handle);
   }

   @Override
   public String toString() {
      return this.name;
   }

   public static CursorType createStandardCursor(int p4278de98_3_0, String p4278de98_4_1, CursorType p4278de98_5_2) {
      long $$3 = GLFW.glfwCreateStandardCursor(p4278de98_3_0);
      return $$3 == 0L ? p4278de98_5_2 : new CursorType(p4278de98_4_1, $$3);
   }
}
