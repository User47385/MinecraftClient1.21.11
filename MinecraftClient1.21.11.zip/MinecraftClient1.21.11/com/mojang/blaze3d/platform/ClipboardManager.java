package com.mojang.blaze3d.platform;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import net.minecraft.util.StringDecomposer;
import org.lwjgl.BufferUtils;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWErrorCallbackI;
import org.lwjgl.system.MemoryUtil;

public class ClipboardManager {
   public static final int FORMAT_UNAVAILABLE = 65545;
   private final ByteBuffer clipboardScratchBuffer = BufferUtils.createByteBuffer(8192);

   public String getClipboard(Window p1d8f1508_0_0, GLFWErrorCallbackI p1d8f1508_1_1) {
      GLFWErrorCallback $$2 = GLFW.glfwSetErrorCallback(p1d8f1508_1_1);
      String $$3 = GLFW.glfwGetClipboardString(p1d8f1508_0_0.handle());
      $$3 = $$3 != null ? StringDecomposer.filterBrokenSurrogates($$3) : "";
      GLFWErrorCallback $$4 = GLFW.glfwSetErrorCallback($$2);
      if ($$4 != null) {
         $$4.free();
      }

      return $$3;
   }

   private static void pushClipboard(Window p1d8f1508_2_0, ByteBuffer p1d8f1508_3_1, byte[] p1d8f1508_4_2) {
      p1d8f1508_3_1.clear();
      p1d8f1508_3_1.put(p1d8f1508_4_2);
      p1d8f1508_3_1.put((byte)0);
      p1d8f1508_3_1.flip();
      GLFW.glfwSetClipboardString(p1d8f1508_2_0.handle(), p1d8f1508_3_1);
   }

   public void setClipboard(Window p1d8f1508_5_0, String p1d8f1508_6_1) {
      byte[] $$2 = p1d8f1508_6_1.getBytes(StandardCharsets.UTF_8);
      int $$3 = $$2.length + 1;
      if ($$3 < this.clipboardScratchBuffer.capacity()) {
         pushClipboard(p1d8f1508_5_0, this.clipboardScratchBuffer, $$2);
      } else {
         ByteBuffer $$4 = MemoryUtil.memAlloc($$3);

         try {
            pushClipboard(p1d8f1508_5_0, $$4, $$2);
         } finally {
            MemoryUtil.memFree($$4);
         }
      }
   }
}
