package com.mojang.blaze3d.platform;

import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jspecify.annotations.Nullable;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.glfw.GLFWVidMode.Buffer;

public final class VideoMode {
   private final int width;
   private final int height;
   private final int redBits;
   private final int greenBits;
   private final int blueBits;
   private final int refreshRate;
   private static final Pattern PATTERN = Pattern.compile("(\\d+)x(\\d+)(?:@(\\d+)(?::(\\d+))?)?");

   public VideoMode(int pf213260d_0_0, int pf213260d_1_1, int pf213260d_2_2, int pf213260d_3_3, int pf213260d_4_4, int pf213260d_5_5) {
      this.width = pf213260d_0_0;
      this.height = pf213260d_1_1;
      this.redBits = pf213260d_2_2;
      this.greenBits = pf213260d_3_3;
      this.blueBits = pf213260d_4_4;
      this.refreshRate = pf213260d_5_5;
   }

   public VideoMode(Buffer pf213260d_6_0) {
      this.width = pf213260d_6_0.width();
      this.height = pf213260d_6_0.height();
      this.redBits = pf213260d_6_0.redBits();
      this.greenBits = pf213260d_6_0.greenBits();
      this.blueBits = pf213260d_6_0.blueBits();
      this.refreshRate = pf213260d_6_0.refreshRate();
   }

   public VideoMode(GLFWVidMode pf213260d_7_0) {
      this.width = pf213260d_7_0.width();
      this.height = pf213260d_7_0.height();
      this.redBits = pf213260d_7_0.redBits();
      this.greenBits = pf213260d_7_0.greenBits();
      this.blueBits = pf213260d_7_0.blueBits();
      this.refreshRate = pf213260d_7_0.refreshRate();
   }

   public int getWidth() {
      return this.width;
   }

   public int getHeight() {
      return this.height;
   }

   public int getRedBits() {
      return this.redBits;
   }

   public int getGreenBits() {
      return this.greenBits;
   }

   public int getBlueBits() {
      return this.blueBits;
   }

   public int getRefreshRate() {
      return this.refreshRate;
   }

   @Override
   public boolean equals(Object pf213260d_8_0) {
      if (this == pf213260d_8_0) {
         return true;
      } else if (pf213260d_8_0 != null && this.getClass() == pf213260d_8_0.getClass()) {
         VideoMode $$1 = (VideoMode)pf213260d_8_0;
         return this.width == $$1.width
            && this.height == $$1.height
            && this.redBits == $$1.redBits
            && this.greenBits == $$1.greenBits
            && this.blueBits == $$1.blueBits
            && this.refreshRate == $$1.refreshRate;
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.width, this.height, this.redBits, this.greenBits, this.blueBits, this.refreshRate);
   }

   @Override
   public String toString() {
      return String.format(Locale.ROOT, "%sx%s@%s (%sbit)", this.width, this.height, this.refreshRate, this.redBits + this.greenBits + this.blueBits);
   }

   public static Optional<VideoMode> read(@Nullable String pf213260d_9_0) {
      if (pf213260d_9_0 == null) {
         return Optional.empty();
      }

      try {
         Matcher $$1 = PATTERN.matcher(pf213260d_9_0);
         if ($$1.matches()) {
            int $$2 = Integer.parseInt($$1.group(1));
            int $$3 = Integer.parseInt($$1.group(2));
            String $$4 = $$1.group(3);
            int $$5;
            if ($$4 == null) {
               $$5 = 60;
            } else {
               $$5 = Integer.parseInt($$4);
            }

            String $$7 = $$1.group(4);
            int $$8;
            if ($$7 == null) {
               $$8 = 24;
            } else {
               $$8 = Integer.parseInt($$7);
            }

            int $$10 = $$8 / 3;
            return Optional.of(new VideoMode($$2, $$3, $$10, $$10, $$10, $$5));
         }
      } catch (Exception var9) {
      }

      return Optional.empty();
   }

   public String write() {
      return String.format(Locale.ROOT, "%sx%s@%s:%s", this.width, this.height, this.refreshRate, this.redBits + this.greenBits + this.blueBits);
   }
}
