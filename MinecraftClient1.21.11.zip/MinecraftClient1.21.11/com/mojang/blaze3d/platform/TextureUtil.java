package com.mojang.blaze3d.platform;

import com.mojang.blaze3d.DontObfuscate;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.ints.IntArrayFIFOQueue;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntUnaryOperator;
import net.minecraft.util.ARGB;
import org.lwjgl.system.MemoryUtil;
import org.slf4j.Logger;

@DontObfuscate
public class TextureUtil {
   private static final Logger LOGGER = LogUtils.getLogger();
   public static final int MIN_MIPMAP_LEVEL = 0;
   private static final int DEFAULT_IMAGE_BUFFER_SIZE = 8192;
   private static final int[][] DIRECTIONS = new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

   public static ByteBuffer readResource(InputStream pe672354c_0_0) throws IOException {
      ReadableByteChannel $$1 = Channels.newChannel(pe672354c_0_0);
      return $$1 instanceof SeekableByteChannel $$2 ? readResource($$1, (int)$$2.size() + 1) : readResource($$1, 8192);
   }

   private static ByteBuffer readResource(ReadableByteChannel pe672354c_1_0, int pe672354c_2_1) throws IOException {
      ByteBuffer $$2 = MemoryUtil.memAlloc(pe672354c_2_1);

      try {
         while (pe672354c_1_0.read($$2) != -1) {
            if (!$$2.hasRemaining()) {
               $$2 = MemoryUtil.memRealloc($$2, $$2.capacity() * 2);
            }
         }

         $$2.flip();
         return $$2;
      } catch (IOException $$3) {
         MemoryUtil.memFree($$2);
         throw $$3;
      }
   }

   public static void writeAsPNG(Path pe672354c_3_0, String pe672354c_4_1, GpuTexture pe672354c_5_2, int pe672354c_6_3, IntUnaryOperator pe672354c_7_4) {
      RenderSystem.assertOnRenderThread();
      long $$5 = 0L;

      for (int $$6 = 0; $$6 <= pe672354c_6_3; $$6++) {
         $$5 += (long)pe672354c_5_2.getFormat().pixelSize() * pe672354c_5_2.getWidth($$6) * pe672354c_5_2.getHeight($$6);
      }

      if ($$5 > 2147483647L) {
         throw new IllegalArgumentException("Exporting textures larger than 2GB is not supported");
      }

      GpuBuffer $$7 = RenderSystem.getDevice().createBuffer(() -> "Texture output buffer", 9, $$5);
      CommandEncoder $$8 = RenderSystem.getDevice().createCommandEncoder();
      Runnable $$9 = () -> {
         try (GpuBuffer.MappedView $$7x = $$8.mapBuffer($$7, true, false)) {
            int $$8x = 0;

            for (int $$9x = 0; $$9x <= pe672354c_6_3; $$9x++) {
               int $$10x = pe672354c_5_2.getWidth($$9x);
               int $$11x = pe672354c_5_2.getHeight($$9x);

               try (NativeImage $$12x = new NativeImage($$10x, $$11x, false)) {
                  for (int $$13 = 0; $$13 < $$11x; $$13++) {
                     for (int $$14 = 0; $$14 < $$10x; $$14++) {
                        int $$15 = $$7x.data().getInt($$8x + ($$14 + $$13 * $$10x) * pe672354c_5_2.getFormat().pixelSize());
                        $$12x.setPixelABGR($$14, $$13, pe672354c_7_4.applyAsInt($$15));
                     }
                  }

                  Path $$16 = pe672354c_3_0.resolve(pe672354c_4_1 + "_" + $$9x + ".png");
                  $$12x.writeToFile($$16);
                  LOGGER.debug("Exported png to: {}", $$16.toAbsolutePath());
               } catch (IOException $$17) {
                  LOGGER.debug("Unable to write: ", $$17);
               }

               $$8x += pe672354c_5_2.getFormat().pixelSize() * $$10x * $$11x;
            }
         }

         $$7.close();
      };
      AtomicInteger $$10 = new AtomicInteger();
      int $$11 = 0;

      for (int $$12 = 0; $$12 <= pe672354c_6_3; $$12++) {
         $$8.copyTextureToBuffer(pe672354c_5_2, $$7, $$11, () -> {
            if ($$10.getAndIncrement() == pe672354c_6_3) {
               $$9.run();
            }
         }, $$12);
         $$11 += pe672354c_5_2.getFormat().pixelSize() * pe672354c_5_2.getWidth($$12) * pe672354c_5_2.getHeight($$12);
      }
   }

   public static Path getDebugTexturePath(Path pe672354c_8_0) {
      return pe672354c_8_0.resolve("screenshots").resolve("debug");
   }

   public static Path getDebugTexturePath() {
      return getDebugTexturePath(Path.of("."));
   }

   public static void solidify(NativeImage pe672354c_9_0) {
      int $$1 = pe672354c_9_0.getWidth();
      int $$2 = pe672354c_9_0.getHeight();
      int[] $$3 = new int[$$1 * $$2];
      int[] $$4 = new int[$$1 * $$2];
      Arrays.fill($$4, Integer.MAX_VALUE);
      IntArrayFIFOQueue $$5 = new IntArrayFIFOQueue();

      for (int $$6 = 0; $$6 < $$1; $$6++) {
         for (int $$7 = 0; $$7 < $$2; $$7++) {
            int $$8 = pe672354c_9_0.getPixel($$6, $$7);
            if (ARGB.alpha($$8) != 0) {
               int $$9 = pack($$6, $$7, $$1);
               $$4[$$9] = 0;
               $$3[$$9] = $$8;
               $$5.enqueue($$9);
            }
         }
      }

      while (!$$5.isEmpty()) {
         int $$10 = $$5.dequeueInt();
         int $$11 = x($$10, $$1);
         int $$12 = y($$10, $$1);

         for (int[] $$13 : DIRECTIONS) {
            int $$14 = $$11 + $$13[0];
            int $$15 = $$12 + $$13[1];
            int $$16 = pack($$14, $$15, $$1);
            if ($$14 >= 0 && $$15 >= 0 && $$14 < $$1 && $$15 < $$2 && $$4[$$16] > $$4[$$10] + 1) {
               $$4[$$16] = $$4[$$10] + 1;
               $$3[$$16] = $$3[$$10];
               $$5.enqueue($$16);
            }
         }
      }

      for (int $$17 = 0; $$17 < $$1; $$17++) {
         for (int $$18 = 0; $$18 < $$2; $$18++) {
            int $$19 = pe672354c_9_0.getPixel($$17, $$18);
            if (ARGB.alpha($$19) == 0) {
               pe672354c_9_0.setPixel($$17, $$18, ARGB.color(0, $$3[pack($$17, $$18, $$1)]));
            } else {
               pe672354c_9_0.setPixel($$17, $$18, $$19);
            }
         }
      }
   }

   public static void fillEmptyAreasWithDarkColor(NativeImage pe672354c_10_0) {
      int $$1 = pe672354c_10_0.getWidth();
      int $$2 = pe672354c_10_0.getHeight();
      int $$3 = -1;
      int $$4 = Integer.MAX_VALUE;

      for (int $$5 = 0; $$5 < $$1; $$5++) {
         for (int $$6 = 0; $$6 < $$2; $$6++) {
            int $$7 = pe672354c_10_0.getPixel($$5, $$6);
            int $$8 = ARGB.alpha($$7);
            if ($$8 != 0) {
               int $$9 = ARGB.red($$7);
               int $$10 = ARGB.green($$7);
               int $$11 = ARGB.blue($$7);
               int $$12 = $$9 + $$10 + $$11;
               if ($$12 < $$4) {
                  $$4 = $$12;
                  $$3 = $$7;
               }
            }
         }
      }

      int $$13 = 3 * ARGB.red($$3) / 4;
      int $$14 = 3 * ARGB.green($$3) / 4;
      int $$15 = 3 * ARGB.blue($$3) / 4;
      int $$16 = ARGB.color(0, $$13, $$14, $$15);

      for (int $$17 = 0; $$17 < $$1; $$17++) {
         for (int $$18 = 0; $$18 < $$2; $$18++) {
            int $$19 = pe672354c_10_0.getPixel($$17, $$18);
            if (ARGB.alpha($$19) == 0) {
               pe672354c_10_0.setPixel($$17, $$18, $$16);
            }
         }
      }
   }

   private static int pack(int pe672354c_11_0, int pe672354c_12_1, int pe672354c_13_2) {
      return pe672354c_11_0 + pe672354c_12_1 * pe672354c_13_2;
   }

   private static int x(int pe672354c_14_0, int pe672354c_15_1) {
      return pe672354c_14_0 % pe672354c_15_1;
   }

   private static int y(int pe672354c_16_0, int pe672354c_17_1) {
      return pe672354c_16_0 / pe672354c_17_1;
   }
}
