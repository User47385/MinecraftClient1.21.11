package com.mojang.blaze3d.platform;

import com.mojang.jtracy.MemoryPool;
import com.mojang.jtracy.TracyClient;
import com.mojang.logging.LogUtils;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.WritableByteChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.EnumSet;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.function.IntUnaryOperator;
import net.minecraft.client.gui.font.providers.FreeTypeUtil;
import net.minecraft.util.ARGB;
import net.minecraft.util.PngInfo;
import org.apache.commons.io.IOUtils;
import org.jspecify.annotations.Nullable;
import org.lwjgl.stb.STBIWriteCallback;
import org.lwjgl.stb.STBImage;
import org.lwjgl.stb.STBImageResize;
import org.lwjgl.stb.STBImageWrite;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.freetype.FT_Bitmap;
import org.lwjgl.util.freetype.FT_Face;
import org.lwjgl.util.freetype.FT_GlyphSlot;
import org.lwjgl.util.freetype.FreeType;
import org.slf4j.Logger;

public final class NativeImage implements AutoCloseable {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final MemoryPool MEMORY_POOL = TracyClient.createMemoryPool("NativeImage");
   private static final Set<StandardOpenOption> OPEN_OPTIONS = EnumSet.of(
      StandardOpenOption.WRITE, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING
   );
   private final NativeImage.Format format;
   private final int width;
   private final int height;
   private final boolean useStbFree;
   private long pixels;
   private final long size;

   public NativeImage(int ped68e113_0_0, int ped68e113_1_1, boolean ped68e113_2_2) {
      this(NativeImage.Format.RGBA, ped68e113_0_0, ped68e113_1_1, ped68e113_2_2);
   }

   public NativeImage(NativeImage.Format ped68e113_3_0, int ped68e113_4_1, int ped68e113_5_2, boolean ped68e113_6_3) {
      if (ped68e113_4_1 > 0 && ped68e113_5_2 > 0) {
         this.format = ped68e113_3_0;
         this.width = ped68e113_4_1;
         this.height = ped68e113_5_2;
         this.size = (long)ped68e113_4_1 * ped68e113_5_2 * ped68e113_3_0.components();
         this.useStbFree = false;
         if (ped68e113_6_3) {
            this.pixels = MemoryUtil.nmemCalloc(1L, this.size);
         } else {
            this.pixels = MemoryUtil.nmemAlloc(this.size);
         }

         MEMORY_POOL.malloc(this.pixels, (int)this.size);
         if (this.pixels == 0L) {
            throw new IllegalStateException(
               "Unable to allocate texture of size " + ped68e113_4_1 + "x" + ped68e113_5_2 + " (" + ped68e113_3_0.components() + " channels)"
            );
         }
      } else {
         throw new IllegalArgumentException("Invalid texture size: " + ped68e113_4_1 + "x" + ped68e113_5_2);
      }
   }

   public NativeImage(NativeImage.Format ped68e113_7_0, int ped68e113_8_1, int ped68e113_9_2, boolean ped68e113_10_3, long ped68e113_11_4) {
      if (ped68e113_8_1 > 0 && ped68e113_9_2 > 0) {
         this.format = ped68e113_7_0;
         this.width = ped68e113_8_1;
         this.height = ped68e113_9_2;
         this.useStbFree = ped68e113_10_3;
         this.pixels = ped68e113_11_4;
         this.size = (long)ped68e113_8_1 * ped68e113_9_2 * ped68e113_7_0.components();
      } else {
         throw new IllegalArgumentException("Invalid texture size: " + ped68e113_8_1 + "x" + ped68e113_9_2);
      }
   }

   @Override
   public String toString() {
      return "NativeImage[" + this.format + " " + this.width + "x" + this.height + "@" + this.pixels + (this.useStbFree ? "S" : "N") + "]";
   }

   private boolean isOutsideBounds(int ped68e113_12_0, int ped68e113_13_1) {
      return ped68e113_12_0 < 0 || ped68e113_12_0 >= this.width || ped68e113_13_1 < 0 || ped68e113_13_1 >= this.height;
   }

   public static NativeImage read(InputStream ped68e113_14_0) throws IOException {
      return read(NativeImage.Format.RGBA, ped68e113_14_0);
   }

   public static NativeImage read(NativeImage.@Nullable Format ped68e113_15_0, InputStream ped68e113_16_1) throws IOException {
      ByteBuffer $$2 = null;

      try {
         $$2 = TextureUtil.readResource(ped68e113_16_1);
         return read(ped68e113_15_0, $$2);
      } finally {
         MemoryUtil.memFree($$2);
         IOUtils.closeQuietly(ped68e113_16_1);
      }
   }

   public static NativeImage read(ByteBuffer ped68e113_17_0) throws IOException {
      return read(NativeImage.Format.RGBA, ped68e113_17_0);
   }

   public static NativeImage read(byte[] ped68e113_18_0) throws IOException {
      MemoryStack $$1 = MemoryStack.stackGet();
      int $$2 = $$1.getPointer();
      if ($$2 < ped68e113_18_0.length) {
         ByteBuffer $$3 = MemoryUtil.memAlloc(ped68e113_18_0.length);

         try {
            return putAndRead($$3, ped68e113_18_0);
         } finally {
            MemoryUtil.memFree($$3);
         }
      } else {
         try (MemoryStack $$4 = MemoryStack.stackPush()) {
            ByteBuffer $$5 = $$4.malloc(ped68e113_18_0.length);
            return putAndRead($$5, ped68e113_18_0);
         }
      }
   }

   private static NativeImage putAndRead(ByteBuffer ped68e113_19_0, byte[] ped68e113_20_1) throws IOException {
      ped68e113_19_0.put(ped68e113_20_1);
      ped68e113_19_0.rewind();
      return read(ped68e113_19_0);
   }

   public static NativeImage read(NativeImage.@Nullable Format ped68e113_21_0, ByteBuffer ped68e113_22_1) throws IOException {
      if (ped68e113_21_0 != null && !ped68e113_21_0.supportedByStb()) {
         throw new UnsupportedOperationException("Don't know how to read format " + ped68e113_21_0);
      }

      if (MemoryUtil.memAddress(ped68e113_22_1) == 0L) {
         throw new IllegalArgumentException("Invalid buffer");
      }

      PngInfo.validateHeader(ped68e113_22_1);

      try (MemoryStack $$2 = MemoryStack.stackPush()) {
         IntBuffer $$3 = $$2.mallocInt(1);
         IntBuffer $$4 = $$2.mallocInt(1);
         IntBuffer $$5 = $$2.mallocInt(1);
         ByteBuffer $$6 = STBImage.stbi_load_from_memory(ped68e113_22_1, $$3, $$4, $$5, ped68e113_21_0 == null ? 0 : ped68e113_21_0.components);
         if ($$6 == null) {
            throw new IOException("Could not load image: " + STBImage.stbi_failure_reason());
         }

         long $$7 = MemoryUtil.memAddress($$6);
         MEMORY_POOL.malloc($$7, $$6.limit());
         return new NativeImage(ped68e113_21_0 == null ? NativeImage.Format.getStbFormat($$5.get(0)) : ped68e113_21_0, $$3.get(0), $$4.get(0), true, $$7);
      }
   }

   private void checkAllocated() {
      if (this.pixels == 0L) {
         throw new IllegalStateException("Image is not allocated.");
      }
   }

   @Override
   public void close() {
      if (this.pixels != 0L) {
         if (this.useStbFree) {
            STBImage.nstbi_image_free(this.pixels);
         } else {
            MemoryUtil.nmemFree(this.pixels);
         }

         MEMORY_POOL.free(this.pixels);
      }

      this.pixels = 0L;
   }

   public int getWidth() {
      return this.width;
   }

   public int getHeight() {
      return this.height;
   }

   public NativeImage.Format format() {
      return this.format;
   }

   private int getPixelABGR(int ped68e113_23_0, int ped68e113_24_1) {
      if (this.format != NativeImage.Format.RGBA) {
         throw new IllegalArgumentException(String.format(Locale.ROOT, "getPixelRGBA only works on RGBA images; have %s", this.format));
      }

      if (this.isOutsideBounds(ped68e113_23_0, ped68e113_24_1)) {
         throw new IllegalArgumentException(
            String.format(Locale.ROOT, "(%s, %s) outside of image bounds (%s, %s)", ped68e113_23_0, ped68e113_24_1, this.width, this.height)
         );
      }

      this.checkAllocated();
      long $$2 = (ped68e113_23_0 + (long)ped68e113_24_1 * this.width) * 4L;
      return MemoryUtil.memGetInt(this.pixels + $$2);
   }

   public int getPixel(int ped68e113_25_0, int ped68e113_26_1) {
      return ARGB.fromABGR(this.getPixelABGR(ped68e113_25_0, ped68e113_26_1));
   }

   public void setPixelABGR(int ped68e113_27_0, int ped68e113_28_1, int ped68e113_29_2) {
      if (this.format != NativeImage.Format.RGBA) {
         throw new IllegalArgumentException(String.format(Locale.ROOT, "setPixelRGBA only works on RGBA images; have %s", this.format));
      }

      if (this.isOutsideBounds(ped68e113_27_0, ped68e113_28_1)) {
         throw new IllegalArgumentException(
            String.format(Locale.ROOT, "(%s, %s) outside of image bounds (%s, %s)", ped68e113_27_0, ped68e113_28_1, this.width, this.height)
         );
      }

      this.checkAllocated();
      long $$3 = (ped68e113_27_0 + (long)ped68e113_28_1 * this.width) * 4L;
      MemoryUtil.memPutInt(this.pixels + $$3, ped68e113_29_2);
   }

   public void setPixel(int ped68e113_30_0, int ped68e113_31_1, int ped68e113_32_2) {
      this.setPixelABGR(ped68e113_30_0, ped68e113_31_1, ARGB.toABGR(ped68e113_32_2));
   }

   public NativeImage mappedCopy(IntUnaryOperator ped68e113_33_0) {
      if (this.format != NativeImage.Format.RGBA) {
         throw new IllegalArgumentException(String.format(Locale.ROOT, "function application only works on RGBA images; have %s", this.format));
      }

      this.checkAllocated();
      NativeImage $$1 = new NativeImage(this.width, this.height, false);
      int $$2 = this.width * this.height;
      IntBuffer $$3 = MemoryUtil.memIntBuffer(this.pixels, $$2);
      IntBuffer $$4 = MemoryUtil.memIntBuffer($$1.pixels, $$2);

      for (int $$5 = 0; $$5 < $$2; $$5++) {
         int $$6 = ARGB.fromABGR($$3.get($$5));
         int $$7 = ped68e113_33_0.applyAsInt($$6);
         $$4.put($$5, ARGB.toABGR($$7));
      }

      return $$1;
   }

   public int[] getPixelsABGR() {
      if (this.format != NativeImage.Format.RGBA) {
         throw new IllegalArgumentException(String.format(Locale.ROOT, "getPixels only works on RGBA images; have %s", this.format));
      }

      this.checkAllocated();
      int[] $$0 = new int[this.width * this.height];
      MemoryUtil.memIntBuffer(this.pixels, this.width * this.height).get($$0);
      return $$0;
   }

   public int[] getPixels() {
      int[] $$0 = this.getPixelsABGR();

      for (int $$1 = 0; $$1 < $$0.length; $$1++) {
         $$0[$$1] = ARGB.fromABGR($$0[$$1]);
      }

      return $$0;
   }

   public byte getLuminanceOrAlpha(int ped68e113_34_0, int ped68e113_35_1) {
      if (!this.format.hasLuminanceOrAlpha()) {
         throw new IllegalArgumentException(String.format(Locale.ROOT, "no luminance or alpha in %s", this.format));
      }

      if (this.isOutsideBounds(ped68e113_34_0, ped68e113_35_1)) {
         throw new IllegalArgumentException(
            String.format(Locale.ROOT, "(%s, %s) outside of image bounds (%s, %s)", ped68e113_34_0, ped68e113_35_1, this.width, this.height)
         );
      }

      int $$2 = (ped68e113_34_0 + ped68e113_35_1 * this.width) * this.format.components() + this.format.luminanceOrAlphaOffset() / 8;
      return MemoryUtil.memGetByte(this.pixels + $$2);
   }

   @Deprecated
   public int[] makePixelArray() {
      if (this.format != NativeImage.Format.RGBA) {
         throw new UnsupportedOperationException("can only call makePixelArray for RGBA images.");
      }

      this.checkAllocated();
      int[] $$0 = new int[this.getWidth() * this.getHeight()];

      for (int $$1 = 0; $$1 < this.getHeight(); $$1++) {
         for (int $$2 = 0; $$2 < this.getWidth(); $$2++) {
            $$0[$$2 + $$1 * this.getWidth()] = this.getPixel($$2, $$1);
         }
      }

      return $$0;
   }

   public void writeToFile(File ped68e113_36_0) throws IOException {
      this.writeToFile(ped68e113_36_0.toPath());
   }

   public boolean copyFromFont(FT_Face ped68e113_37_0, int ped68e113_38_1) {
      if (this.format.components() != 1) {
         throw new IllegalArgumentException("Can only write fonts into 1-component images.");
      } else if (FreeTypeUtil.checkError(FreeType.FT_Load_Glyph(ped68e113_37_0, ped68e113_38_1, 4), "Loading glyph")) {
         return false;
      } else {
         FT_GlyphSlot $$2 = Objects.requireNonNull(ped68e113_37_0.glyph(), "Glyph not initialized");
         FT_Bitmap $$3 = $$2.bitmap();
         if ($$3.pixel_mode() != 2) {
            throw new IllegalStateException("Rendered glyph was not 8-bit grayscale");
         } else if ($$3.width() == this.getWidth() && $$3.rows() == this.getHeight()) {
            int $$4 = $$3.width() * $$3.rows();
            ByteBuffer $$5 = Objects.requireNonNull($$3.buffer($$4), "Glyph has no bitmap");
            MemoryUtil.memCopy(MemoryUtil.memAddress($$5), this.pixels, $$4);
            return true;
         } else {
            throw new IllegalArgumentException(
               String.format(
                  Locale.ROOT, "Glyph bitmap of size %sx%s does not match image of size: %sx%s", $$3.width(), $$3.rows(), this.getWidth(), this.getHeight()
               )
            );
         }
      }
   }

   public void writeToFile(Path ped68e113_39_0) throws IOException {
      if (!this.format.supportedByStb()) {
         throw new UnsupportedOperationException("Don't know how to write format " + this.format);
      }

      this.checkAllocated();

      try (WritableByteChannel $$1 = Files.newByteChannel(ped68e113_39_0, OPEN_OPTIONS)) {
         if (!this.writeToChannel($$1)) {
            throw new IOException("Could not write image to the PNG file \"" + ped68e113_39_0.toAbsolutePath() + "\": " + STBImage.stbi_failure_reason());
         }
      }
   }

   private boolean writeToChannel(WritableByteChannel ped68e113_40_0) throws IOException {
      NativeImage.WriteCallback $$1 = new NativeImage.WriteCallback(ped68e113_40_0);

      try {
         int $$2 = Math.min(this.getHeight(), Integer.MAX_VALUE / this.getWidth() / this.format.components());
         if ($$2 < this.getHeight()) {
            LOGGER.warn("Dropping image height from {} to {} to fit the size into 32-bit signed int", this.getHeight(), $$2);
         }

         if (STBImageWrite.nstbi_write_png_to_func($$1.address(), 0L, this.getWidth(), $$2, this.format.components(), this.pixels, 0) == 0) {
            return false;
         }

         $$1.throwIfException();
         return true;
      } finally {
         $$1.free();
      }
   }

   public void copyFrom(NativeImage ped68e113_41_0) {
      if (ped68e113_41_0.format() != this.format) {
         throw new UnsupportedOperationException("Image formats don't match.");
      }

      int $$1 = this.format.components();
      this.checkAllocated();
      ped68e113_41_0.checkAllocated();
      if (this.width == ped68e113_41_0.width) {
         MemoryUtil.memCopy(ped68e113_41_0.pixels, this.pixels, Math.min(this.size, ped68e113_41_0.size));
      } else {
         int $$2 = Math.min(this.getWidth(), ped68e113_41_0.getWidth());
         int $$3 = Math.min(this.getHeight(), ped68e113_41_0.getHeight());

         for (int $$4 = 0; $$4 < $$3; $$4++) {
            int $$5 = $$4 * ped68e113_41_0.getWidth() * $$1;
            int $$6 = $$4 * this.getWidth() * $$1;
            MemoryUtil.memCopy(ped68e113_41_0.pixels + $$5, this.pixels + $$6, $$2);
         }
      }
   }

   public void fillRect(int ped68e113_42_0, int ped68e113_43_1, int ped68e113_44_2, int ped68e113_45_3, int ped68e113_46_4) {
      for (int $$5 = ped68e113_43_1; $$5 < ped68e113_43_1 + ped68e113_45_3; $$5++) {
         for (int $$6 = ped68e113_42_0; $$6 < ped68e113_42_0 + ped68e113_44_2; $$6++) {
            this.setPixel($$6, $$5, ped68e113_46_4);
         }
      }
   }

   public void copyRect(
      int ped68e113_47_0,
      int ped68e113_48_1,
      int ped68e113_49_2,
      int ped68e113_50_3,
      int ped68e113_51_4,
      int ped68e113_52_5,
      boolean ped68e113_53_6,
      boolean ped68e113_54_7
   ) {
      this.copyRect(
         this,
         ped68e113_47_0,
         ped68e113_48_1,
         ped68e113_47_0 + ped68e113_49_2,
         ped68e113_48_1 + ped68e113_50_3,
         ped68e113_51_4,
         ped68e113_52_5,
         ped68e113_53_6,
         ped68e113_54_7
      );
   }

   public void copyRect(
      NativeImage ped68e113_55_0,
      int ped68e113_56_1,
      int ped68e113_57_2,
      int ped68e113_58_3,
      int ped68e113_59_4,
      int ped68e113_60_5,
      int ped68e113_61_6,
      boolean ped68e113_62_7,
      boolean ped68e113_63_8
   ) {
      for (int $$9 = 0; $$9 < ped68e113_61_6; $$9++) {
         for (int $$10 = 0; $$10 < ped68e113_60_5; $$10++) {
            int $$11 = ped68e113_62_7 ? ped68e113_60_5 - 1 - $$10 : $$10;
            int $$12 = ped68e113_63_8 ? ped68e113_61_6 - 1 - $$9 : $$9;
            int $$13 = this.getPixelABGR(ped68e113_56_1 + $$10, ped68e113_57_2 + $$9);
            ped68e113_55_0.setPixelABGR(ped68e113_58_3 + $$11, ped68e113_59_4 + $$12, $$13);
         }
      }
   }

   public void resizeSubRectTo(int ped68e113_64_0, int ped68e113_65_1, int ped68e113_66_2, int ped68e113_67_3, NativeImage ped68e113_68_4) {
      this.checkAllocated();
      if (ped68e113_68_4.format() != this.format) {
         throw new UnsupportedOperationException("resizeSubRectTo only works for images of the same format.");
      }

      int $$5 = this.format.components();
      STBImageResize.nstbir_resize_uint8(
         this.pixels + (ped68e113_64_0 + ped68e113_65_1 * this.getWidth()) * $$5,
         ped68e113_66_2,
         ped68e113_67_3,
         this.getWidth() * $$5,
         ped68e113_68_4.pixels,
         ped68e113_68_4.getWidth(),
         ped68e113_68_4.getHeight(),
         0,
         $$5
      );
   }

   public void untrack() {
      DebugMemoryUntracker.untrack(this.pixels);
   }

   public long getPointer() {
      return this.pixels;
   }

   public enum Format {
      RGBA(4, true, true, true, false, true, 0, 8, 16, 255, 24, true),
      RGB(3, true, true, true, false, false, 0, 8, 16, 255, 255, true),
      LUMINANCE_ALPHA(2, false, false, false, true, true, 255, 255, 255, 0, 8, true),
      LUMINANCE(1, false, false, false, true, false, 0, 0, 0, 0, 255, true);

      final int components;
      private final boolean hasRed;
      private final boolean hasGreen;
      private final boolean hasBlue;
      private final boolean hasLuminance;
      private final boolean hasAlpha;
      private final int redOffset;
      private final int greenOffset;
      private final int blueOffset;
      private final int luminanceOffset;
      private final int alphaOffset;
      private final boolean supportedByStb;

      Format(
         final int p39e38cc8_3_2,
         final boolean p39e38cc8_4_3,
         final boolean p39e38cc8_5_4,
         final boolean p39e38cc8_6_5,
         final boolean p39e38cc8_7_6,
         final boolean p39e38cc8_8_7,
         final int p39e38cc8_9_8,
         final int p39e38cc8_10_9,
         final int p39e38cc8_11_10,
         final int p39e38cc8_12_11,
         final int p39e38cc8_13_12,
         final boolean p39e38cc8_14_13
      ) {
         this.components = p39e38cc8_3_2;
         this.hasRed = p39e38cc8_4_3;
         this.hasGreen = p39e38cc8_5_4;
         this.hasBlue = p39e38cc8_6_5;
         this.hasLuminance = p39e38cc8_7_6;
         this.hasAlpha = p39e38cc8_8_7;
         this.redOffset = p39e38cc8_9_8;
         this.greenOffset = p39e38cc8_10_9;
         this.blueOffset = p39e38cc8_11_10;
         this.luminanceOffset = p39e38cc8_12_11;
         this.alphaOffset = p39e38cc8_13_12;
         this.supportedByStb = p39e38cc8_14_13;
      }

      public int components() {
         return this.components;
      }

      public boolean hasRed() {
         return this.hasRed;
      }

      public boolean hasGreen() {
         return this.hasGreen;
      }

      public boolean hasBlue() {
         return this.hasBlue;
      }

      public boolean hasLuminance() {
         return this.hasLuminance;
      }

      public boolean hasAlpha() {
         return this.hasAlpha;
      }

      public int redOffset() {
         return this.redOffset;
      }

      public int greenOffset() {
         return this.greenOffset;
      }

      public int blueOffset() {
         return this.blueOffset;
      }

      public int luminanceOffset() {
         return this.luminanceOffset;
      }

      public int alphaOffset() {
         return this.alphaOffset;
      }

      public boolean hasLuminanceOrRed() {
         return this.hasLuminance || this.hasRed;
      }

      public boolean hasLuminanceOrGreen() {
         return this.hasLuminance || this.hasGreen;
      }

      public boolean hasLuminanceOrBlue() {
         return this.hasLuminance || this.hasBlue;
      }

      public boolean hasLuminanceOrAlpha() {
         return this.hasLuminance || this.hasAlpha;
      }

      public int luminanceOrRedOffset() {
         return this.hasLuminance ? this.luminanceOffset : this.redOffset;
      }

      public int luminanceOrGreenOffset() {
         return this.hasLuminance ? this.luminanceOffset : this.greenOffset;
      }

      public int luminanceOrBlueOffset() {
         return this.hasLuminance ? this.luminanceOffset : this.blueOffset;
      }

      public int luminanceOrAlphaOffset() {
         return this.hasLuminance ? this.luminanceOffset : this.alphaOffset;
      }

      public boolean supportedByStb() {
         return this.supportedByStb;
      }

      static NativeImage.Format getStbFormat(int p39e38cc8_15_0) {
         switch (p39e38cc8_15_0) {
            case 1:
               return LUMINANCE;
            case 2:
               return LUMINANCE_ALPHA;
            case 3:
               return RGB;
            case 4:
            default:
               return RGBA;
         }
      }
   }

   static class WriteCallback extends STBIWriteCallback {
      private final WritableByteChannel output;
      private @Nullable IOException exception;

      WriteCallback(WritableByteChannel p55921b53_0_0) {
         this.output = p55921b53_0_0;
      }

      @Override
      public void invoke(long p55921b53_1_0, long p55921b53_2_1, int p55921b53_3_2) {
         ByteBuffer $$3 = getData(p55921b53_2_1, p55921b53_3_2);

         try {
            this.output.write($$3);
         } catch (IOException $$4) {
            this.exception = $$4;
         }
      }

      public void throwIfException() throws IOException {
         if (this.exception != null) {
            throw this.exception;
         }
      }
   }
}
