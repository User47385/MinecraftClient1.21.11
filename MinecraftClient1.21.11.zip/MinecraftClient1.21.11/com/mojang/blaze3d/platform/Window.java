package com.mojang.blaze3d.platform;

import com.mojang.blaze3d.TracyFrameCapture;
import com.mojang.blaze3d.platform.cursor.CursorType;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.function.BiConsumer;
import net.minecraft.CrashReport;
import net.minecraft.CrashReportCategory;
import net.minecraft.ReportedException;
import net.minecraft.client.main.SilentInitException;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.resources.IoSupplier;
import org.jspecify.annotations.Nullable;
import org.lwjgl.PointerBuffer;
import org.lwjgl.glfw.Callbacks;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.glfw.GLFWWindowCloseCallback;
import org.lwjgl.glfw.GLFWImage.Buffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.tinyfd.TinyFileDialogs;
import org.slf4j.Logger;

public final class Window implements AutoCloseable {
   private static final Logger LOGGER = LogUtils.getLogger();
   public static final int BASE_WIDTH = 320;
   public static final int BASE_HEIGHT = 240;
   private final GLFWErrorCallback defaultErrorCallback = GLFWErrorCallback.create(this::defaultErrorCallback);
   private final WindowEventHandler eventHandler;
   private final ScreenManager screenManager;
   private final long handle;
   private int windowedX;
   private int windowedY;
   private int windowedWidth;
   private int windowedHeight;
   private Optional<VideoMode> preferredFullscreenVideoMode;
   private boolean fullscreen;
   private boolean actuallyFullscreen;
   private int x;
   private int y;
   private int width;
   private int height;
   private int framebufferWidth;
   private int framebufferHeight;
   private int guiScaledWidth;
   private int guiScaledHeight;
   private int guiScale;
   private String errorSection = "";
   private boolean dirty;
   private boolean vsync;
   private boolean iconified;
   private boolean minimized;
   private boolean allowCursorChanges;
   private CursorType currentCursor = CursorType.DEFAULT;

   public Window(WindowEventHandler pb844dd01_0_0, ScreenManager pb844dd01_1_1, DisplayData pb844dd01_2_2, @Nullable String pb844dd01_3_3, String pb844dd01_4_4) {
      this.screenManager = pb844dd01_1_1;
      this.setBootErrorCallback();
      this.setErrorSection("Pre startup");
      this.eventHandler = pb844dd01_0_0;
      Optional<VideoMode> $$5 = VideoMode.read(pb844dd01_3_3);
      if ($$5.isPresent()) {
         this.preferredFullscreenVideoMode = $$5;
      } else if (pb844dd01_2_2.fullscreenWidth().isPresent() && pb844dd01_2_2.fullscreenHeight().isPresent()) {
         this.preferredFullscreenVideoMode = Optional.of(
            new VideoMode(pb844dd01_2_2.fullscreenWidth().getAsInt(), pb844dd01_2_2.fullscreenHeight().getAsInt(), 8, 8, 8, 60)
         );
      } else {
         this.preferredFullscreenVideoMode = Optional.empty();
      }

      this.actuallyFullscreen = this.fullscreen = pb844dd01_2_2.isFullscreen();
      Monitor $$6 = pb844dd01_1_1.getMonitor(GLFW.glfwGetPrimaryMonitor());
      this.windowedWidth = this.width = Math.max(pb844dd01_2_2.width(), 1);
      this.windowedHeight = this.height = Math.max(pb844dd01_2_2.height(), 1);
      GLFW.glfwDefaultWindowHints();
      GLFW.glfwWindowHint(139265, 196609);
      GLFW.glfwWindowHint(139275, 221185);
      GLFW.glfwWindowHint(139266, 3);
      GLFW.glfwWindowHint(139267, 3);
      GLFW.glfwWindowHint(139272, 204801);
      GLFW.glfwWindowHint(139270, 1);
      this.handle = GLFW.glfwCreateWindow(this.width, this.height, pb844dd01_4_4, this.fullscreen && $$6 != null ? $$6.getMonitor() : 0L, 0L);
      if ($$6 != null) {
         VideoMode $$7 = $$6.getPreferredVidMode(this.fullscreen ? this.preferredFullscreenVideoMode : Optional.empty());
         this.windowedX = this.x = $$6.getX() + $$7.getWidth() / 2 - this.width / 2;
         this.windowedY = this.y = $$6.getY() + $$7.getHeight() / 2 - this.height / 2;
      } else {
         int[] $$8 = new int[1];
         int[] $$9 = new int[1];
         GLFW.glfwGetWindowPos(this.handle, $$8, $$9);
         this.windowedX = this.x = $$8[0];
         this.windowedY = this.y = $$9[0];
      }

      this.setMode();
      this.refreshFramebufferSize();
      GLFW.glfwSetFramebufferSizeCallback(this.handle, this::onFramebufferResize);
      GLFW.glfwSetWindowPosCallback(this.handle, this::onMove);
      GLFW.glfwSetWindowSizeCallback(this.handle, this::onResize);
      GLFW.glfwSetWindowFocusCallback(this.handle, this::onFocus);
      GLFW.glfwSetCursorEnterCallback(this.handle, this::onEnter);
      GLFW.glfwSetWindowIconifyCallback(this.handle, this::onIconify);
   }

   public static String getPlatform() {
      int $$0 = GLFW.glfwGetPlatform();

      return switch ($$0) {
         case 0 -> "<error>";
         case 393217 -> "win32";
         case 393218 -> "cocoa";
         case 393219 -> "wayland";
         case 393220 -> "x11";
         case 393221 -> "null";
         default -> String.format(Locale.ROOT, "unknown (%08X)", $$0);
      };
   }

   public int getRefreshRate() {
      RenderSystem.assertOnRenderThread();
      return GLX._getRefreshRate(this);
   }

   public boolean shouldClose() {
      return GLX._shouldClose(this);
   }

   public static void checkGlfwError(BiConsumer<Integer, String> pb844dd01_5_0) {
      try (MemoryStack $$1 = MemoryStack.stackPush()) {
         PointerBuffer $$2 = $$1.mallocPointer(1);
         int $$3 = GLFW.glfwGetError($$2);
         if ($$3 != 0) {
            long $$4 = $$2.get();
            String $$5 = $$4 == 0L ? "" : MemoryUtil.memUTF8($$4);
            pb844dd01_5_0.accept($$3, $$5);
         }
      }
   }

   public void setIcon(PackResources pb844dd01_6_0, IconSet pb844dd01_7_1) throws IOException {
      int $$2 = GLFW.glfwGetPlatform();
      switch ($$2) {
         case 393217:
         case 393220:
            List<IoSupplier<InputStream>> $$3 = pb844dd01_7_1.getStandardIcons(pb844dd01_6_0);
            List<ByteBuffer> $$4 = new ArrayList<>($$3.size());

            try (MemoryStack $$5 = MemoryStack.stackPush()) {
               Buffer $$6 = GLFWImage.malloc($$3.size(), $$5);

               for (int $$7 = 0; $$7 < $$3.size(); $$7++) {
                  try (NativeImage $$8 = NativeImage.read($$3.get($$7).get())) {
                     ByteBuffer $$9 = MemoryUtil.memAlloc($$8.getWidth() * $$8.getHeight() * 4);
                     $$4.add($$9);
                     $$9.asIntBuffer().put($$8.getPixelsABGR());
                     $$6.position($$7);
                     $$6.width($$8.getWidth());
                     $$6.height($$8.getHeight());
                     $$6.pixels($$9);
                  }
               }

               GLFW.glfwSetWindowIcon(this.handle, $$6.position(0));
               break;
            } finally {
               $$4.forEach(MemoryUtil::memFree);
            }
         case 393218:
            MacosUtil.loadIcon(pb844dd01_7_1.getMacIcon(pb844dd01_6_0));
         case 393219:
         case 393221:
            break;
         default:
            LOGGER.warn("Not setting icon for unrecognized platform: {}", $$2);
      }
   }

   public void setErrorSection(String pb844dd01_8_0) {
      this.errorSection = pb844dd01_8_0;
   }

   private void setBootErrorCallback() {
      GLFW.glfwSetErrorCallback(Window::bootCrash);
   }

   private static void bootCrash(int pb844dd01_9_0, long pb844dd01_10_1) {
      String $$2 = "GLFW error " + pb844dd01_9_0 + ": " + MemoryUtil.memUTF8(pb844dd01_10_1);
      TinyFileDialogs.tinyfd_messageBox(
         "Minecraft", $$2 + ".\n\nPlease make sure you have up-to-date drivers (see aka.ms/mcdriver for instructions).", "ok", "error", false
      );
      throw new Window.WindowInitFailed($$2);
   }

   public void defaultErrorCallback(int pb844dd01_11_0, long pb844dd01_12_1) {
      RenderSystem.assertOnRenderThread();
      String $$2 = MemoryUtil.memUTF8(pb844dd01_12_1);
      LOGGER.error("########## GL ERROR ##########");
      LOGGER.error("@ {}", this.errorSection);
      LOGGER.error("{}: {}", pb844dd01_11_0, $$2);
   }

   public void setDefaultErrorCallback() {
      GLFWErrorCallback $$0 = GLFW.glfwSetErrorCallback(this.defaultErrorCallback);
      if ($$0 != null) {
         $$0.free();
      }
   }

   public void updateVsync(boolean pb844dd01_13_0) {
      RenderSystem.assertOnRenderThread();
      this.vsync = pb844dd01_13_0;
      GLFW.glfwSwapInterval(pb844dd01_13_0 ? 1 : 0);
   }

   @Override
   public void close() {
      RenderSystem.assertOnRenderThread();
      Callbacks.glfwFreeCallbacks(this.handle);
      this.defaultErrorCallback.close();
      GLFW.glfwDestroyWindow(this.handle);
      GLFW.glfwTerminate();
   }

   private void onMove(long pb844dd01_14_0, int pb844dd01_15_1, int pb844dd01_16_2) {
      this.x = pb844dd01_15_1;
      this.y = pb844dd01_16_2;
   }

   private void onFramebufferResize(long pb844dd01_17_0, int pb844dd01_18_1, int pb844dd01_19_2) {
      if (pb844dd01_17_0 == this.handle) {
         int $$3 = this.getWidth();
         int $$4 = this.getHeight();
         if (pb844dd01_18_1 != 0 && pb844dd01_19_2 != 0) {
            this.minimized = false;
            this.framebufferWidth = pb844dd01_18_1;
            this.framebufferHeight = pb844dd01_19_2;
            if (this.getWidth() != $$3 || this.getHeight() != $$4) {
               try {
                  this.eventHandler.resizeDisplay();
               } catch (Exception $$5) {
                  CrashReport $$6 = CrashReport.forThrowable($$5, "Window resize");
                  CrashReportCategory $$7 = $$6.addCategory("Window Dimensions");
                  $$7.setDetail("Old", $$3 + "x" + $$4);
                  $$7.setDetail("New", pb844dd01_18_1 + "x" + pb844dd01_19_2);
                  throw new ReportedException($$6);
               }
            }
         } else {
            this.minimized = true;
         }
      }
   }

   private void refreshFramebufferSize() {
      int[] $$0 = new int[1];
      int[] $$1 = new int[1];
      GLFW.glfwGetFramebufferSize(this.handle, $$0, $$1);
      this.framebufferWidth = $$0[0] > 0 ? $$0[0] : 1;
      this.framebufferHeight = $$1[0] > 0 ? $$1[0] : 1;
   }

   private void onResize(long pb844dd01_20_0, int pb844dd01_21_1, int pb844dd01_22_2) {
      this.width = pb844dd01_21_1;
      this.height = pb844dd01_22_2;
   }

   private void onFocus(long pb844dd01_23_0, boolean pb844dd01_24_1) {
      if (pb844dd01_23_0 == this.handle) {
         this.eventHandler.setWindowActive(pb844dd01_24_1);
      }
   }

   private void onEnter(long pb844dd01_25_0, boolean pb844dd01_26_1) {
      if (pb844dd01_26_1) {
         this.eventHandler.cursorEntered();
      }
   }

   private void onIconify(long pb844dd01_27_0, boolean pb844dd01_28_1) {
      this.iconified = pb844dd01_28_1;
   }

   public void updateDisplay(@Nullable TracyFrameCapture pb844dd01_29_0) {
      RenderSystem.flipFrame(this, pb844dd01_29_0);
      if (this.fullscreen != this.actuallyFullscreen) {
         this.actuallyFullscreen = this.fullscreen;
         this.updateFullscreen(this.vsync, pb844dd01_29_0);
      }
   }

   public Optional<VideoMode> getPreferredFullscreenVideoMode() {
      return this.preferredFullscreenVideoMode;
   }

   public void setPreferredFullscreenVideoMode(Optional<VideoMode> pb844dd01_30_0) {
      boolean $$1 = !pb844dd01_30_0.equals(this.preferredFullscreenVideoMode);
      this.preferredFullscreenVideoMode = pb844dd01_30_0;
      if ($$1) {
         this.dirty = true;
      }
   }

   public void changeFullscreenVideoMode() {
      if (this.fullscreen && this.dirty) {
         this.dirty = false;
         this.setMode();
         this.eventHandler.resizeDisplay();
      }
   }

   private void setMode() {
      boolean $$0 = GLFW.glfwGetWindowMonitor(this.handle) != 0L;
      if (this.fullscreen) {
         Monitor $$1 = this.screenManager.findBestMonitor(this);
         if ($$1 == null) {
            LOGGER.warn("Failed to find suitable monitor for fullscreen mode");
            this.fullscreen = false;
         } else {
            if (MacosUtil.IS_MACOS) {
               MacosUtil.exitNativeFullscreen(this);
            }

            VideoMode $$2 = $$1.getPreferredVidMode(this.preferredFullscreenVideoMode);
            if (!$$0) {
               this.windowedX = this.x;
               this.windowedY = this.y;
               this.windowedWidth = this.width;
               this.windowedHeight = this.height;
            }

            this.x = 0;
            this.y = 0;
            this.width = $$2.getWidth();
            this.height = $$2.getHeight();
            GLFW.glfwSetWindowMonitor(this.handle, $$1.getMonitor(), this.x, this.y, this.width, this.height, $$2.getRefreshRate());
            if (MacosUtil.IS_MACOS) {
               MacosUtil.clearResizableBit(this);
            }
         }
      } else {
         this.x = this.windowedX;
         this.y = this.windowedY;
         this.width = this.windowedWidth;
         this.height = this.windowedHeight;
         GLFW.glfwSetWindowMonitor(this.handle, 0L, this.x, this.y, this.width, this.height, -1);
      }
   }

   public void toggleFullScreen() {
      this.fullscreen = !this.fullscreen;
   }

   public void setWindowed(int pb844dd01_31_0, int pb844dd01_32_1) {
      this.windowedWidth = pb844dd01_31_0;
      this.windowedHeight = pb844dd01_32_1;
      this.fullscreen = false;
      this.setMode();
   }

   private void updateFullscreen(boolean pb844dd01_33_0, @Nullable TracyFrameCapture pb844dd01_34_1) {
      RenderSystem.assertOnRenderThread();

      try {
         this.setMode();
         this.eventHandler.resizeDisplay();
         this.updateVsync(pb844dd01_33_0);
         this.updateDisplay(pb844dd01_34_1);
      } catch (Exception $$2) {
         LOGGER.error("Couldn't toggle fullscreen", $$2);
      }
   }

   public int calculateScale(int pb844dd01_35_0, boolean pb844dd01_36_1) {
      int $$2 = 1;

      while (
         $$2 != pb844dd01_35_0
            && $$2 < this.framebufferWidth
            && $$2 < this.framebufferHeight
            && this.framebufferWidth / ($$2 + 1) >= 320
            && this.framebufferHeight / ($$2 + 1) >= 240
      ) {
         $$2++;
      }

      if (pb844dd01_36_1 && $$2 % 2 != 0) {
         $$2++;
      }

      return $$2;
   }

   public void setGuiScale(int pb844dd01_37_0) {
      this.guiScale = pb844dd01_37_0;
      double $$1 = pb844dd01_37_0;
      int $$2 = (int)(this.framebufferWidth / $$1);
      this.guiScaledWidth = this.framebufferWidth / $$1 > $$2 ? $$2 + 1 : $$2;
      int $$3 = (int)(this.framebufferHeight / $$1);
      this.guiScaledHeight = this.framebufferHeight / $$1 > $$3 ? $$3 + 1 : $$3;
   }

   public void setTitle(String pb844dd01_38_0) {
      GLFW.glfwSetWindowTitle(this.handle, pb844dd01_38_0);
   }

   public long handle() {
      return this.handle;
   }

   public boolean isFullscreen() {
      return this.fullscreen;
   }

   public boolean isIconified() {
      return this.iconified;
   }

   public int getWidth() {
      return this.framebufferWidth;
   }

   public int getHeight() {
      return this.framebufferHeight;
   }

   public void setWidth(int pb844dd01_39_0) {
      this.framebufferWidth = pb844dd01_39_0;
   }

   public void setHeight(int pb844dd01_40_0) {
      this.framebufferHeight = pb844dd01_40_0;
   }

   public int getScreenWidth() {
      return this.width;
   }

   public int getScreenHeight() {
      return this.height;
   }

   public int getGuiScaledWidth() {
      return this.guiScaledWidth;
   }

   public int getGuiScaledHeight() {
      return this.guiScaledHeight;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getGuiScale() {
      return this.guiScale;
   }

   public @Nullable Monitor findBestMonitor() {
      return this.screenManager.findBestMonitor(this);
   }

   public void updateRawMouseInput(boolean pb844dd01_41_0) {
      InputConstants.updateRawMouseInput(this, pb844dd01_41_0);
   }

   public void setWindowCloseCallback(Runnable pb844dd01_42_0) {
      GLFWWindowCloseCallback $$1 = GLFW.glfwSetWindowCloseCallback(this.handle, pb844dd01_46_1 -> pb844dd01_42_0.run());
      if ($$1 != null) {
         $$1.free();
      }
   }

   public boolean isMinimized() {
      return this.minimized;
   }

   public void setAllowCursorChanges(boolean pb844dd01_43_0) {
      this.allowCursorChanges = pb844dd01_43_0;
   }

   public void selectCursor(CursorType pb844dd01_44_0) {
      CursorType $$1 = this.allowCursorChanges ? pb844dd01_44_0 : CursorType.DEFAULT;
      if (this.currentCursor != $$1) {
         this.currentCursor = $$1;
         $$1.select(this);
      }
   }

   public float getAppropriateLineWidth() {
      return Math.max(2.5F, this.getWidth() / 1920.0F * 2.5F);
   }

   public static class WindowInitFailed extends SilentInitException {
      WindowInitFailed(String p1c4a86e0_0_0) {
         super(p1c4a86e0_0_0);
      }
   }
}
