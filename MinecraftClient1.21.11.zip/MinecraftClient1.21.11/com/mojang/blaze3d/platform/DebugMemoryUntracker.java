package com.mojang.blaze3d.platform;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.Pointer;

public class DebugMemoryUntracker {
   private static final @Nullable MethodHandle UNTRACK = GLX.make(() -> {
      try {
         Lookup $$0 = MethodHandles.lookup();
         Class<?> $$1 = Class.forName("org.lwjgl.system.MemoryManage$DebugAllocator");
         Method $$2 = $$1.getDeclaredMethod("untrack", long.class);
         $$2.setAccessible(true);
         Field $$3 = Class.forName("org.lwjgl.system.MemoryUtil$LazyInit").getDeclaredField("ALLOCATOR");
         $$3.setAccessible(true);
         Object $$4 = $$3.get(null);
         return $$1.isInstance($$4) ? $$0.unreflect($$2) : null;
      } catch (ClassNotFoundException | NoSuchMethodException | NoSuchFieldException | IllegalAccessException $$5) {
         throw new RuntimeException($$5);
      }
   });

   public static void untrack(long pac9eefc_0_0) {
      if (UNTRACK != null) {
         try {
            UNTRACK.invoke((long)pac9eefc_0_0);
         } catch (Throwable $$1) {
            throw new RuntimeException($$1);
         }
      }
   }

   public static void untrack(Pointer pac9eefc_1_0) {
      untrack(pac9eefc_1_0.address());
   }
}
