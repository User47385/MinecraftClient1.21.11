package com.mojang.blaze3d.platform;

import java.io.File;
import java.time.Duration;
import net.minecraft.CrashReport;
import net.minecraft.client.Minecraft;
import net.minecraft.server.dedicated.ServerWatchdog;

public class ClientShutdownWatchdog {
   private static final Duration CRASH_REPORT_PRELOAD_LOAD = Duration.ofSeconds(15L);

   public static void startShutdownWatchdog(File pc37b0f7f_0_0, long pc37b0f7f_1_1) {
      Thread $$2 = new Thread(() -> {
         try {
            Thread.sleep(CRASH_REPORT_PRELOAD_LOAD);
         } catch (InterruptedException $$2x) {
            return;
         }

         CrashReport $$3 = ServerWatchdog.createWatchdogCrashReport("Client shutdown", pc37b0f7f_1_1);
         Minecraft.saveReport(pc37b0f7f_0_0, $$3);
      });
      $$2.setDaemon(true);
      $$2.setName("Client shutdown watchdog");
      $$2.start();
   }
}
