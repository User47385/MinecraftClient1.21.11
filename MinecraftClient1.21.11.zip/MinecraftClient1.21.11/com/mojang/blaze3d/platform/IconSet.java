package com.mojang.blaze3d.platform;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.resources.IoSupplier;
import org.apache.commons.lang3.ArrayUtils;

public enum IconSet {
   RELEASE("icons"),
   SNAPSHOT("icons", "snapshot");

   private final String[] path;

   IconSet(final String... p6194aa38_3_2) {
      this.path = p6194aa38_3_2;
   }

   public List<IoSupplier<InputStream>> getStandardIcons(PackResources p6194aa38_4_0) throws IOException {
      return List.of(
         this.getFile(p6194aa38_4_0, "icon_16x16.png"),
         this.getFile(p6194aa38_4_0, "icon_32x32.png"),
         this.getFile(p6194aa38_4_0, "icon_48x48.png"),
         this.getFile(p6194aa38_4_0, "icon_128x128.png"),
         this.getFile(p6194aa38_4_0, "icon_256x256.png")
      );
   }

   public IoSupplier<InputStream> getMacIcon(PackResources p6194aa38_5_0) throws IOException {
      return this.getFile(p6194aa38_5_0, "minecraft.icns");
   }

   private IoSupplier<InputStream> getFile(PackResources p6194aa38_6_0, String p6194aa38_7_1) throws IOException {
      String[] $$2 = ArrayUtils.add(this.path, p6194aa38_7_1);
      IoSupplier<InputStream> $$3 = p6194aa38_6_0.getRootResource($$2);
      if ($$3 == null) {
         throw new FileNotFoundException(String.join("/", $$2));
      } else {
         return $$3;
      }
   }
}
