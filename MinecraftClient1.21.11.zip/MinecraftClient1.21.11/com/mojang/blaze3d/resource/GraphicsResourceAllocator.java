package com.mojang.blaze3d.resource;

public interface GraphicsResourceAllocator {
   GraphicsResourceAllocator UNPOOLED = new GraphicsResourceAllocator() {
      @Override
      public <T> T acquire(ResourceDescriptor<T> pc0f57309_0_0) {
         T $$1 = pc0f57309_0_0.allocate();
         pc0f57309_0_0.prepare($$1);
         return $$1;
      }

      @Override
      public <T> void release(ResourceDescriptor<T> pc0f57309_1_0, T pc0f57309_2_1) {
         pc0f57309_1_0.free(pc0f57309_2_1);
      }
   };

   <T> T acquire(ResourceDescriptor<T> var1);

   <T> void release(ResourceDescriptor<T> var1, T var2);
}
