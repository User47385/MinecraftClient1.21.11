package com.mojang.blaze3d.resource;

import com.google.common.annotations.VisibleForTesting;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Deque;
import java.util.Iterator;

public class CrossFrameResourcePool implements GraphicsResourceAllocator, AutoCloseable {
   private final int framesToKeepResource;
   private final Deque<CrossFrameResourcePool.ResourceEntry<?>> pool = new ArrayDeque<>();

   public CrossFrameResourcePool(int pfd0a100d_0_0) {
      this.framesToKeepResource = pfd0a100d_0_0;
   }

   public void endFrame() {
      Iterator<? extends CrossFrameResourcePool.ResourceEntry<?>> $$0 = this.pool.iterator();

      while ($$0.hasNext()) {
         CrossFrameResourcePool.ResourceEntry<?> $$1 = (CrossFrameResourcePool.ResourceEntry<?>)$$0.next();
         if ($$1.framesToLive-- == 0) {
            $$1.close();
            $$0.remove();
         }
      }
   }

   @Override
   public <T> T acquire(ResourceDescriptor<T> pfd0a100d_1_0) {
      T $$1 = this.acquireWithoutPreparing(pfd0a100d_1_0);
      pfd0a100d_1_0.prepare($$1);
      return $$1;
   }

   private <T> T acquireWithoutPreparing(ResourceDescriptor<T> pfd0a100d_2_0) {
      Iterator<? extends CrossFrameResourcePool.ResourceEntry<?>> $$1 = this.pool.iterator();

      while ($$1.hasNext()) {
         CrossFrameResourcePool.ResourceEntry<?> $$2 = (CrossFrameResourcePool.ResourceEntry<?>)$$1.next();
         if (pfd0a100d_2_0.canUsePhysicalResource($$2.descriptor)) {
            $$1.remove();
            return (T)$$2.value;
         }
      }

      return pfd0a100d_2_0.allocate();
   }

   @Override
   public <T> void release(ResourceDescriptor<T> pfd0a100d_3_0, T pfd0a100d_4_1) {
      this.pool.addFirst(new CrossFrameResourcePool.ResourceEntry<>(pfd0a100d_3_0, pfd0a100d_4_1, this.framesToKeepResource));
   }

   public void clear() {
      this.pool.forEach(CrossFrameResourcePool.ResourceEntry::close);
      this.pool.clear();
   }

   @Override
   public void close() {
      this.clear();
   }

   @VisibleForTesting
   protected Collection<CrossFrameResourcePool.ResourceEntry<?>> entries() {
      return this.pool;
   }

   @VisibleForTesting
   protected static final class ResourceEntry<T> implements AutoCloseable {
      final ResourceDescriptor<T> descriptor;
      final T value;
      int framesToLive;

      ResourceEntry(ResourceDescriptor<T> pd614ac8d_0_0, T pd614ac8d_1_1, int pd614ac8d_2_2) {
         this.descriptor = pd614ac8d_0_0;
         this.value = pd614ac8d_1_1;
         this.framesToLive = pd614ac8d_2_2;
      }

      @Override
      public void close() {
         this.descriptor.free(this.value);
      }
   }
}
