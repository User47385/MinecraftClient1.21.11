package com.mojang.blaze3d.resource;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;

public record RenderTargetDescriptor(int width, int height, boolean useDepth, int clearColor) implements ResourceDescriptor<RenderTarget> {
   public RenderTarget allocate() {
      return new TextureTarget(null, this.width, this.height, this.useDepth);
   }

   public void prepare(RenderTarget p13063eac_4_0) {
      if (this.useDepth) {
         RenderSystem.getDevice()
            .createCommandEncoder()
            .clearColorAndDepthTextures(p13063eac_4_0.getColorTexture(), this.clearColor, p13063eac_4_0.getDepthTexture(), 1.0);
      } else {
         RenderSystem.getDevice().createCommandEncoder().clearColorTexture(p13063eac_4_0.getColorTexture(), this.clearColor);
      }
   }

   public void free(RenderTarget p13063eac_5_0) {
      p13063eac_5_0.destroyBuffers();
   }

   @Override
   public boolean canUsePhysicalResource(ResourceDescriptor<?> p13063eac_6_0) {
      return !(p13063eac_6_0 instanceof RenderTargetDescriptor $$1)
         ? false
         : this.width == $$1.width && this.height == $$1.height && this.useDepth == $$1.useDepth;
   }
}
