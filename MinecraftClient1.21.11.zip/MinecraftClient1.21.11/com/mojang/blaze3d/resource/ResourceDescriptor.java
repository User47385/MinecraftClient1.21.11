package com.mojang.blaze3d.resource;

public interface ResourceDescriptor<T> {
   T allocate();

   default void prepare(T p474ba33_0_0) {
   }

   void free(T var1);

   default boolean canUsePhysicalResource(ResourceDescriptor<?> p474ba33_1_0) {
      return this.equals(p474ba33_1_0);
   }
}
