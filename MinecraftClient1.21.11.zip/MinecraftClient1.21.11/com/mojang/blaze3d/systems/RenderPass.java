package com.mojang.blaze3d.systems;

import com.mojang.blaze3d.DontObfuscate;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.textures.GpuSampler;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.util.Collection;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import org.jspecify.annotations.Nullable;

@DontObfuscate
public interface RenderPass extends AutoCloseable {
   void pushDebugGroup(Supplier<String> var1);

   void popDebugGroup();

   void setPipeline(RenderPipeline var1);

   void bindTexture(String var1, @Nullable GpuTextureView var2, @Nullable GpuSampler var3);

   void setUniform(String var1, GpuBuffer var2);

   void setUniform(String var1, GpuBufferSlice var2);

   void enableScissor(int var1, int var2, int var3, int var4);

   void disableScissor();

   void setVertexBuffer(int var1, GpuBuffer var2);

   void setIndexBuffer(GpuBuffer var1, VertexFormat.IndexType var2);

   void drawIndexed(int var1, int var2, int var3, int var4);

   <T> void drawMultipleIndexed(
      Collection<RenderPass.Draw<T>> var1, @Nullable GpuBuffer var2, VertexFormat.@Nullable IndexType var3, Collection<String> var4, T var5
   );

   void draw(int var1, int var2);

   @Override
   void close();

   record Draw<T>(
      int slot,
      GpuBuffer vertexBuffer,
      @Nullable GpuBuffer indexBuffer,
      VertexFormat.@Nullable IndexType indexType,
      int firstIndex,
      int indexCount,
      @Nullable BiConsumer<T, RenderPass.UniformUploader> uniformUploaderConsumer
   ) {
      public Draw(
         int p8b3003eb_0_0, GpuBuffer p8b3003eb_1_1, GpuBuffer p8b3003eb_2_2, VertexFormat.IndexType p8b3003eb_3_3, int p8b3003eb_4_4, int p8b3003eb_5_5
      ) {
         this(p8b3003eb_0_0, p8b3003eb_1_1, p8b3003eb_2_2, p8b3003eb_3_3, p8b3003eb_4_4, p8b3003eb_5_5, null);
      }
   }

   interface UniformUploader {
      void upload(String var1, GpuBufferSlice var2);
   }
}
