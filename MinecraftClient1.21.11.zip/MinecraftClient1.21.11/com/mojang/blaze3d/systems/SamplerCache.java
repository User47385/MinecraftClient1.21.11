package com.mojang.blaze3d.systems;

import com.google.common.annotations.VisibleForTesting;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;
import java.util.OptionalDouble;

public class SamplerCache {
   private final GpuSampler[] samplers = new GpuSampler[32];

   public void initialize() {
      GpuDevice $$0 = RenderSystem.getDevice();
      if (AddressMode.values().length == 2 && FilterMode.values().length == 2) {
         for (AddressMode $$1 : AddressMode.values()) {
            for (AddressMode $$2 : AddressMode.values()) {
               for (FilterMode $$3 : FilterMode.values()) {
                  for (FilterMode $$4 : FilterMode.values()) {
                     for (boolean $$5 : new boolean[]{true, false}) {
                        this.samplers[encode($$1, $$2, $$3, $$4, $$5)] = $$0.createSampler(
                           $$1, $$2, $$3, $$4, 1, $$5 ? OptionalDouble.empty() : OptionalDouble.of(0.0)
                        );
                     }
                  }
               }
            }
         }
      } else {
         throw new IllegalStateException("AddressMode and FilterMode enum sizes must be 2 - if you expanded them, please update SamplerCache");
      }
   }

   public GpuSampler getSampler(AddressMode p7f9379d0_0_0, AddressMode p7f9379d0_1_1, FilterMode p7f9379d0_2_2, FilterMode p7f9379d0_3_3, boolean p7f9379d0_4_4) {
      return this.samplers[encode(p7f9379d0_0_0, p7f9379d0_1_1, p7f9379d0_2_2, p7f9379d0_3_3, p7f9379d0_4_4)];
   }

   public GpuSampler getClampToEdge(FilterMode p7f9379d0_5_0) {
      return this.getSampler(AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, p7f9379d0_5_0, p7f9379d0_5_0, false);
   }

   public GpuSampler getClampToEdge(FilterMode p7f9379d0_6_0, boolean p7f9379d0_7_1) {
      return this.getSampler(AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, p7f9379d0_6_0, p7f9379d0_6_0, p7f9379d0_7_1);
   }

   public GpuSampler getRepeat(FilterMode p7f9379d0_8_0) {
      return this.getSampler(AddressMode.REPEAT, AddressMode.REPEAT, p7f9379d0_8_0, p7f9379d0_8_0, false);
   }

   public GpuSampler getRepeat(FilterMode p7f9379d0_9_0, boolean p7f9379d0_10_1) {
      return this.getSampler(AddressMode.REPEAT, AddressMode.REPEAT, p7f9379d0_9_0, p7f9379d0_9_0, p7f9379d0_10_1);
   }

   public void close() {
      for (GpuSampler $$0 : this.samplers) {
         $$0.close();
      }
   }

   @VisibleForTesting
   static int encode(AddressMode p7f9379d0_11_0, AddressMode p7f9379d0_12_1, FilterMode p7f9379d0_13_2, FilterMode p7f9379d0_14_3, boolean p7f9379d0_15_4) {
      int $$5 = 0;
      $$5 |= p7f9379d0_11_0.ordinal() & 1;
      $$5 |= (p7f9379d0_12_1.ordinal() & 1) << 1;
      $$5 |= (p7f9379d0_13_2.ordinal() & 1) << 2;
      $$5 |= (p7f9379d0_14_3.ordinal() & 1) << 3;
      if (p7f9379d0_15_4) {
         $$5 |= 16;
      }

      return $$5;
   }
}
