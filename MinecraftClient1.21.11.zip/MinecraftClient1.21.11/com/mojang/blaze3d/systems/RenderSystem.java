package com.mojang.blaze3d.systems;

import com.mojang.blaze3d.DontObfuscate;
import com.mojang.blaze3d.ProjectionType;
import com.mojang.blaze3d.TracyFrameCapture;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.opengl.GlDevice;
import com.mojang.blaze3d.platform.GLX;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.shaders.ShaderSource;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.logging.LogUtils;
import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.IntConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.DynamicUniforms;
import net.minecraft.util.ArrayListDeque;
import net.minecraft.util.Mth;
import net.minecraft.util.TimeSource;
import net.minecraft.util.Util;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.jspecify.annotations.Nullable;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallbackI;
import org.lwjgl.system.MemoryUtil;
import org.slf4j.Logger;

@DontObfuscate
public class RenderSystem {
   static final Logger LOGGER = LogUtils.getLogger();
   public static final int MINIMUM_ATLAS_TEXTURE_SIZE = 1024;
   public static final int PROJECTION_MATRIX_UBO_SIZE = new Std140SizeCalculator().putMat4f().get();
   private static @Nullable Thread renderThread;
   private static @Nullable GpuDevice DEVICE;
   private static double lastDrawTime = Double.MIN_VALUE;
   private static final RenderSystem.AutoStorageIndexBuffer sharedSequential = new RenderSystem.AutoStorageIndexBuffer(1, 1, IntConsumer::accept);
   private static final RenderSystem.AutoStorageIndexBuffer sharedSequentialQuad = new RenderSystem.AutoStorageIndexBuffer(
      4, 6, (p732cccdb_23_0, p732cccdb_24_1) -> {
         p732cccdb_23_0.accept(p732cccdb_24_1);
         p732cccdb_23_0.accept(p732cccdb_24_1 + 1);
         p732cccdb_23_0.accept(p732cccdb_24_1 + 2);
         p732cccdb_23_0.accept(p732cccdb_24_1 + 2);
         p732cccdb_23_0.accept(p732cccdb_24_1 + 3);
         p732cccdb_23_0.accept(p732cccdb_24_1);
      }
   );
   private static final RenderSystem.AutoStorageIndexBuffer sharedSequentialLines = new RenderSystem.AutoStorageIndexBuffer(
      4, 6, (p732cccdb_21_0, p732cccdb_22_1) -> {
         p732cccdb_21_0.accept(p732cccdb_22_1);
         p732cccdb_21_0.accept(p732cccdb_22_1 + 1);
         p732cccdb_21_0.accept(p732cccdb_22_1 + 2);
         p732cccdb_21_0.accept(p732cccdb_22_1 + 3);
         p732cccdb_21_0.accept(p732cccdb_22_1 + 2);
         p732cccdb_21_0.accept(p732cccdb_22_1 + 1);
      }
   );
   private static ProjectionType projectionType = ProjectionType.PERSPECTIVE;
   private static ProjectionType savedProjectionType = ProjectionType.PERSPECTIVE;
   private static final Matrix4fStack modelViewStack = new Matrix4fStack(16);
   private static @Nullable GpuBufferSlice shaderFog = null;
   private static @Nullable GpuBufferSlice shaderLightDirections;
   private static @Nullable GpuBufferSlice projectionMatrixBuffer;
   private static @Nullable GpuBufferSlice savedProjectionMatrixBuffer;
   private static String apiDescription = "Unknown";
   private static final AtomicLong pollEventsWaitStart = new AtomicLong();
   private static final AtomicBoolean pollingEvents = new AtomicBoolean(false);
   private static final ArrayListDeque<RenderSystem.GpuAsyncTask> PENDING_FENCES = new ArrayListDeque<>();
   public static @Nullable GpuTextureView outputColorTextureOverride;
   public static @Nullable GpuTextureView outputDepthTextureOverride;
   private static @Nullable GpuBuffer globalSettingsUniform;
   private static @Nullable DynamicUniforms dynamicUniforms;
   private static final ScissorState scissorStateForRenderTypeDraws = new ScissorState();
   private static SamplerCache samplerCache = new SamplerCache();

   public static SamplerCache getSamplerCache() {
      return samplerCache;
   }

   public static void initRenderThread() {
      if (renderThread != null) {
         throw new IllegalStateException("Could not initialize render thread");
      }

      renderThread = Thread.currentThread();
   }

   public static boolean isOnRenderThread() {
      return Thread.currentThread() == renderThread;
   }

   public static void assertOnRenderThread() {
      if (!isOnRenderThread()) {
         throw constructThreadException();
      }
   }

   private static IllegalStateException constructThreadException() {
      return new IllegalStateException("Rendersystem called from wrong thread");
   }

   private static void pollEvents() {
      pollEventsWaitStart.set(Util.getMillis());
      pollingEvents.set(true);
      GLFW.glfwPollEvents();
      pollingEvents.set(false);
   }

   public static boolean isFrozenAtPollEvents() {
      return pollingEvents.get() && Util.getMillis() - pollEventsWaitStart.get() > 200L;
   }

   public static void flipFrame(Window p732cccdb_0_0, @Nullable TracyFrameCapture p732cccdb_1_1) {
      pollEvents();
      Tesselator.getInstance().clear();
      GLFW.glfwSwapBuffers(p732cccdb_0_0.handle());
      if (p732cccdb_1_1 != null) {
         p732cccdb_1_1.endFrame();
      }

      dynamicUniforms.reset();
      Minecraft.getInstance().levelRenderer.endFrame();
      pollEvents();
   }

   public static void limitDisplayFPS(int p732cccdb_2_0) {
      double $$1 = lastDrawTime + 1.0 / p732cccdb_2_0;

      double $$2;
      for ($$2 = GLFW.glfwGetTime(); $$2 < $$1; $$2 = GLFW.glfwGetTime()) {
         GLFW.glfwWaitEventsTimeout($$1 - $$2);
      }

      lastDrawTime = $$2;
   }

   public static void setShaderFog(GpuBufferSlice p732cccdb_3_0) {
      shaderFog = p732cccdb_3_0;
   }

   public static @Nullable GpuBufferSlice getShaderFog() {
      return shaderFog;
   }

   public static void setShaderLights(GpuBufferSlice p732cccdb_4_0) {
      shaderLightDirections = p732cccdb_4_0;
   }

   public static @Nullable GpuBufferSlice getShaderLights() {
      return shaderLightDirections;
   }

   public static void enableScissorForRenderTypeDraws(int p732cccdb_5_0, int p732cccdb_6_1, int p732cccdb_7_2, int p732cccdb_8_3) {
      scissorStateForRenderTypeDraws.enable(p732cccdb_5_0, p732cccdb_6_1, p732cccdb_7_2, p732cccdb_8_3);
   }

   public static void disableScissorForRenderTypeDraws() {
      scissorStateForRenderTypeDraws.disable();
   }

   public static ScissorState getScissorStateForRenderTypeDraws() {
      return scissorStateForRenderTypeDraws;
   }

   public static String getBackendDescription() {
      return String.format(Locale.ROOT, "LWJGL version %s", GLX._getLWJGLVersion());
   }

   public static String getApiDescription() {
      return apiDescription;
   }

   public static TimeSource.NanoTimeSource initBackendSystem() {
      return GLX._initGlfw()::getAsLong;
   }

   public static void initRenderer(long p732cccdb_9_0, int p732cccdb_10_1, boolean p732cccdb_11_2, ShaderSource p732cccdb_12_3, boolean p732cccdb_13_4) {
      DEVICE = new GlDevice(p732cccdb_9_0, p732cccdb_10_1, p732cccdb_11_2, p732cccdb_12_3, p732cccdb_13_4);
      apiDescription = getDevice().getImplementationInformation();
      dynamicUniforms = new DynamicUniforms();
      samplerCache.initialize();
   }

   public static void setErrorCallback(GLFWErrorCallbackI p732cccdb_14_0) {
      GLX._setGlfwErrorCallback(p732cccdb_14_0);
   }

   public static void setupDefaultState() {
      modelViewStack.clear();
   }

   public static void setProjectionMatrix(GpuBufferSlice p732cccdb_15_0, ProjectionType p732cccdb_16_1) {
      assertOnRenderThread();
      projectionMatrixBuffer = p732cccdb_15_0;
      projectionType = p732cccdb_16_1;
   }

   public static void backupProjectionMatrix() {
      assertOnRenderThread();
      savedProjectionMatrixBuffer = projectionMatrixBuffer;
      savedProjectionType = projectionType;
   }

   public static void restoreProjectionMatrix() {
      assertOnRenderThread();
      projectionMatrixBuffer = savedProjectionMatrixBuffer;
      projectionType = savedProjectionType;
   }

   public static @Nullable GpuBufferSlice getProjectionMatrixBuffer() {
      assertOnRenderThread();
      return projectionMatrixBuffer;
   }

   public static Matrix4f getModelViewMatrix() {
      assertOnRenderThread();
      return modelViewStack;
   }

   public static Matrix4fStack getModelViewStack() {
      assertOnRenderThread();
      return modelViewStack;
   }

   public static RenderSystem.AutoStorageIndexBuffer getSequentialBuffer(VertexFormat.Mode p732cccdb_17_0) {
      assertOnRenderThread();

      return switch (p732cccdb_17_0) {
         case QUADS -> sharedSequentialQuad;
         case LINES -> sharedSequentialLines;
         default -> sharedSequential;
      };
   }

   public static void setGlobalSettingsUniform(GpuBuffer p732cccdb_18_0) {
      globalSettingsUniform = p732cccdb_18_0;
   }

   public static @Nullable GpuBuffer getGlobalSettingsUniform() {
      return globalSettingsUniform;
   }

   public static ProjectionType getProjectionType() {
      assertOnRenderThread();
      return projectionType;
   }

   public static void queueFencedTask(Runnable p732cccdb_19_0) {
      PENDING_FENCES.addLast(new RenderSystem.GpuAsyncTask(p732cccdb_19_0, getDevice().createCommandEncoder().createFence()));
   }

   public static void executePendingTasks() {
      for (RenderSystem.GpuAsyncTask $$0 = PENDING_FENCES.peekFirst(); $$0 != null; $$0 = PENDING_FENCES.peekFirst()) {
         if (!$$0.fence.awaitCompletion(0L)) {
            return;
         }

         try {
            $$0.callback.run();
         } finally {
            $$0.fence.close();
         }

         PENDING_FENCES.removeFirst();
      }
   }

   public static GpuDevice getDevice() {
      if (DEVICE == null) {
         throw new IllegalStateException("Can't getDevice() before it was initialized");
      } else {
         return DEVICE;
      }
   }

   public static @Nullable GpuDevice tryGetDevice() {
      return DEVICE;
   }

   public static DynamicUniforms getDynamicUniforms() {
      if (dynamicUniforms == null) {
         throw new IllegalStateException("Can't getDynamicUniforms() before device was initialized");
      } else {
         return dynamicUniforms;
      }
   }

   public static void bindDefaultUniforms(RenderPass p732cccdb_20_0) {
      GpuBufferSlice $$1 = getProjectionMatrixBuffer();
      if ($$1 != null) {
         p732cccdb_20_0.setUniform("Projection", $$1);
      }

      GpuBufferSlice $$2 = getShaderFog();
      if ($$2 != null) {
         p732cccdb_20_0.setUniform("Fog", $$2);
      }

      GpuBuffer $$3 = getGlobalSettingsUniform();
      if ($$3 != null) {
         p732cccdb_20_0.setUniform("Globals", $$3);
      }

      GpuBufferSlice $$4 = getShaderLights();
      if ($$4 != null) {
         p732cccdb_20_0.setUniform("Lighting", $$4);
      }
   }

   public static final class AutoStorageIndexBuffer {
      private final int vertexStride;
      private final int indexStride;
      private final RenderSystem.AutoStorageIndexBuffer.IndexGenerator generator;
      private @Nullable GpuBuffer buffer;
      private VertexFormat.IndexType type = VertexFormat.IndexType.SHORT;
      private int indexCount;

      AutoStorageIndexBuffer(int p4f23304f_0_0, int p4f23304f_1_1, RenderSystem.AutoStorageIndexBuffer.IndexGenerator p4f23304f_2_2) {
         this.vertexStride = p4f23304f_0_0;
         this.indexStride = p4f23304f_1_1;
         this.generator = p4f23304f_2_2;
      }

      public boolean hasStorage(int p4f23304f_3_0) {
         return p4f23304f_3_0 <= this.indexCount;
      }

      public GpuBuffer getBuffer(int p4f23304f_4_0) {
         this.ensureStorage(p4f23304f_4_0);
         return this.buffer;
      }

      private void ensureStorage(int p4f23304f_5_0) {
         if (!this.hasStorage(p4f23304f_5_0)) {
            p4f23304f_5_0 = Mth.roundToward(p4f23304f_5_0 * 2, this.indexStride);
            RenderSystem.LOGGER.debug("Growing IndexBuffer: Old limit {}, new limit {}.", this.indexCount, p4f23304f_5_0);
            int $$1 = p4f23304f_5_0 / this.indexStride;
            int $$2 = $$1 * this.vertexStride;
            VertexFormat.IndexType $$3 = VertexFormat.IndexType.least($$2);
            int $$4 = Mth.roundToward(p4f23304f_5_0 * $$3.bytes, 4);
            ByteBuffer $$5 = MemoryUtil.memAlloc($$4);

            try {
               this.type = $$3;
               it.unimi.dsi.fastutil.ints.IntConsumer $$6 = this.intConsumer($$5);

               for (int $$7 = 0; $$7 < p4f23304f_5_0; $$7 += this.indexStride) {
                  this.generator.accept($$6, $$7 * this.vertexStride / this.indexStride);
               }

               $$5.flip();
               if (this.buffer != null) {
                  this.buffer.close();
               }

               this.buffer = RenderSystem.getDevice().createBuffer(() -> "Auto Storage index buffer", 64, $$5);
            } finally {
               MemoryUtil.memFree($$5);
            }

            this.indexCount = p4f23304f_5_0;
         }
      }

      private it.unimi.dsi.fastutil.ints.IntConsumer intConsumer(ByteBuffer p4f23304f_6_0) {
         switch (this.type) {
            case SHORT:
               return p4f23304f_8_1 -> p4f23304f_6_0.putShort((short)p4f23304f_8_1);
            case INT:
            default:
               return p4f23304f_6_0::putInt;
         }
      }

      public VertexFormat.IndexType type() {
         return this.type;
      }

      interface IndexGenerator {
         void accept(it.unimi.dsi.fastutil.ints.IntConsumer var1, int var2);
      }
   }

   record GpuAsyncTask(Runnable callback, GpuFence fence) {
   }
}
