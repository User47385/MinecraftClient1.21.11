package com.mojang.blaze3d.systems;

public class ScissorState {
   private boolean enabled;
   private int x;
   private int y;
   private int width;
   private int height;

   public void enable(int p7e15078b_0_0, int p7e15078b_1_1, int p7e15078b_2_2, int p7e15078b_3_3) {
      this.enabled = true;
      this.x = p7e15078b_0_0;
      this.y = p7e15078b_1_1;
      this.width = p7e15078b_2_2;
      this.height = p7e15078b_3_3;
   }

   public void disable() {
      this.enabled = false;
   }

   public boolean enabled() {
      return this.enabled;
   }

   public int x() {
      return this.x;
   }

   public int y() {
      return this.y;
   }

   public int width() {
      return this.width;
   }

   public int height() {
      return this.height;
   }
}
