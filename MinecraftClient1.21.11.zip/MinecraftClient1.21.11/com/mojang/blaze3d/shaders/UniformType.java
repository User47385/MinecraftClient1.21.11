package com.mojang.blaze3d.shaders;

public enum UniformType {
   UNIFORM_BUFFER("ubo"),
   TEXEL_BUFFER("utb");

   final String name;

   UniformType(final String pd39198e2_3_2) {
      this.name = pd39198e2_3_2;
   }
}
