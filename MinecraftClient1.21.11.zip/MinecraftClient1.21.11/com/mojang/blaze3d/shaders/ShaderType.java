package com.mojang.blaze3d.shaders;

import com.mojang.blaze3d.DontObfuscate;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;

@DontObfuscate
public enum ShaderType {
   VERTEX("vertex", ".vsh"),
   FRAGMENT("fragment", ".fsh");

   private static final ShaderType[] TYPES = values();
   private final String name;
   private final String extension;

   ShaderType(final String pc9ac406b_3_2, final String pc9ac406b_4_3) {
      this.name = pc9ac406b_3_2;
      this.extension = pc9ac406b_4_3;
   }

   public static @Nullable ShaderType byLocation(Identifier pc9ac406b_5_0) {
      for (ShaderType $$1 : TYPES) {
         if (pc9ac406b_5_0.getPath().endsWith($$1.extension)) {
            return $$1;
         }
      }

      return null;
   }

   public String getName() {
      return this.name;
   }

   public FileToIdConverter idConverter() {
      return new FileToIdConverter("shaders", this.extension);
   }
}
