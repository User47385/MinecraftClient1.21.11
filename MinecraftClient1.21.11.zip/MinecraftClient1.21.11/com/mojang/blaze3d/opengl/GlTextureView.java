package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import it.unimi.dsi.fastutil.ints.Int2IntArrayMap;
import it.unimi.dsi.fastutil.ints.Int2IntMap;
import org.jspecify.annotations.Nullable;

public class GlTextureView extends GpuTextureView {
   private static final int EMPTY = -1;
   private boolean closed;
   private int firstFboId = -1;
   private int firstFboDepthId = -1;
   private @Nullable Int2IntMap fboCache;

   protected GlTextureView(GlTexture p889bd006_0_0, int p889bd006_1_1, int p889bd006_2_2) {
      super(p889bd006_0_0, p889bd006_1_1, p889bd006_2_2);
      p889bd006_0_0.addViews();
   }

   @Override
   public boolean isClosed() {
      return this.closed;
   }

   @Override
   public void close() {
      if (!this.closed) {
         this.closed = true;
         this.texture().removeViews();
         if (this.firstFboId != -1) {
            GlStateManager._glDeleteFramebuffers(this.firstFboId);
         }

         if (this.fboCache != null) {
            for (int $$0 : this.fboCache.values()) {
               GlStateManager._glDeleteFramebuffers($$0);
            }
         }
      }
   }

   public int getFbo(DirectStateAccess p889bd006_3_0, @Nullable GpuTexture p889bd006_4_1) {
      int $$2 = p889bd006_4_1 == null ? 0 : ((GlTexture)p889bd006_4_1).id;
      if (this.firstFboDepthId == $$2) {
         return this.firstFboId;
      }

      if (this.firstFboId == -1) {
         this.firstFboId = this.createFbo(p889bd006_3_0, $$2);
         this.firstFboDepthId = $$2;
         return this.firstFboId;
      }

      if (this.fboCache == null) {
         this.fboCache = new Int2IntArrayMap();
      }

      return this.fboCache.computeIfAbsent($$2, p889bd006_8_1 -> this.createFbo(p889bd006_3_0, p889bd006_8_1));
   }

   private int createFbo(DirectStateAccess p889bd006_5_0, int p889bd006_6_1) {
      int $$2 = p889bd006_5_0.createFrameBufferObject();
      p889bd006_5_0.bindFrameBufferTextures($$2, this.texture().id, p889bd006_6_1, this.baseMipLevel(), 0);
      return $$2;
   }

   public GlTexture texture() {
      return (GlTexture)super.texture();
   }
}
