package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.DontObfuscate;
import com.mojang.blaze3d.platform.MacosUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.jtracy.Plot;
import com.mojang.jtracy.TracyClient;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.stream.IntStream;
import org.jspecify.annotations.Nullable;
import org.lwjgl.PointerBuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL20C;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL32;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

@DontObfuscate
public class GlStateManager {
   private static final Plot PLOT_TEXTURES = TracyClient.createPlot("GPU Textures");
   private static int numTextures = 0;
   private static final Plot PLOT_BUFFERS = TracyClient.createPlot("GPU Buffers");
   private static int numBuffers = 0;
   private static final GlStateManager.BlendState BLEND = new GlStateManager.BlendState();
   private static final GlStateManager.DepthState DEPTH = new GlStateManager.DepthState();
   private static final GlStateManager.CullState CULL = new GlStateManager.CullState();
   private static final GlStateManager.PolygonOffsetState POLY_OFFSET = new GlStateManager.PolygonOffsetState();
   private static final GlStateManager.ColorLogicState COLOR_LOGIC = new GlStateManager.ColorLogicState();
   private static final GlStateManager.ScissorState SCISSOR = new GlStateManager.ScissorState();
   private static int activeTexture;
   private static final int TEXTURE_COUNT = 12;
   private static final GlStateManager.TextureState[] TEXTURES = IntStream.range(0, 12)
      .mapToObj(p211bb0f6_163_0 -> new GlStateManager.TextureState())
      .toArray(GlStateManager.TextureState[]::new);
   private static final GlStateManager.ColorMask COLOR_MASK = new GlStateManager.ColorMask();
   private static int readFbo;
   private static int writeFbo;

   public static void _disableScissorTest() {
      RenderSystem.assertOnRenderThread();
      SCISSOR.mode.disable();
   }

   public static void _enableScissorTest() {
      RenderSystem.assertOnRenderThread();
      SCISSOR.mode.enable();
   }

   public static void _scissorBox(int p211bb0f6_0_0, int p211bb0f6_1_1, int p211bb0f6_2_2, int p211bb0f6_3_3) {
      RenderSystem.assertOnRenderThread();
      GL20.glScissor(p211bb0f6_0_0, p211bb0f6_1_1, p211bb0f6_2_2, p211bb0f6_3_3);
   }

   public static void _disableDepthTest() {
      RenderSystem.assertOnRenderThread();
      DEPTH.mode.disable();
   }

   public static void _enableDepthTest() {
      RenderSystem.assertOnRenderThread();
      DEPTH.mode.enable();
   }

   public static void _depthFunc(int p211bb0f6_4_0) {
      RenderSystem.assertOnRenderThread();
      if (p211bb0f6_4_0 != DEPTH.func) {
         DEPTH.func = p211bb0f6_4_0;
         GL11.glDepthFunc(p211bb0f6_4_0);
      }
   }

   public static void _depthMask(boolean p211bb0f6_5_0) {
      RenderSystem.assertOnRenderThread();
      if (p211bb0f6_5_0 != DEPTH.mask) {
         DEPTH.mask = p211bb0f6_5_0;
         GL11.glDepthMask(p211bb0f6_5_0);
      }
   }

   public static void _disableBlend() {
      RenderSystem.assertOnRenderThread();
      BLEND.mode.disable();
   }

   public static void _enableBlend() {
      RenderSystem.assertOnRenderThread();
      BLEND.mode.enable();
   }

   public static void _blendFuncSeparate(int p211bb0f6_6_0, int p211bb0f6_7_1, int p211bb0f6_8_2, int p211bb0f6_9_3) {
      RenderSystem.assertOnRenderThread();
      if (p211bb0f6_6_0 != BLEND.srcRgb || p211bb0f6_7_1 != BLEND.dstRgb || p211bb0f6_8_2 != BLEND.srcAlpha || p211bb0f6_9_3 != BLEND.dstAlpha) {
         BLEND.srcRgb = p211bb0f6_6_0;
         BLEND.dstRgb = p211bb0f6_7_1;
         BLEND.srcAlpha = p211bb0f6_8_2;
         BLEND.dstAlpha = p211bb0f6_9_3;
         glBlendFuncSeparate(p211bb0f6_6_0, p211bb0f6_7_1, p211bb0f6_8_2, p211bb0f6_9_3);
      }
   }

   public static int glGetProgrami(int p211bb0f6_10_0, int p211bb0f6_11_1) {
      RenderSystem.assertOnRenderThread();
      return GL20.glGetProgrami(p211bb0f6_10_0, p211bb0f6_11_1);
   }

   public static void glAttachShader(int p211bb0f6_12_0, int p211bb0f6_13_1) {
      RenderSystem.assertOnRenderThread();
      GL20.glAttachShader(p211bb0f6_12_0, p211bb0f6_13_1);
   }

   public static void glDeleteShader(int p211bb0f6_14_0) {
      RenderSystem.assertOnRenderThread();
      GL20.glDeleteShader(p211bb0f6_14_0);
   }

   public static int glCreateShader(int p211bb0f6_15_0) {
      RenderSystem.assertOnRenderThread();
      return GL20.glCreateShader(p211bb0f6_15_0);
   }

   public static void glShaderSource(int p211bb0f6_16_0, String p211bb0f6_17_1) {
      RenderSystem.assertOnRenderThread();
      byte[] $$2 = p211bb0f6_17_1.getBytes(StandardCharsets.UTF_8);
      ByteBuffer $$3 = MemoryUtil.memAlloc($$2.length + 1);
      $$3.put($$2);
      $$3.put((byte)0);
      $$3.flip();

      try (MemoryStack $$4 = MemoryStack.stackPush()) {
         PointerBuffer $$5 = $$4.mallocPointer(1);
         $$5.put($$3);
         GL20C.nglShaderSource(p211bb0f6_16_0, 1, $$5.address0(), 0L);
      } finally {
         MemoryUtil.memFree($$3);
      }
   }

   public static void glCompileShader(int p211bb0f6_18_0) {
      RenderSystem.assertOnRenderThread();
      GL20.glCompileShader(p211bb0f6_18_0);
   }

   public static int glGetShaderi(int p211bb0f6_19_0, int p211bb0f6_20_1) {
      RenderSystem.assertOnRenderThread();
      return GL20.glGetShaderi(p211bb0f6_19_0, p211bb0f6_20_1);
   }

   public static void _glUseProgram(int p211bb0f6_21_0) {
      RenderSystem.assertOnRenderThread();
      GL20.glUseProgram(p211bb0f6_21_0);
   }

   public static int glCreateProgram() {
      RenderSystem.assertOnRenderThread();
      return GL20.glCreateProgram();
   }

   public static void glDeleteProgram(int p211bb0f6_22_0) {
      RenderSystem.assertOnRenderThread();
      GL20.glDeleteProgram(p211bb0f6_22_0);
   }

   public static void glLinkProgram(int p211bb0f6_23_0) {
      RenderSystem.assertOnRenderThread();
      GL20.glLinkProgram(p211bb0f6_23_0);
   }

   public static int _glGetUniformLocation(int p211bb0f6_24_0, CharSequence p211bb0f6_25_1) {
      RenderSystem.assertOnRenderThread();
      return GL20.glGetUniformLocation(p211bb0f6_24_0, p211bb0f6_25_1);
   }

   public static void _glUniform1i(int p211bb0f6_26_0, int p211bb0f6_27_1) {
      RenderSystem.assertOnRenderThread();
      GL20.glUniform1i(p211bb0f6_26_0, p211bb0f6_27_1);
   }

   public static void _glBindAttribLocation(int p211bb0f6_28_0, int p211bb0f6_29_1, CharSequence p211bb0f6_30_2) {
      RenderSystem.assertOnRenderThread();
      GL20.glBindAttribLocation(p211bb0f6_28_0, p211bb0f6_29_1, p211bb0f6_30_2);
   }

   public static void incrementTrackedBuffers() {
      numBuffers++;
      PLOT_BUFFERS.setValue(numBuffers);
   }

   public static int _glGenBuffers() {
      RenderSystem.assertOnRenderThread();
      incrementTrackedBuffers();
      return GL15.glGenBuffers();
   }

   public static int _glGenVertexArrays() {
      RenderSystem.assertOnRenderThread();
      return GL30.glGenVertexArrays();
   }

   public static void _glBindBuffer(int p211bb0f6_31_0, int p211bb0f6_32_1) {
      RenderSystem.assertOnRenderThread();
      GL15.glBindBuffer(p211bb0f6_31_0, p211bb0f6_32_1);
   }

   public static void _glBindVertexArray(int p211bb0f6_33_0) {
      RenderSystem.assertOnRenderThread();
      GL30.glBindVertexArray(p211bb0f6_33_0);
   }

   public static void _glBufferData(int p211bb0f6_34_0, ByteBuffer p211bb0f6_35_1, int p211bb0f6_36_2) {
      RenderSystem.assertOnRenderThread();
      GL15.glBufferData(p211bb0f6_34_0, p211bb0f6_35_1, p211bb0f6_36_2);
   }

   public static void _glBufferSubData(int p211bb0f6_37_0, long p211bb0f6_38_1, ByteBuffer p211bb0f6_39_2) {
      RenderSystem.assertOnRenderThread();
      GL15.glBufferSubData(p211bb0f6_37_0, p211bb0f6_38_1, p211bb0f6_39_2);
   }

   public static void _glBufferData(int p211bb0f6_40_0, long p211bb0f6_41_1, int p211bb0f6_42_2) {
      RenderSystem.assertOnRenderThread();
      GL15.glBufferData(p211bb0f6_40_0, p211bb0f6_41_1, p211bb0f6_42_2);
   }

   public static @Nullable ByteBuffer _glMapBufferRange(int p211bb0f6_43_0, long p211bb0f6_44_1, long p211bb0f6_45_2, int p211bb0f6_46_3) {
      RenderSystem.assertOnRenderThread();
      return GL30.glMapBufferRange(p211bb0f6_43_0, p211bb0f6_44_1, p211bb0f6_45_2, p211bb0f6_46_3);
   }

   public static void _glUnmapBuffer(int p211bb0f6_47_0) {
      RenderSystem.assertOnRenderThread();
      GL15.glUnmapBuffer(p211bb0f6_47_0);
   }

   public static void _glDeleteBuffers(int p211bb0f6_48_0) {
      RenderSystem.assertOnRenderThread();
      numBuffers--;
      PLOT_BUFFERS.setValue(numBuffers);
      GL15.glDeleteBuffers(p211bb0f6_48_0);
   }

   public static void _glBindFramebuffer(int p211bb0f6_49_0, int p211bb0f6_50_1) {
      if ((p211bb0f6_49_0 == 36008 || p211bb0f6_49_0 == 36160) && readFbo != p211bb0f6_50_1) {
         GL30.glBindFramebuffer(36008, p211bb0f6_50_1);
         readFbo = p211bb0f6_50_1;
      }

      if ((p211bb0f6_49_0 == 36009 || p211bb0f6_49_0 == 36160) && writeFbo != p211bb0f6_50_1) {
         GL30.glBindFramebuffer(36009, p211bb0f6_50_1);
         writeFbo = p211bb0f6_50_1;
      }
   }

   public static int getFrameBuffer(int p211bb0f6_51_0) {
      if (p211bb0f6_51_0 == 36008) {
         return readFbo;
      } else {
         return p211bb0f6_51_0 == 36009 ? writeFbo : 0;
      }
   }

   public static void _glBlitFrameBuffer(
      int p211bb0f6_52_0,
      int p211bb0f6_53_1,
      int p211bb0f6_54_2,
      int p211bb0f6_55_3,
      int p211bb0f6_56_4,
      int p211bb0f6_57_5,
      int p211bb0f6_58_6,
      int p211bb0f6_59_7,
      int p211bb0f6_60_8,
      int p211bb0f6_61_9
   ) {
      RenderSystem.assertOnRenderThread();
      GL30.glBlitFramebuffer(
         p211bb0f6_52_0,
         p211bb0f6_53_1,
         p211bb0f6_54_2,
         p211bb0f6_55_3,
         p211bb0f6_56_4,
         p211bb0f6_57_5,
         p211bb0f6_58_6,
         p211bb0f6_59_7,
         p211bb0f6_60_8,
         p211bb0f6_61_9
      );
   }

   public static void _glDeleteFramebuffers(int p211bb0f6_62_0) {
      RenderSystem.assertOnRenderThread();
      GL30.glDeleteFramebuffers(p211bb0f6_62_0);
      if (readFbo == p211bb0f6_62_0) {
         readFbo = 0;
      }

      if (writeFbo == p211bb0f6_62_0) {
         writeFbo = 0;
      }
   }

   public static int glGenFramebuffers() {
      RenderSystem.assertOnRenderThread();
      return GL30.glGenFramebuffers();
   }

   public static void _glFramebufferTexture2D(int p211bb0f6_63_0, int p211bb0f6_64_1, int p211bb0f6_65_2, int p211bb0f6_66_3, int p211bb0f6_67_4) {
      RenderSystem.assertOnRenderThread();
      GL30.glFramebufferTexture2D(p211bb0f6_63_0, p211bb0f6_64_1, p211bb0f6_65_2, p211bb0f6_66_3, p211bb0f6_67_4);
   }

   public static void glBlendFuncSeparate(int p211bb0f6_68_0, int p211bb0f6_69_1, int p211bb0f6_70_2, int p211bb0f6_71_3) {
      RenderSystem.assertOnRenderThread();
      GL14.glBlendFuncSeparate(p211bb0f6_68_0, p211bb0f6_69_1, p211bb0f6_70_2, p211bb0f6_71_3);
   }

   public static String glGetShaderInfoLog(int p211bb0f6_72_0, int p211bb0f6_73_1) {
      RenderSystem.assertOnRenderThread();
      return GL20.glGetShaderInfoLog(p211bb0f6_72_0, p211bb0f6_73_1);
   }

   public static String glGetProgramInfoLog(int p211bb0f6_74_0, int p211bb0f6_75_1) {
      RenderSystem.assertOnRenderThread();
      return GL20.glGetProgramInfoLog(p211bb0f6_74_0, p211bb0f6_75_1);
   }

   public static void _enableCull() {
      RenderSystem.assertOnRenderThread();
      CULL.enable.enable();
   }

   public static void _disableCull() {
      RenderSystem.assertOnRenderThread();
      CULL.enable.disable();
   }

   public static void _polygonMode(int p211bb0f6_76_0, int p211bb0f6_77_1) {
      RenderSystem.assertOnRenderThread();
      GL11.glPolygonMode(p211bb0f6_76_0, p211bb0f6_77_1);
   }

   public static void _enablePolygonOffset() {
      RenderSystem.assertOnRenderThread();
      POLY_OFFSET.fill.enable();
   }

   public static void _disablePolygonOffset() {
      RenderSystem.assertOnRenderThread();
      POLY_OFFSET.fill.disable();
   }

   public static void _polygonOffset(float p211bb0f6_78_0, float p211bb0f6_79_1) {
      RenderSystem.assertOnRenderThread();
      if (p211bb0f6_78_0 != POLY_OFFSET.factor || p211bb0f6_79_1 != POLY_OFFSET.units) {
         POLY_OFFSET.factor = p211bb0f6_78_0;
         POLY_OFFSET.units = p211bb0f6_79_1;
         GL11.glPolygonOffset(p211bb0f6_78_0, p211bb0f6_79_1);
      }
   }

   public static void _enableColorLogicOp() {
      RenderSystem.assertOnRenderThread();
      COLOR_LOGIC.enable.enable();
   }

   public static void _disableColorLogicOp() {
      RenderSystem.assertOnRenderThread();
      COLOR_LOGIC.enable.disable();
   }

   public static void _logicOp(int p211bb0f6_80_0) {
      RenderSystem.assertOnRenderThread();
      if (p211bb0f6_80_0 != COLOR_LOGIC.op) {
         COLOR_LOGIC.op = p211bb0f6_80_0;
         GL11.glLogicOp(p211bb0f6_80_0);
      }
   }

   public static void _activeTexture(int p211bb0f6_81_0) {
      RenderSystem.assertOnRenderThread();
      if (activeTexture != p211bb0f6_81_0 - 33984) {
         activeTexture = p211bb0f6_81_0 - 33984;
         GL13.glActiveTexture(p211bb0f6_81_0);
      }
   }

   public static void _texParameter(int p211bb0f6_82_0, int p211bb0f6_83_1, int p211bb0f6_84_2) {
      RenderSystem.assertOnRenderThread();
      GL11.glTexParameteri(p211bb0f6_82_0, p211bb0f6_83_1, p211bb0f6_84_2);
   }

   public static int _getTexLevelParameter(int p211bb0f6_85_0, int p211bb0f6_86_1, int p211bb0f6_87_2) {
      return GL11.glGetTexLevelParameteri(p211bb0f6_85_0, p211bb0f6_86_1, p211bb0f6_87_2);
   }

   public static int _genTexture() {
      RenderSystem.assertOnRenderThread();
      numTextures++;
      PLOT_TEXTURES.setValue(numTextures);
      return GL11.glGenTextures();
   }

   public static void _deleteTexture(int p211bb0f6_88_0) {
      RenderSystem.assertOnRenderThread();
      GL11.glDeleteTextures(p211bb0f6_88_0);

      for (GlStateManager.TextureState $$1 : TEXTURES) {
         if ($$1.binding == p211bb0f6_88_0) {
            $$1.binding = -1;
         }
      }

      numTextures--;
      PLOT_TEXTURES.setValue(numTextures);
   }

   public static void _bindTexture(int p211bb0f6_89_0) {
      RenderSystem.assertOnRenderThread();
      if (p211bb0f6_89_0 != TEXTURES[activeTexture].binding) {
         TEXTURES[activeTexture].binding = p211bb0f6_89_0;
         GL11.glBindTexture(3553, p211bb0f6_89_0);
      }
   }

   public static void _texImage2D(
      int p211bb0f6_90_0,
      int p211bb0f6_91_1,
      int p211bb0f6_92_2,
      int p211bb0f6_93_3,
      int p211bb0f6_94_4,
      int p211bb0f6_95_5,
      int p211bb0f6_96_6,
      int p211bb0f6_97_7,
      @Nullable ByteBuffer p211bb0f6_98_8
   ) {
      RenderSystem.assertOnRenderThread();
      GL11.glTexImage2D(
         p211bb0f6_90_0, p211bb0f6_91_1, p211bb0f6_92_2, p211bb0f6_93_3, p211bb0f6_94_4, p211bb0f6_95_5, p211bb0f6_96_6, p211bb0f6_97_7, p211bb0f6_98_8
      );
   }

   public static void _texSubImage2D(
      int p211bb0f6_99_0,
      int p211bb0f6_100_1,
      int p211bb0f6_101_2,
      int p211bb0f6_102_3,
      int p211bb0f6_103_4,
      int p211bb0f6_104_5,
      int p211bb0f6_105_6,
      int p211bb0f6_106_7,
      long p211bb0f6_107_8
   ) {
      RenderSystem.assertOnRenderThread();
      GL11.glTexSubImage2D(
         p211bb0f6_99_0, p211bb0f6_100_1, p211bb0f6_101_2, p211bb0f6_102_3, p211bb0f6_103_4, p211bb0f6_104_5, p211bb0f6_105_6, p211bb0f6_106_7, p211bb0f6_107_8
      );
   }

   public static void _texSubImage2D(
      int p211bb0f6_108_0,
      int p211bb0f6_109_1,
      int p211bb0f6_110_2,
      int p211bb0f6_111_3,
      int p211bb0f6_112_4,
      int p211bb0f6_113_5,
      int p211bb0f6_114_6,
      int p211bb0f6_115_7,
      ByteBuffer p211bb0f6_116_8
   ) {
      RenderSystem.assertOnRenderThread();
      GL11.glTexSubImage2D(
         p211bb0f6_108_0,
         p211bb0f6_109_1,
         p211bb0f6_110_2,
         p211bb0f6_111_3,
         p211bb0f6_112_4,
         p211bb0f6_113_5,
         p211bb0f6_114_6,
         p211bb0f6_115_7,
         p211bb0f6_116_8
      );
   }

   public static void _viewport(int p211bb0f6_117_0, int p211bb0f6_118_1, int p211bb0f6_119_2, int p211bb0f6_120_3) {
      GL11.glViewport(p211bb0f6_117_0, p211bb0f6_118_1, p211bb0f6_119_2, p211bb0f6_120_3);
   }

   public static void _colorMask(boolean p211bb0f6_121_0, boolean p211bb0f6_122_1, boolean p211bb0f6_123_2, boolean p211bb0f6_124_3) {
      RenderSystem.assertOnRenderThread();
      if (p211bb0f6_121_0 != COLOR_MASK.red || p211bb0f6_122_1 != COLOR_MASK.green || p211bb0f6_123_2 != COLOR_MASK.blue || p211bb0f6_124_3 != COLOR_MASK.alpha
         )
       {
         COLOR_MASK.red = p211bb0f6_121_0;
         COLOR_MASK.green = p211bb0f6_122_1;
         COLOR_MASK.blue = p211bb0f6_123_2;
         COLOR_MASK.alpha = p211bb0f6_124_3;
         GL11.glColorMask(p211bb0f6_121_0, p211bb0f6_122_1, p211bb0f6_123_2, p211bb0f6_124_3);
      }
   }

   public static void _clear(int p211bb0f6_125_0) {
      RenderSystem.assertOnRenderThread();
      GL11.glClear(p211bb0f6_125_0);
      if (MacosUtil.IS_MACOS) {
         _getError();
      }
   }

   public static void _vertexAttribPointer(
      int p211bb0f6_126_0, int p211bb0f6_127_1, int p211bb0f6_128_2, boolean p211bb0f6_129_3, int p211bb0f6_130_4, long p211bb0f6_131_5
   ) {
      RenderSystem.assertOnRenderThread();
      GL20.glVertexAttribPointer(p211bb0f6_126_0, p211bb0f6_127_1, p211bb0f6_128_2, p211bb0f6_129_3, p211bb0f6_130_4, p211bb0f6_131_5);
   }

   public static void _vertexAttribIPointer(int p211bb0f6_132_0, int p211bb0f6_133_1, int p211bb0f6_134_2, int p211bb0f6_135_3, long p211bb0f6_136_4) {
      RenderSystem.assertOnRenderThread();
      GL30.glVertexAttribIPointer(p211bb0f6_132_0, p211bb0f6_133_1, p211bb0f6_134_2, p211bb0f6_135_3, p211bb0f6_136_4);
   }

   public static void _enableVertexAttribArray(int p211bb0f6_137_0) {
      RenderSystem.assertOnRenderThread();
      GL20.glEnableVertexAttribArray(p211bb0f6_137_0);
   }

   public static void _drawElements(int p211bb0f6_138_0, int p211bb0f6_139_1, int p211bb0f6_140_2, long p211bb0f6_141_3) {
      RenderSystem.assertOnRenderThread();
      GL11.glDrawElements(p211bb0f6_138_0, p211bb0f6_139_1, p211bb0f6_140_2, p211bb0f6_141_3);
   }

   public static void _drawArrays(int p211bb0f6_142_0, int p211bb0f6_143_1, int p211bb0f6_144_2) {
      RenderSystem.assertOnRenderThread();
      GL11.glDrawArrays(p211bb0f6_142_0, p211bb0f6_143_1, p211bb0f6_144_2);
   }

   public static void _pixelStore(int p211bb0f6_145_0, int p211bb0f6_146_1) {
      RenderSystem.assertOnRenderThread();
      GL11.glPixelStorei(p211bb0f6_145_0, p211bb0f6_146_1);
   }

   public static void _readPixels(
      int p211bb0f6_147_0, int p211bb0f6_148_1, int p211bb0f6_149_2, int p211bb0f6_150_3, int p211bb0f6_151_4, int p211bb0f6_152_5, long p211bb0f6_153_6
   ) {
      RenderSystem.assertOnRenderThread();
      GL11.glReadPixels(p211bb0f6_147_0, p211bb0f6_148_1, p211bb0f6_149_2, p211bb0f6_150_3, p211bb0f6_151_4, p211bb0f6_152_5, p211bb0f6_153_6);
   }

   public static int _getError() {
      RenderSystem.assertOnRenderThread();
      return GL11.glGetError();
   }

   public static void clearGlErrors() {
      RenderSystem.assertOnRenderThread();

      while (GL11.glGetError() != 0) {
      }
   }

   public static String _getString(int p211bb0f6_154_0) {
      RenderSystem.assertOnRenderThread();
      return GL11.glGetString(p211bb0f6_154_0);
   }

   public static int _getInteger(int p211bb0f6_155_0) {
      RenderSystem.assertOnRenderThread();
      return GL11.glGetInteger(p211bb0f6_155_0);
   }

   public static long _glFenceSync(int p211bb0f6_156_0, int p211bb0f6_157_1) {
      RenderSystem.assertOnRenderThread();
      return GL32.glFenceSync(p211bb0f6_156_0, p211bb0f6_157_1);
   }

   public static int _glClientWaitSync(long p211bb0f6_158_0, int p211bb0f6_159_1, long p211bb0f6_160_2) {
      RenderSystem.assertOnRenderThread();
      return GL32.glClientWaitSync(p211bb0f6_158_0, p211bb0f6_159_1, p211bb0f6_160_2);
   }

   public static void _glDeleteSync(long p211bb0f6_161_0) {
      RenderSystem.assertOnRenderThread();
      GL32.glDeleteSync(p211bb0f6_161_0);
   }

   static class BlendState {
      public final GlStateManager.BooleanState mode = new GlStateManager.BooleanState(3042);
      public int srcRgb = 1;
      public int dstRgb = 0;
      public int srcAlpha = 1;
      public int dstAlpha = 0;
   }

   static class BooleanState {
      private final int state;
      private boolean enabled;

      public BooleanState(int p9e2c0e57_0_0) {
         this.state = p9e2c0e57_0_0;
      }

      public void disable() {
         this.setEnabled(false);
      }

      public void enable() {
         this.setEnabled(true);
      }

      public void setEnabled(boolean p9e2c0e57_1_0) {
         RenderSystem.assertOnRenderThread();
         if (p9e2c0e57_1_0 != this.enabled) {
            this.enabled = p9e2c0e57_1_0;
            if (p9e2c0e57_1_0) {
               GL11.glEnable(this.state);
            } else {
               GL11.glDisable(this.state);
            }
         }
      }
   }

   static class ColorLogicState {
      public final GlStateManager.BooleanState enable = new GlStateManager.BooleanState(3058);
      public int op = 5379;
   }

   static class ColorMask {
      public boolean red = true;
      public boolean green = true;
      public boolean blue = true;
      public boolean alpha = true;
   }

   static class CullState {
      public final GlStateManager.BooleanState enable = new GlStateManager.BooleanState(2884);
   }

   static class DepthState {
      public final GlStateManager.BooleanState mode = new GlStateManager.BooleanState(2929);
      public boolean mask = true;
      public int func = 513;
   }

   static class PolygonOffsetState {
      public final GlStateManager.BooleanState fill = new GlStateManager.BooleanState(32823);
      public float factor;
      public float units;
   }

   static class ScissorState {
      public final GlStateManager.BooleanState mode = new GlStateManager.BooleanState(3089);
   }

   static class TextureState {
      public int binding;
   }
}
