package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.TextureFormat;
import it.unimi.dsi.fastutil.ints.Int2IntArrayMap;
import it.unimi.dsi.fastutil.ints.Int2IntMap;
import org.jspecify.annotations.Nullable;

public class GlTexture extends GpuTexture {
   private static final int EMPTY = -1;
   protected final int id;
   private int firstFboId = -1;
   private int firstFboDepthId = -1;
   private @Nullable Int2IntMap fboCache;
   protected boolean closed;
   private int views;

   protected GlTexture(
      @GpuTexture.Usage int p39efe9c1_0_0,
      String p39efe9c1_1_1,
      TextureFormat p39efe9c1_2_2,
      int p39efe9c1_3_3,
      int p39efe9c1_4_4,
      int p39efe9c1_5_5,
      int p39efe9c1_6_6,
      int p39efe9c1_7_7
   ) {
      super(p39efe9c1_0_0, p39efe9c1_1_1, p39efe9c1_2_2, p39efe9c1_3_3, p39efe9c1_4_4, p39efe9c1_5_5, p39efe9c1_6_6);
      this.id = p39efe9c1_7_7;
   }

   @Override
   public void close() {
      if (!this.closed) {
         this.closed = true;
         if (this.views == 0) {
            this.destroyImmediately();
         }
      }
   }

   private void destroyImmediately() {
      GlStateManager._deleteTexture(this.id);
      if (this.firstFboId != -1) {
         GlStateManager._glDeleteFramebuffers(this.firstFboId);
      }

      if (this.fboCache != null) {
         for (int $$0 : this.fboCache.values()) {
            GlStateManager._glDeleteFramebuffers($$0);
         }
      }
   }

   @Override
   public boolean isClosed() {
      return this.closed;
   }

   public int getFbo(DirectStateAccess p39efe9c1_8_0, @Nullable GpuTexture p39efe9c1_9_1) {
      int $$2 = p39efe9c1_9_1 == null ? 0 : ((GlTexture)p39efe9c1_9_1).id;
      if (this.firstFboDepthId == $$2) {
         return this.firstFboId;
      }

      if (this.firstFboId == -1) {
         this.firstFboId = this.createFbo(p39efe9c1_8_0, $$2);
         this.firstFboDepthId = $$2;
         return this.firstFboId;
      }

      if (this.fboCache == null) {
         this.fboCache = new Int2IntArrayMap();
      }

      return this.fboCache.computeIfAbsent($$2, p39efe9c1_13_1 -> this.createFbo(p39efe9c1_8_0, p39efe9c1_13_1));
   }

   private int createFbo(DirectStateAccess p39efe9c1_10_0, int p39efe9c1_11_1) {
      int $$2 = p39efe9c1_10_0.createFrameBufferObject();
      p39efe9c1_10_0.bindFrameBufferTextures($$2, this.id, p39efe9c1_11_1, 0, 0);
      return $$2;
   }

   public int glId() {
      return this.id;
   }

   public void addViews() {
      this.views++;
   }

   public void removeViews() {
      this.views--;
      if (this.closed && this.views == 0) {
         this.destroyImmediately();
      }
   }
}
