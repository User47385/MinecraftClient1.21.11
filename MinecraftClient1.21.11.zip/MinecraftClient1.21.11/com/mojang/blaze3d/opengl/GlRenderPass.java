package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.ScissorState;
import com.mojang.blaze3d.textures.GpuSampler;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.SharedConstants;
import org.jspecify.annotations.Nullable;

public class GlRenderPass implements RenderPass {
   protected static final int MAX_VERTEX_BUFFERS = 1;
   public static final boolean VALIDATION = SharedConstants.IS_RUNNING_IN_IDE;
   private final GlCommandEncoder encoder;
   private final boolean hasDepthTexture;
   private boolean closed;
   protected @Nullable GlRenderPipeline pipeline;
   protected final @Nullable GpuBuffer[] vertexBuffers = new GpuBuffer[1];
   protected @Nullable GpuBuffer indexBuffer;
   protected VertexFormat.IndexType indexType = VertexFormat.IndexType.INT;
   private final ScissorState scissorState = new ScissorState();
   protected final HashMap<String, GpuBufferSlice> uniforms = new HashMap<>();
   protected final HashMap<String, GlRenderPass.TextureViewAndSampler> samplers = new HashMap<>();
   protected final Set<String> dirtyUniforms = new HashSet<>();
   protected int pushedDebugGroups;

   public GlRenderPass(GlCommandEncoder pd4db4061_0_0, boolean pd4db4061_1_1) {
      this.encoder = pd4db4061_0_0;
      this.hasDepthTexture = pd4db4061_1_1;
   }

   public boolean hasDepthTexture() {
      return this.hasDepthTexture;
   }

   @Override
   public void pushDebugGroup(Supplier<String> pd4db4061_2_0) {
      if (this.closed) {
         throw new IllegalStateException("Can't use a closed render pass");
      }

      this.pushedDebugGroups++;
      this.encoder.getDevice().debugLabels().pushDebugGroup(pd4db4061_2_0);
   }

   @Override
   public void popDebugGroup() {
      if (this.closed) {
         throw new IllegalStateException("Can't use a closed render pass");
      }

      if (this.pushedDebugGroups == 0) {
         throw new IllegalStateException("Can't pop more debug groups than was pushed!");
      }

      this.pushedDebugGroups--;
      this.encoder.getDevice().debugLabels().popDebugGroup();
   }

   @Override
   public void setPipeline(RenderPipeline pd4db4061_3_0) {
      if (this.pipeline == null || this.pipeline.info() != pd4db4061_3_0) {
         this.dirtyUniforms.addAll(this.uniforms.keySet());
         this.dirtyUniforms.addAll(this.samplers.keySet());
      }

      this.pipeline = this.encoder.getDevice().getOrCompilePipeline(pd4db4061_3_0);
   }

   @Override
   public void bindTexture(String pd4db4061_4_0, @Nullable GpuTextureView pd4db4061_5_1, @Nullable GpuSampler pd4db4061_6_2) {
      if (pd4db4061_6_2 == null) {
         this.samplers.remove(pd4db4061_4_0);
      } else {
         this.samplers.put(pd4db4061_4_0, new GlRenderPass.TextureViewAndSampler((GlTextureView)pd4db4061_5_1, (GlSampler)pd4db4061_6_2));
      }

      this.dirtyUniforms.add(pd4db4061_4_0);
   }

   @Override
   public void setUniform(String pd4db4061_7_0, GpuBuffer pd4db4061_8_1) {
      this.uniforms.put(pd4db4061_7_0, pd4db4061_8_1.slice());
      this.dirtyUniforms.add(pd4db4061_7_0);
   }

   @Override
   public void setUniform(String pd4db4061_9_0, GpuBufferSlice pd4db4061_10_1) {
      int $$2 = this.encoder.getDevice().getUniformOffsetAlignment();
      if (pd4db4061_10_1.offset() % $$2 > 0L) {
         throw new IllegalArgumentException("Uniform buffer offset must be aligned to " + $$2);
      }

      this.uniforms.put(pd4db4061_9_0, pd4db4061_10_1);
      this.dirtyUniforms.add(pd4db4061_9_0);
   }

   @Override
   public void enableScissor(int pd4db4061_11_0, int pd4db4061_12_1, int pd4db4061_13_2, int pd4db4061_14_3) {
      this.scissorState.enable(pd4db4061_11_0, pd4db4061_12_1, pd4db4061_13_2, pd4db4061_14_3);
   }

   @Override
   public void disableScissor() {
      this.scissorState.disable();
   }

   public boolean isScissorEnabled() {
      return this.scissorState.enabled();
   }

   public int getScissorX() {
      return this.scissorState.x();
   }

   public int getScissorY() {
      return this.scissorState.y();
   }

   public int getScissorWidth() {
      return this.scissorState.width();
   }

   public int getScissorHeight() {
      return this.scissorState.height();
   }

   @Override
   public void setVertexBuffer(int pd4db4061_15_0, GpuBuffer pd4db4061_16_1) {
      if (pd4db4061_15_0 >= 0 && pd4db4061_15_0 < 1) {
         this.vertexBuffers[pd4db4061_15_0] = pd4db4061_16_1;
      } else {
         throw new IllegalArgumentException("Vertex buffer slot is out of range: " + pd4db4061_15_0);
      }
   }

   @Override
   public void setIndexBuffer(@Nullable GpuBuffer pd4db4061_17_0, VertexFormat.IndexType pd4db4061_18_1) {
      this.indexBuffer = pd4db4061_17_0;
      this.indexType = pd4db4061_18_1;
   }

   @Override
   public void drawIndexed(int pd4db4061_19_0, int pd4db4061_20_1, int pd4db4061_21_2, int pd4db4061_22_3) {
      if (this.closed) {
         throw new IllegalStateException("Can't use a closed render pass");
      }

      this.encoder.executeDraw(this, pd4db4061_19_0, pd4db4061_20_1, pd4db4061_21_2, this.indexType, pd4db4061_22_3);
   }

   @Override
   public <T> void drawMultipleIndexed(
      Collection<RenderPass.Draw<T>> pd4db4061_23_0,
      @Nullable GpuBuffer pd4db4061_24_1,
      VertexFormat.@Nullable IndexType pd4db4061_25_2,
      Collection<String> pd4db4061_26_3,
      T pd4db4061_27_4
   ) {
      if (this.closed) {
         throw new IllegalStateException("Can't use a closed render pass");
      }

      this.encoder.executeDrawMultiple(this, pd4db4061_23_0, pd4db4061_24_1, pd4db4061_25_2, pd4db4061_26_3, pd4db4061_27_4);
   }

   @Override
   public void draw(int pd4db4061_28_0, int pd4db4061_29_1) {
      if (this.closed) {
         throw new IllegalStateException("Can't use a closed render pass");
      }

      this.encoder.executeDraw(this, pd4db4061_28_0, 0, pd4db4061_29_1, null, 1);
   }

   @Override
   public void close() {
      if (!this.closed) {
         if (this.pushedDebugGroups > 0) {
            throw new IllegalStateException("Render pass had debug groups left open!");
         }

         this.closed = true;
         this.encoder.finishRenderPass();
      }
   }

   protected record TextureViewAndSampler(GlTextureView view, GlSampler sampler) {
   }
}
