package com.mojang.blaze3d.opengl;

import com.mojang.logging.LogUtils;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.util.StringUtil;
import org.lwjgl.opengl.EXTDebugLabel;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLCapabilities;
import org.lwjgl.opengl.KHRDebug;
import org.slf4j.Logger;

public abstract class GlDebugLabel {
   private static final Logger LOGGER = LogUtils.getLogger();

   public void applyLabel(GlBuffer p1eecd5fb_0_0) {
   }

   public void applyLabel(GlTexture p1eecd5fb_1_0) {
   }

   public void applyLabel(GlShaderModule p1eecd5fb_2_0) {
   }

   public void applyLabel(GlProgram p1eecd5fb_3_0) {
   }

   public void applyLabel(VertexArrayCache.VertexArray p1eecd5fb_4_0) {
   }

   public void pushDebugGroup(Supplier<String> p1eecd5fb_5_0) {
   }

   public void popDebugGroup() {
   }

   public static GlDebugLabel create(GLCapabilities p1eecd5fb_6_0, boolean p1eecd5fb_7_1, Set<String> p1eecd5fb_8_2) {
      if (p1eecd5fb_7_1) {
         if (p1eecd5fb_6_0.GL_KHR_debug && GlDevice.USE_GL_KHR_debug) {
            p1eecd5fb_8_2.add("GL_KHR_debug");
            return new GlDebugLabel.Core();
         }

         if (p1eecd5fb_6_0.GL_EXT_debug_label && GlDevice.USE_GL_EXT_debug_label) {
            p1eecd5fb_8_2.add("GL_EXT_debug_label");
            return new GlDebugLabel.Ext();
         }

         LOGGER.warn("Debug labels unavailable: neither KHR_debug nor EXT_debug_label are supported");
      }

      return new GlDebugLabel.Empty();
   }

   public boolean exists() {
      return false;
   }

   static class Core extends GlDebugLabel {
      private final int maxLabelLength = GL11.glGetInteger(33512);

      @Override
      public void applyLabel(GlBuffer p7b3c20c8_0_0) {
         Supplier<String> $$1 = p7b3c20c8_0_0.label;
         if ($$1 != null) {
            KHRDebug.glObjectLabel(33504, p7b3c20c8_0_0.handle, StringUtil.truncateStringIfNecessary($$1.get(), this.maxLabelLength, true));
         }
      }

      @Override
      public void applyLabel(GlTexture p7b3c20c8_1_0) {
         KHRDebug.glObjectLabel(5890, p7b3c20c8_1_0.id, StringUtil.truncateStringIfNecessary(p7b3c20c8_1_0.getLabel(), this.maxLabelLength, true));
      }

      @Override
      public void applyLabel(GlShaderModule p7b3c20c8_2_0) {
         KHRDebug.glObjectLabel(
            33505, p7b3c20c8_2_0.getShaderId(), StringUtil.truncateStringIfNecessary(p7b3c20c8_2_0.getDebugLabel(), this.maxLabelLength, true)
         );
      }

      @Override
      public void applyLabel(GlProgram p7b3c20c8_3_0) {
         KHRDebug.glObjectLabel(
            33506, p7b3c20c8_3_0.getProgramId(), StringUtil.truncateStringIfNecessary(p7b3c20c8_3_0.getDebugLabel(), this.maxLabelLength, true)
         );
      }

      @Override
      public void applyLabel(VertexArrayCache.VertexArray p7b3c20c8_4_0) {
         KHRDebug.glObjectLabel(32884, p7b3c20c8_4_0.id, StringUtil.truncateStringIfNecessary(p7b3c20c8_4_0.format.toString(), this.maxLabelLength, true));
      }

      @Override
      public void pushDebugGroup(Supplier<String> p7b3c20c8_5_0) {
         KHRDebug.glPushDebugGroup(33354, 0, p7b3c20c8_5_0.get());
      }

      @Override
      public void popDebugGroup() {
         KHRDebug.glPopDebugGroup();
      }

      @Override
      public boolean exists() {
         return true;
      }
   }

   static class Empty extends GlDebugLabel {
   }

   static class Ext extends GlDebugLabel {
      @Override
      public void applyLabel(GlBuffer p905ccfd8_0_0) {
         Supplier<String> $$1 = p905ccfd8_0_0.label;
         if ($$1 != null) {
            EXTDebugLabel.glLabelObjectEXT(37201, p905ccfd8_0_0.handle, StringUtil.truncateStringIfNecessary($$1.get(), 256, true));
         }
      }

      @Override
      public void applyLabel(GlTexture p905ccfd8_1_0) {
         EXTDebugLabel.glLabelObjectEXT(5890, p905ccfd8_1_0.id, StringUtil.truncateStringIfNecessary(p905ccfd8_1_0.getLabel(), 256, true));
      }

      @Override
      public void applyLabel(GlShaderModule p905ccfd8_2_0) {
         EXTDebugLabel.glLabelObjectEXT(35656, p905ccfd8_2_0.getShaderId(), StringUtil.truncateStringIfNecessary(p905ccfd8_2_0.getDebugLabel(), 256, true));
      }

      @Override
      public void applyLabel(GlProgram p905ccfd8_3_0) {
         EXTDebugLabel.glLabelObjectEXT(35648, p905ccfd8_3_0.getProgramId(), StringUtil.truncateStringIfNecessary(p905ccfd8_3_0.getDebugLabel(), 256, true));
      }

      @Override
      public void applyLabel(VertexArrayCache.VertexArray p905ccfd8_4_0) {
         EXTDebugLabel.glLabelObjectEXT(32884, p905ccfd8_4_0.id, StringUtil.truncateStringIfNecessary(p905ccfd8_4_0.format.toString(), 256, true));
      }

      @Override
      public boolean exists() {
         return true;
      }
   }
}
