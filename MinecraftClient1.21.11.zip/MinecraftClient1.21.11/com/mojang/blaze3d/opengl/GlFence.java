package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.buffers.GpuFence;

public class GlFence implements GpuFence {
   private long handle = GlStateManager._glFenceSync(37143, 0);

   @Override
   public void close() {
      if (this.handle != 0L) {
         GlStateManager._glDeleteSync(this.handle);
         this.handle = 0L;
      }
   }

   @Override
   public boolean awaitCompletion(long p6ee7f657_0_0) {
      if (this.handle == 0L) {
         return true;
      } else {
         int $$1 = GlStateManager._glClientWaitSync(this.handle, 0, p6ee7f657_0_0);
         if ($$1 == 37147) {
            return false;
         } else if ($$1 == 37149) {
            throw new IllegalStateException("Failed to complete GPU fence: " + GlStateManager._getError());
         } else {
            return true;
         }
      }
   }
}
