package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.GpuOutOfMemoryException;
import com.mojang.blaze3d.GraphicsWorkarounds;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.preprocessor.GlslPreprocessor;
import com.mojang.blaze3d.shaders.ShaderSource;
import com.mojang.blaze3d.shaders.ShaderType;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.logging.LogUtils;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.client.renderer.ShaderDefines;
import net.minecraft.client.renderer.ShaderManager;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import org.apache.commons.lang3.StringUtils;
import org.jspecify.annotations.Nullable;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLCapabilities;
import org.slf4j.Logger;

public class GlDevice implements GpuDevice {
   private static final Logger LOGGER = LogUtils.getLogger();
   protected static boolean USE_GL_ARB_vertex_attrib_binding = true;
   protected static boolean USE_GL_KHR_debug = true;
   protected static boolean USE_GL_EXT_debug_label = true;
   protected static boolean USE_GL_ARB_debug_output = true;
   protected static boolean USE_GL_ARB_direct_state_access = true;
   protected static boolean USE_GL_ARB_buffer_storage = true;
   private final CommandEncoder encoder;
   private final @Nullable GlDebug debugLog;
   private final GlDebugLabel debugLabels;
   private final int maxSupportedTextureSize;
   private final DirectStateAccess directStateAccess;
   private final ShaderSource defaultShaderSource;
   private final Map<RenderPipeline, GlRenderPipeline> pipelineCache = new IdentityHashMap<>();
   private final Map<GlDevice.ShaderCompilationKey, GlShaderModule> shaderCache = new HashMap<>();
   private final VertexArrayCache vertexArrayCache;
   private final BufferStorage bufferStorage;
   private final Set<String> enabledExtensions = new HashSet<>();
   private final int uniformOffsetAlignment;
   private final int maxSupportedAnisotropy;

   public GlDevice(long p6ab0dcf0_0_0, int p6ab0dcf0_1_1, boolean p6ab0dcf0_2_2, ShaderSource p6ab0dcf0_3_3, boolean p6ab0dcf0_4_4) {
      GLFW.glfwMakeContextCurrent(p6ab0dcf0_0_0);
      GLCapabilities $$5 = GL.createCapabilities();
      int $$6 = getMaxSupportedTextureSize();
      GLFW.glfwSetWindowSizeLimits(p6ab0dcf0_0_0, -1, -1, $$6, $$6);
      GraphicsWorkarounds $$7 = GraphicsWorkarounds.get(this);
      this.debugLog = GlDebug.enableDebugCallback(p6ab0dcf0_1_1, p6ab0dcf0_2_2, this.enabledExtensions);
      this.debugLabels = GlDebugLabel.create($$5, p6ab0dcf0_4_4, this.enabledExtensions);
      this.vertexArrayCache = VertexArrayCache.create($$5, this.debugLabels, this.enabledExtensions);
      this.bufferStorage = BufferStorage.create($$5, this.enabledExtensions);
      this.directStateAccess = DirectStateAccess.create($$5, this.enabledExtensions, $$7);
      this.maxSupportedTextureSize = $$6;
      this.defaultShaderSource = p6ab0dcf0_3_3;
      this.encoder = new GlCommandEncoder(this);
      this.uniformOffsetAlignment = GL11.glGetInteger(35380);
      GL11.glEnable(34895);
      GL11.glEnable(34370);
      if ($$5.GL_EXT_texture_filter_anisotropic) {
         this.maxSupportedAnisotropy = Mth.floor(GL11.glGetFloat(34047));
         this.enabledExtensions.add("GL_EXT_texture_filter_anisotropic");
      } else {
         this.maxSupportedAnisotropy = 1;
      }
   }

   public GlDebugLabel debugLabels() {
      return this.debugLabels;
   }

   @Override
   public CommandEncoder createCommandEncoder() {
      return this.encoder;
   }

   @Override
   public int getMaxSupportedAnisotropy() {
      return this.maxSupportedAnisotropy;
   }

   @Override
   public GpuSampler createSampler(
      AddressMode p6ab0dcf0_5_0,
      AddressMode p6ab0dcf0_6_1,
      FilterMode p6ab0dcf0_7_2,
      FilterMode p6ab0dcf0_8_3,
      int p6ab0dcf0_9_4,
      OptionalDouble p6ab0dcf0_10_5
   ) {
      if (p6ab0dcf0_9_4 >= 1 && p6ab0dcf0_9_4 <= this.maxSupportedAnisotropy) {
         return new GlSampler(p6ab0dcf0_5_0, p6ab0dcf0_6_1, p6ab0dcf0_7_2, p6ab0dcf0_8_3, p6ab0dcf0_9_4, p6ab0dcf0_10_5);
      } else {
         throw new IllegalArgumentException(
            "maxAnisotropy out of range; must be >= 1 and <= " + this.getMaxSupportedAnisotropy() + ", but was " + p6ab0dcf0_9_4
         );
      }
   }

   @Override
   public GpuTexture createTexture(
      @Nullable Supplier<String> p6ab0dcf0_11_0,
      @GpuTexture.Usage int p6ab0dcf0_12_1,
      TextureFormat p6ab0dcf0_13_2,
      int p6ab0dcf0_14_3,
      int p6ab0dcf0_15_4,
      int p6ab0dcf0_16_5,
      int p6ab0dcf0_17_6
   ) {
      return this.createTexture(
         this.debugLabels.exists() && p6ab0dcf0_11_0 != null ? p6ab0dcf0_11_0.get() : null,
         p6ab0dcf0_12_1,
         p6ab0dcf0_13_2,
         p6ab0dcf0_14_3,
         p6ab0dcf0_15_4,
         p6ab0dcf0_16_5,
         p6ab0dcf0_17_6
      );
   }

   @Override
   public GpuTexture createTexture(
      @Nullable String p6ab0dcf0_18_0,
      @GpuTexture.Usage int p6ab0dcf0_19_1,
      TextureFormat p6ab0dcf0_20_2,
      int p6ab0dcf0_21_3,
      int p6ab0dcf0_22_4,
      int p6ab0dcf0_23_5,
      int p6ab0dcf0_24_6
   ) {
      if (p6ab0dcf0_24_6 < 1) {
         throw new IllegalArgumentException("mipLevels must be at least 1");
      }

      if (p6ab0dcf0_23_5 < 1) {
         throw new IllegalArgumentException("depthOrLayers must be at least 1");
      }

      boolean $$7 = (p6ab0dcf0_19_1 & 16) != 0;
      if ($$7) {
         if (p6ab0dcf0_21_3 != p6ab0dcf0_22_4) {
            throw new IllegalArgumentException("Cubemap compatible textures must be square, but size is " + p6ab0dcf0_21_3 + "x" + p6ab0dcf0_22_4);
         }

         if (p6ab0dcf0_23_5 % 6 != 0) {
            throw new IllegalArgumentException("Cubemap compatible textures must have a layer count with a multiple of 6, was " + p6ab0dcf0_23_5);
         }

         if (p6ab0dcf0_23_5 > 6) {
            throw new UnsupportedOperationException("Array textures are not yet supported");
         }
      } else if (p6ab0dcf0_23_5 > 1) {
         throw new UnsupportedOperationException("Array or 3D textures are not yet supported");
      }

      GlStateManager.clearGlErrors();
      int $$8 = GlStateManager._genTexture();
      if (p6ab0dcf0_18_0 == null) {
         p6ab0dcf0_18_0 = String.valueOf($$8);
      }

      int $$9;
      if ($$7) {
         GL11.glBindTexture(34067, $$8);
         $$9 = 34067;
      } else {
         GlStateManager._bindTexture($$8);
         $$9 = 3553;
      }

      GlStateManager._texParameter($$9, 33085, p6ab0dcf0_24_6 - 1);
      GlStateManager._texParameter($$9, 33082, 0);
      GlStateManager._texParameter($$9, 33083, p6ab0dcf0_24_6 - 1);
      if (p6ab0dcf0_20_2.hasDepthAspect()) {
         GlStateManager._texParameter($$9, 34892, 0);
      }

      if ($$7) {
         for (int $$11 : GlConst.CUBEMAP_TARGETS) {
            for (int $$12 = 0; $$12 < p6ab0dcf0_24_6; $$12++) {
               GlStateManager._texImage2D(
                  $$11,
                  $$12,
                  GlConst.toGlInternalId(p6ab0dcf0_20_2),
                  p6ab0dcf0_21_3 >> $$12,
                  p6ab0dcf0_22_4 >> $$12,
                  0,
                  GlConst.toGlExternalId(p6ab0dcf0_20_2),
                  GlConst.toGlType(p6ab0dcf0_20_2),
                  null
               );
            }
         }
      } else {
         for (int $$13 = 0; $$13 < p6ab0dcf0_24_6; $$13++) {
            GlStateManager._texImage2D(
               $$9,
               $$13,
               GlConst.toGlInternalId(p6ab0dcf0_20_2),
               p6ab0dcf0_21_3 >> $$13,
               p6ab0dcf0_22_4 >> $$13,
               0,
               GlConst.toGlExternalId(p6ab0dcf0_20_2),
               GlConst.toGlType(p6ab0dcf0_20_2),
               null
            );
         }
      }

      int $$14 = GlStateManager._getError();
      if ($$14 == 1285) {
         throw new GpuOutOfMemoryException("Could not allocate texture of " + p6ab0dcf0_21_3 + "x" + p6ab0dcf0_22_4 + " for " + p6ab0dcf0_18_0);
      }

      if ($$14 != 0) {
         throw new IllegalStateException("OpenGL error " + $$14);
      }

      GlTexture $$15 = new GlTexture(p6ab0dcf0_19_1, p6ab0dcf0_18_0, p6ab0dcf0_20_2, p6ab0dcf0_21_3, p6ab0dcf0_22_4, p6ab0dcf0_23_5, p6ab0dcf0_24_6, $$8);
      this.debugLabels.applyLabel($$15);
      return $$15;
   }

   @Override
   public GpuTextureView createTextureView(GpuTexture p6ab0dcf0_25_0) {
      return this.createTextureView(p6ab0dcf0_25_0, 0, p6ab0dcf0_25_0.getMipLevels());
   }

   @Override
   public GpuTextureView createTextureView(GpuTexture p6ab0dcf0_26_0, int p6ab0dcf0_27_1, int p6ab0dcf0_28_2) {
      if (p6ab0dcf0_26_0.isClosed()) {
         throw new IllegalArgumentException("Can't create texture view with closed texture");
      } else if (p6ab0dcf0_27_1 >= 0 && p6ab0dcf0_27_1 + p6ab0dcf0_28_2 <= p6ab0dcf0_26_0.getMipLevels()) {
         return new GlTextureView((GlTexture)p6ab0dcf0_26_0, p6ab0dcf0_27_1, p6ab0dcf0_28_2);
      } else {
         throw new IllegalArgumentException(
            p6ab0dcf0_28_2
               + " mip levels starting from "
               + p6ab0dcf0_27_1
               + " would be out of range for texture with only "
               + p6ab0dcf0_26_0.getMipLevels()
               + " mip levels"
         );
      }
   }

   @Override
   public GpuBuffer createBuffer(@Nullable Supplier<String> p6ab0dcf0_29_0, @GpuBuffer.Usage int p6ab0dcf0_30_1, long p6ab0dcf0_31_2) {
      if (p6ab0dcf0_31_2 <= 0L) {
         throw new IllegalArgumentException("Buffer size must be greater than zero");
      }

      GlStateManager.clearGlErrors();
      GlBuffer $$3 = this.bufferStorage.createBuffer(this.directStateAccess, p6ab0dcf0_29_0, p6ab0dcf0_30_1, p6ab0dcf0_31_2);
      int $$4 = GlStateManager._getError();
      if ($$4 == 1285) {
         throw new GpuOutOfMemoryException("Could not allocate buffer of " + p6ab0dcf0_31_2 + " for " + p6ab0dcf0_29_0);
      }

      if ($$4 != 0) {
         throw new IllegalStateException("OpenGL error " + $$4);
      }

      this.debugLabels.applyLabel($$3);
      return $$3;
   }

   @Override
   public GpuBuffer createBuffer(@Nullable Supplier<String> p6ab0dcf0_32_0, @GpuBuffer.Usage int p6ab0dcf0_33_1, ByteBuffer p6ab0dcf0_34_2) {
      if (!p6ab0dcf0_34_2.hasRemaining()) {
         throw new IllegalArgumentException("Buffer source must not be empty");
      }

      GlStateManager.clearGlErrors();
      long $$3 = p6ab0dcf0_34_2.remaining();
      GlBuffer $$4 = this.bufferStorage.createBuffer(this.directStateAccess, p6ab0dcf0_32_0, p6ab0dcf0_33_1, p6ab0dcf0_34_2);
      int $$5 = GlStateManager._getError();
      if ($$5 == 1285) {
         throw new GpuOutOfMemoryException("Could not allocate buffer of " + $$3 + " for " + p6ab0dcf0_32_0);
      }

      if ($$5 != 0) {
         throw new IllegalStateException("OpenGL error " + $$5);
      }

      this.debugLabels.applyLabel($$4);
      return $$4;
   }

   @Override
   public String getImplementationInformation() {
      return GLFW.glfwGetCurrentContext() == 0L
         ? "NO CONTEXT"
         : GlStateManager._getString(7937) + " GL version " + GlStateManager._getString(7938) + ", " + GlStateManager._getString(7936);
   }

   @Override
   public List<String> getLastDebugMessages() {
      return this.debugLog == null ? Collections.emptyList() : this.debugLog.getLastOpenGlDebugMessages();
   }

   @Override
   public boolean isDebuggingEnabled() {
      return this.debugLog != null;
   }

   @Override
   public String getRenderer() {
      return GlStateManager._getString(7937);
   }

   @Override
   public String getVendor() {
      return GlStateManager._getString(7936);
   }

   @Override
   public String getBackendName() {
      return "OpenGL";
   }

   @Override
   public String getVersion() {
      return GlStateManager._getString(7938);
   }

   private static int getMaxSupportedTextureSize() {
      int $$0 = GlStateManager._getInteger(3379);

      for (int $$1 = Math.max(32768, $$0); $$1 >= 1024; $$1 >>= 1) {
         GlStateManager._texImage2D(32868, 0, 6408, $$1, $$1, 0, 6408, 5121, null);
         int $$2 = GlStateManager._getTexLevelParameter(32868, 0, 4096);
         if ($$2 != 0) {
            return $$1;
         }
      }

      int $$3 = Math.max($$0, 1024);
      LOGGER.info("Failed to determine maximum texture size by probing, trying GL_MAX_TEXTURE_SIZE = {}", $$3);
      return $$3;
   }

   @Override
   public int getMaxTextureSize() {
      return this.maxSupportedTextureSize;
   }

   @Override
   public int getUniformOffsetAlignment() {
      return this.uniformOffsetAlignment;
   }

   @Override
   public void clearPipelineCache() {
      for (GlRenderPipeline $$0 : this.pipelineCache.values()) {
         if ($$0.program() != GlProgram.INVALID_PROGRAM) {
            $$0.program().close();
         }
      }

      this.pipelineCache.clear();

      for (GlShaderModule $$1 : this.shaderCache.values()) {
         if ($$1 != GlShaderModule.INVALID_SHADER) {
            $$1.close();
         }
      }

      this.shaderCache.clear();
      String $$2 = GlStateManager._getString(7937);
      if ($$2.contains("AMD")) {
         sacrificeShaderToOpenGlAndAmd();
      }
   }

   private static void sacrificeShaderToOpenGlAndAmd() {
      int $$0 = GlStateManager.glCreateShader(35633);
      int $$1 = GlStateManager.glCreateProgram();
      GlStateManager.glAttachShader($$1, $$0);
      GlStateManager.glDeleteShader($$0);
      GlStateManager.glDeleteProgram($$1);
   }

   @Override
   public List<String> getEnabledExtensions() {
      return new ArrayList<>(this.enabledExtensions);
   }

   @Override
   public void close() {
      this.clearPipelineCache();
   }

   public DirectStateAccess directStateAccess() {
      return this.directStateAccess;
   }

   protected GlRenderPipeline getOrCompilePipeline(RenderPipeline p6ab0dcf0_35_0) {
      return this.pipelineCache.computeIfAbsent(p6ab0dcf0_35_0, p6ab0dcf0_54_0 -> this.compilePipeline(p6ab0dcf0_54_0, this.defaultShaderSource));
   }

   protected GlShaderModule getOrCompileShader(Identifier p6ab0dcf0_36_0, ShaderType p6ab0dcf0_37_1, ShaderDefines p6ab0dcf0_38_2, ShaderSource p6ab0dcf0_39_3) {
      GlDevice.ShaderCompilationKey $$4 = new GlDevice.ShaderCompilationKey(p6ab0dcf0_36_0, p6ab0dcf0_37_1, p6ab0dcf0_38_2);
      return this.shaderCache.computeIfAbsent($$4, p6ab0dcf0_53_1 -> this.compileShader(p6ab0dcf0_53_1, p6ab0dcf0_39_3));
   }

   public GlRenderPipeline precompilePipeline(RenderPipeline p6ab0dcf0_40_0, @Nullable ShaderSource p6ab0dcf0_41_1) {
      ShaderSource $$2 = p6ab0dcf0_41_1 == null ? this.defaultShaderSource : p6ab0dcf0_41_1;
      return this.pipelineCache.computeIfAbsent(p6ab0dcf0_40_0, p6ab0dcf0_51_1 -> this.compilePipeline(p6ab0dcf0_51_1, $$2));
   }

   private GlShaderModule compileShader(GlDevice.ShaderCompilationKey p6ab0dcf0_42_0, ShaderSource p6ab0dcf0_43_1) {
      String $$2 = p6ab0dcf0_43_1.get(p6ab0dcf0_42_0.id, p6ab0dcf0_42_0.type);
      if ($$2 == null) {
         LOGGER.error("Couldn't find source for {} shader ({})", p6ab0dcf0_42_0.type, p6ab0dcf0_42_0.id);
         return GlShaderModule.INVALID_SHADER;
      } else {
         String $$3 = GlslPreprocessor.injectDefines($$2, p6ab0dcf0_42_0.defines);
         int $$4 = GlStateManager.glCreateShader(GlConst.toGl(p6ab0dcf0_42_0.type));
         GlStateManager.glShaderSource($$4, $$3);
         GlStateManager.glCompileShader($$4);
         if (GlStateManager.glGetShaderi($$4, 35713) == 0) {
            String $$5 = StringUtils.trim(GlStateManager.glGetShaderInfoLog($$4, 32768));
            LOGGER.error("Couldn't compile {} shader ({}): {}", p6ab0dcf0_42_0.type.getName(), p6ab0dcf0_42_0.id, $$5);
            return GlShaderModule.INVALID_SHADER;
         } else {
            GlShaderModule $$6 = new GlShaderModule($$4, p6ab0dcf0_42_0.id, p6ab0dcf0_42_0.type);
            this.debugLabels.applyLabel($$6);
            return $$6;
         }
      }
   }

   private GlProgram compileProgram(RenderPipeline p6ab0dcf0_44_0, ShaderSource p6ab0dcf0_45_1) {
      GlShaderModule $$2 = this.getOrCompileShader(p6ab0dcf0_44_0.getVertexShader(), ShaderType.VERTEX, p6ab0dcf0_44_0.getShaderDefines(), p6ab0dcf0_45_1);
      GlShaderModule $$3 = this.getOrCompileShader(p6ab0dcf0_44_0.getFragmentShader(), ShaderType.FRAGMENT, p6ab0dcf0_44_0.getShaderDefines(), p6ab0dcf0_45_1);
      if ($$2 == GlShaderModule.INVALID_SHADER) {
         LOGGER.error("Couldn't compile pipeline {}: vertex shader {} was invalid", p6ab0dcf0_44_0.getLocation(), p6ab0dcf0_44_0.getVertexShader());
         return GlProgram.INVALID_PROGRAM;
      }

      if ($$3 == GlShaderModule.INVALID_SHADER) {
         LOGGER.error("Couldn't compile pipeline {}: fragment shader {} was invalid", p6ab0dcf0_44_0.getLocation(), p6ab0dcf0_44_0.getFragmentShader());
         return GlProgram.INVALID_PROGRAM;
      }

      try {
         GlProgram $$4 = GlProgram.link($$2, $$3, p6ab0dcf0_44_0.getVertexFormat(), p6ab0dcf0_44_0.getLocation().toString());
         $$4.setupUniforms(p6ab0dcf0_44_0.getUniforms(), p6ab0dcf0_44_0.getSamplers());
         this.debugLabels.applyLabel($$4);
         return $$4;
      } catch (ShaderManager.CompilationException $$5) {
         LOGGER.error("Couldn't compile program for pipeline {}: {}", p6ab0dcf0_44_0.getLocation(), $$5);
         return GlProgram.INVALID_PROGRAM;
      }
   }

   private GlRenderPipeline compilePipeline(RenderPipeline p6ab0dcf0_46_0, ShaderSource p6ab0dcf0_47_1) {
      return new GlRenderPipeline(p6ab0dcf0_46_0, this.compileProgram(p6ab0dcf0_46_0, p6ab0dcf0_47_1));
   }

   public VertexArrayCache vertexArrayCache() {
      return this.vertexArrayCache;
   }

   public BufferStorage getBufferStorage() {
      return this.bufferStorage;
   }

   record ShaderCompilationKey(Identifier id, ShaderType type, ShaderDefines defines) {

      @Override
      public String toString() {
         String $$0 = this.id + " (" + this.type + ")";
         return !this.defines.isEmpty() ? $$0 + " with " + this.defines : $$0;
      }
   }
}
