package com.mojang.blaze3d.opengl;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Sets;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.logging.LogUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.client.renderer.ShaderManager;
import org.jspecify.annotations.Nullable;
import org.lwjgl.opengl.GL31;
import org.slf4j.Logger;

public class GlProgram implements AutoCloseable {
   private static final Logger LOGGER = LogUtils.getLogger();
   public static Set<String> BUILT_IN_UNIFORMS = Sets.newHashSet("Projection", "Lighting", "Fog", "Globals");
   public static GlProgram INVALID_PROGRAM = new GlProgram(-1, "invalid");
   private final Map<String, Uniform> uniformsByName = new HashMap<>();
   private final int programId;
   private final String debugLabel;

   private GlProgram(int p7c01332a_0_0, String p7c01332a_1_1) {
      this.programId = p7c01332a_0_0;
      this.debugLabel = p7c01332a_1_1;
   }

   public static GlProgram link(GlShaderModule p7c01332a_2_0, GlShaderModule p7c01332a_3_1, VertexFormat p7c01332a_4_2, String p7c01332a_5_3) throws ShaderManager.CompilationException {
      int $$4 = GlStateManager.glCreateProgram();
      if ($$4 <= 0) {
         throw new ShaderManager.CompilationException("Could not create shader program (returned program ID " + $$4 + ")");
      }

      int $$5 = 0;

      for (String $$6 : p7c01332a_4_2.getElementAttributeNames()) {
         GlStateManager._glBindAttribLocation($$4, $$5, $$6);
         $$5++;
      }

      GlStateManager.glAttachShader($$4, p7c01332a_2_0.getShaderId());
      GlStateManager.glAttachShader($$4, p7c01332a_3_1.getShaderId());
      GlStateManager.glLinkProgram($$4);
      int $$7 = GlStateManager.glGetProgrami($$4, 35714);
      String $$8 = GlStateManager.glGetProgramInfoLog($$4, 32768);
      if ($$7 != 0 && !$$8.contains("Failed for unknown reason")) {
         if (!$$8.isEmpty()) {
            LOGGER.info("Info log when linking program containing VS {} and FS {}. Log output: {}", p7c01332a_2_0.getId(), p7c01332a_3_1.getId(), $$8);
         }

         return new GlProgram($$4, p7c01332a_5_3);
      } else {
         throw new ShaderManager.CompilationException(
            "Error encountered when linking program containing VS " + p7c01332a_2_0.getId() + " and FS " + p7c01332a_3_1.getId() + ". Log output: " + $$8
         );
      }
   }

   public void setupUniforms(List<RenderPipeline.UniformDescription> p7c01332a_6_0, List<String> p7c01332a_7_1) {
      int $$2 = 0;
      int $$3 = 0;

      for (RenderPipeline.UniformDescription $$4 : p7c01332a_6_0) {
         String $$5 = $$4.name();

         Uniform $$10 = switch ($$4.type()) {
            case UNIFORM_BUFFER -> {
               int $$6 = GL31.glGetUniformBlockIndex(this.programId, $$5);
               if ($$6 == -1) {
                  yield null;
               } else {
                  int $$7 = $$2++;
                  GL31.glUniformBlockBinding(this.programId, $$6, $$7);
                  yield new Uniform.Ubo($$7);
               }
            }
            case TEXEL_BUFFER -> {
               int $$8 = GlStateManager._glGetUniformLocation(this.programId, $$5);
               if ($$8 == -1) {
                  LOGGER.warn("{} shader program does not use utb {} defined in the pipeline. This might be a bug.", this.debugLabel, $$5);
                  yield null;
               } else {
                  int $$9 = $$3++;
                  yield new Uniform.Utb($$8, $$9, Objects.requireNonNull($$4.textureFormat()));
               }
            }
         };
         if ($$10 != null) {
            this.uniformsByName.put($$5, $$10);
         }
      }

      for (String $$11 : p7c01332a_7_1) {
         int $$12 = GlStateManager._glGetUniformLocation(this.programId, $$11);
         if ($$12 == -1) {
            LOGGER.warn("{} shader program does not use sampler {} defined in the pipeline. This might be a bug.", this.debugLabel, $$11);
         } else {
            int $$13 = $$3++;
            this.uniformsByName.put($$11, new Uniform.Sampler($$12, $$13));
         }
      }

      int $$14 = GlStateManager.glGetProgrami(this.programId, 35382);

      for (int $$15 = 0; $$15 < $$14; $$15++) {
         String $$16 = GL31.glGetActiveUniformBlockName(this.programId, $$15);
         if (!this.uniformsByName.containsKey($$16)) {
            if (!p7c01332a_7_1.contains($$16) && BUILT_IN_UNIFORMS.contains($$16)) {
               int $$17 = $$2++;
               GL31.glUniformBlockBinding(this.programId, $$15, $$17);
               this.uniformsByName.put($$16, new Uniform.Ubo($$17));
            } else {
               LOGGER.warn("Found unknown and unsupported uniform {} in {}", $$16, this.debugLabel);
            }
         }
      }
   }

   @Override
   public void close() {
      this.uniformsByName.values().forEach(Uniform::close);
      GlStateManager.glDeleteProgram(this.programId);
   }

   public @Nullable Uniform getUniform(String p7c01332a_8_0) {
      RenderSystem.assertOnRenderThread();
      return this.uniformsByName.get(p7c01332a_8_0);
   }

   @VisibleForTesting
   public int getProgramId() {
      return this.programId;
   }

   @Override
   public String toString() {
      return this.debugLabel;
   }

   public String getDebugLabel() {
      return this.debugLabel;
   }

   public Map<String, Uniform> getUniforms() {
      return this.uniformsByName;
   }
}
