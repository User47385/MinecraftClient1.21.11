package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuQuery;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.logging.LogUtils;
import java.nio.ByteBuffer;
import java.util.Collection;
import java.util.Collections;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.util.ARGB;
import org.jspecify.annotations.Nullable;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL11C;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GL32;
import org.lwjgl.opengl.GL32C;
import org.lwjgl.opengl.GL33C;
import org.slf4j.Logger;

public class GlCommandEncoder implements CommandEncoder {
   private static final Logger LOGGER = LogUtils.getLogger();
   private final GlDevice device;
   private final int readFbo;
   private final int drawFbo;
   private @Nullable RenderPipeline lastPipeline;
   private boolean inRenderPass;
   private @Nullable GlProgram lastProgram;
   private @Nullable GlTimerQuery activeTimerQuery;

   protected GlCommandEncoder(GlDevice ped0607eb_0_0) {
      this.device = ped0607eb_0_0;
      this.readFbo = ped0607eb_0_0.directStateAccess().createFrameBufferObject();
      this.drawFbo = ped0607eb_0_0.directStateAccess().createFrameBufferObject();
   }

   @Override
   public RenderPass createRenderPass(Supplier<String> ped0607eb_1_0, GpuTextureView ped0607eb_2_1, OptionalInt ped0607eb_3_2) {
      return this.createRenderPass(ped0607eb_1_0, ped0607eb_2_1, ped0607eb_3_2, null, OptionalDouble.empty());
   }

   @Override
   public RenderPass createRenderPass(
      Supplier<String> ped0607eb_4_0,
      GpuTextureView ped0607eb_5_1,
      OptionalInt ped0607eb_6_2,
      @Nullable GpuTextureView ped0607eb_7_3,
      OptionalDouble ped0607eb_8_4
   ) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before creating a new one!");
      }

      if (ped0607eb_8_4.isPresent() && ped0607eb_7_3 == null) {
         LOGGER.warn("Depth clear value was provided but no depth texture is being used");
      }

      if (ped0607eb_5_1.isClosed()) {
         throw new IllegalStateException("Color texture is closed");
      }

      if ((ped0607eb_5_1.texture().usage() & 8) == 0) {
         throw new IllegalStateException("Color texture must have USAGE_RENDER_ATTACHMENT");
      }

      if (ped0607eb_5_1.texture().getDepthOrLayers() > 1) {
         throw new UnsupportedOperationException("Textures with multiple depths or layers are not yet supported as an attachment");
      }

      if (ped0607eb_7_3 != null) {
         if (ped0607eb_7_3.isClosed()) {
            throw new IllegalStateException("Depth texture is closed");
         }

         if ((ped0607eb_7_3.texture().usage() & 8) == 0) {
            throw new IllegalStateException("Depth texture must have USAGE_RENDER_ATTACHMENT");
         }

         if (ped0607eb_7_3.texture().getDepthOrLayers() > 1) {
            throw new UnsupportedOperationException("Textures with multiple depths or layers are not yet supported as an attachment");
         }
      }

      this.inRenderPass = true;
      this.device.debugLabels().pushDebugGroup(ped0607eb_4_0);
      int $$5 = ((GlTextureView)ped0607eb_5_1).getFbo(this.device.directStateAccess(), ped0607eb_7_3 == null ? null : ped0607eb_7_3.texture());
      GlStateManager._glBindFramebuffer(36160, $$5);
      int $$6 = 0;
      if (ped0607eb_6_2.isPresent()) {
         int $$7 = ped0607eb_6_2.getAsInt();
         GL11.glClearColor(ARGB.redFloat($$7), ARGB.greenFloat($$7), ARGB.blueFloat($$7), ARGB.alphaFloat($$7));
         $$6 |= 16384;
      }

      if (ped0607eb_7_3 != null && ped0607eb_8_4.isPresent()) {
         GL11.glClearDepth(ped0607eb_8_4.getAsDouble());
         $$6 |= 256;
      }

      if ($$6 != 0) {
         GlStateManager._disableScissorTest();
         GlStateManager._depthMask(true);
         GlStateManager._colorMask(true, true, true, true);
         GlStateManager._clear($$6);
      }

      GlStateManager._viewport(0, 0, ped0607eb_5_1.getWidth(0), ped0607eb_5_1.getHeight(0));
      this.lastPipeline = null;
      return new GlRenderPass(this, ped0607eb_7_3 != null);
   }

   @Override
   public void clearColorTexture(GpuTexture ped0607eb_9_0, int ped0607eb_10_1) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before creating a new one!");
      }

      this.verifyColorTexture(ped0607eb_9_0);
      this.device.directStateAccess().bindFrameBufferTextures(this.drawFbo, ((GlTexture)ped0607eb_9_0).id, 0, 0, 36160);
      GL11.glClearColor(ARGB.redFloat(ped0607eb_10_1), ARGB.greenFloat(ped0607eb_10_1), ARGB.blueFloat(ped0607eb_10_1), ARGB.alphaFloat(ped0607eb_10_1));
      GlStateManager._disableScissorTest();
      GlStateManager._colorMask(true, true, true, true);
      GlStateManager._clear(16384);
      GlStateManager._glFramebufferTexture2D(36160, 36064, 3553, 0, 0);
      GlStateManager._glBindFramebuffer(36160, 0);
   }

   @Override
   public void clearColorAndDepthTextures(GpuTexture ped0607eb_11_0, int ped0607eb_12_1, GpuTexture ped0607eb_13_2, double ped0607eb_14_3) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before creating a new one!");
      }

      this.verifyColorTexture(ped0607eb_11_0);
      this.verifyDepthTexture(ped0607eb_13_2);
      int $$4 = ((GlTexture)ped0607eb_11_0).getFbo(this.device.directStateAccess(), ped0607eb_13_2);
      GlStateManager._glBindFramebuffer(36160, $$4);
      GlStateManager._disableScissorTest();
      GL11.glClearDepth(ped0607eb_14_3);
      GL11.glClearColor(ARGB.redFloat(ped0607eb_12_1), ARGB.greenFloat(ped0607eb_12_1), ARGB.blueFloat(ped0607eb_12_1), ARGB.alphaFloat(ped0607eb_12_1));
      GlStateManager._depthMask(true);
      GlStateManager._colorMask(true, true, true, true);
      GlStateManager._clear(16640);
      GlStateManager._glBindFramebuffer(36160, 0);
   }

   @Override
   public void clearColorAndDepthTextures(
      GpuTexture ped0607eb_15_0,
      int ped0607eb_16_1,
      GpuTexture ped0607eb_17_2,
      double ped0607eb_18_3,
      int ped0607eb_19_4,
      int ped0607eb_20_5,
      int ped0607eb_21_6,
      int ped0607eb_22_7
   ) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before creating a new one!");
      }

      this.verifyColorTexture(ped0607eb_15_0);
      this.verifyDepthTexture(ped0607eb_17_2);
      this.verifyRegion(ped0607eb_15_0, ped0607eb_19_4, ped0607eb_20_5, ped0607eb_21_6, ped0607eb_22_7);
      int $$8 = ((GlTexture)ped0607eb_15_0).getFbo(this.device.directStateAccess(), ped0607eb_17_2);
      GlStateManager._glBindFramebuffer(36160, $$8);
      GlStateManager._scissorBox(ped0607eb_19_4, ped0607eb_20_5, ped0607eb_21_6, ped0607eb_22_7);
      GlStateManager._enableScissorTest();
      GL11.glClearDepth(ped0607eb_18_3);
      GL11.glClearColor(ARGB.redFloat(ped0607eb_16_1), ARGB.greenFloat(ped0607eb_16_1), ARGB.blueFloat(ped0607eb_16_1), ARGB.alphaFloat(ped0607eb_16_1));
      GlStateManager._depthMask(true);
      GlStateManager._colorMask(true, true, true, true);
      GlStateManager._clear(16640);
      GlStateManager._glBindFramebuffer(36160, 0);
   }

   private void verifyRegion(GpuTexture ped0607eb_23_0, int ped0607eb_24_1, int ped0607eb_25_2, int ped0607eb_26_3, int ped0607eb_27_4) {
      if (ped0607eb_24_1 < 0 || ped0607eb_24_1 >= ped0607eb_23_0.getWidth(0)) {
         throw new IllegalArgumentException("regionX should not be outside of the texture");
      }

      if (ped0607eb_25_2 < 0 || ped0607eb_25_2 >= ped0607eb_23_0.getHeight(0)) {
         throw new IllegalArgumentException("regionY should not be outside of the texture");
      }

      if (ped0607eb_26_3 <= 0) {
         throw new IllegalArgumentException("regionWidth should be greater than 0");
      }

      if (ped0607eb_24_1 + ped0607eb_26_3 > ped0607eb_23_0.getWidth(0)) {
         throw new IllegalArgumentException("regionWidth + regionX should be less than the texture width");
      }

      if (ped0607eb_27_4 <= 0) {
         throw new IllegalArgumentException("regionHeight should be greater than 0");
      }

      if (ped0607eb_25_2 + ped0607eb_27_4 > ped0607eb_23_0.getHeight(0)) {
         throw new IllegalArgumentException("regionWidth + regionX should be less than the texture height");
      }
   }

   @Override
   public void clearDepthTexture(GpuTexture ped0607eb_28_0, double ped0607eb_29_1) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before creating a new one!");
      }

      this.verifyDepthTexture(ped0607eb_28_0);
      this.device.directStateAccess().bindFrameBufferTextures(this.drawFbo, 0, ((GlTexture)ped0607eb_28_0).id, 0, 36160);
      GL11.glDrawBuffer(0);
      GL11.glClearDepth(ped0607eb_29_1);
      GlStateManager._depthMask(true);
      GlStateManager._disableScissorTest();
      GlStateManager._clear(256);
      GL11.glDrawBuffer(36064);
      GlStateManager._glFramebufferTexture2D(36160, 36096, 3553, 0, 0);
      GlStateManager._glBindFramebuffer(36160, 0);
   }

   private void verifyColorTexture(GpuTexture ped0607eb_30_0) {
      if (!ped0607eb_30_0.getFormat().hasColorAspect()) {
         throw new IllegalStateException("Trying to clear a non-color texture as color");
      }

      if (ped0607eb_30_0.isClosed()) {
         throw new IllegalStateException("Color texture is closed");
      }

      if ((ped0607eb_30_0.usage() & 8) == 0) {
         throw new IllegalStateException("Color texture must have USAGE_RENDER_ATTACHMENT");
      }

      if (ped0607eb_30_0.getDepthOrLayers() > 1) {
         throw new UnsupportedOperationException("Clearing a texture with multiple layers or depths is not yet supported");
      }
   }

   private void verifyDepthTexture(GpuTexture ped0607eb_31_0) {
      if (!ped0607eb_31_0.getFormat().hasDepthAspect()) {
         throw new IllegalStateException("Trying to clear a non-depth texture as depth");
      }

      if (ped0607eb_31_0.isClosed()) {
         throw new IllegalStateException("Depth texture is closed");
      }

      if ((ped0607eb_31_0.usage() & 8) == 0) {
         throw new IllegalStateException("Depth texture must have USAGE_RENDER_ATTACHMENT");
      }

      if (ped0607eb_31_0.getDepthOrLayers() > 1) {
         throw new UnsupportedOperationException("Clearing a texture with multiple layers or depths is not yet supported");
      }
   }

   @Override
   public void writeToBuffer(GpuBufferSlice ped0607eb_32_0, ByteBuffer ped0607eb_33_1) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before performing additional commands");
      }

      GlBuffer $$2 = (GlBuffer)ped0607eb_32_0.buffer();
      if ($$2.closed) {
         throw new IllegalStateException("Buffer already closed");
      }

      if (($$2.usage() & 8) == 0) {
         throw new IllegalStateException("Buffer needs USAGE_COPY_DST to be a destination for a copy");
      }

      int $$3 = ped0607eb_33_1.remaining();
      if ($$3 > ped0607eb_32_0.length()) {
         throw new IllegalArgumentException(
            "Cannot write more data than the slice allows (attempting to write " + $$3 + " bytes into a slice of length " + ped0607eb_32_0.length() + ")"
         );
      }

      if (ped0607eb_32_0.length() + ped0607eb_32_0.offset() > $$2.size()) {
         throw new IllegalArgumentException(
            "Cannot write more data than this buffer can hold (attempting to write "
               + $$3
               + " bytes at offset "
               + ped0607eb_32_0.offset()
               + " to "
               + $$2.size()
               + " size buffer)"
         );
      }

      this.device.directStateAccess().bufferSubData($$2.handle, ped0607eb_32_0.offset(), ped0607eb_33_1, $$2.usage());
   }

   @Override
   public GpuBuffer.MappedView mapBuffer(GpuBuffer ped0607eb_34_0, boolean ped0607eb_35_1, boolean ped0607eb_36_2) {
      return this.mapBuffer(ped0607eb_34_0.slice(), ped0607eb_35_1, ped0607eb_36_2);
   }

   @Override
   public GpuBuffer.MappedView mapBuffer(GpuBufferSlice ped0607eb_37_0, boolean ped0607eb_38_1, boolean ped0607eb_39_2) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before performing additional commands");
      }

      GlBuffer $$3 = (GlBuffer)ped0607eb_37_0.buffer();
      if ($$3.closed) {
         throw new IllegalStateException("Buffer already closed");
      }

      if (!ped0607eb_38_1 && !ped0607eb_39_2) {
         throw new IllegalArgumentException("At least read or write must be true");
      }

      if (ped0607eb_38_1 && ($$3.usage() & 1) == 0) {
         throw new IllegalStateException("Buffer is not readable");
      }

      if (ped0607eb_39_2 && ($$3.usage() & 2) == 0) {
         throw new IllegalStateException("Buffer is not writable");
      }

      if (ped0607eb_37_0.offset() + ped0607eb_37_0.length() > $$3.size()) {
         throw new IllegalArgumentException(
            "Cannot map more data than this buffer can hold (attempting to map "
               + ped0607eb_37_0.length()
               + " bytes at offset "
               + ped0607eb_37_0.offset()
               + " from "
               + $$3.size()
               + " size buffer)"
         );
      }

      int $$4 = 0;
      if (ped0607eb_38_1) {
         $$4 |= 1;
      }

      if (ped0607eb_39_2) {
         $$4 |= 34;
      }

      return this.device.getBufferStorage().mapBuffer(this.device.directStateAccess(), $$3, ped0607eb_37_0.offset(), ped0607eb_37_0.length(), $$4);
   }

   @Override
   public void copyToBuffer(GpuBufferSlice ped0607eb_40_0, GpuBufferSlice ped0607eb_41_1) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before performing additional commands");
      }

      GlBuffer $$2 = (GlBuffer)ped0607eb_40_0.buffer();
      if ($$2.closed) {
         throw new IllegalStateException("Source buffer already closed");
      }

      if (($$2.usage() & 16) == 0) {
         throw new IllegalStateException("Source buffer needs USAGE_COPY_SRC to be a source for a copy");
      }

      GlBuffer $$3 = (GlBuffer)ped0607eb_41_1.buffer();
      if ($$3.closed) {
         throw new IllegalStateException("Target buffer already closed");
      }

      if (($$3.usage() & 8) == 0) {
         throw new IllegalStateException("Target buffer needs USAGE_COPY_DST to be a destination for a copy");
      }

      if (ped0607eb_40_0.length() != ped0607eb_41_1.length()) {
         throw new IllegalArgumentException(
            "Cannot copy from slice of size " + ped0607eb_40_0.length() + " to slice of size " + ped0607eb_41_1.length() + ", they must be equal"
         );
      }

      if (ped0607eb_40_0.offset() + ped0607eb_40_0.length() > $$2.size()) {
         throw new IllegalArgumentException(
            "Cannot copy more data than the source buffer holds (attempting to copy "
               + ped0607eb_40_0.length()
               + " bytes at offset "
               + ped0607eb_40_0.offset()
               + " from "
               + $$2.size()
               + " size buffer)"
         );
      }

      if (ped0607eb_41_1.offset() + ped0607eb_41_1.length() > $$3.size()) {
         throw new IllegalArgumentException(
            "Cannot copy more data than the target buffer can hold (attempting to copy "
               + ped0607eb_41_1.length()
               + " bytes at offset "
               + ped0607eb_41_1.offset()
               + " to "
               + $$3.size()
               + " size buffer)"
         );
      }

      this.device.directStateAccess().copyBufferSubData($$2.handle, $$3.handle, ped0607eb_40_0.offset(), ped0607eb_41_1.offset(), ped0607eb_40_0.length());
   }

   @Override
   public void writeToTexture(GpuTexture ped0607eb_42_0, NativeImage ped0607eb_43_1) {
      int $$2 = ped0607eb_42_0.getWidth(0);
      int $$3 = ped0607eb_42_0.getHeight(0);
      if (ped0607eb_43_1.getWidth() != $$2 || ped0607eb_43_1.getHeight() != $$3) {
         throw new IllegalArgumentException(
            "Cannot replace texture of size " + $$2 + "x" + $$3 + " with image of size " + ped0607eb_43_1.getWidth() + "x" + ped0607eb_43_1.getHeight()
         );
      }

      if (ped0607eb_42_0.isClosed()) {
         throw new IllegalStateException("Destination texture is closed");
      }

      if ((ped0607eb_42_0.usage() & 1) == 0) {
         throw new IllegalStateException("Color texture must have USAGE_COPY_DST to be a destination for a write");
      }

      this.writeToTexture(ped0607eb_42_0, ped0607eb_43_1, 0, 0, 0, 0, $$2, $$3, 0, 0);
   }

   @Override
   public void writeToTexture(
      GpuTexture ped0607eb_44_0,
      NativeImage ped0607eb_45_1,
      int ped0607eb_46_2,
      int ped0607eb_47_3,
      int ped0607eb_48_4,
      int ped0607eb_49_5,
      int ped0607eb_50_6,
      int ped0607eb_51_7,
      int ped0607eb_52_8,
      int ped0607eb_53_9
   ) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before performing additional commands");
      }

      if (ped0607eb_46_2 >= 0 && ped0607eb_46_2 < ped0607eb_44_0.getMipLevels()) {
         if (ped0607eb_52_8 + ped0607eb_50_6 > ped0607eb_45_1.getWidth() || ped0607eb_53_9 + ped0607eb_51_7 > ped0607eb_45_1.getHeight()) {
            throw new IllegalArgumentException(
               "Copy source ("
                  + ped0607eb_45_1.getWidth()
                  + "x"
                  + ped0607eb_45_1.getHeight()
                  + ") is not large enough to read a rectangle of "
                  + ped0607eb_50_6
                  + "x"
                  + ped0607eb_51_7
                  + " from "
                  + ped0607eb_52_8
                  + "x"
                  + ped0607eb_53_9
            );
         }

         if (ped0607eb_48_4 + ped0607eb_50_6 > ped0607eb_44_0.getWidth(ped0607eb_46_2)
            || ped0607eb_49_5 + ped0607eb_51_7 > ped0607eb_44_0.getHeight(ped0607eb_46_2)) {
            throw new IllegalArgumentException(
               "Dest texture ("
                  + ped0607eb_50_6
                  + "x"
                  + ped0607eb_51_7
                  + ") is not large enough to write a rectangle of "
                  + ped0607eb_50_6
                  + "x"
                  + ped0607eb_51_7
                  + " at "
                  + ped0607eb_48_4
                  + "x"
                  + ped0607eb_49_5
                  + " (at mip level "
                  + ped0607eb_46_2
                  + ")"
            );
         }

         if (ped0607eb_44_0.isClosed()) {
            throw new IllegalStateException("Destination texture is closed");
         }

         if ((ped0607eb_44_0.usage() & 1) == 0) {
            throw new IllegalStateException("Color texture must have USAGE_COPY_DST to be a destination for a write");
         }

         if (ped0607eb_47_3 >= ped0607eb_44_0.getDepthOrLayers()) {
            throw new UnsupportedOperationException("Depth or layer is out of range, must be >= 0 and < " + ped0607eb_44_0.getDepthOrLayers());
         }

         int $$10;
         if ((ped0607eb_44_0.usage() & 16) != 0) {
            $$10 = GlConst.CUBEMAP_TARGETS[ped0607eb_47_3 % 6];
            GL11.glBindTexture(34067, ((GlTexture)ped0607eb_44_0).id);
         } else {
            $$10 = 3553;
            GlStateManager._bindTexture(((GlTexture)ped0607eb_44_0).id);
         }

         GlStateManager._pixelStore(3314, ped0607eb_45_1.getWidth());
         GlStateManager._pixelStore(3316, ped0607eb_52_8);
         GlStateManager._pixelStore(3315, ped0607eb_53_9);
         GlStateManager._pixelStore(3317, ped0607eb_45_1.format().components());
         GlStateManager._texSubImage2D(
            $$10,
            ped0607eb_46_2,
            ped0607eb_48_4,
            ped0607eb_49_5,
            ped0607eb_50_6,
            ped0607eb_51_7,
            GlConst.toGl(ped0607eb_45_1.format()),
            5121,
            ped0607eb_45_1.getPointer()
         );
      } else {
         throw new IllegalArgumentException("Invalid mipLevel " + ped0607eb_46_2 + ", must be >= 0 and < " + ped0607eb_44_0.getMipLevels());
      }
   }

   @Override
   public void writeToTexture(
      GpuTexture ped0607eb_54_0,
      ByteBuffer ped0607eb_55_1,
      NativeImage.Format ped0607eb_56_2,
      int ped0607eb_57_3,
      int ped0607eb_58_4,
      int ped0607eb_59_5,
      int ped0607eb_60_6,
      int ped0607eb_61_7,
      int ped0607eb_62_8
   ) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before performing additional commands");
      }

      if (ped0607eb_57_3 >= 0 && ped0607eb_57_3 < ped0607eb_54_0.getMipLevels()) {
         if (ped0607eb_61_7 * ped0607eb_62_8 * ped0607eb_56_2.components() > ped0607eb_55_1.remaining()) {
            throw new IllegalArgumentException(
               "Copy would overrun the source buffer (remaining length of "
                  + ped0607eb_55_1.remaining()
                  + ", but copy is "
                  + ped0607eb_61_7
                  + "x"
                  + ped0607eb_62_8
                  + " of format "
                  + ped0607eb_56_2
                  + ")"
            );
         }

         if (ped0607eb_59_5 + ped0607eb_61_7 > ped0607eb_54_0.getWidth(ped0607eb_57_3)
            || ped0607eb_60_6 + ped0607eb_62_8 > ped0607eb_54_0.getHeight(ped0607eb_57_3)) {
            throw new IllegalArgumentException(
               "Dest texture ("
                  + ped0607eb_54_0.getWidth(ped0607eb_57_3)
                  + "x"
                  + ped0607eb_54_0.getHeight(ped0607eb_57_3)
                  + ") is not large enough to write a rectangle of "
                  + ped0607eb_61_7
                  + "x"
                  + ped0607eb_62_8
                  + " at "
                  + ped0607eb_59_5
                  + "x"
                  + ped0607eb_60_6
            );
         }

         if (ped0607eb_54_0.isClosed()) {
            throw new IllegalStateException("Destination texture is closed");
         }

         if ((ped0607eb_54_0.usage() & 1) == 0) {
            throw new IllegalStateException("Color texture must have USAGE_COPY_DST to be a destination for a write");
         }

         if (ped0607eb_58_4 >= ped0607eb_54_0.getDepthOrLayers()) {
            throw new UnsupportedOperationException("Depth or layer is out of range, must be >= 0 and < " + ped0607eb_54_0.getDepthOrLayers());
         }

         int $$9;
         if ((ped0607eb_54_0.usage() & 16) != 0) {
            $$9 = GlConst.CUBEMAP_TARGETS[ped0607eb_58_4 % 6];
            GL11.glBindTexture(34067, ((GlTexture)ped0607eb_54_0).id);
         } else {
            $$9 = 3553;
            GlStateManager._bindTexture(((GlTexture)ped0607eb_54_0).id);
         }

         GlStateManager._pixelStore(3314, ped0607eb_61_7);
         GlStateManager._pixelStore(3316, 0);
         GlStateManager._pixelStore(3315, 0);
         GlStateManager._pixelStore(3317, ped0607eb_56_2.components());
         GlStateManager._texSubImage2D(
            $$9, ped0607eb_57_3, ped0607eb_59_5, ped0607eb_60_6, ped0607eb_61_7, ped0607eb_62_8, GlConst.toGl(ped0607eb_56_2), 5121, ped0607eb_55_1
         );
      } else {
         throw new IllegalArgumentException("Invalid mipLevel, must be >= 0 and < " + ped0607eb_54_0.getMipLevels());
      }
   }

   @Override
   public void copyTextureToBuffer(GpuTexture ped0607eb_63_0, GpuBuffer ped0607eb_64_1, long ped0607eb_65_2, Runnable ped0607eb_66_3, int ped0607eb_67_4) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before performing additional commands");
      }

      this.copyTextureToBuffer(
         ped0607eb_63_0,
         ped0607eb_64_1,
         ped0607eb_65_2,
         ped0607eb_66_3,
         ped0607eb_67_4,
         0,
         0,
         ped0607eb_63_0.getWidth(ped0607eb_67_4),
         ped0607eb_63_0.getHeight(ped0607eb_67_4)
      );
   }

   @Override
   public void copyTextureToBuffer(
      GpuTexture ped0607eb_68_0,
      GpuBuffer ped0607eb_69_1,
      long ped0607eb_70_2,
      Runnable ped0607eb_71_3,
      int ped0607eb_72_4,
      int ped0607eb_73_5,
      int ped0607eb_74_6,
      int ped0607eb_75_7,
      int ped0607eb_76_8
   ) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before performing additional commands");
      }

      if (ped0607eb_72_4 >= 0 && ped0607eb_72_4 < ped0607eb_68_0.getMipLevels()) {
         if (ped0607eb_68_0.getWidth(ped0607eb_72_4) * ped0607eb_68_0.getHeight(ped0607eb_72_4) * ped0607eb_68_0.getFormat().pixelSize() + ped0607eb_70_2
            > ped0607eb_69_1.size()) {
            throw new IllegalArgumentException(
               "Buffer of size "
                  + ped0607eb_69_1.size()
                  + " is not large enough to hold "
                  + ped0607eb_75_7
                  + "x"
                  + ped0607eb_76_8
                  + " pixels ("
                  + ped0607eb_68_0.getFormat().pixelSize()
                  + " bytes each) starting from offset "
                  + ped0607eb_70_2
            );
         }

         if ((ped0607eb_68_0.usage() & 2) == 0) {
            throw new IllegalArgumentException("Texture needs USAGE_COPY_SRC to be a source for a copy");
         }

         if ((ped0607eb_69_1.usage() & 8) == 0) {
            throw new IllegalArgumentException("Buffer needs USAGE_COPY_DST to be a destination for a copy");
         }

         if (ped0607eb_73_5 + ped0607eb_75_7 > ped0607eb_68_0.getWidth(ped0607eb_72_4)
            || ped0607eb_74_6 + ped0607eb_76_8 > ped0607eb_68_0.getHeight(ped0607eb_72_4)) {
            throw new IllegalArgumentException(
               "Copy source texture ("
                  + ped0607eb_68_0.getWidth(ped0607eb_72_4)
                  + "x"
                  + ped0607eb_68_0.getHeight(ped0607eb_72_4)
                  + ") is not large enough to read a rectangle of "
                  + ped0607eb_75_7
                  + "x"
                  + ped0607eb_76_8
                  + " from "
                  + ped0607eb_73_5
                  + ","
                  + ped0607eb_74_6
            );
         }

         if (ped0607eb_68_0.isClosed()) {
            throw new IllegalStateException("Source texture is closed");
         }

         if (ped0607eb_69_1.isClosed()) {
            throw new IllegalStateException("Destination buffer is closed");
         }

         if (ped0607eb_68_0.getDepthOrLayers() > 1) {
            throw new UnsupportedOperationException("Textures with multiple depths or layers are not yet supported for copying");
         }

         GlStateManager.clearGlErrors();
         this.device.directStateAccess().bindFrameBufferTextures(this.readFbo, ((GlTexture)ped0607eb_68_0).glId(), 0, ped0607eb_72_4, 36008);
         GlStateManager._glBindBuffer(35051, ((GlBuffer)ped0607eb_69_1).handle);
         GlStateManager._pixelStore(3330, ped0607eb_75_7);
         GlStateManager._readPixels(
            ped0607eb_73_5,
            ped0607eb_74_6,
            ped0607eb_75_7,
            ped0607eb_76_8,
            GlConst.toGlExternalId(ped0607eb_68_0.getFormat()),
            GlConst.toGlType(ped0607eb_68_0.getFormat()),
            ped0607eb_70_2
         );
         RenderSystem.queueFencedTask(ped0607eb_71_3);
         GlStateManager._glFramebufferTexture2D(36008, 36064, 3553, 0, ped0607eb_72_4);
         GlStateManager._glBindFramebuffer(36008, 0);
         GlStateManager._glBindBuffer(35051, 0);
         int $$9 = GlStateManager._getError();
         if ($$9 != 0) {
            throw new IllegalStateException("Couldn't perform copyTobuffer for texture " + ped0607eb_68_0.getLabel() + ": GL error " + $$9);
         }
      } else {
         throw new IllegalArgumentException("Invalid mipLevel " + ped0607eb_72_4 + ", must be >= 0 and < " + ped0607eb_68_0.getMipLevels());
      }
   }

   @Override
   public void copyTextureToTexture(
      GpuTexture ped0607eb_77_0,
      GpuTexture ped0607eb_78_1,
      int ped0607eb_79_2,
      int ped0607eb_80_3,
      int ped0607eb_81_4,
      int ped0607eb_82_5,
      int ped0607eb_83_6,
      int ped0607eb_84_7,
      int ped0607eb_85_8
   ) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before performing additional commands");
      }

      if (ped0607eb_79_2 >= 0 && ped0607eb_79_2 < ped0607eb_77_0.getMipLevels() && ped0607eb_79_2 < ped0607eb_78_1.getMipLevels()) {
         if (ped0607eb_80_3 + ped0607eb_84_7 > ped0607eb_78_1.getWidth(ped0607eb_79_2)
            || ped0607eb_81_4 + ped0607eb_85_8 > ped0607eb_78_1.getHeight(ped0607eb_79_2)) {
            throw new IllegalArgumentException(
               "Dest texture ("
                  + ped0607eb_78_1.getWidth(ped0607eb_79_2)
                  + "x"
                  + ped0607eb_78_1.getHeight(ped0607eb_79_2)
                  + ") is not large enough to write a rectangle of "
                  + ped0607eb_84_7
                  + "x"
                  + ped0607eb_85_8
                  + " at "
                  + ped0607eb_80_3
                  + "x"
                  + ped0607eb_81_4
            );
         }

         if (ped0607eb_82_5 + ped0607eb_84_7 > ped0607eb_77_0.getWidth(ped0607eb_79_2)
            || ped0607eb_83_6 + ped0607eb_85_8 > ped0607eb_77_0.getHeight(ped0607eb_79_2)) {
            throw new IllegalArgumentException(
               "Source texture ("
                  + ped0607eb_77_0.getWidth(ped0607eb_79_2)
                  + "x"
                  + ped0607eb_77_0.getHeight(ped0607eb_79_2)
                  + ") is not large enough to read a rectangle of "
                  + ped0607eb_84_7
                  + "x"
                  + ped0607eb_85_8
                  + " at "
                  + ped0607eb_82_5
                  + "x"
                  + ped0607eb_83_6
            );
         }

         if (ped0607eb_77_0.isClosed()) {
            throw new IllegalStateException("Source texture is closed");
         }

         if (ped0607eb_78_1.isClosed()) {
            throw new IllegalStateException("Destination texture is closed");
         }

         if ((ped0607eb_77_0.usage() & 2) == 0) {
            throw new IllegalArgumentException("Texture needs USAGE_COPY_SRC to be a source for a copy");
         }

         if ((ped0607eb_78_1.usage() & 1) == 0) {
            throw new IllegalArgumentException("Texture needs USAGE_COPY_DST to be a destination for a copy");
         }

         if (ped0607eb_77_0.getDepthOrLayers() > 1) {
            throw new UnsupportedOperationException("Textures with multiple depths or layers are not yet supported for copying");
         }

         if (ped0607eb_78_1.getDepthOrLayers() > 1) {
            throw new UnsupportedOperationException("Textures with multiple depths or layers are not yet supported for copying");
         }

         GlStateManager.clearGlErrors();
         GlStateManager._disableScissorTest();
         boolean $$9 = ped0607eb_77_0.getFormat().hasDepthAspect();
         int $$10 = ((GlTexture)ped0607eb_77_0).glId();
         int $$11 = ((GlTexture)ped0607eb_78_1).glId();
         this.device.directStateAccess().bindFrameBufferTextures(this.readFbo, $$9 ? 0 : $$10, $$9 ? $$10 : 0, 0, 0);
         this.device.directStateAccess().bindFrameBufferTextures(this.drawFbo, $$9 ? 0 : $$11, $$9 ? $$11 : 0, 0, 0);
         this.device
            .directStateAccess()
            .blitFrameBuffers(
               this.readFbo,
               this.drawFbo,
               ped0607eb_82_5,
               ped0607eb_83_6,
               ped0607eb_84_7,
               ped0607eb_85_8,
               ped0607eb_80_3,
               ped0607eb_81_4,
               ped0607eb_84_7,
               ped0607eb_85_8,
               $$9 ? 256 : 16384,
               9728
            );
         int $$12 = GlStateManager._getError();
         if ($$12 != 0) {
            throw new IllegalStateException(
               "Couldn't perform copyToTexture for texture " + ped0607eb_77_0.getLabel() + " to " + ped0607eb_78_1.getLabel() + ": GL error " + $$12
            );
         }
      } else {
         throw new IllegalArgumentException(
            "Invalid mipLevel " + ped0607eb_79_2 + ", must be >= 0 and < " + ped0607eb_77_0.getMipLevels() + " and < " + ped0607eb_78_1.getMipLevels()
         );
      }
   }

   @Override
   public void presentTexture(GpuTextureView ped0607eb_86_0) {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before performing additional commands");
      }

      if (!ped0607eb_86_0.texture().getFormat().hasColorAspect()) {
         throw new IllegalStateException("Cannot present a non-color texture!");
      }

      if ((ped0607eb_86_0.texture().usage() & 8) == 0) {
         throw new IllegalStateException("Color texture must have USAGE_RENDER_ATTACHMENT to presented to the screen");
      }

      if (ped0607eb_86_0.texture().getDepthOrLayers() > 1) {
         throw new UnsupportedOperationException("Textures with multiple depths or layers are not yet supported for presentation");
      }

      GlStateManager._disableScissorTest();
      GlStateManager._viewport(0, 0, ped0607eb_86_0.getWidth(0), ped0607eb_86_0.getHeight(0));
      GlStateManager._depthMask(true);
      GlStateManager._colorMask(true, true, true, true);
      this.device.directStateAccess().bindFrameBufferTextures(this.drawFbo, ((GlTexture)ped0607eb_86_0.texture()).glId(), 0, 0, 0);
      this.device
         .directStateAccess()
         .blitFrameBuffers(
            this.drawFbo,
            0,
            0,
            0,
            ped0607eb_86_0.getWidth(0),
            ped0607eb_86_0.getHeight(0),
            0,
            0,
            ped0607eb_86_0.getWidth(0),
            ped0607eb_86_0.getHeight(0),
            16384,
            9728
         );
   }

   @Override
   public GpuFence createFence() {
      if (this.inRenderPass) {
         throw new IllegalStateException("Close the existing render pass before performing additional commands");
      } else {
         return new GlFence();
      }
   }

   protected <T> void executeDrawMultiple(
      GlRenderPass ped0607eb_87_0,
      Collection<RenderPass.Draw<T>> ped0607eb_88_1,
      @Nullable GpuBuffer ped0607eb_89_2,
      VertexFormat.@Nullable IndexType ped0607eb_90_3,
      Collection<String> ped0607eb_91_4,
      T ped0607eb_92_5
   ) {
      if (this.trySetup(ped0607eb_87_0, ped0607eb_91_4)) {
         if (ped0607eb_90_3 == null) {
            ped0607eb_90_3 = VertexFormat.IndexType.SHORT;
         }

         for (RenderPass.Draw<T> $$6 : ped0607eb_88_1) {
            VertexFormat.IndexType $$7 = $$6.indexType() == null ? ped0607eb_90_3 : $$6.indexType();
            ped0607eb_87_0.setIndexBuffer($$6.indexBuffer() == null ? ped0607eb_89_2 : $$6.indexBuffer(), $$7);
            ped0607eb_87_0.setVertexBuffer($$6.slot(), $$6.vertexBuffer());
            if (GlRenderPass.VALIDATION) {
               if (ped0607eb_87_0.indexBuffer == null) {
                  throw new IllegalStateException("Missing index buffer");
               }

               if (ped0607eb_87_0.indexBuffer.isClosed()) {
                  throw new IllegalStateException("Index buffer has been closed!");
               }

               if (ped0607eb_87_0.vertexBuffers[0] == null) {
                  throw new IllegalStateException("Missing vertex buffer at slot 0");
               }

               if (ped0607eb_87_0.vertexBuffers[0].isClosed()) {
                  throw new IllegalStateException("Vertex buffer at slot 0 has been closed!");
               }
            }

            BiConsumer<T, RenderPass.UniformUploader> $$8 = $$6.uniformUploaderConsumer();
            if ($$8 != null) {
               $$8.accept(ped0607eb_92_5, (ped0607eb_111_1, ped0607eb_112_2) -> {
                  if (ped0607eb_87_0.pipeline.program().getUniform(ped0607eb_111_1) instanceof Uniform.Ubo(int $$6x)) {
                     GL32.glBindBufferRange(35345, $$6x, ((GlBuffer)ped0607eb_112_2.buffer()).handle, ped0607eb_112_2.offset(), ped0607eb_112_2.length());
                  }
               });
            }

            this.drawFromBuffers(ped0607eb_87_0, 0, $$6.firstIndex(), $$6.indexCount(), $$7, ped0607eb_87_0.pipeline, 1);
         }
      }
   }

   protected void executeDraw(
      GlRenderPass ped0607eb_93_0,
      int ped0607eb_94_1,
      int ped0607eb_95_2,
      int ped0607eb_96_3,
      VertexFormat.@Nullable IndexType ped0607eb_97_4,
      int ped0607eb_98_5
   ) {
      if (this.trySetup(ped0607eb_93_0, Collections.emptyList())) {
         if (GlRenderPass.VALIDATION) {
            if (ped0607eb_97_4 != null) {
               if (ped0607eb_93_0.indexBuffer == null) {
                  throw new IllegalStateException("Missing index buffer");
               }

               if (ped0607eb_93_0.indexBuffer.isClosed()) {
                  throw new IllegalStateException("Index buffer has been closed!");
               }

               if ((ped0607eb_93_0.indexBuffer.usage() & 64) == 0) {
                  throw new IllegalStateException("Index buffer must have GpuBuffer.USAGE_INDEX!");
               }
            }

            GlRenderPipeline $$6 = ped0607eb_93_0.pipeline;
            if (ped0607eb_93_0.vertexBuffers[0] == null && $$6 != null && !$$6.info().getVertexFormat().getElements().isEmpty()) {
               throw new IllegalStateException("Vertex format contains elements but vertex buffer at slot 0 is null");
            }

            if (ped0607eb_93_0.vertexBuffers[0] != null && ped0607eb_93_0.vertexBuffers[0].isClosed()) {
               throw new IllegalStateException("Vertex buffer at slot 0 has been closed!");
            }

            if (ped0607eb_93_0.vertexBuffers[0] != null && (ped0607eb_93_0.vertexBuffers[0].usage() & 32) == 0) {
               throw new IllegalStateException("Vertex buffer must have GpuBuffer.USAGE_VERTEX!");
            }
         }

         this.drawFromBuffers(ped0607eb_93_0, ped0607eb_94_1, ped0607eb_95_2, ped0607eb_96_3, ped0607eb_97_4, ped0607eb_93_0.pipeline, ped0607eb_98_5);
      }
   }

   private void drawFromBuffers(
      GlRenderPass ped0607eb_99_0,
      int ped0607eb_100_1,
      int ped0607eb_101_2,
      int ped0607eb_102_3,
      VertexFormat.@Nullable IndexType ped0607eb_103_4,
      GlRenderPipeline ped0607eb_104_5,
      int ped0607eb_105_6
   ) {
      this.device.vertexArrayCache().bindVertexArray(ped0607eb_104_5.info().getVertexFormat(), (GlBuffer)ped0607eb_99_0.vertexBuffers[0]);
      if (ped0607eb_103_4 != null) {
         GlStateManager._glBindBuffer(34963, ((GlBuffer)ped0607eb_99_0.indexBuffer).handle);
         if (ped0607eb_105_6 > 1) {
            if (ped0607eb_100_1 > 0) {
               GL32.glDrawElementsInstancedBaseVertex(
                  GlConst.toGl(ped0607eb_104_5.info().getVertexFormatMode()),
                  ped0607eb_102_3,
                  GlConst.toGl(ped0607eb_103_4),
                  (long)ped0607eb_101_2 * ped0607eb_103_4.bytes,
                  ped0607eb_105_6,
                  ped0607eb_100_1
               );
            } else {
               GL31.glDrawElementsInstanced(
                  GlConst.toGl(ped0607eb_104_5.info().getVertexFormatMode()),
                  ped0607eb_102_3,
                  GlConst.toGl(ped0607eb_103_4),
                  (long)ped0607eb_101_2 * ped0607eb_103_4.bytes,
                  ped0607eb_105_6
               );
            }
         } else if (ped0607eb_100_1 > 0) {
            GL32.glDrawElementsBaseVertex(
               GlConst.toGl(ped0607eb_104_5.info().getVertexFormatMode()),
               ped0607eb_102_3,
               GlConst.toGl(ped0607eb_103_4),
               (long)ped0607eb_101_2 * ped0607eb_103_4.bytes,
               ped0607eb_100_1
            );
         } else {
            GlStateManager._drawElements(
               GlConst.toGl(ped0607eb_104_5.info().getVertexFormatMode()),
               ped0607eb_102_3,
               GlConst.toGl(ped0607eb_103_4),
               (long)ped0607eb_101_2 * ped0607eb_103_4.bytes
            );
         }
      } else if (ped0607eb_105_6 > 1) {
         GL31.glDrawArraysInstanced(GlConst.toGl(ped0607eb_104_5.info().getVertexFormatMode()), ped0607eb_100_1, ped0607eb_102_3, ped0607eb_105_6);
      } else {
         GlStateManager._drawArrays(GlConst.toGl(ped0607eb_104_5.info().getVertexFormatMode()), ped0607eb_100_1, ped0607eb_102_3);
      }
   }

   private boolean trySetup(GlRenderPass ped0607eb_106_0, Collection<String> ped0607eb_107_1) {
      if (GlRenderPass.VALIDATION) {
         if (ped0607eb_106_0.pipeline == null) {
            throw new IllegalStateException("Can't draw without a render pipeline");
         }

         if (ped0607eb_106_0.pipeline.program() == GlProgram.INVALID_PROGRAM) {
            throw new IllegalStateException("Pipeline contains invalid shader program");
         }

         for (RenderPipeline.UniformDescription $$2 : ped0607eb_106_0.pipeline.info().getUniforms()) {
            GpuBufferSlice $$3 = ped0607eb_106_0.uniforms.get($$2.name());
            if (!ped0607eb_107_1.contains($$2.name())) {
               if ($$3 == null) {
                  throw new IllegalStateException("Missing uniform " + $$2.name() + " (should be " + $$2.type() + ")");
               }

               if ($$2.type() == UniformType.UNIFORM_BUFFER) {
                  if ($$3.buffer().isClosed()) {
                     throw new IllegalStateException("Uniform buffer " + $$2.name() + " is already closed");
                  }

                  if (($$3.buffer().usage() & 128) == 0) {
                     throw new IllegalStateException("Uniform buffer " + $$2.name() + " must have GpuBuffer.USAGE_UNIFORM");
                  }
               }

               if ($$2.type() == UniformType.TEXEL_BUFFER) {
                  if ($$3.offset() != 0L || $$3.length() != $$3.buffer().size()) {
                     throw new IllegalStateException("Uniform texel buffers do not support a slice of a buffer, must be entire buffer");
                  }

                  if ($$2.textureFormat() == null) {
                     throw new IllegalStateException("Invalid uniform texel buffer " + $$2.name() + " (missing a texture format)");
                  }
               }
            }
         }

         for (Entry<String, Uniform> $$4 : ped0607eb_106_0.pipeline.program().getUniforms().entrySet()) {
            if ($$4.getValue() instanceof Uniform.Sampler) {
               String $$5 = $$4.getKey();
               GlRenderPass.TextureViewAndSampler $$6 = ped0607eb_106_0.samplers.get($$5);
               if ($$6 == null) {
                  throw new IllegalStateException("Missing sampler " + $$5);
               }

               GlTextureView $$7 = $$6.view();
               if ($$7.isClosed()) {
                  throw new IllegalStateException("Texture view " + $$5 + " (" + $$7.texture().getLabel() + ") has been closed!");
               }

               if (($$7.texture().usage() & 4) == 0) {
                  throw new IllegalStateException("Texture view " + $$5 + " (" + $$7.texture().getLabel() + ") must have USAGE_TEXTURE_BINDING!");
               }

               if ($$6.sampler().isClosed()) {
                  throw new IllegalStateException("Sampler for " + $$5 + " (" + $$7.texture().getLabel() + ") has been closed!");
               }
            }
         }

         if (ped0607eb_106_0.pipeline.info().wantsDepthTexture() && !ped0607eb_106_0.hasDepthTexture()) {
            LOGGER.warn(
               "Render pipeline {} wants a depth texture but none was provided - this is probably a bug", ped0607eb_106_0.pipeline.info().getLocation()
            );
         }
      } else if (ped0607eb_106_0.pipeline == null || ped0607eb_106_0.pipeline.program() == GlProgram.INVALID_PROGRAM) {
         return false;
      }

      RenderPipeline $$8 = ped0607eb_106_0.pipeline.info();
      GlProgram $$9 = ped0607eb_106_0.pipeline.program();
      this.applyPipelineState($$8);
      boolean $$10 = this.lastProgram != $$9;
      if ($$10) {
         GlStateManager._glUseProgram($$9.getProgramId());
         this.lastProgram = $$9;
      }

      for (Entry<String, Uniform> $$11 : $$9.getUniforms().entrySet()) {
         String $$12 = $$11.getKey();
         boolean $$13 = ped0607eb_106_0.dirtyUniforms.contains($$12);
         switch ((Uniform)$$11.getValue()) {
            case Uniform.Ubo(int $$14):
               if ($$13) {
                  GpuBufferSlice $$15 = ped0607eb_106_0.uniforms.get($$12);
                  GL32.glBindBufferRange(35345, $$14, ((GlBuffer)$$15.buffer()).handle, $$15.offset(), $$15.length());
               }
               break;
            case Uniform.Utb(int $$16, int $$17, TextureFormat $$18, int $$19):
               if ($$10 || $$13) {
                  GlStateManager._glUniform1i($$16, $$17);
               }

               GlStateManager._activeTexture(33984 + $$17);
               GL11C.glBindTexture(35882, $$19);
               if ($$13) {
                  GpuBufferSlice $$20 = ped0607eb_106_0.uniforms.get($$12);
                  GL31.glTexBuffer(35882, GlConst.toGlInternalId($$18), ((GlBuffer)$$20.buffer()).handle);
               }
               break;
            case Uniform.Sampler(int $$21, int $$22):
               GlRenderPass.TextureViewAndSampler $$23 = ped0607eb_106_0.samplers.get($$12);
               if ($$23 == null) {
                  break;
               }

               GlTextureView $$24 = $$23.view();
               if ($$10 || $$13) {
                  GlStateManager._glUniform1i($$21, $$22);
               }

               GlStateManager._activeTexture(33984 + $$22);
               GlTexture $$25 = $$24.texture();
               int $$26;
               if (($$25.usage() & 16) != 0) {
                  $$26 = 34067;
                  GL11.glBindTexture(34067, $$25.id);
               } else {
                  $$26 = 3553;
                  GlStateManager._bindTexture($$25.id);
               }

               GL33C.glBindSampler($$22, $$23.sampler().getId());
               GlStateManager._texParameter($$26, 33084, $$24.baseMipLevel());
               GlStateManager._texParameter($$26, 33085, $$24.baseMipLevel() + $$24.mipLevels() - 1);
               break;
            default:
               throw new MatchException(null, null);
         }
      }

      ped0607eb_106_0.dirtyUniforms.clear();
      if (ped0607eb_106_0.isScissorEnabled()) {
         GlStateManager._enableScissorTest();
         GlStateManager._scissorBox(
            ped0607eb_106_0.getScissorX(), ped0607eb_106_0.getScissorY(), ped0607eb_106_0.getScissorWidth(), ped0607eb_106_0.getScissorHeight()
         );
      } else {
         GlStateManager._disableScissorTest();
      }

      return true;
   }

   private void applyPipelineState(RenderPipeline ped0607eb_108_0) {
      if (this.lastPipeline != ped0607eb_108_0) {
         this.lastPipeline = ped0607eb_108_0;
         if (ped0607eb_108_0.getDepthTestFunction() != DepthTestFunction.NO_DEPTH_TEST) {
            GlStateManager._enableDepthTest();
            GlStateManager._depthFunc(GlConst.toGl(ped0607eb_108_0.getDepthTestFunction()));
         } else {
            GlStateManager._disableDepthTest();
         }

         if (ped0607eb_108_0.isCull()) {
            GlStateManager._enableCull();
         } else {
            GlStateManager._disableCull();
         }

         if (ped0607eb_108_0.getBlendFunction().isPresent()) {
            GlStateManager._enableBlend();
            BlendFunction $$1 = ped0607eb_108_0.getBlendFunction().get();
            GlStateManager._blendFuncSeparate(
               GlConst.toGl($$1.sourceColor()), GlConst.toGl($$1.destColor()), GlConst.toGl($$1.sourceAlpha()), GlConst.toGl($$1.destAlpha())
            );
         } else {
            GlStateManager._disableBlend();
         }

         GlStateManager._polygonMode(1032, GlConst.toGl(ped0607eb_108_0.getPolygonMode()));
         GlStateManager._depthMask(ped0607eb_108_0.isWriteDepth());
         GlStateManager._colorMask(
            ped0607eb_108_0.isWriteColor(), ped0607eb_108_0.isWriteColor(), ped0607eb_108_0.isWriteColor(), ped0607eb_108_0.isWriteAlpha()
         );
         if (ped0607eb_108_0.getDepthBiasConstant() == 0.0F && ped0607eb_108_0.getDepthBiasScaleFactor() == 0.0F) {
            GlStateManager._disablePolygonOffset();
         } else {
            GlStateManager._polygonOffset(ped0607eb_108_0.getDepthBiasScaleFactor(), ped0607eb_108_0.getDepthBiasConstant());
            GlStateManager._enablePolygonOffset();
         }

         switch (ped0607eb_108_0.getColorLogic()) {
            case NONE:
               GlStateManager._disableColorLogicOp();
               break;
            case OR_REVERSE:
               GlStateManager._enableColorLogicOp();
               GlStateManager._logicOp(5387);
         }
      }
   }

   public void finishRenderPass() {
      this.inRenderPass = false;
      GlStateManager._glBindFramebuffer(36160, 0);
      this.device.debugLabels().popDebugGroup();
   }

   protected GlDevice getDevice() {
      return this.device;
   }

   @Override
   public GpuQuery timerQueryBegin() {
      RenderSystem.assertOnRenderThread();
      if (this.activeTimerQuery != null) {
         throw new IllegalStateException("A GL_TIME_ELAPSED query is already active");
      }

      int $$0 = GL32C.glGenQueries();
      GL32C.glBeginQuery(35007, $$0);
      this.activeTimerQuery = new GlTimerQuery($$0);
      return this.activeTimerQuery;
   }

   @Override
   public void timerQueryEnd(GpuQuery ped0607eb_109_0) {
      RenderSystem.assertOnRenderThread();
      if (ped0607eb_109_0 != this.activeTimerQuery) {
         throw new IllegalStateException("Mismatched or duplicate GpuQuery when ending timerQuery");
      }

      GL32C.glEndQuery(35007);
      this.activeTimerQuery = null;
   }
}
