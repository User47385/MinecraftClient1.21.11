package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;
import java.util.OptionalDouble;
import org.lwjgl.opengl.GL33C;

public class GlSampler extends GpuSampler {
   private final int id;
   private final AddressMode addressModeU;
   private final AddressMode addressModeV;
   private final FilterMode minFilter;
   private final FilterMode magFilter;
   private final int maxAnisotropy;
   private final OptionalDouble maxLod;
   private boolean closed;

   public GlSampler(
      AddressMode pfd9954ae_0_0, AddressMode pfd9954ae_1_1, FilterMode pfd9954ae_2_2, FilterMode pfd9954ae_3_3, int pfd9954ae_4_4, OptionalDouble pfd9954ae_5_5
   ) {
      this.addressModeU = pfd9954ae_0_0;
      this.addressModeV = pfd9954ae_1_1;
      this.minFilter = pfd9954ae_2_2;
      this.magFilter = pfd9954ae_3_3;
      this.maxAnisotropy = pfd9954ae_4_4;
      this.maxLod = pfd9954ae_5_5;
      this.id = GL33C.glGenSamplers();
      GL33C.glSamplerParameteri(this.id, 10242, GlConst.toGl(pfd9954ae_0_0));
      GL33C.glSamplerParameteri(this.id, 10243, GlConst.toGl(pfd9954ae_1_1));
      if (pfd9954ae_4_4 > 1) {
         GL33C.glSamplerParameterf(this.id, 34046, pfd9954ae_4_4);
      }

      switch (pfd9954ae_2_2) {
         case NEAREST:
            GL33C.glSamplerParameteri(this.id, 10241, 9986);
            break;
         case LINEAR:
            GL33C.glSamplerParameteri(this.id, 10241, 9987);
      }

      switch (pfd9954ae_3_3) {
         case NEAREST:
            GL33C.glSamplerParameteri(this.id, 10240, 9728);
            break;
         case LINEAR:
            GL33C.glSamplerParameteri(this.id, 10240, 9729);
      }

      if (pfd9954ae_5_5.isPresent()) {
         GL33C.glSamplerParameterf(this.id, 33083, (float)pfd9954ae_5_5.getAsDouble());
      }
   }

   public int getId() {
      return this.id;
   }

   @Override
   public AddressMode getAddressModeU() {
      return this.addressModeU;
   }

   @Override
   public AddressMode getAddressModeV() {
      return this.addressModeV;
   }

   @Override
   public FilterMode getMinFilter() {
      return this.minFilter;
   }

   @Override
   public FilterMode getMagFilter() {
      return this.magFilter;
   }

   @Override
   public int getMaxAnisotropy() {
      return this.maxAnisotropy;
   }

   @Override
   public OptionalDouble getMaxLod() {
      return this.maxLod;
   }

   @Override
   public void close() {
      if (!this.closed) {
         this.closed = true;
         GL33C.glDeleteSamplers(this.id);
      }
   }

   public boolean isClosed() {
      return this.closed;
   }
}
