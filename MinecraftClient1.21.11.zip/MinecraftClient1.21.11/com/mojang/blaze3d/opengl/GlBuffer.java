package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.jtracy.MemoryPool;
import com.mojang.jtracy.TracyClient;
import java.nio.ByteBuffer;
import java.util.function.Supplier;
import org.jspecify.annotations.Nullable;

public class GlBuffer extends GpuBuffer {
   protected static final MemoryPool MEMORY_POOl = TracyClient.createMemoryPool("GPU Buffers");
   protected boolean closed;
   protected final @Nullable Supplier<String> label;
   private final DirectStateAccess dsa;
   protected final int handle;
   protected @Nullable ByteBuffer persistentBuffer;

   protected GlBuffer(
      @Nullable Supplier<String> p682152da_0_0,
      DirectStateAccess p682152da_1_1,
      @GpuBuffer.Usage int p682152da_2_2,
      long p682152da_3_3,
      int p682152da_4_4,
      @Nullable ByteBuffer p682152da_5_5
   ) {
      super(p682152da_2_2, p682152da_3_3);
      this.label = p682152da_0_0;
      this.dsa = p682152da_1_1;
      this.handle = p682152da_4_4;
      this.persistentBuffer = p682152da_5_5;
      int $$6 = (int)Math.min(p682152da_3_3, 2147483647L);
      MEMORY_POOl.malloc(p682152da_4_4, $$6);
   }

   @Override
   public boolean isClosed() {
      return this.closed;
   }

   @Override
   public void close() {
      if (!this.closed) {
         this.closed = true;
         if (this.persistentBuffer != null) {
            this.dsa.unmapBuffer(this.handle, this.usage());
            this.persistentBuffer = null;
         }

         GlStateManager._glDeleteBuffers(this.handle);
         MEMORY_POOl.free(this.handle);
      }
   }

   public static class GlMappedView implements GpuBuffer.MappedView {
      private final Runnable unmap;
      private final GlBuffer buffer;
      private final ByteBuffer data;
      private boolean closed;

      protected GlMappedView(Runnable p6564c7e7_0_0, GlBuffer p6564c7e7_1_1, ByteBuffer p6564c7e7_2_2) {
         this.unmap = p6564c7e7_0_0;
         this.buffer = p6564c7e7_1_1;
         this.data = p6564c7e7_2_2;
      }

      @Override
      public ByteBuffer data() {
         return this.data;
      }

      @Override
      public void close() {
         if (!this.closed) {
            this.closed = true;
            this.unmap.run();
         }
      }
   }
}
