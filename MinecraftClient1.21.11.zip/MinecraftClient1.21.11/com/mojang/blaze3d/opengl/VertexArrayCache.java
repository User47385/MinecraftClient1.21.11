package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jspecify.annotations.Nullable;
import org.lwjgl.opengl.ARBVertexAttribBinding;
import org.lwjgl.opengl.GLCapabilities;

public abstract class VertexArrayCache {
   public static VertexArrayCache create(GLCapabilities p487e4dc2_0_0, GlDebugLabel p487e4dc2_1_1, Set<String> p487e4dc2_2_2) {
      if (p487e4dc2_0_0.GL_ARB_vertex_attrib_binding && GlDevice.USE_GL_ARB_vertex_attrib_binding) {
         p487e4dc2_2_2.add("GL_ARB_vertex_attrib_binding");
         return new VertexArrayCache.Separate(p487e4dc2_1_1);
      } else {
         return new VertexArrayCache.Emulated(p487e4dc2_1_1);
      }
   }

   public abstract void bindVertexArray(VertexFormat var1, @Nullable GlBuffer var2);

   static class Emulated extends VertexArrayCache {
      private final Map<VertexFormat, VertexArrayCache.VertexArray> cache = new HashMap<>();
      private final GlDebugLabel debugLabels;

      public Emulated(GlDebugLabel pc90ebe93_0_0) {
         this.debugLabels = pc90ebe93_0_0;
      }

      @Override
      public void bindVertexArray(VertexFormat pc90ebe93_1_0, @Nullable GlBuffer pc90ebe93_2_1) {
         VertexArrayCache.VertexArray $$2 = this.cache.get(pc90ebe93_1_0);
         if ($$2 == null) {
            int $$3 = GlStateManager._glGenVertexArrays();
            GlStateManager._glBindVertexArray($$3);
            if (pc90ebe93_2_1 != null) {
               GlStateManager._glBindBuffer(34962, pc90ebe93_2_1.handle);
               setupCombinedAttributes(pc90ebe93_1_0, true);
            }

            VertexArrayCache.VertexArray $$4 = new VertexArrayCache.VertexArray($$3, pc90ebe93_1_0, pc90ebe93_2_1);
            this.debugLabels.applyLabel($$4);
            this.cache.put(pc90ebe93_1_0, $$4);
         } else {
            GlStateManager._glBindVertexArray($$2.id);
            if (pc90ebe93_2_1 != null && $$2.lastVertexBuffer != pc90ebe93_2_1) {
               GlStateManager._glBindBuffer(34962, pc90ebe93_2_1.handle);
               $$2.lastVertexBuffer = pc90ebe93_2_1;
               setupCombinedAttributes(pc90ebe93_1_0, false);
            }
         }
      }

      private static void setupCombinedAttributes(VertexFormat pc90ebe93_3_0, boolean pc90ebe93_4_1) {
         int $$2 = pc90ebe93_3_0.getVertexSize();
         List<VertexFormatElement> $$3 = pc90ebe93_3_0.getElements();

         for (int $$4 = 0; $$4 < $$3.size(); $$4++) {
            VertexFormatElement $$5 = $$3.get($$4);
            if (pc90ebe93_4_1) {
               GlStateManager._enableVertexAttribArray($$4);
            }

            switch ($$5.usage()) {
               case POSITION:
               case GENERIC:
               case UV:
                  if ($$5.type() == VertexFormatElement.Type.FLOAT) {
                     GlStateManager._vertexAttribPointer($$4, $$5.count(), GlConst.toGl($$5.type()), false, $$2, pc90ebe93_3_0.getOffset($$5));
                  } else {
                     GlStateManager._vertexAttribIPointer($$4, $$5.count(), GlConst.toGl($$5.type()), $$2, pc90ebe93_3_0.getOffset($$5));
                  }
                  break;
               case NORMAL:
               case COLOR:
                  GlStateManager._vertexAttribPointer($$4, $$5.count(), GlConst.toGl($$5.type()), true, $$2, pc90ebe93_3_0.getOffset($$5));
            }
         }
      }
   }

   static class Separate extends VertexArrayCache {
      private final Map<VertexFormat, VertexArrayCache.VertexArray> cache = new HashMap<>();
      private final GlDebugLabel debugLabels;
      private final boolean needsMesaWorkaround;

      public Separate(GlDebugLabel pc7118fe5_0_0) {
         this.debugLabels = pc7118fe5_0_0;
         if ("Mesa".equals(GlStateManager._getString(7936))) {
            String $$1 = GlStateManager._getString(7938);
            this.needsMesaWorkaround = $$1.contains("25.0.0") || $$1.contains("25.0.1") || $$1.contains("25.0.2");
         } else {
            this.needsMesaWorkaround = false;
         }
      }

      @Override
      public void bindVertexArray(VertexFormat pc7118fe5_1_0, @Nullable GlBuffer pc7118fe5_2_1) {
         VertexArrayCache.VertexArray $$2 = this.cache.get(pc7118fe5_1_0);
         if ($$2 != null) {
            GlStateManager._glBindVertexArray($$2.id);
            if (pc7118fe5_2_1 != null && $$2.lastVertexBuffer != pc7118fe5_2_1) {
               if (this.needsMesaWorkaround && $$2.lastVertexBuffer != null && $$2.lastVertexBuffer.handle == pc7118fe5_2_1.handle) {
                  ARBVertexAttribBinding.glBindVertexBuffer(0, 0, 0L, 0);
               }

               ARBVertexAttribBinding.glBindVertexBuffer(0, pc7118fe5_2_1.handle, 0L, pc7118fe5_1_0.getVertexSize());
               $$2.lastVertexBuffer = pc7118fe5_2_1;
            }
         } else {
            int $$3 = GlStateManager._glGenVertexArrays();
            GlStateManager._glBindVertexArray($$3);
            if (pc7118fe5_2_1 != null) {
               List<VertexFormatElement> $$4 = pc7118fe5_1_0.getElements();

               for (int $$5 = 0; $$5 < $$4.size(); $$5++) {
                  VertexFormatElement $$6 = $$4.get($$5);
                  GlStateManager._enableVertexAttribArray($$5);
                  switch ($$6.usage()) {
                     case POSITION:
                     case GENERIC:
                     case UV:
                        if ($$6.type() == VertexFormatElement.Type.FLOAT) {
                           ARBVertexAttribBinding.glVertexAttribFormat($$5, $$6.count(), GlConst.toGl($$6.type()), false, pc7118fe5_1_0.getOffset($$6));
                        } else {
                           ARBVertexAttribBinding.glVertexAttribIFormat($$5, $$6.count(), GlConst.toGl($$6.type()), pc7118fe5_1_0.getOffset($$6));
                        }
                        break;
                     case NORMAL:
                     case COLOR:
                        ARBVertexAttribBinding.glVertexAttribFormat($$5, $$6.count(), GlConst.toGl($$6.type()), true, pc7118fe5_1_0.getOffset($$6));
                  }

                  ARBVertexAttribBinding.glVertexAttribBinding($$5, 0);
               }
            }

            if (pc7118fe5_2_1 != null) {
               ARBVertexAttribBinding.glBindVertexBuffer(0, pc7118fe5_2_1.handle, 0L, pc7118fe5_1_0.getVertexSize());
            }

            VertexArrayCache.VertexArray $$7 = new VertexArrayCache.VertexArray($$3, pc7118fe5_1_0, pc7118fe5_2_1);
            this.debugLabels.applyLabel($$7);
            this.cache.put(pc7118fe5_1_0, $$7);
         }
      }
   }

   public static class VertexArray {
      final int id;
      final VertexFormat format;
      @Nullable GlBuffer lastVertexBuffer;

      VertexArray(int pe66cdb13_0_0, VertexFormat pe66cdb13_1_1, @Nullable GlBuffer pe66cdb13_2_2) {
         this.id = pe66cdb13_0_0;
         this.format = pe66cdb13_1_1;
         this.lastVertexBuffer = pe66cdb13_2_2;
      }
   }
}
