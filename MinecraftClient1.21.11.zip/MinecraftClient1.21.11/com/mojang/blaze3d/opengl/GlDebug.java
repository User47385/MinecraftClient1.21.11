package com.mojang.blaze3d.opengl;

import com.google.common.collect.EvictingQueue;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.mojang.blaze3d.platform.DebugMemoryUntracker;
import com.mojang.blaze3d.platform.GLX;
import com.mojang.logging.LogUtils;
import java.util.HexFormat;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import org.jspecify.annotations.Nullable;
import org.lwjgl.opengl.ARBDebugOutput;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLCapabilities;
import org.lwjgl.opengl.GLDebugMessageARBCallback;
import org.lwjgl.opengl.GLDebugMessageCallback;
import org.lwjgl.opengl.KHRDebug;
import org.slf4j.Logger;

public class GlDebug {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final int CIRCULAR_LOG_SIZE = 10;
   private final Queue<GlDebug.LogEntry> MESSAGE_BUFFER = EvictingQueue.create(10);
   private volatile GlDebug.@Nullable LogEntry lastEntry;
   private static final List<Integer> DEBUG_LEVELS = ImmutableList.of(37190, 37191, 37192, 33387);
   private static final List<Integer> DEBUG_LEVELS_ARB = ImmutableList.of(37190, 37191, 37192);

   private static String printUnknownToken(int p6ecb9c79_0_0) {
      return "Unknown (0x" + HexFormat.of().withUpperCase().toHexDigits(p6ecb9c79_0_0) + ")";
   }

   public static String sourceToString(int p6ecb9c79_1_0) {
      switch (p6ecb9c79_1_0) {
         case 33350:
            return "API";
         case 33351:
            return "WINDOW SYSTEM";
         case 33352:
            return "SHADER COMPILER";
         case 33353:
            return "THIRD PARTY";
         case 33354:
            return "APPLICATION";
         case 33355:
            return "OTHER";
         default:
            return printUnknownToken(p6ecb9c79_1_0);
      }
   }

   public static String typeToString(int p6ecb9c79_2_0) {
      switch (p6ecb9c79_2_0) {
         case 33356:
            return "ERROR";
         case 33357:
            return "DEPRECATED BEHAVIOR";
         case 33358:
            return "UNDEFINED BEHAVIOR";
         case 33359:
            return "PORTABILITY";
         case 33360:
            return "PERFORMANCE";
         case 33361:
            return "OTHER";
         case 33384:
            return "MARKER";
         default:
            return printUnknownToken(p6ecb9c79_2_0);
      }
   }

   public static String severityToString(int p6ecb9c79_3_0) {
      switch (p6ecb9c79_3_0) {
         case 33387:
            return "NOTIFICATION";
         case 37190:
            return "HIGH";
         case 37191:
            return "MEDIUM";
         case 37192:
            return "LOW";
         default:
            return printUnknownToken(p6ecb9c79_3_0);
      }
   }

   private void printDebugLog(
      int p6ecb9c79_4_0, int p6ecb9c79_5_1, int p6ecb9c79_6_2, int p6ecb9c79_7_3, int p6ecb9c79_8_4, long p6ecb9c79_9_5, long p6ecb9c79_10_6
   ) {
      String $$7 = GLDebugMessageCallback.getMessage(p6ecb9c79_8_4, p6ecb9c79_9_5);
      GlDebug.LogEntry $$8;
      synchronized (this.MESSAGE_BUFFER) {
         $$8 = this.lastEntry;
         if ($$8 != null && $$8.isSame(p6ecb9c79_4_0, p6ecb9c79_5_1, p6ecb9c79_6_2, p6ecb9c79_7_3, $$7)) {
            $$8.count++;
         } else {
            $$8 = new GlDebug.LogEntry(p6ecb9c79_4_0, p6ecb9c79_5_1, p6ecb9c79_6_2, p6ecb9c79_7_3, $$7);
            this.MESSAGE_BUFFER.add($$8);
            this.lastEntry = $$8;
         }
      }

      LOGGER.info("OpenGL debug message: {}", $$8);
   }

   public List<String> getLastOpenGlDebugMessages() {
      synchronized (this.MESSAGE_BUFFER) {
         List<String> $$0 = Lists.newArrayListWithCapacity(this.MESSAGE_BUFFER.size());

         for (GlDebug.LogEntry $$1 : this.MESSAGE_BUFFER) {
            $$0.add($$1 + " x " + $$1.count);
         }

         return $$0;
      }
   }

   public static @Nullable GlDebug enableDebugCallback(int p6ecb9c79_11_0, boolean p6ecb9c79_12_1, Set<String> p6ecb9c79_13_2) {
      if (p6ecb9c79_11_0 <= 0) {
         return null;
      }

      GLCapabilities $$3 = GL.getCapabilities();
      if ($$3.GL_KHR_debug && GlDevice.USE_GL_KHR_debug) {
         GlDebug $$4 = new GlDebug();
         p6ecb9c79_13_2.add("GL_KHR_debug");
         GL11.glEnable(37600);
         if (p6ecb9c79_12_1) {
            GL11.glEnable(33346);
         }

         for (int $$5 = 0; $$5 < DEBUG_LEVELS.size(); $$5++) {
            boolean $$6 = $$5 < p6ecb9c79_11_0;
            KHRDebug.glDebugMessageControl(4352, 4352, DEBUG_LEVELS.get($$5), (int[])null, $$6);
         }

         KHRDebug.glDebugMessageCallback(GLX.make(GLDebugMessageCallback.create($$4::printDebugLog), DebugMemoryUntracker::untrack), 0L);
         return $$4;
      } else if ($$3.GL_ARB_debug_output && GlDevice.USE_GL_ARB_debug_output) {
         GlDebug $$7 = new GlDebug();
         p6ecb9c79_13_2.add("GL_ARB_debug_output");
         if (p6ecb9c79_12_1) {
            GL11.glEnable(33346);
         }

         for (int $$8 = 0; $$8 < DEBUG_LEVELS_ARB.size(); $$8++) {
            boolean $$9 = $$8 < p6ecb9c79_11_0;
            ARBDebugOutput.glDebugMessageControlARB(4352, 4352, DEBUG_LEVELS_ARB.get($$8), (int[])null, $$9);
         }

         ARBDebugOutput.glDebugMessageCallbackARB(GLX.make(GLDebugMessageARBCallback.create($$7::printDebugLog), DebugMemoryUntracker::untrack), 0L);
         return $$7;
      } else {
         return null;
      }
   }

   static class LogEntry {
      private final int id;
      private final int source;
      private final int type;
      private final int severity;
      private final String message;
      int count = 1;

      LogEntry(int p914a3b79_0_0, int p914a3b79_1_1, int p914a3b79_2_2, int p914a3b79_3_3, String p914a3b79_4_4) {
         this.id = p914a3b79_2_2;
         this.source = p914a3b79_0_0;
         this.type = p914a3b79_1_1;
         this.severity = p914a3b79_3_3;
         this.message = p914a3b79_4_4;
      }

      boolean isSame(int p914a3b79_5_0, int p914a3b79_6_1, int p914a3b79_7_2, int p914a3b79_8_3, String p914a3b79_9_4) {
         return p914a3b79_6_1 == this.type
            && p914a3b79_5_0 == this.source
            && p914a3b79_7_2 == this.id
            && p914a3b79_8_3 == this.severity
            && p914a3b79_9_4.equals(this.message);
      }

      @Override
      public String toString() {
         return "id="
            + this.id
            + ", source="
            + GlDebug.sourceToString(this.source)
            + ", type="
            + GlDebug.typeToString(this.type)
            + ", severity="
            + GlDebug.severityToString(this.severity)
            + ", message='"
            + this.message
            + "'";
      }
   }
}
