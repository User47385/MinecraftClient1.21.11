package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.GraphicsWorkarounds;
import com.mojang.blaze3d.buffers.GpuBuffer;
import java.nio.ByteBuffer;
import java.util.Set;
import org.jspecify.annotations.Nullable;
import org.lwjgl.opengl.ARBBufferStorage;
import org.lwjgl.opengl.ARBDirectStateAccess;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GLCapabilities;

public abstract class DirectStateAccess {
   public static DirectStateAccess create(GLCapabilities p825e0ff7_0_0, Set<String> p825e0ff7_1_1, GraphicsWorkarounds p825e0ff7_2_2) {
      if (p825e0ff7_0_0.GL_ARB_direct_state_access && GlDevice.USE_GL_ARB_direct_state_access && !p825e0ff7_2_2.isGlOnDx12()) {
         p825e0ff7_1_1.add("GL_ARB_direct_state_access");
         return new DirectStateAccess.Core();
      } else {
         return new DirectStateAccess.Emulated();
      }
   }

   abstract int createBuffer();

   abstract void bufferData(int var1, long var2, @GpuBuffer.Usage int var4);

   abstract void bufferData(int var1, ByteBuffer var2, @GpuBuffer.Usage int var3);

   abstract void bufferSubData(int var1, long var2, ByteBuffer var4, @GpuBuffer.Usage int var5);

   abstract void bufferStorage(int var1, long var2, @GpuBuffer.Usage int var4);

   abstract void bufferStorage(int var1, ByteBuffer var2, @GpuBuffer.Usage int var3);

   abstract @Nullable ByteBuffer mapBufferRange(int var1, long var2, long var4, int var6, @GpuBuffer.Usage int var7);

   abstract void unmapBuffer(int var1, @GpuBuffer.Usage int var2);

   abstract int createFrameBufferObject();

   abstract void bindFrameBufferTextures(int var1, int var2, int var3, int var4, int var5);

   abstract void blitFrameBuffers(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12);

   abstract void flushMappedBufferRange(int var1, long var2, long var4, @GpuBuffer.Usage int var6);

   abstract void copyBufferSubData(int var1, int var2, long var3, long var5, long var7);

   static class Core extends DirectStateAccess {
      @Override
      int createBuffer() {
         GlStateManager.incrementTrackedBuffers();
         return ARBDirectStateAccess.glCreateBuffers();
      }

      @Override
      void bufferData(int p88abc44c_0_0, long p88abc44c_1_1, @GpuBuffer.Usage int p88abc44c_2_2) {
         ARBDirectStateAccess.glNamedBufferData(p88abc44c_0_0, p88abc44c_1_1, GlConst.bufferUsageToGlEnum(p88abc44c_2_2));
      }

      @Override
      void bufferData(int p88abc44c_3_0, ByteBuffer p88abc44c_4_1, @GpuBuffer.Usage int p88abc44c_5_2) {
         ARBDirectStateAccess.glNamedBufferData(p88abc44c_3_0, p88abc44c_4_1, GlConst.bufferUsageToGlEnum(p88abc44c_5_2));
      }

      @Override
      void bufferSubData(int p88abc44c_6_0, long p88abc44c_7_1, ByteBuffer p88abc44c_8_2, @GpuBuffer.Usage int p88abc44c_9_3) {
         ARBDirectStateAccess.glNamedBufferSubData(p88abc44c_6_0, p88abc44c_7_1, p88abc44c_8_2);
      }

      @Override
      void bufferStorage(int p88abc44c_10_0, long p88abc44c_11_1, @GpuBuffer.Usage int p88abc44c_12_2) {
         ARBDirectStateAccess.glNamedBufferStorage(p88abc44c_10_0, p88abc44c_11_1, GlConst.bufferUsageToGlFlag(p88abc44c_12_2));
      }

      @Override
      void bufferStorage(int p88abc44c_13_0, ByteBuffer p88abc44c_14_1, @GpuBuffer.Usage int p88abc44c_15_2) {
         ARBDirectStateAccess.glNamedBufferStorage(p88abc44c_13_0, p88abc44c_14_1, GlConst.bufferUsageToGlFlag(p88abc44c_15_2));
      }

      @Override
      @Nullable ByteBuffer mapBufferRange(int p88abc44c_16_0, long p88abc44c_17_1, long p88abc44c_18_2, int p88abc44c_19_3, @GpuBuffer.Usage int p88abc44c_20_4) {
         return ARBDirectStateAccess.glMapNamedBufferRange(p88abc44c_16_0, p88abc44c_17_1, p88abc44c_18_2, p88abc44c_19_3);
      }

      @Override
      void unmapBuffer(int p88abc44c_21_0, int p88abc44c_22_1) {
         ARBDirectStateAccess.glUnmapNamedBuffer(p88abc44c_21_0);
      }

      @Override
      public int createFrameBufferObject() {
         return ARBDirectStateAccess.glCreateFramebuffers();
      }

      @Override
      public void bindFrameBufferTextures(int p88abc44c_23_0, int p88abc44c_24_1, int p88abc44c_25_2, int p88abc44c_26_3, @GpuBuffer.Usage int p88abc44c_27_4) {
         ARBDirectStateAccess.glNamedFramebufferTexture(p88abc44c_23_0, 36064, p88abc44c_24_1, p88abc44c_26_3);
         ARBDirectStateAccess.glNamedFramebufferTexture(p88abc44c_23_0, 36096, p88abc44c_25_2, p88abc44c_26_3);
         if (p88abc44c_27_4 != 0) {
            GlStateManager._glBindFramebuffer(p88abc44c_27_4, p88abc44c_23_0);
         }
      }

      @Override
      public void blitFrameBuffers(
         int p88abc44c_28_0,
         int p88abc44c_29_1,
         int p88abc44c_30_2,
         int p88abc44c_31_3,
         int p88abc44c_32_4,
         int p88abc44c_33_5,
         int p88abc44c_34_6,
         int p88abc44c_35_7,
         int p88abc44c_36_8,
         int p88abc44c_37_9,
         int p88abc44c_38_10,
         int p88abc44c_39_11
      ) {
         ARBDirectStateAccess.glBlitNamedFramebuffer(
            p88abc44c_28_0,
            p88abc44c_29_1,
            p88abc44c_30_2,
            p88abc44c_31_3,
            p88abc44c_32_4,
            p88abc44c_33_5,
            p88abc44c_34_6,
            p88abc44c_35_7,
            p88abc44c_36_8,
            p88abc44c_37_9,
            p88abc44c_38_10,
            p88abc44c_39_11
         );
      }

      @Override
      void flushMappedBufferRange(int p88abc44c_40_0, long p88abc44c_41_1, long p88abc44c_42_2, @GpuBuffer.Usage int p88abc44c_43_3) {
         ARBDirectStateAccess.glFlushMappedNamedBufferRange(p88abc44c_40_0, p88abc44c_41_1, p88abc44c_42_2);
      }

      @Override
      void copyBufferSubData(int p88abc44c_44_0, int p88abc44c_45_1, long p88abc44c_46_2, long p88abc44c_47_3, long p88abc44c_48_4) {
         ARBDirectStateAccess.glCopyNamedBufferSubData(p88abc44c_44_0, p88abc44c_45_1, p88abc44c_46_2, p88abc44c_47_3, p88abc44c_48_4);
      }
   }

   static class Emulated extends DirectStateAccess {
      private int selectBufferBindTarget(@GpuBuffer.Usage int p74fda7fe_0_0) {
         if ((p74fda7fe_0_0 & 32) != 0) {
            return 34962;
         } else if ((p74fda7fe_0_0 & 64) != 0) {
            return 34963;
         } else {
            return (p74fda7fe_0_0 & 128) != 0 ? 35345 : 36663;
         }
      }

      @Override
      int createBuffer() {
         return GlStateManager._glGenBuffers();
      }

      @Override
      void bufferData(int p74fda7fe_1_0, long p74fda7fe_2_1, @GpuBuffer.Usage int p74fda7fe_3_2) {
         int $$3 = this.selectBufferBindTarget(p74fda7fe_3_2);
         GlStateManager._glBindBuffer($$3, p74fda7fe_1_0);
         GlStateManager._glBufferData($$3, p74fda7fe_2_1, GlConst.bufferUsageToGlEnum(p74fda7fe_3_2));
         GlStateManager._glBindBuffer($$3, 0);
      }

      @Override
      void bufferData(int p74fda7fe_4_0, ByteBuffer p74fda7fe_5_1, @GpuBuffer.Usage int p74fda7fe_6_2) {
         int $$3 = this.selectBufferBindTarget(p74fda7fe_6_2);
         GlStateManager._glBindBuffer($$3, p74fda7fe_4_0);
         GlStateManager._glBufferData($$3, p74fda7fe_5_1, GlConst.bufferUsageToGlEnum(p74fda7fe_6_2));
         GlStateManager._glBindBuffer($$3, 0);
      }

      @Override
      void bufferSubData(int p74fda7fe_7_0, long p74fda7fe_8_1, ByteBuffer p74fda7fe_9_2, @GpuBuffer.Usage int p74fda7fe_10_3) {
         int $$4 = this.selectBufferBindTarget(p74fda7fe_10_3);
         GlStateManager._glBindBuffer($$4, p74fda7fe_7_0);
         GlStateManager._glBufferSubData($$4, p74fda7fe_8_1, p74fda7fe_9_2);
         GlStateManager._glBindBuffer($$4, 0);
      }

      @Override
      void bufferStorage(int p74fda7fe_11_0, long p74fda7fe_12_1, @GpuBuffer.Usage int p74fda7fe_13_2) {
         int $$3 = this.selectBufferBindTarget(p74fda7fe_13_2);
         GlStateManager._glBindBuffer($$3, p74fda7fe_11_0);
         ARBBufferStorage.glBufferStorage($$3, p74fda7fe_12_1, GlConst.bufferUsageToGlFlag(p74fda7fe_13_2));
         GlStateManager._glBindBuffer($$3, 0);
      }

      @Override
      void bufferStorage(int p74fda7fe_14_0, ByteBuffer p74fda7fe_15_1, @GpuBuffer.Usage int p74fda7fe_16_2) {
         int $$3 = this.selectBufferBindTarget(p74fda7fe_16_2);
         GlStateManager._glBindBuffer($$3, p74fda7fe_14_0);
         ARBBufferStorage.glBufferStorage($$3, p74fda7fe_15_1, GlConst.bufferUsageToGlFlag(p74fda7fe_16_2));
         GlStateManager._glBindBuffer($$3, 0);
      }

      @Override
      @Nullable ByteBuffer mapBufferRange(int p74fda7fe_17_0, long p74fda7fe_18_1, long p74fda7fe_19_2, int p74fda7fe_20_3, @GpuBuffer.Usage int p74fda7fe_21_4) {
         int $$5 = this.selectBufferBindTarget(p74fda7fe_21_4);
         GlStateManager._glBindBuffer($$5, p74fda7fe_17_0);
         ByteBuffer $$6 = GlStateManager._glMapBufferRange($$5, p74fda7fe_18_1, p74fda7fe_19_2, p74fda7fe_20_3);
         GlStateManager._glBindBuffer($$5, 0);
         return $$6;
      }

      @Override
      void unmapBuffer(int p74fda7fe_22_0, @GpuBuffer.Usage int p74fda7fe_23_1) {
         int $$2 = this.selectBufferBindTarget(p74fda7fe_23_1);
         GlStateManager._glBindBuffer($$2, p74fda7fe_22_0);
         GlStateManager._glUnmapBuffer($$2);
         GlStateManager._glBindBuffer($$2, 0);
      }

      @Override
      void flushMappedBufferRange(int p74fda7fe_24_0, long p74fda7fe_25_1, long p74fda7fe_26_2, @GpuBuffer.Usage int p74fda7fe_27_3) {
         int $$4 = this.selectBufferBindTarget(p74fda7fe_27_3);
         GlStateManager._glBindBuffer($$4, p74fda7fe_24_0);
         GL30.glFlushMappedBufferRange($$4, p74fda7fe_25_1, p74fda7fe_26_2);
         GlStateManager._glBindBuffer($$4, 0);
      }

      @Override
      void copyBufferSubData(int p74fda7fe_28_0, int p74fda7fe_29_1, long p74fda7fe_30_2, long p74fda7fe_31_3, long p74fda7fe_32_4) {
         GlStateManager._glBindBuffer(36662, p74fda7fe_28_0);
         GlStateManager._glBindBuffer(36663, p74fda7fe_29_1);
         GL31.glCopyBufferSubData(36662, 36663, p74fda7fe_30_2, p74fda7fe_31_3, p74fda7fe_32_4);
         GlStateManager._glBindBuffer(36662, 0);
         GlStateManager._glBindBuffer(36663, 0);
      }

      @Override
      public int createFrameBufferObject() {
         return GlStateManager.glGenFramebuffers();
      }

      @Override
      public void bindFrameBufferTextures(int p74fda7fe_33_0, int p74fda7fe_34_1, int p74fda7fe_35_2, int p74fda7fe_36_3, int p74fda7fe_37_4) {
         int $$5 = p74fda7fe_37_4 == 0 ? 36009 : p74fda7fe_37_4;
         int $$6 = GlStateManager.getFrameBuffer($$5);
         GlStateManager._glBindFramebuffer($$5, p74fda7fe_33_0);
         GlStateManager._glFramebufferTexture2D($$5, 36064, 3553, p74fda7fe_34_1, p74fda7fe_36_3);
         GlStateManager._glFramebufferTexture2D($$5, 36096, 3553, p74fda7fe_35_2, p74fda7fe_36_3);
         if (p74fda7fe_37_4 == 0) {
            GlStateManager._glBindFramebuffer($$5, $$6);
         }
      }

      @Override
      public void blitFrameBuffers(
         int p74fda7fe_38_0,
         int p74fda7fe_39_1,
         int p74fda7fe_40_2,
         int p74fda7fe_41_3,
         int p74fda7fe_42_4,
         int p74fda7fe_43_5,
         int p74fda7fe_44_6,
         int p74fda7fe_45_7,
         int p74fda7fe_46_8,
         int p74fda7fe_47_9,
         int p74fda7fe_48_10,
         int p74fda7fe_49_11
      ) {
         int $$12 = GlStateManager.getFrameBuffer(36008);
         int $$13 = GlStateManager.getFrameBuffer(36009);
         GlStateManager._glBindFramebuffer(36008, p74fda7fe_38_0);
         GlStateManager._glBindFramebuffer(36009, p74fda7fe_39_1);
         GlStateManager._glBlitFrameBuffer(
            p74fda7fe_40_2,
            p74fda7fe_41_3,
            p74fda7fe_42_4,
            p74fda7fe_43_5,
            p74fda7fe_44_6,
            p74fda7fe_45_7,
            p74fda7fe_46_8,
            p74fda7fe_47_9,
            p74fda7fe_48_10,
            p74fda7fe_49_11
         );
         GlStateManager._glBindFramebuffer(36008, $$12);
         GlStateManager._glBindFramebuffer(36009, $$13);
      }
   }
}
