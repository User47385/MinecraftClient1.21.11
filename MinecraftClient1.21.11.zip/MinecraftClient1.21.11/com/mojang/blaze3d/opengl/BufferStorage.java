package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.buffers.GpuBuffer;
import java.nio.ByteBuffer;
import java.util.Set;
import java.util.function.Supplier;
import org.jspecify.annotations.Nullable;
import org.lwjgl.opengl.GLCapabilities;
import org.lwjgl.system.MemoryUtil;

public abstract class BufferStorage {
   public static BufferStorage create(GLCapabilities pbe4245e6_0_0, Set<String> pbe4245e6_1_1) {
      if (pbe4245e6_0_0.GL_ARB_buffer_storage && GlDevice.USE_GL_ARB_buffer_storage) {
         pbe4245e6_1_1.add("GL_ARB_buffer_storage");
         return new BufferStorage.Immutable();
      } else {
         return new BufferStorage.Mutable();
      }
   }

   public abstract GlBuffer createBuffer(DirectStateAccess var1, @Nullable Supplier<String> var2, @GpuBuffer.Usage int var3, long var4);

   public abstract GlBuffer createBuffer(DirectStateAccess var1, @Nullable Supplier<String> var2, @GpuBuffer.Usage int var3, ByteBuffer var4);

   public abstract GlBuffer.GlMappedView mapBuffer(DirectStateAccess var1, GlBuffer var2, long var3, long var5, int var7);

   static class Immutable extends BufferStorage {
      @Override
      public GlBuffer createBuffer(
         DirectStateAccess pee5ec024_0_0, @Nullable Supplier<String> pee5ec024_1_1, @GpuBuffer.Usage int pee5ec024_2_2, long pee5ec024_3_3
      ) {
         int $$4 = pee5ec024_0_0.createBuffer();
         pee5ec024_0_0.bufferStorage($$4, pee5ec024_3_3, pee5ec024_2_2);
         ByteBuffer $$5 = this.tryMapBufferPersistent(pee5ec024_0_0, pee5ec024_2_2, $$4, pee5ec024_3_3);
         return new GlBuffer(pee5ec024_1_1, pee5ec024_0_0, pee5ec024_2_2, pee5ec024_3_3, $$4, $$5);
      }

      @Override
      public GlBuffer createBuffer(
         DirectStateAccess pee5ec024_4_0, @Nullable Supplier<String> pee5ec024_5_1, @GpuBuffer.Usage int pee5ec024_6_2, ByteBuffer pee5ec024_7_3
      ) {
         int $$4 = pee5ec024_4_0.createBuffer();
         int $$5 = pee5ec024_7_3.remaining();
         pee5ec024_4_0.bufferStorage($$4, pee5ec024_7_3, pee5ec024_6_2);
         ByteBuffer $$6 = this.tryMapBufferPersistent(pee5ec024_4_0, pee5ec024_6_2, $$4, $$5);
         return new GlBuffer(pee5ec024_5_1, pee5ec024_4_0, pee5ec024_6_2, $$5, $$4, $$6);
      }

      private @Nullable ByteBuffer tryMapBufferPersistent(
         DirectStateAccess pee5ec024_8_0, @GpuBuffer.Usage int pee5ec024_9_1, int pee5ec024_10_2, long pee5ec024_11_3
      ) {
         int $$4 = 0;
         if ((pee5ec024_9_1 & 1) != 0) {
            $$4 |= 1;
         }

         if ((pee5ec024_9_1 & 2) != 0) {
            $$4 |= 18;
         }

         ByteBuffer $$5;
         if ($$4 != 0) {
            GlStateManager.clearGlErrors();
            $$5 = pee5ec024_8_0.mapBufferRange(pee5ec024_10_2, 0L, pee5ec024_11_3, $$4 | 64, pee5ec024_9_1);
            if ($$5 == null) {
               throw new IllegalStateException("Can't persistently map buffer, opengl error " + GlStateManager._getError());
            }
         } else {
            $$5 = null;
         }

         return $$5;
      }

      @Override
      public GlBuffer.GlMappedView mapBuffer(
         DirectStateAccess pee5ec024_12_0, GlBuffer pee5ec024_13_1, long pee5ec024_14_2, long pee5ec024_15_3, int pee5ec024_16_4
      ) {
         if (pee5ec024_13_1.persistentBuffer == null) {
            throw new IllegalStateException("Somehow trying to map an unmappable buffer");
         } else if (pee5ec024_14_2 > 2147483647L || pee5ec024_15_3 > 2147483647L) {
            throw new IllegalArgumentException("Mapping buffers larger than 2GB is not supported");
         } else if (pee5ec024_14_2 >= 0L && pee5ec024_15_3 >= 0L) {
            return new GlBuffer.GlMappedView(() -> {
               if ((pee5ec024_16_4 & 2) != 0) {
                  pee5ec024_12_0.flushMappedBufferRange(pee5ec024_13_1.handle, pee5ec024_14_2, pee5ec024_15_3, pee5ec024_13_1.usage());
               }
            }, pee5ec024_13_1, MemoryUtil.memSlice(pee5ec024_13_1.persistentBuffer, (int)pee5ec024_14_2, (int)pee5ec024_15_3));
         } else {
            throw new IllegalArgumentException("Offset or length must be positive integer values");
         }
      }
   }

   static class Mutable extends BufferStorage {
      @Override
      public GlBuffer createBuffer(
         DirectStateAccess p56ca5e48_0_0, @Nullable Supplier<String> p56ca5e48_1_1, @GpuBuffer.Usage int p56ca5e48_2_2, long p56ca5e48_3_3
      ) {
         int $$4 = p56ca5e48_0_0.createBuffer();
         p56ca5e48_0_0.bufferData($$4, p56ca5e48_3_3, p56ca5e48_2_2);
         return new GlBuffer(p56ca5e48_1_1, p56ca5e48_0_0, p56ca5e48_2_2, p56ca5e48_3_3, $$4, null);
      }

      @Override
      public GlBuffer createBuffer(
         DirectStateAccess p56ca5e48_4_0, @Nullable Supplier<String> p56ca5e48_5_1, @GpuBuffer.Usage int p56ca5e48_6_2, ByteBuffer p56ca5e48_7_3
      ) {
         int $$4 = p56ca5e48_4_0.createBuffer();
         int $$5 = p56ca5e48_7_3.remaining();
         p56ca5e48_4_0.bufferData($$4, p56ca5e48_7_3, p56ca5e48_6_2);
         return new GlBuffer(p56ca5e48_5_1, p56ca5e48_4_0, p56ca5e48_6_2, $$5, $$4, null);
      }

      @Override
      public GlBuffer.GlMappedView mapBuffer(
         DirectStateAccess p56ca5e48_8_0, GlBuffer p56ca5e48_9_1, long p56ca5e48_10_2, long p56ca5e48_11_3, int p56ca5e48_12_4
      ) {
         GlStateManager.clearGlErrors();
         ByteBuffer $$5 = p56ca5e48_8_0.mapBufferRange(p56ca5e48_9_1.handle, p56ca5e48_10_2, p56ca5e48_11_3, p56ca5e48_12_4, p56ca5e48_9_1.usage());
         if ($$5 == null) {
            throw new IllegalStateException("Can't map buffer, opengl error " + GlStateManager._getError());
         } else {
            return new GlBuffer.GlMappedView(() -> p56ca5e48_8_0.unmapBuffer(p56ca5e48_9_1.handle, p56ca5e48_9_1.usage()), p56ca5e48_9_1, $$5);
         }
      }
   }
}
