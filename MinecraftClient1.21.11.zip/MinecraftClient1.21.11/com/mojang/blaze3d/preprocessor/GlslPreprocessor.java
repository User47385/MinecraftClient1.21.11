package com.mojang.blaze3d.preprocessor;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.renderer.ShaderDefines;
import net.minecraft.util.FileUtil;
import net.minecraft.util.StringUtil;
import org.jspecify.annotations.Nullable;

public abstract class GlslPreprocessor {
   private static final String C_COMMENT = "/\\*(?:[^*]|\\*+[^*/])*\\*+/";
   private static final String LINE_COMMENT = "//[^\\v]*";
   private static final Pattern REGEX_MOJ_IMPORT = Pattern.compile(
      "(#(?:/\\*(?:[^*]|\\*+[^*/])*\\*+/|\\h)*moj_import(?:/\\*(?:[^*]|\\*+[^*/])*\\*+/|\\h)*(?:\"(.*)\"|<(.*)>))"
   );
   private static final Pattern REGEX_VERSION = Pattern.compile("(#(?:/\\*(?:[^*]|\\*+[^*/])*\\*+/|\\h)*version(?:/\\*(?:[^*]|\\*+[^*/])*\\*+/|\\h)*(\\d+))\\b");
   private static final Pattern REGEX_ENDS_WITH_WHITESPACE = Pattern.compile("(?:^|\\v)(?:\\s|/\\*(?:[^*]|\\*+[^*/])*\\*+/|(//[^\\v]*))*\\z");

   public List<String> process(String p8d004662_0_0) {
      GlslPreprocessor.Context $$1 = new GlslPreprocessor.Context();
      List<String> $$2 = this.processImports(p8d004662_0_0, $$1, "");
      $$2.set(0, this.setVersion($$2.get(0), $$1.glslVersion));
      return $$2;
   }

   private List<String> processImports(String p8d004662_1_0, GlslPreprocessor.Context p8d004662_2_1, String p8d004662_3_2) {
      int $$3 = p8d004662_2_1.sourceId;
      int $$4 = 0;
      String $$5 = "";
      List<String> $$6 = Lists.newArrayList();
      Matcher $$7 = REGEX_MOJ_IMPORT.matcher(p8d004662_1_0);

      while ($$7.find()) {
         if (!isDirectiveDisabled(p8d004662_1_0, $$7, $$4)) {
            String $$8 = $$7.group(2);
            boolean $$9 = $$8 != null;
            if (!$$9) {
               $$8 = $$7.group(3);
            }

            if ($$8 != null) {
               String $$10 = p8d004662_1_0.substring($$4, $$7.start(1));
               String $$11 = p8d004662_3_2 + $$8;
               String $$12 = this.applyImport($$9, $$11);
               if (!Strings.isNullOrEmpty($$12)) {
                  if (!StringUtil.endsWithNewLine($$12)) {
                     $$12 = $$12 + System.lineSeparator();
                  }

                  p8d004662_2_1.sourceId++;
                  int $$13 = p8d004662_2_1.sourceId;
                  List<String> $$14 = this.processImports($$12, p8d004662_2_1, $$9 ? FileUtil.getFullResourcePath($$11) : "");
                  $$14.set(0, String.format(Locale.ROOT, "#line %d %d\n%s", 0, $$13, this.processVersions($$14.get(0), p8d004662_2_1)));
                  if (!StringUtil.isBlank($$10)) {
                     $$6.add($$10);
                  }

                  $$6.addAll($$14);
               } else {
                  String $$15 = $$9 ? String.format(Locale.ROOT, "/*#moj_import \"%s\"*/", $$8) : String.format(Locale.ROOT, "/*#moj_import <%s>*/", $$8);
                  $$6.add($$5 + $$10 + $$15);
               }

               int $$16 = StringUtil.lineCount(p8d004662_1_0.substring(0, $$7.end(1)));
               $$5 = String.format(Locale.ROOT, "#line %d %d", $$16, $$3);
               $$4 = $$7.end(1);
            }
         }
      }

      String $$17 = p8d004662_1_0.substring($$4);
      if (!StringUtil.isBlank($$17)) {
         $$6.add($$5 + $$17);
      }

      return $$6;
   }

   private String processVersions(String p8d004662_4_0, GlslPreprocessor.Context p8d004662_5_1) {
      Matcher $$2 = REGEX_VERSION.matcher(p8d004662_4_0);
      if ($$2.find() && isDirectiveEnabled(p8d004662_4_0, $$2)) {
         p8d004662_5_1.glslVersion = Math.max(p8d004662_5_1.glslVersion, Integer.parseInt($$2.group(2)));
         return p8d004662_4_0.substring(0, $$2.start(1))
            + "/*"
            + p8d004662_4_0.substring($$2.start(1), $$2.end(1))
            + "*/"
            + p8d004662_4_0.substring($$2.end(1));
      } else {
         return p8d004662_4_0;
      }
   }

   private String setVersion(String p8d004662_6_0, int p8d004662_7_1) {
      Matcher $$2 = REGEX_VERSION.matcher(p8d004662_6_0);
      return $$2.find() && isDirectiveEnabled(p8d004662_6_0, $$2)
         ? p8d004662_6_0.substring(0, $$2.start(2)) + Math.max(p8d004662_7_1, Integer.parseInt($$2.group(2))) + p8d004662_6_0.substring($$2.end(2))
         : p8d004662_6_0;
   }

   private static boolean isDirectiveEnabled(String p8d004662_8_0, Matcher p8d004662_9_1) {
      return !isDirectiveDisabled(p8d004662_8_0, p8d004662_9_1, 0);
   }

   private static boolean isDirectiveDisabled(String p8d004662_10_0, Matcher p8d004662_11_1, int p8d004662_12_2) {
      int $$3 = p8d004662_11_1.start() - p8d004662_12_2;
      if ($$3 == 0) {
         return false;
      }

      Matcher $$4 = REGEX_ENDS_WITH_WHITESPACE.matcher(p8d004662_10_0.substring(p8d004662_12_2, p8d004662_11_1.start()));
      if (!$$4.find()) {
         return true;
      }

      int $$5 = $$4.end(1);
      return $$5 == p8d004662_11_1.start();
   }

   public abstract @Nullable String applyImport(boolean var1, String var2);

   public static String injectDefines(String p8d004662_13_0, ShaderDefines p8d004662_14_1) {
      if (p8d004662_14_1.isEmpty()) {
         return p8d004662_13_0;
      }

      int $$2 = p8d004662_13_0.indexOf(10);
      int $$3 = $$2 + 1;
      return p8d004662_13_0.substring(0, $$3) + p8d004662_14_1.asSourceDirectives() + "#line 1 0\n" + p8d004662_13_0.substring($$3);
   }

   static final class Context {
      int glslVersion;
      int sourceId;
   }
}
