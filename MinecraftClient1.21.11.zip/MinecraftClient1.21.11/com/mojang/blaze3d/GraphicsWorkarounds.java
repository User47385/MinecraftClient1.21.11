package com.mojang.blaze3d;

import com.mojang.blaze3d.platform.GLX;
import com.mojang.blaze3d.systems.GpuDevice;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Locale;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;

public class GraphicsWorkarounds {
   private static final List<String> INTEL_GEN11_CORE = List.of(
      "i3-1000g1",
      "i3-1000g4",
      "i3-1000ng4",
      "i3-1005g1",
      "i3-l13g4",
      "i5-1030g4",
      "i5-1030g7",
      "i5-1030ng7",
      "i5-1034g1",
      "i5-1035g1",
      "i5-1035g4",
      "i5-1035g7",
      "i5-1038ng7",
      "i5-l16g7",
      "i7-1060g7",
      "i7-1060ng7",
      "i7-1065g7",
      "i7-1068g7",
      "i7-1068ng7"
   );
   private static final List<String> INTEL_GEN11_ATOM = List.of("x6211e", "x6212re", "x6214re", "x6413e", "x6414re", "x6416re", "x6425e", "x6425re", "x6427fe");
   private static final List<String> INTEL_GEN11_CELERON = List.of("j6412", "j6413", "n4500", "n4505", "n5095", "n5095a", "n5100", "n5105", "n6210", "n6211");
   private static final List<String> INTEL_GEN11_PENTIUM = List.of("6805", "j6426", "n6415", "n6000", "n6005");
   private static @Nullable GraphicsWorkarounds instance;
   private final WeakReference<GpuDevice> gpuDevice;
   private final boolean alwaysCreateFreshImmediateBuffer;
   private final boolean isGlOnDx12;
   private final boolean isAmd;

   private GraphicsWorkarounds(GpuDevice p720c19bf_0_0) {
      this.gpuDevice = new WeakReference<>(p720c19bf_0_0);
      this.alwaysCreateFreshImmediateBuffer = isIntelGen11(p720c19bf_0_0);
      this.isGlOnDx12 = isGlOnDx12(p720c19bf_0_0);
      this.isAmd = isAmd(p720c19bf_0_0);
   }

   public static GraphicsWorkarounds get(GpuDevice p720c19bf_1_0) {
      GraphicsWorkarounds $$1 = instance;
      if ($$1 == null || $$1.gpuDevice.get() != p720c19bf_1_0) {
         instance = $$1 = new GraphicsWorkarounds(p720c19bf_1_0);
      }

      return $$1;
   }

   public boolean alwaysCreateFreshImmediateBuffer() {
      return this.alwaysCreateFreshImmediateBuffer;
   }

   public boolean isGlOnDx12() {
      return this.isGlOnDx12;
   }

   public boolean isAmd() {
      return this.isAmd;
   }

   private static boolean isIntelGen11(GpuDevice p720c19bf_2_0) {
      String $$1 = GLX._getCpuInfo().toLowerCase(Locale.ROOT);
      String $$2 = p720c19bf_2_0.getRenderer().toLowerCase(Locale.ROOT);
      if (!$$1.contains("intel") || !$$2.contains("intel") || $$2.contains("mesa")) {
         return false;
      } else if ($$2.endsWith("gen11")) {
         return true;
      } else {
         return !$$2.contains("uhd graphics") && !$$2.contains("iris")
            ? false
            : $$1.contains("atom") && INTEL_GEN11_ATOM.stream().anyMatch($$1::contains)
               || $$1.contains("celeron") && INTEL_GEN11_CELERON.stream().anyMatch($$1::contains)
               || $$1.contains("pentium") && INTEL_GEN11_PENTIUM.stream().anyMatch($$1::contains)
               || INTEL_GEN11_CORE.stream().anyMatch($$1::contains);
      }
   }

   private static boolean isGlOnDx12(GpuDevice p720c19bf_3_0) {
      boolean $$1 = Util.getPlatform() == Util.OS.WINDOWS && Util.isAarch64();
      return $$1 || p720c19bf_3_0.getRenderer().startsWith("D3D12");
   }

   private static boolean isAmd(GpuDevice p720c19bf_4_0) {
      return p720c19bf_4_0.getRenderer().contains("AMD");
   }
}
