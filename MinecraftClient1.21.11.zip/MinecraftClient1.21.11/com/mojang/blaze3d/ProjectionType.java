package com.mojang.blaze3d;

import com.mojang.blaze3d.vertex.VertexSorting;
import org.joml.Matrix4f;

public enum ProjectionType {
   PERSPECTIVE(VertexSorting.DISTANCE_TO_ORIGIN, (pda0517d4_9_0, pda0517d4_10_1) -> pda0517d4_9_0.scale(1.0F - pda0517d4_10_1 / 4096.0F)),
   ORTHOGRAPHIC(VertexSorting.ORTHOGRAPHIC_Z, (pda0517d4_7_0, pda0517d4_8_1) -> pda0517d4_7_0.translate(0.0F, 0.0F, pda0517d4_8_1 / 512.0F));

   private final VertexSorting vertexSorting;
   private final ProjectionType.LayeringTransform layeringTransform;

   ProjectionType(final VertexSorting pda0517d4_3_2, final ProjectionType.LayeringTransform pda0517d4_4_3) {
      this.vertexSorting = pda0517d4_3_2;
      this.layeringTransform = pda0517d4_4_3;
   }

   public VertexSorting vertexSorting() {
      return this.vertexSorting;
   }

   public void applyLayeringTransform(Matrix4f pda0517d4_5_0, float pda0517d4_6_1) {
      this.layeringTransform.apply(pda0517d4_5_0, pda0517d4_6_1);
   }

   @FunctionalInterface
   interface LayeringTransform {
      void apply(Matrix4f var1, float var2);
   }
}
