package net.minecraft.network;

import com.mojang.datafixers.DataFixUtils;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public interface HashedStack {
   HashedStack EMPTY = new HashedStack() {
      @Override
      public String toString() {
         return "<empty>";
      }

      @Override
      public boolean matches(ItemStack p885a093_0_0, HashedPatchMap.HashGenerator p885a093_1_1) {
         return p885a093_0_0.isEmpty();
      }
   };
   StreamCodec<RegistryFriendlyByteBuf, HashedStack> STREAM_CODEC = ByteBufCodecs.optional(HashedStack.ActualItem.STREAM_CODEC)
      .map(
         p2f28e586_3_0 -> DataFixUtils.orElse((Optional<? extends HashedStack>)p2f28e586_3_0, EMPTY),
         p2f28e586_2_0 -> p2f28e586_2_0 instanceof HashedStack.ActualItem $$1 ? Optional.of($$1) : Optional.empty()
      );

   boolean matches(ItemStack var1, HashedPatchMap.HashGenerator var2);

   static HashedStack create(ItemStack p2f28e586_0_0, HashedPatchMap.HashGenerator p2f28e586_1_1) {
      return p2f28e586_0_0.isEmpty()
         ? EMPTY
         : new HashedStack.ActualItem(
            p2f28e586_0_0.getItemHolder(), p2f28e586_0_0.getCount(), HashedPatchMap.create(p2f28e586_0_0.getComponentsPatch(), p2f28e586_1_1)
         );
   }

   record ActualItem(Holder<Item> item, int count, HashedPatchMap components) implements HashedStack {
      public static final StreamCodec<RegistryFriendlyByteBuf, HashedStack.ActualItem> STREAM_CODEC = StreamCodec.composite(
         ByteBufCodecs.holderRegistry(Registries.ITEM),
         HashedStack.ActualItem::item,
         ByteBufCodecs.VAR_INT,
         HashedStack.ActualItem::count,
         HashedPatchMap.STREAM_CODEC,
         HashedStack.ActualItem::components,
         HashedStack.ActualItem::new
      );

      @Override
      public boolean matches(ItemStack p6fe4abbf_3_0, HashedPatchMap.HashGenerator p6fe4abbf_4_1) {
         if (this.count != p6fe4abbf_3_0.getCount()) {
            return false;
         } else {
            return !this.item.equals(p6fe4abbf_3_0.getItemHolder()) ? false : this.components.matches(p6fe4abbf_3_0.getComponentsPatch(), p6fe4abbf_4_1);
         }
      }
   }
}
