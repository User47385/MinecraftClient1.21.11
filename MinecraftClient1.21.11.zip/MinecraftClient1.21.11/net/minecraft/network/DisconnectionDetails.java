package net.minecraft.network;

import java.net.URI;
import java.nio.file.Path;
import java.util.Optional;
import net.minecraft.network.chat.Component;

public record DisconnectionDetails(Component reason, Optional<Path> report, Optional<URI> bugReportLink) {
   public DisconnectionDetails(Component pb6f3deb_0_0) {
      this(pb6f3deb_0_0, Optional.empty(), Optional.empty());
   }
}
