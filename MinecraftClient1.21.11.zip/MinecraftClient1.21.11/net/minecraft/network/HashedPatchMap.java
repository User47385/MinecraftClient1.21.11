package net.minecraft.network;

import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.TypedDataComponent;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

public record HashedPatchMap(Map<DataComponentType<?>, Integer> addedComponents, Set<DataComponentType<?>> removedComponents) {
   public static final StreamCodec<RegistryFriendlyByteBuf, HashedPatchMap> STREAM_CODEC = StreamCodec.composite(
      ByteBufCodecs.map(HashMap::new, ByteBufCodecs.registry(Registries.DATA_COMPONENT_TYPE), ByteBufCodecs.INT, 256),
      HashedPatchMap::addedComponents,
      ByteBufCodecs.collection(HashSet::new, ByteBufCodecs.registry(Registries.DATA_COMPONENT_TYPE), 256),
      HashedPatchMap::removedComponents,
      HashedPatchMap::new
   );

   public static HashedPatchMap create(DataComponentPatch p3dfdc36_2_0, HashedPatchMap.HashGenerator p3dfdc36_3_1) {
      DataComponentPatch.SplitResult $$2 = p3dfdc36_2_0.split();
      Map<DataComponentType<?>, Integer> $$3 = new IdentityHashMap<>($$2.added().size());
      $$2.added().forEach(p3dfdc36_9_2 -> $$3.put(p3dfdc36_9_2.type(), p3dfdc36_3_1.apply((TypedDataComponent<?>)p3dfdc36_9_2)));
      return new HashedPatchMap($$3, $$2.removed());
   }

   public boolean matches(DataComponentPatch p3dfdc36_4_0, HashedPatchMap.HashGenerator p3dfdc36_5_1) {
      DataComponentPatch.SplitResult $$2 = p3dfdc36_4_0.split();
      if (!$$2.removed().equals(this.removedComponents)) {
         return false;
      }

      if (this.addedComponents.size() != $$2.added().size()) {
         return false;
      }

      for (TypedDataComponent<?> $$3 : $$2.added()) {
         Integer $$4 = this.addedComponents.get($$3.type());
         if ($$4 == null) {
            return false;
         }

         Integer $$5 = p3dfdc36_5_1.apply($$3);
         if (!$$5.equals($$4)) {
            return false;
         }
      }

      return true;
   }

   @FunctionalInterface
   public interface HashGenerator extends Function<TypedDataComponent<?>, Integer> {
   }
}
