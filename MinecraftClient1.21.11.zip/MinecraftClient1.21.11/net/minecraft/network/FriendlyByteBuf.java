package net.minecraft.network;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import io.netty.util.ByteProcessor;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.channels.GatheringByteChannel;
import java.nio.channels.ScatteringByteChannel;
import java.nio.charset.Charset;
import java.security.PublicKey;
import java.time.Instant;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collection;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.IntFunction;
import java.util.function.ToIntFunction;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.EndTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.Tag;
import net.minecraft.network.codec.StreamDecoder;
import net.minecraft.network.codec.StreamEncoder;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.Crypt;
import net.minecraft.util.CryptException;
import net.minecraft.util.LenientJsonParser;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.jspecify.annotations.Nullable;

public class FriendlyByteBuf extends ByteBuf {
   private final ByteBuf source;
   public static final short MAX_STRING_LENGTH = 32767;
   public static final int MAX_COMPONENT_STRING_LENGTH = 262144;
   private static final int PUBLIC_KEY_SIZE = 256;
   private static final int MAX_PUBLIC_KEY_HEADER_SIZE = 256;
   private static final int MAX_PUBLIC_KEY_LENGTH = 512;
   private static final Gson GSON = new Gson();

   public FriendlyByteBuf(ByteBuf p5dd544cb_0_0) {
      this.source = p5dd544cb_0_0;
   }

   @Deprecated
   public <T> T readWithCodecTrusted(DynamicOps<Tag> p5dd544cb_1_0, Codec<T> p5dd544cb_2_1) {
      return this.readWithCodec(p5dd544cb_1_0, p5dd544cb_2_1, NbtAccounter.unlimitedHeap());
   }

   @Deprecated
   public <T> T readWithCodec(DynamicOps<Tag> p5dd544cb_3_0, Codec<T> p5dd544cb_4_1, NbtAccounter p5dd544cb_5_2) {
      Tag $$3 = this.readNbt(p5dd544cb_5_2);
      return p5dd544cb_4_1.parse(p5dd544cb_3_0, $$3).getOrThrow(p5dd544cb_474_1 -> new DecoderException("Failed to decode: " + p5dd544cb_474_1 + " " + $$3));
   }

   @Deprecated
   public <T> FriendlyByteBuf writeWithCodec(DynamicOps<Tag> p5dd544cb_6_0, Codec<T> p5dd544cb_7_1, T p5dd544cb_8_2) {
      Tag $$3 = p5dd544cb_7_1.encodeStart(p5dd544cb_6_0, p5dd544cb_8_2)
         .getOrThrow(p5dd544cb_472_1 -> new EncoderException("Failed to encode: " + p5dd544cb_472_1 + " " + p5dd544cb_8_2));
      this.writeNbt($$3);
      return this;
   }

   public <T> T readLenientJsonWithCodec(Codec<T> p5dd544cb_9_0) {
      JsonElement $$1 = LenientJsonParser.parse(this.readUtf());
      DataResult<T> $$2 = p5dd544cb_9_0.parse(JsonOps.INSTANCE, $$1);
      return $$2.getOrThrow(p5dd544cb_470_0 -> new DecoderException("Failed to decode JSON: " + p5dd544cb_470_0));
   }

   public <T> void writeJsonWithCodec(Codec<T> p5dd544cb_10_0, T p5dd544cb_11_1) {
      DataResult<JsonElement> $$2 = p5dd544cb_10_0.encodeStart(JsonOps.INSTANCE, p5dd544cb_11_1);
      this.writeUtf(GSON.toJson($$2.getOrThrow(p5dd544cb_469_1 -> new EncoderException("Failed to encode: " + p5dd544cb_469_1 + " " + p5dd544cb_11_1))));
   }

   public static <T> IntFunction<T> limitValue(IntFunction<T> p5dd544cb_12_0, int p5dd544cb_13_1) {
      return p5dd544cb_467_2 -> {
         if (p5dd544cb_467_2 > p5dd544cb_13_1) {
            throw new DecoderException("Value " + p5dd544cb_467_2 + " is larger than limit " + p5dd544cb_13_1);
         } else {
            return p5dd544cb_12_0.apply(p5dd544cb_467_2);
         }
      };
   }

   public <T, C extends Collection<T>> C readCollection(IntFunction<C> p5dd544cb_14_0, StreamDecoder<? super FriendlyByteBuf, T> p5dd544cb_15_1) {
      int $$2 = this.readVarInt();
      C $$3 = (C)p5dd544cb_14_0.apply($$2);

      for (int $$4 = 0; $$4 < $$2; $$4++) {
         $$3.add(p5dd544cb_15_1.decode(this));
      }

      return $$3;
   }

   public <T> void writeCollection(Collection<T> p5dd544cb_16_0, StreamEncoder<? super FriendlyByteBuf, T> p5dd544cb_17_1) {
      this.writeVarInt(p5dd544cb_16_0.size());

      for (T $$2 : p5dd544cb_16_0) {
         p5dd544cb_17_1.encode(this, $$2);
      }
   }

   public <T> List<T> readList(StreamDecoder<? super FriendlyByteBuf, T> p5dd544cb_18_0) {
      return this.readCollection(Lists::newArrayListWithCapacity, p5dd544cb_18_0);
   }

   public IntList readIntIdList() {
      int $$0 = this.readVarInt();
      IntList $$1 = new IntArrayList();

      for (int $$2 = 0; $$2 < $$0; $$2++) {
         $$1.add(this.readVarInt());
      }

      return $$1;
   }

   public void writeIntIdList(IntList p5dd544cb_19_0) {
      this.writeVarInt(p5dd544cb_19_0.size());
      p5dd544cb_19_0.forEach(this::writeVarInt);
   }

   public <K, V, M extends Map<K, V>> M readMap(
      IntFunction<M> p5dd544cb_20_0, StreamDecoder<? super FriendlyByteBuf, K> p5dd544cb_21_1, StreamDecoder<? super FriendlyByteBuf, V> p5dd544cb_22_2
   ) {
      int $$3 = this.readVarInt();
      M $$4 = (M)p5dd544cb_20_0.apply($$3);

      for (int $$5 = 0; $$5 < $$3; $$5++) {
         K $$6 = p5dd544cb_21_1.decode(this);
         V $$7 = p5dd544cb_22_2.decode(this);
         $$4.put($$6, $$7);
      }

      return $$4;
   }

   public <K, V> Map<K, V> readMap(StreamDecoder<? super FriendlyByteBuf, K> p5dd544cb_23_0, StreamDecoder<? super FriendlyByteBuf, V> p5dd544cb_24_1) {
      return this.readMap(Maps::newHashMapWithExpectedSize, p5dd544cb_23_0, p5dd544cb_24_1);
   }

   public <K, V> void writeMap(
      Map<K, V> p5dd544cb_25_0, StreamEncoder<? super FriendlyByteBuf, K> p5dd544cb_26_1, StreamEncoder<? super FriendlyByteBuf, V> p5dd544cb_27_2
   ) {
      this.writeVarInt(p5dd544cb_25_0.size());
      p5dd544cb_25_0.forEach((p5dd544cb_463_2, p5dd544cb_464_3) -> {
         p5dd544cb_26_1.encode(this, (K)p5dd544cb_463_2);
         p5dd544cb_27_2.encode(this, (V)p5dd544cb_464_3);
      });
   }

   public void readWithCount(Consumer<FriendlyByteBuf> p5dd544cb_28_0) {
      int $$1 = this.readVarInt();

      for (int $$2 = 0; $$2 < $$1; $$2++) {
         p5dd544cb_28_0.accept(this);
      }
   }

   public <E extends Enum<E>> void writeEnumSet(EnumSet<E> p5dd544cb_29_0, Class<E> p5dd544cb_30_1) {
      E[] $$2 = (E[])p5dd544cb_30_1.getEnumConstants();
      BitSet $$3 = new BitSet($$2.length);

      for (int $$4 = 0; $$4 < $$2.length; $$4++) {
         $$3.set($$4, p5dd544cb_29_0.contains($$2[$$4]));
      }

      this.writeFixedBitSet($$3, $$2.length);
   }

   public <E extends Enum<E>> EnumSet<E> readEnumSet(Class<E> p5dd544cb_31_0) {
      E[] $$1 = (E[])p5dd544cb_31_0.getEnumConstants();
      BitSet $$2 = this.readFixedBitSet($$1.length);
      EnumSet<E> $$3 = EnumSet.noneOf(p5dd544cb_31_0);

      for (int $$4 = 0; $$4 < $$1.length; $$4++) {
         if ($$2.get($$4)) {
            $$3.add($$1[$$4]);
         }
      }

      return $$3;
   }

   public <T> void writeOptional(Optional<T> p5dd544cb_32_0, StreamEncoder<? super FriendlyByteBuf, T> p5dd544cb_33_1) {
      if (p5dd544cb_32_0.isPresent()) {
         this.writeBoolean(true);
         p5dd544cb_33_1.encode(this, p5dd544cb_32_0.get());
      } else {
         this.writeBoolean(false);
      }
   }

   public <T> Optional<T> readOptional(StreamDecoder<? super FriendlyByteBuf, T> p5dd544cb_34_0) {
      return this.readBoolean() ? Optional.of(p5dd544cb_34_0.decode(this)) : Optional.empty();
   }

   public <L, R> void writeEither(
      Either<L, R> p5dd544cb_35_0, StreamEncoder<? super FriendlyByteBuf, L> p5dd544cb_36_1, StreamEncoder<? super FriendlyByteBuf, R> p5dd544cb_37_2
   ) {
      p5dd544cb_35_0.ifLeft(p5dd544cb_460_1 -> {
         this.writeBoolean(true);
         p5dd544cb_36_1.encode(this, (L)p5dd544cb_460_1);
      }).ifRight(p5dd544cb_458_1 -> {
         this.writeBoolean(false);
         p5dd544cb_37_2.encode(this, (R)p5dd544cb_458_1);
      });
   }

   public <L, R> Either<L, R> readEither(StreamDecoder<? super FriendlyByteBuf, L> p5dd544cb_38_0, StreamDecoder<? super FriendlyByteBuf, R> p5dd544cb_39_1) {
      return this.readBoolean() ? Either.left(p5dd544cb_38_0.decode(this)) : Either.right(p5dd544cb_39_1.decode(this));
   }

   public <T> @Nullable T readNullable(StreamDecoder<? super FriendlyByteBuf, T> p5dd544cb_40_0) {
      return readNullable(this, p5dd544cb_40_0);
   }

   public static <T, B extends ByteBuf> @Nullable T readNullable(B p5dd544cb_41_0, StreamDecoder<? super B, T> p5dd544cb_42_1) {
      return p5dd544cb_41_0.readBoolean() ? p5dd544cb_42_1.decode(p5dd544cb_41_0) : null;
   }

   public <T> void writeNullable(@Nullable T p5dd544cb_43_0, StreamEncoder<? super FriendlyByteBuf, T> p5dd544cb_44_1) {
      writeNullable(this, p5dd544cb_43_0, p5dd544cb_44_1);
   }

   public static <T, B extends ByteBuf> void writeNullable(B p5dd544cb_45_0, @Nullable T p5dd544cb_46_1, StreamEncoder<? super B, T> p5dd544cb_47_2) {
      if (p5dd544cb_46_1 != null) {
         p5dd544cb_45_0.writeBoolean(true);
         p5dd544cb_47_2.encode(p5dd544cb_45_0, p5dd544cb_46_1);
      } else {
         p5dd544cb_45_0.writeBoolean(false);
      }
   }

   public byte[] readByteArray() {
      return readByteArray(this);
   }

   public static byte[] readByteArray(ByteBuf p5dd544cb_48_0) {
      return readByteArray(p5dd544cb_48_0, p5dd544cb_48_0.readableBytes());
   }

   public FriendlyByteBuf writeByteArray(byte[] p5dd544cb_49_0) {
      writeByteArray(this, p5dd544cb_49_0);
      return this;
   }

   public static void writeByteArray(ByteBuf p5dd544cb_50_0, byte[] p5dd544cb_51_1) {
      VarInt.write(p5dd544cb_50_0, p5dd544cb_51_1.length);
      p5dd544cb_50_0.writeBytes(p5dd544cb_51_1);
   }

   public byte[] readByteArray(int p5dd544cb_52_0) {
      return readByteArray(this, p5dd544cb_52_0);
   }

   public static byte[] readByteArray(ByteBuf p5dd544cb_53_0, int p5dd544cb_54_1) {
      int $$2 = VarInt.read(p5dd544cb_53_0);
      if ($$2 > p5dd544cb_54_1) {
         throw new DecoderException("ByteArray with size " + $$2 + " is bigger than allowed " + p5dd544cb_54_1);
      }

      byte[] $$3 = new byte[$$2];
      p5dd544cb_53_0.readBytes($$3);
      return $$3;
   }

   public FriendlyByteBuf writeVarIntArray(int[] p5dd544cb_55_0) {
      this.writeVarInt(p5dd544cb_55_0.length);

      for (int $$1 : p5dd544cb_55_0) {
         this.writeVarInt($$1);
      }

      return this;
   }

   public int[] readVarIntArray() {
      return this.readVarIntArray(this.readableBytes());
   }

   public int[] readVarIntArray(int p5dd544cb_56_0) {
      int $$1 = this.readVarInt();
      if ($$1 > p5dd544cb_56_0) {
         throw new DecoderException("VarIntArray with size " + $$1 + " is bigger than allowed " + p5dd544cb_56_0);
      }

      int[] $$2 = new int[$$1];

      for (int $$3 = 0; $$3 < $$2.length; $$3++) {
         $$2[$$3] = this.readVarInt();
      }

      return $$2;
   }

   public FriendlyByteBuf writeLongArray(long[] p5dd544cb_57_0) {
      writeLongArray(this, p5dd544cb_57_0);
      return this;
   }

   public static void writeLongArray(ByteBuf p5dd544cb_58_0, long[] p5dd544cb_59_1) {
      VarInt.write(p5dd544cb_58_0, p5dd544cb_59_1.length);
      writeFixedSizeLongArray(p5dd544cb_58_0, p5dd544cb_59_1);
   }

   public FriendlyByteBuf writeFixedSizeLongArray(long[] p5dd544cb_60_0) {
      writeFixedSizeLongArray(this, p5dd544cb_60_0);
      return this;
   }

   public static void writeFixedSizeLongArray(ByteBuf p5dd544cb_61_0, long[] p5dd544cb_62_1) {
      for (long $$2 : p5dd544cb_62_1) {
         p5dd544cb_61_0.writeLong($$2);
      }
   }

   public long[] readLongArray() {
      return readLongArray(this);
   }

   public long[] readFixedSizeLongArray(long[] p5dd544cb_63_0) {
      return readFixedSizeLongArray(this, p5dd544cb_63_0);
   }

   public static long[] readLongArray(ByteBuf p5dd544cb_64_0) {
      int $$1 = VarInt.read(p5dd544cb_64_0);
      int $$2 = p5dd544cb_64_0.readableBytes() / 8;
      if ($$1 > $$2) {
         throw new DecoderException("LongArray with size " + $$1 + " is bigger than allowed " + $$2);
      } else {
         return readFixedSizeLongArray(p5dd544cb_64_0, new long[$$1]);
      }
   }

   public static long[] readFixedSizeLongArray(ByteBuf p5dd544cb_65_0, long[] p5dd544cb_66_1) {
      for (int $$2 = 0; $$2 < p5dd544cb_66_1.length; $$2++) {
         p5dd544cb_66_1[$$2] = p5dd544cb_65_0.readLong();
      }

      return p5dd544cb_66_1;
   }

   public BlockPos readBlockPos() {
      return readBlockPos(this);
   }

   public static BlockPos readBlockPos(ByteBuf p5dd544cb_67_0) {
      return BlockPos.of(p5dd544cb_67_0.readLong());
   }

   public FriendlyByteBuf writeBlockPos(BlockPos p5dd544cb_68_0) {
      writeBlockPos(this, p5dd544cb_68_0);
      return this;
   }

   public static void writeBlockPos(ByteBuf p5dd544cb_69_0, BlockPos p5dd544cb_70_1) {
      p5dd544cb_69_0.writeLong(p5dd544cb_70_1.asLong());
   }

   public ChunkPos readChunkPos() {
      return new ChunkPos(this.readLong());
   }

   public FriendlyByteBuf writeChunkPos(ChunkPos p5dd544cb_71_0) {
      this.writeLong(p5dd544cb_71_0.toLong());
      return this;
   }

   public static ChunkPos readChunkPos(ByteBuf p5dd544cb_72_0) {
      return new ChunkPos(p5dd544cb_72_0.readLong());
   }

   public static void writeChunkPos(ByteBuf p5dd544cb_73_0, ChunkPos p5dd544cb_74_1) {
      p5dd544cb_73_0.writeLong(p5dd544cb_74_1.toLong());
   }

   public GlobalPos readGlobalPos() {
      ResourceKey<Level> $$0 = this.readResourceKey(Registries.DIMENSION);
      BlockPos $$1 = this.readBlockPos();
      return GlobalPos.of($$0, $$1);
   }

   public void writeGlobalPos(GlobalPos p5dd544cb_75_0) {
      this.writeResourceKey(p5dd544cb_75_0.dimension());
      this.writeBlockPos(p5dd544cb_75_0.pos());
   }

   public Vector3f readVector3f() {
      return readVector3f(this);
   }

   public static Vector3f readVector3f(ByteBuf p5dd544cb_76_0) {
      return new Vector3f(p5dd544cb_76_0.readFloat(), p5dd544cb_76_0.readFloat(), p5dd544cb_76_0.readFloat());
   }

   public void writeVector3f(Vector3f p5dd544cb_77_0) {
      writeVector3f(this, p5dd544cb_77_0);
   }

   public static void writeVector3f(ByteBuf p5dd544cb_78_0, Vector3fc p5dd544cb_79_1) {
      p5dd544cb_78_0.writeFloat(p5dd544cb_79_1.x());
      p5dd544cb_78_0.writeFloat(p5dd544cb_79_1.y());
      p5dd544cb_78_0.writeFloat(p5dd544cb_79_1.z());
   }

   public Quaternionf readQuaternion() {
      return readQuaternion(this);
   }

   public static Quaternionf readQuaternion(ByteBuf p5dd544cb_80_0) {
      return new Quaternionf(p5dd544cb_80_0.readFloat(), p5dd544cb_80_0.readFloat(), p5dd544cb_80_0.readFloat(), p5dd544cb_80_0.readFloat());
   }

   public void writeQuaternion(Quaternionf p5dd544cb_81_0) {
      writeQuaternion(this, p5dd544cb_81_0);
   }

   public static void writeQuaternion(ByteBuf p5dd544cb_82_0, Quaternionfc p5dd544cb_83_1) {
      p5dd544cb_82_0.writeFloat(p5dd544cb_83_1.x());
      p5dd544cb_82_0.writeFloat(p5dd544cb_83_1.y());
      p5dd544cb_82_0.writeFloat(p5dd544cb_83_1.z());
      p5dd544cb_82_0.writeFloat(p5dd544cb_83_1.w());
   }

   public static Vec3 readVec3(ByteBuf p5dd544cb_84_0) {
      return new Vec3(p5dd544cb_84_0.readDouble(), p5dd544cb_84_0.readDouble(), p5dd544cb_84_0.readDouble());
   }

   public Vec3 readVec3() {
      return readVec3(this);
   }

   public static void writeVec3(ByteBuf p5dd544cb_85_0, Vec3 p5dd544cb_86_1) {
      p5dd544cb_85_0.writeDouble(p5dd544cb_86_1.x());
      p5dd544cb_85_0.writeDouble(p5dd544cb_86_1.y());
      p5dd544cb_85_0.writeDouble(p5dd544cb_86_1.z());
   }

   public void writeVec3(Vec3 p5dd544cb_87_0) {
      writeVec3(this, p5dd544cb_87_0);
   }

   public Vec3 readLpVec3() {
      return LpVec3.read(this);
   }

   public void writeLpVec3(Vec3 p5dd544cb_88_0) {
      LpVec3.write(this, p5dd544cb_88_0);
   }

   public <T extends Enum<T>> T readEnum(Class<T> p5dd544cb_89_0) {
      return p5dd544cb_89_0.getEnumConstants()[this.readVarInt()];
   }

   public FriendlyByteBuf writeEnum(Enum<?> p5dd544cb_90_0) {
      return this.writeVarInt(p5dd544cb_90_0.ordinal());
   }

   public <T> T readById(IntFunction<T> p5dd544cb_91_0) {
      int $$1 = this.readVarInt();
      return p5dd544cb_91_0.apply($$1);
   }

   public <T> FriendlyByteBuf writeById(ToIntFunction<T> p5dd544cb_92_0, T p5dd544cb_93_1) {
      int $$2 = p5dd544cb_92_0.applyAsInt(p5dd544cb_93_1);
      return this.writeVarInt($$2);
   }

   public int readVarInt() {
      return VarInt.read(this.source);
   }

   public long readVarLong() {
      return VarLong.read(this.source);
   }

   public FriendlyByteBuf writeUUID(UUID p5dd544cb_94_0) {
      writeUUID(this, p5dd544cb_94_0);
      return this;
   }

   public static void writeUUID(ByteBuf p5dd544cb_95_0, UUID p5dd544cb_96_1) {
      p5dd544cb_95_0.writeLong(p5dd544cb_96_1.getMostSignificantBits());
      p5dd544cb_95_0.writeLong(p5dd544cb_96_1.getLeastSignificantBits());
   }

   public UUID readUUID() {
      return readUUID(this);
   }

   public static UUID readUUID(ByteBuf p5dd544cb_97_0) {
      return new UUID(p5dd544cb_97_0.readLong(), p5dd544cb_97_0.readLong());
   }

   public FriendlyByteBuf writeVarInt(int p5dd544cb_98_0) {
      VarInt.write(this.source, p5dd544cb_98_0);
      return this;
   }

   public FriendlyByteBuf writeVarLong(long p5dd544cb_99_0) {
      VarLong.write(this.source, p5dd544cb_99_0);
      return this;
   }

   public FriendlyByteBuf writeNbt(@Nullable Tag p5dd544cb_100_0) {
      writeNbt(this, p5dd544cb_100_0);
      return this;
   }

   public static void writeNbt(ByteBuf p5dd544cb_101_0, @Nullable Tag p5dd544cb_102_1) {
      if (p5dd544cb_102_1 == null) {
         p5dd544cb_102_1 = EndTag.INSTANCE;
      }

      try {
         NbtIo.writeAnyTag(p5dd544cb_102_1, new ByteBufOutputStream(p5dd544cb_101_0));
      } catch (IOException $$2) {
         throw new EncoderException($$2);
      }
   }

   public @Nullable CompoundTag readNbt() {
      return readNbt(this);
   }

   public static @Nullable CompoundTag readNbt(ByteBuf p5dd544cb_103_0) {
      Tag $$1 = readNbt(p5dd544cb_103_0, NbtAccounter.defaultQuota());
      if ($$1 != null && !($$1 instanceof CompoundTag)) {
         throw new DecoderException("Not a compound tag: " + $$1);
      } else {
         return (CompoundTag)$$1;
      }
   }

   public static @Nullable Tag readNbt(ByteBuf p5dd544cb_104_0, NbtAccounter p5dd544cb_105_1) {
      try {
         Tag $$2 = NbtIo.readAnyTag(new ByteBufInputStream(p5dd544cb_104_0), p5dd544cb_105_1);
         return $$2.getId() == 0 ? null : $$2;
      } catch (IOException $$3) {
         throw new EncoderException($$3);
      }
   }

   public @Nullable Tag readNbt(NbtAccounter p5dd544cb_106_0) {
      return readNbt(this, p5dd544cb_106_0);
   }

   public String readUtf() {
      return this.readUtf(32767);
   }

   public String readUtf(int p5dd544cb_107_0) {
      return Utf8String.read(this.source, p5dd544cb_107_0);
   }

   public FriendlyByteBuf writeUtf(String p5dd544cb_108_0) {
      return this.writeUtf(p5dd544cb_108_0, 32767);
   }

   public FriendlyByteBuf writeUtf(String p5dd544cb_109_0, int p5dd544cb_110_1) {
      Utf8String.write(this.source, p5dd544cb_109_0, p5dd544cb_110_1);
      return this;
   }

   public Identifier readIdentifier() {
      return Identifier.parse(this.readUtf(32767));
   }

   public FriendlyByteBuf writeIdentifier(Identifier p5dd544cb_111_0) {
      this.writeUtf(p5dd544cb_111_0.toString());
      return this;
   }

   public <T> ResourceKey<T> readResourceKey(ResourceKey<? extends Registry<T>> p5dd544cb_112_0) {
      Identifier $$1 = this.readIdentifier();
      return ResourceKey.create(p5dd544cb_112_0, $$1);
   }

   public void writeResourceKey(ResourceKey<?> p5dd544cb_113_0) {
      this.writeIdentifier(p5dd544cb_113_0.identifier());
   }

   public <T> ResourceKey<? extends Registry<T>> readRegistryKey() {
      Identifier $$0 = this.readIdentifier();
      return ResourceKey.createRegistryKey($$0);
   }

   public Instant readInstant() {
      return Instant.ofEpochMilli(this.readLong());
   }

   public void writeInstant(Instant p5dd544cb_114_0) {
      this.writeLong(p5dd544cb_114_0.toEpochMilli());
   }

   public PublicKey readPublicKey() {
      try {
         return Crypt.byteToPublicKey(this.readByteArray(512));
      } catch (CryptException $$0) {
         throw new DecoderException("Malformed public key bytes", $$0);
      }
   }

   public FriendlyByteBuf writePublicKey(PublicKey p5dd544cb_115_0) {
      this.writeByteArray(p5dd544cb_115_0.getEncoded());
      return this;
   }

   public BlockHitResult readBlockHitResult() {
      BlockPos $$0 = this.readBlockPos();
      Direction $$1 = this.readEnum(Direction.class);
      float $$2 = this.readFloat();
      float $$3 = this.readFloat();
      float $$4 = this.readFloat();
      boolean $$5 = this.readBoolean();
      boolean $$6 = this.readBoolean();
      return new BlockHitResult(new Vec3((double)$$0.getX() + $$2, (double)$$0.getY() + $$3, (double)$$0.getZ() + $$4), $$1, $$0, $$5, $$6);
   }

   public void writeBlockHitResult(BlockHitResult p5dd544cb_116_0) {
      BlockPos $$1 = p5dd544cb_116_0.getBlockPos();
      this.writeBlockPos($$1);
      this.writeEnum(p5dd544cb_116_0.getDirection());
      Vec3 $$2 = p5dd544cb_116_0.getLocation();
      this.writeFloat((float)($$2.x - $$1.getX()));
      this.writeFloat((float)($$2.y - $$1.getY()));
      this.writeFloat((float)($$2.z - $$1.getZ()));
      this.writeBoolean(p5dd544cb_116_0.isInside());
      this.writeBoolean(p5dd544cb_116_0.isWorldBorderHit());
   }

   public BitSet readBitSet() {
      return BitSet.valueOf(this.readLongArray());
   }

   public void writeBitSet(BitSet p5dd544cb_117_0) {
      this.writeLongArray(p5dd544cb_117_0.toLongArray());
   }

   public BitSet readFixedBitSet(int p5dd544cb_118_0) {
      byte[] $$1 = new byte[Mth.positiveCeilDiv(p5dd544cb_118_0, 8)];
      this.readBytes($$1);
      return BitSet.valueOf($$1);
   }

   public void writeFixedBitSet(BitSet p5dd544cb_119_0, int p5dd544cb_120_1) {
      if (p5dd544cb_119_0.length() > p5dd544cb_120_1) {
         throw new EncoderException("BitSet is larger than expected size (" + p5dd544cb_119_0.length() + ">" + p5dd544cb_120_1 + ")");
      }

      byte[] $$2 = p5dd544cb_119_0.toByteArray();
      this.writeBytes(Arrays.copyOf($$2, Mth.positiveCeilDiv(p5dd544cb_120_1, 8)));
   }

   public static int readContainerId(ByteBuf p5dd544cb_121_0) {
      return VarInt.read(p5dd544cb_121_0);
   }

   public int readContainerId() {
      return readContainerId(this.source);
   }

   public static void writeContainerId(ByteBuf p5dd544cb_122_0, int p5dd544cb_123_1) {
      VarInt.write(p5dd544cb_122_0, p5dd544cb_123_1);
   }

   public void writeContainerId(int p5dd544cb_124_0) {
      writeContainerId(this.source, p5dd544cb_124_0);
   }

   @Override
   public boolean isContiguous() {
      return this.source.isContiguous();
   }

   @Override
   public int maxFastWritableBytes() {
      return this.source.maxFastWritableBytes();
   }

   @Override
   public int capacity() {
      return this.source.capacity();
   }

   public FriendlyByteBuf capacity(int p5dd544cb_125_0) {
      this.source.capacity(p5dd544cb_125_0);
      return this;
   }

   @Override
   public int maxCapacity() {
      return this.source.maxCapacity();
   }

   @Override
   public ByteBufAllocator alloc() {
      return this.source.alloc();
   }

   @Override
   public ByteOrder order() {
      return this.source.order();
   }

   @Override
   public ByteBuf order(ByteOrder p5dd544cb_126_0) {
      return this.source.order(p5dd544cb_126_0);
   }

   @Override
   public ByteBuf unwrap() {
      return this.source;
   }

   @Override
   public boolean isDirect() {
      return this.source.isDirect();
   }

   @Override
   public boolean isReadOnly() {
      return this.source.isReadOnly();
   }

   @Override
   public ByteBuf asReadOnly() {
      return this.source.asReadOnly();
   }

   @Override
   public int readerIndex() {
      return this.source.readerIndex();
   }

   public FriendlyByteBuf readerIndex(int p5dd544cb_127_0) {
      this.source.readerIndex(p5dd544cb_127_0);
      return this;
   }

   @Override
   public int writerIndex() {
      return this.source.writerIndex();
   }

   public FriendlyByteBuf writerIndex(int p5dd544cb_128_0) {
      this.source.writerIndex(p5dd544cb_128_0);
      return this;
   }

   public FriendlyByteBuf setIndex(int p5dd544cb_129_0, int p5dd544cb_130_1) {
      this.source.setIndex(p5dd544cb_129_0, p5dd544cb_130_1);
      return this;
   }

   @Override
   public int readableBytes() {
      return this.source.readableBytes();
   }

   @Override
   public int writableBytes() {
      return this.source.writableBytes();
   }

   @Override
   public int maxWritableBytes() {
      return this.source.maxWritableBytes();
   }

   @Override
   public boolean isReadable() {
      return this.source.isReadable();
   }

   @Override
   public boolean isReadable(int p5dd544cb_131_0) {
      return this.source.isReadable(p5dd544cb_131_0);
   }

   @Override
   public boolean isWritable() {
      return this.source.isWritable();
   }

   @Override
   public boolean isWritable(int p5dd544cb_132_0) {
      return this.source.isWritable(p5dd544cb_132_0);
   }

   public FriendlyByteBuf clear() {
      this.source.clear();
      return this;
   }

   public FriendlyByteBuf markReaderIndex() {
      this.source.markReaderIndex();
      return this;
   }

   public FriendlyByteBuf resetReaderIndex() {
      this.source.resetReaderIndex();
      return this;
   }

   public FriendlyByteBuf markWriterIndex() {
      this.source.markWriterIndex();
      return this;
   }

   public FriendlyByteBuf resetWriterIndex() {
      this.source.resetWriterIndex();
      return this;
   }

   public FriendlyByteBuf discardReadBytes() {
      this.source.discardReadBytes();
      return this;
   }

   public FriendlyByteBuf discardSomeReadBytes() {
      this.source.discardSomeReadBytes();
      return this;
   }

   public FriendlyByteBuf ensureWritable(int p5dd544cb_133_0) {
      this.source.ensureWritable(p5dd544cb_133_0);
      return this;
   }

   @Override
   public int ensureWritable(int p5dd544cb_134_0, boolean p5dd544cb_135_1) {
      return this.source.ensureWritable(p5dd544cb_134_0, p5dd544cb_135_1);
   }

   @Override
   public boolean getBoolean(int p5dd544cb_136_0) {
      return this.source.getBoolean(p5dd544cb_136_0);
   }

   @Override
   public byte getByte(int p5dd544cb_137_0) {
      return this.source.getByte(p5dd544cb_137_0);
   }

   @Override
   public short getUnsignedByte(int p5dd544cb_138_0) {
      return this.source.getUnsignedByte(p5dd544cb_138_0);
   }

   @Override
   public short getShort(int p5dd544cb_139_0) {
      return this.source.getShort(p5dd544cb_139_0);
   }

   @Override
   public short getShortLE(int p5dd544cb_140_0) {
      return this.source.getShortLE(p5dd544cb_140_0);
   }

   @Override
   public int getUnsignedShort(int p5dd544cb_141_0) {
      return this.source.getUnsignedShort(p5dd544cb_141_0);
   }

   @Override
   public int getUnsignedShortLE(int p5dd544cb_142_0) {
      return this.source.getUnsignedShortLE(p5dd544cb_142_0);
   }

   @Override
   public int getMedium(int p5dd544cb_143_0) {
      return this.source.getMedium(p5dd544cb_143_0);
   }

   @Override
   public int getMediumLE(int p5dd544cb_144_0) {
      return this.source.getMediumLE(p5dd544cb_144_0);
   }

   @Override
   public int getUnsignedMedium(int p5dd544cb_145_0) {
      return this.source.getUnsignedMedium(p5dd544cb_145_0);
   }

   @Override
   public int getUnsignedMediumLE(int p5dd544cb_146_0) {
      return this.source.getUnsignedMediumLE(p5dd544cb_146_0);
   }

   @Override
   public int getInt(int p5dd544cb_147_0) {
      return this.source.getInt(p5dd544cb_147_0);
   }

   @Override
   public int getIntLE(int p5dd544cb_148_0) {
      return this.source.getIntLE(p5dd544cb_148_0);
   }

   @Override
   public long getUnsignedInt(int p5dd544cb_149_0) {
      return this.source.getUnsignedInt(p5dd544cb_149_0);
   }

   @Override
   public long getUnsignedIntLE(int p5dd544cb_150_0) {
      return this.source.getUnsignedIntLE(p5dd544cb_150_0);
   }

   @Override
   public long getLong(int p5dd544cb_151_0) {
      return this.source.getLong(p5dd544cb_151_0);
   }

   @Override
   public long getLongLE(int p5dd544cb_152_0) {
      return this.source.getLongLE(p5dd544cb_152_0);
   }

   @Override
   public char getChar(int p5dd544cb_153_0) {
      return this.source.getChar(p5dd544cb_153_0);
   }

   @Override
   public float getFloat(int p5dd544cb_154_0) {
      return this.source.getFloat(p5dd544cb_154_0);
   }

   @Override
   public double getDouble(int p5dd544cb_155_0) {
      return this.source.getDouble(p5dd544cb_155_0);
   }

   public FriendlyByteBuf getBytes(int p5dd544cb_156_0, ByteBuf p5dd544cb_157_1) {
      this.source.getBytes(p5dd544cb_156_0, p5dd544cb_157_1);
      return this;
   }

   public FriendlyByteBuf getBytes(int p5dd544cb_158_0, ByteBuf p5dd544cb_159_1, int p5dd544cb_160_2) {
      this.source.getBytes(p5dd544cb_158_0, p5dd544cb_159_1, p5dd544cb_160_2);
      return this;
   }

   public FriendlyByteBuf getBytes(int p5dd544cb_161_0, ByteBuf p5dd544cb_162_1, int p5dd544cb_163_2, int p5dd544cb_164_3) {
      this.source.getBytes(p5dd544cb_161_0, p5dd544cb_162_1, p5dd544cb_163_2, p5dd544cb_164_3);
      return this;
   }

   public FriendlyByteBuf getBytes(int p5dd544cb_165_0, byte[] p5dd544cb_166_1) {
      this.source.getBytes(p5dd544cb_165_0, p5dd544cb_166_1);
      return this;
   }

   public FriendlyByteBuf getBytes(int p5dd544cb_167_0, byte[] p5dd544cb_168_1, int p5dd544cb_169_2, int p5dd544cb_170_3) {
      this.source.getBytes(p5dd544cb_167_0, p5dd544cb_168_1, p5dd544cb_169_2, p5dd544cb_170_3);
      return this;
   }

   public FriendlyByteBuf getBytes(int p5dd544cb_171_0, ByteBuffer p5dd544cb_172_1) {
      this.source.getBytes(p5dd544cb_171_0, p5dd544cb_172_1);
      return this;
   }

   public FriendlyByteBuf getBytes(int p5dd544cb_173_0, OutputStream p5dd544cb_174_1, int p5dd544cb_175_2) throws IOException {
      this.source.getBytes(p5dd544cb_173_0, p5dd544cb_174_1, p5dd544cb_175_2);
      return this;
   }

   @Override
   public int getBytes(int p5dd544cb_176_0, GatheringByteChannel p5dd544cb_177_1, int p5dd544cb_178_2) throws IOException {
      return this.source.getBytes(p5dd544cb_176_0, p5dd544cb_177_1, p5dd544cb_178_2);
   }

   @Override
   public int getBytes(int p5dd544cb_179_0, FileChannel p5dd544cb_180_1, long p5dd544cb_181_2, int p5dd544cb_182_3) throws IOException {
      return this.source.getBytes(p5dd544cb_179_0, p5dd544cb_180_1, p5dd544cb_181_2, p5dd544cb_182_3);
   }

   @Override
   public CharSequence getCharSequence(int p5dd544cb_183_0, int p5dd544cb_184_1, Charset p5dd544cb_185_2) {
      return this.source.getCharSequence(p5dd544cb_183_0, p5dd544cb_184_1, p5dd544cb_185_2);
   }

   public FriendlyByteBuf setBoolean(int p5dd544cb_186_0, boolean p5dd544cb_187_1) {
      this.source.setBoolean(p5dd544cb_186_0, p5dd544cb_187_1);
      return this;
   }

   public FriendlyByteBuf setByte(int p5dd544cb_188_0, int p5dd544cb_189_1) {
      this.source.setByte(p5dd544cb_188_0, p5dd544cb_189_1);
      return this;
   }

   public FriendlyByteBuf setShort(int p5dd544cb_190_0, int p5dd544cb_191_1) {
      this.source.setShort(p5dd544cb_190_0, p5dd544cb_191_1);
      return this;
   }

   public FriendlyByteBuf setShortLE(int p5dd544cb_192_0, int p5dd544cb_193_1) {
      this.source.setShortLE(p5dd544cb_192_0, p5dd544cb_193_1);
      return this;
   }

   public FriendlyByteBuf setMedium(int p5dd544cb_194_0, int p5dd544cb_195_1) {
      this.source.setMedium(p5dd544cb_194_0, p5dd544cb_195_1);
      return this;
   }

   public FriendlyByteBuf setMediumLE(int p5dd544cb_196_0, int p5dd544cb_197_1) {
      this.source.setMediumLE(p5dd544cb_196_0, p5dd544cb_197_1);
      return this;
   }

   public FriendlyByteBuf setInt(int p5dd544cb_198_0, int p5dd544cb_199_1) {
      this.source.setInt(p5dd544cb_198_0, p5dd544cb_199_1);
      return this;
   }

   public FriendlyByteBuf setIntLE(int p5dd544cb_200_0, int p5dd544cb_201_1) {
      this.source.setIntLE(p5dd544cb_200_0, p5dd544cb_201_1);
      return this;
   }

   public FriendlyByteBuf setLong(int p5dd544cb_202_0, long p5dd544cb_203_1) {
      this.source.setLong(p5dd544cb_202_0, p5dd544cb_203_1);
      return this;
   }

   public FriendlyByteBuf setLongLE(int p5dd544cb_204_0, long p5dd544cb_205_1) {
      this.source.setLongLE(p5dd544cb_204_0, p5dd544cb_205_1);
      return this;
   }

   public FriendlyByteBuf setChar(int p5dd544cb_206_0, int p5dd544cb_207_1) {
      this.source.setChar(p5dd544cb_206_0, p5dd544cb_207_1);
      return this;
   }

   public FriendlyByteBuf setFloat(int p5dd544cb_208_0, float p5dd544cb_209_1) {
      this.source.setFloat(p5dd544cb_208_0, p5dd544cb_209_1);
      return this;
   }

   public FriendlyByteBuf setDouble(int p5dd544cb_210_0, double p5dd544cb_211_1) {
      this.source.setDouble(p5dd544cb_210_0, p5dd544cb_211_1);
      return this;
   }

   public FriendlyByteBuf setBytes(int p5dd544cb_212_0, ByteBuf p5dd544cb_213_1) {
      this.source.setBytes(p5dd544cb_212_0, p5dd544cb_213_1);
      return this;
   }

   public FriendlyByteBuf setBytes(int p5dd544cb_214_0, ByteBuf p5dd544cb_215_1, int p5dd544cb_216_2) {
      this.source.setBytes(p5dd544cb_214_0, p5dd544cb_215_1, p5dd544cb_216_2);
      return this;
   }

   public FriendlyByteBuf setBytes(int p5dd544cb_217_0, ByteBuf p5dd544cb_218_1, int p5dd544cb_219_2, int p5dd544cb_220_3) {
      this.source.setBytes(p5dd544cb_217_0, p5dd544cb_218_1, p5dd544cb_219_2, p5dd544cb_220_3);
      return this;
   }

   public FriendlyByteBuf setBytes(int p5dd544cb_221_0, byte[] p5dd544cb_222_1) {
      this.source.setBytes(p5dd544cb_221_0, p5dd544cb_222_1);
      return this;
   }

   public FriendlyByteBuf setBytes(int p5dd544cb_223_0, byte[] p5dd544cb_224_1, int p5dd544cb_225_2, int p5dd544cb_226_3) {
      this.source.setBytes(p5dd544cb_223_0, p5dd544cb_224_1, p5dd544cb_225_2, p5dd544cb_226_3);
      return this;
   }

   public FriendlyByteBuf setBytes(int p5dd544cb_227_0, ByteBuffer p5dd544cb_228_1) {
      this.source.setBytes(p5dd544cb_227_0, p5dd544cb_228_1);
      return this;
   }

   @Override
   public int setBytes(int p5dd544cb_229_0, InputStream p5dd544cb_230_1, int p5dd544cb_231_2) throws IOException {
      return this.source.setBytes(p5dd544cb_229_0, p5dd544cb_230_1, p5dd544cb_231_2);
   }

   @Override
   public int setBytes(int p5dd544cb_232_0, ScatteringByteChannel p5dd544cb_233_1, int p5dd544cb_234_2) throws IOException {
      return this.source.setBytes(p5dd544cb_232_0, p5dd544cb_233_1, p5dd544cb_234_2);
   }

   @Override
   public int setBytes(int p5dd544cb_235_0, FileChannel p5dd544cb_236_1, long p5dd544cb_237_2, int p5dd544cb_238_3) throws IOException {
      return this.source.setBytes(p5dd544cb_235_0, p5dd544cb_236_1, p5dd544cb_237_2, p5dd544cb_238_3);
   }

   public FriendlyByteBuf setZero(int p5dd544cb_239_0, int p5dd544cb_240_1) {
      this.source.setZero(p5dd544cb_239_0, p5dd544cb_240_1);
      return this;
   }

   @Override
   public int setCharSequence(int p5dd544cb_241_0, CharSequence p5dd544cb_242_1, Charset p5dd544cb_243_2) {
      return this.source.setCharSequence(p5dd544cb_241_0, p5dd544cb_242_1, p5dd544cb_243_2);
   }

   @Override
   public boolean readBoolean() {
      return this.source.readBoolean();
   }

   @Override
   public byte readByte() {
      return this.source.readByte();
   }

   @Override
   public short readUnsignedByte() {
      return this.source.readUnsignedByte();
   }

   @Override
   public short readShort() {
      return this.source.readShort();
   }

   @Override
   public short readShortLE() {
      return this.source.readShortLE();
   }

   @Override
   public int readUnsignedShort() {
      return this.source.readUnsignedShort();
   }

   @Override
   public int readUnsignedShortLE() {
      return this.source.readUnsignedShortLE();
   }

   @Override
   public int readMedium() {
      return this.source.readMedium();
   }

   @Override
   public int readMediumLE() {
      return this.source.readMediumLE();
   }

   @Override
   public int readUnsignedMedium() {
      return this.source.readUnsignedMedium();
   }

   @Override
   public int readUnsignedMediumLE() {
      return this.source.readUnsignedMediumLE();
   }

   @Override
   public int readInt() {
      return this.source.readInt();
   }

   @Override
   public int readIntLE() {
      return this.source.readIntLE();
   }

   @Override
   public long readUnsignedInt() {
      return this.source.readUnsignedInt();
   }

   @Override
   public long readUnsignedIntLE() {
      return this.source.readUnsignedIntLE();
   }

   @Override
   public long readLong() {
      return this.source.readLong();
   }

   @Override
   public long readLongLE() {
      return this.source.readLongLE();
   }

   @Override
   public char readChar() {
      return this.source.readChar();
   }

   @Override
   public float readFloat() {
      return this.source.readFloat();
   }

   @Override
   public double readDouble() {
      return this.source.readDouble();
   }

   @Override
   public ByteBuf readBytes(int p5dd544cb_244_0) {
      return this.source.readBytes(p5dd544cb_244_0);
   }

   @Override
   public ByteBuf readSlice(int p5dd544cb_245_0) {
      return this.source.readSlice(p5dd544cb_245_0);
   }

   @Override
   public ByteBuf readRetainedSlice(int p5dd544cb_246_0) {
      return this.source.readRetainedSlice(p5dd544cb_246_0);
   }

   public FriendlyByteBuf readBytes(ByteBuf p5dd544cb_247_0) {
      this.source.readBytes(p5dd544cb_247_0);
      return this;
   }

   public FriendlyByteBuf readBytes(ByteBuf p5dd544cb_248_0, int p5dd544cb_249_1) {
      this.source.readBytes(p5dd544cb_248_0, p5dd544cb_249_1);
      return this;
   }

   public FriendlyByteBuf readBytes(ByteBuf p5dd544cb_250_0, int p5dd544cb_251_1, int p5dd544cb_252_2) {
      this.source.readBytes(p5dd544cb_250_0, p5dd544cb_251_1, p5dd544cb_252_2);
      return this;
   }

   public FriendlyByteBuf readBytes(byte[] p5dd544cb_253_0) {
      this.source.readBytes(p5dd544cb_253_0);
      return this;
   }

   public FriendlyByteBuf readBytes(byte[] p5dd544cb_254_0, int p5dd544cb_255_1, int p5dd544cb_256_2) {
      this.source.readBytes(p5dd544cb_254_0, p5dd544cb_255_1, p5dd544cb_256_2);
      return this;
   }

   public FriendlyByteBuf readBytes(ByteBuffer p5dd544cb_257_0) {
      this.source.readBytes(p5dd544cb_257_0);
      return this;
   }

   public FriendlyByteBuf readBytes(OutputStream p5dd544cb_258_0, int p5dd544cb_259_1) throws IOException {
      this.source.readBytes(p5dd544cb_258_0, p5dd544cb_259_1);
      return this;
   }

   @Override
   public int readBytes(GatheringByteChannel p5dd544cb_260_0, int p5dd544cb_261_1) throws IOException {
      return this.source.readBytes(p5dd544cb_260_0, p5dd544cb_261_1);
   }

   @Override
   public CharSequence readCharSequence(int p5dd544cb_262_0, Charset p5dd544cb_263_1) {
      return this.source.readCharSequence(p5dd544cb_262_0, p5dd544cb_263_1);
   }

   @Override
   public String readString(int p5dd544cb_264_0, Charset p5dd544cb_265_1) {
      return this.source.readString(p5dd544cb_264_0, p5dd544cb_265_1);
   }

   @Override
   public int readBytes(FileChannel p5dd544cb_266_0, long p5dd544cb_267_1, int p5dd544cb_268_2) throws IOException {
      return this.source.readBytes(p5dd544cb_266_0, p5dd544cb_267_1, p5dd544cb_268_2);
   }

   public FriendlyByteBuf skipBytes(int p5dd544cb_269_0) {
      this.source.skipBytes(p5dd544cb_269_0);
      return this;
   }

   public FriendlyByteBuf writeBoolean(boolean p5dd544cb_270_0) {
      this.source.writeBoolean(p5dd544cb_270_0);
      return this;
   }

   public FriendlyByteBuf writeByte(int p5dd544cb_271_0) {
      this.source.writeByte(p5dd544cb_271_0);
      return this;
   }

   public FriendlyByteBuf writeShort(int p5dd544cb_272_0) {
      this.source.writeShort(p5dd544cb_272_0);
      return this;
   }

   public FriendlyByteBuf writeShortLE(int p5dd544cb_273_0) {
      this.source.writeShortLE(p5dd544cb_273_0);
      return this;
   }

   public FriendlyByteBuf writeMedium(int p5dd544cb_274_0) {
      this.source.writeMedium(p5dd544cb_274_0);
      return this;
   }

   public FriendlyByteBuf writeMediumLE(int p5dd544cb_275_0) {
      this.source.writeMediumLE(p5dd544cb_275_0);
      return this;
   }

   public FriendlyByteBuf writeInt(int p5dd544cb_276_0) {
      this.source.writeInt(p5dd544cb_276_0);
      return this;
   }

   public FriendlyByteBuf writeIntLE(int p5dd544cb_277_0) {
      this.source.writeIntLE(p5dd544cb_277_0);
      return this;
   }

   public FriendlyByteBuf writeLong(long p5dd544cb_278_0) {
      this.source.writeLong(p5dd544cb_278_0);
      return this;
   }

   public FriendlyByteBuf writeLongLE(long p5dd544cb_279_0) {
      this.source.writeLongLE(p5dd544cb_279_0);
      return this;
   }

   public FriendlyByteBuf writeChar(int p5dd544cb_280_0) {
      this.source.writeChar(p5dd544cb_280_0);
      return this;
   }

   public FriendlyByteBuf writeFloat(float p5dd544cb_281_0) {
      this.source.writeFloat(p5dd544cb_281_0);
      return this;
   }

   public FriendlyByteBuf writeDouble(double p5dd544cb_282_0) {
      this.source.writeDouble(p5dd544cb_282_0);
      return this;
   }

   public FriendlyByteBuf writeBytes(ByteBuf p5dd544cb_283_0) {
      this.source.writeBytes(p5dd544cb_283_0);
      return this;
   }

   public FriendlyByteBuf writeBytes(ByteBuf p5dd544cb_284_0, int p5dd544cb_285_1) {
      this.source.writeBytes(p5dd544cb_284_0, p5dd544cb_285_1);
      return this;
   }

   public FriendlyByteBuf writeBytes(ByteBuf p5dd544cb_286_0, int p5dd544cb_287_1, int p5dd544cb_288_2) {
      this.source.writeBytes(p5dd544cb_286_0, p5dd544cb_287_1, p5dd544cb_288_2);
      return this;
   }

   public FriendlyByteBuf writeBytes(byte[] p5dd544cb_289_0) {
      this.source.writeBytes(p5dd544cb_289_0);
      return this;
   }

   public FriendlyByteBuf writeBytes(byte[] p5dd544cb_290_0, int p5dd544cb_291_1, int p5dd544cb_292_2) {
      this.source.writeBytes(p5dd544cb_290_0, p5dd544cb_291_1, p5dd544cb_292_2);
      return this;
   }

   public FriendlyByteBuf writeBytes(ByteBuffer p5dd544cb_293_0) {
      this.source.writeBytes(p5dd544cb_293_0);
      return this;
   }

   @Override
   public int writeBytes(InputStream p5dd544cb_294_0, int p5dd544cb_295_1) throws IOException {
      return this.source.writeBytes(p5dd544cb_294_0, p5dd544cb_295_1);
   }

   @Override
   public int writeBytes(ScatteringByteChannel p5dd544cb_296_0, int p5dd544cb_297_1) throws IOException {
      return this.source.writeBytes(p5dd544cb_296_0, p5dd544cb_297_1);
   }

   @Override
   public int writeBytes(FileChannel p5dd544cb_298_0, long p5dd544cb_299_1, int p5dd544cb_300_2) throws IOException {
      return this.source.writeBytes(p5dd544cb_298_0, p5dd544cb_299_1, p5dd544cb_300_2);
   }

   public FriendlyByteBuf writeZero(int p5dd544cb_301_0) {
      this.source.writeZero(p5dd544cb_301_0);
      return this;
   }

   @Override
   public int writeCharSequence(CharSequence p5dd544cb_302_0, Charset p5dd544cb_303_1) {
      return this.source.writeCharSequence(p5dd544cb_302_0, p5dd544cb_303_1);
   }

   @Override
   public int indexOf(int p5dd544cb_304_0, int p5dd544cb_305_1, byte p5dd544cb_306_2) {
      return this.source.indexOf(p5dd544cb_304_0, p5dd544cb_305_1, p5dd544cb_306_2);
   }

   @Override
   public int bytesBefore(byte p5dd544cb_307_0) {
      return this.source.bytesBefore(p5dd544cb_307_0);
   }

   @Override
   public int bytesBefore(int p5dd544cb_308_0, byte p5dd544cb_309_1) {
      return this.source.bytesBefore(p5dd544cb_308_0, p5dd544cb_309_1);
   }

   @Override
   public int bytesBefore(int p5dd544cb_310_0, int p5dd544cb_311_1, byte p5dd544cb_312_2) {
      return this.source.bytesBefore(p5dd544cb_310_0, p5dd544cb_311_1, p5dd544cb_312_2);
   }

   @Override
   public int forEachByte(ByteProcessor p5dd544cb_313_0) {
      return this.source.forEachByte(p5dd544cb_313_0);
   }

   @Override
   public int forEachByte(int p5dd544cb_314_0, int p5dd544cb_315_1, ByteProcessor p5dd544cb_316_2) {
      return this.source.forEachByte(p5dd544cb_314_0, p5dd544cb_315_1, p5dd544cb_316_2);
   }

   @Override
   public int forEachByteDesc(ByteProcessor p5dd544cb_317_0) {
      return this.source.forEachByteDesc(p5dd544cb_317_0);
   }

   @Override
   public int forEachByteDesc(int p5dd544cb_318_0, int p5dd544cb_319_1, ByteProcessor p5dd544cb_320_2) {
      return this.source.forEachByteDesc(p5dd544cb_318_0, p5dd544cb_319_1, p5dd544cb_320_2);
   }

   @Override
   public ByteBuf copy() {
      return this.source.copy();
   }

   @Override
   public ByteBuf copy(int p5dd544cb_321_0, int p5dd544cb_322_1) {
      return this.source.copy(p5dd544cb_321_0, p5dd544cb_322_1);
   }

   @Override
   public ByteBuf slice() {
      return this.source.slice();
   }

   @Override
   public ByteBuf retainedSlice() {
      return this.source.retainedSlice();
   }

   @Override
   public ByteBuf slice(int p5dd544cb_323_0, int p5dd544cb_324_1) {
      return this.source.slice(p5dd544cb_323_0, p5dd544cb_324_1);
   }

   @Override
   public ByteBuf retainedSlice(int p5dd544cb_325_0, int p5dd544cb_326_1) {
      return this.source.retainedSlice(p5dd544cb_325_0, p5dd544cb_326_1);
   }

   @Override
   public ByteBuf duplicate() {
      return this.source.duplicate();
   }

   @Override
   public ByteBuf retainedDuplicate() {
      return this.source.retainedDuplicate();
   }

   @Override
   public int nioBufferCount() {
      return this.source.nioBufferCount();
   }

   @Override
   public ByteBuffer nioBuffer() {
      return this.source.nioBuffer();
   }

   @Override
   public ByteBuffer nioBuffer(int p5dd544cb_327_0, int p5dd544cb_328_1) {
      return this.source.nioBuffer(p5dd544cb_327_0, p5dd544cb_328_1);
   }

   @Override
   public ByteBuffer internalNioBuffer(int p5dd544cb_329_0, int p5dd544cb_330_1) {
      return this.source.internalNioBuffer(p5dd544cb_329_0, p5dd544cb_330_1);
   }

   @Override
   public ByteBuffer[] nioBuffers() {
      return this.source.nioBuffers();
   }

   @Override
   public ByteBuffer[] nioBuffers(int p5dd544cb_331_0, int p5dd544cb_332_1) {
      return this.source.nioBuffers(p5dd544cb_331_0, p5dd544cb_332_1);
   }

   @Override
   public boolean hasArray() {
      return this.source.hasArray();
   }

   @Override
   public byte[] array() {
      return this.source.array();
   }

   @Override
   public int arrayOffset() {
      return this.source.arrayOffset();
   }

   @Override
   public boolean hasMemoryAddress() {
      return this.source.hasMemoryAddress();
   }

   @Override
   public long memoryAddress() {
      return this.source.memoryAddress();
   }

   @Override
   public String toString(Charset p5dd544cb_333_0) {
      return this.source.toString(p5dd544cb_333_0);
   }

   @Override
   public String toString(int p5dd544cb_334_0, int p5dd544cb_335_1, Charset p5dd544cb_336_2) {
      return this.source.toString(p5dd544cb_334_0, p5dd544cb_335_1, p5dd544cb_336_2);
   }

   @Override
   public int hashCode() {
      return this.source.hashCode();
   }

   @Override
   public boolean equals(Object p5dd544cb_337_0) {
      return this.source.equals(p5dd544cb_337_0);
   }

   @Override
   public int compareTo(ByteBuf p5dd544cb_338_0) {
      return this.source.compareTo(p5dd544cb_338_0);
   }

   @Override
   public String toString() {
      return this.source.toString();
   }

   public FriendlyByteBuf retain(int p5dd544cb_339_0) {
      this.source.retain(p5dd544cb_339_0);
      return this;
   }

   public FriendlyByteBuf retain() {
      this.source.retain();
      return this;
   }

   public FriendlyByteBuf touch() {
      this.source.touch();
      return this;
   }

   public FriendlyByteBuf touch(Object p5dd544cb_340_0) {
      this.source.touch(p5dd544cb_340_0);
      return this;
   }

   @Override
   public int refCnt() {
      return this.source.refCnt();
   }

   @Override
   public boolean release() {
      return this.source.release();
   }

   @Override
   public boolean release(int p5dd544cb_341_0) {
      return this.source.release(p5dd544cb_341_0);
   }
}
