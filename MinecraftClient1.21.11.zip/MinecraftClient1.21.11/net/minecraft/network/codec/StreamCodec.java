package net.minecraft.network.codec;

import com.google.common.base.Suppliers;
import com.mojang.datafixers.util.Function10;
import com.mojang.datafixers.util.Function11;
import com.mojang.datafixers.util.Function12;
import com.mojang.datafixers.util.Function3;
import com.mojang.datafixers.util.Function4;
import com.mojang.datafixers.util.Function5;
import com.mojang.datafixers.util.Function6;
import com.mojang.datafixers.util.Function7;
import com.mojang.datafixers.util.Function8;
import com.mojang.datafixers.util.Function9;
import io.netty.buffer.ByteBuf;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public interface StreamCodec<B, V> extends StreamDecoder<B, V>, StreamEncoder<B, V> {
   static <B, V> StreamCodec<B, V> of(StreamEncoder<B, V> pa38298e8_0_0, StreamDecoder<B, V> pa38298e8_1_1) {
      return new StreamCodec<B, V>() {
         @Override
         public V decode(B pcd400375_2_0) {
            return pa38298e8_1_1.decode(pcd400375_2_0);
         }

         @Override
         public void encode(B pcd400375_3_0, V pcd400375_4_1) {
            pa38298e8_0_0.encode(pcd400375_3_0, pcd400375_4_1);
         }
      };
   }

   static <B, V> StreamCodec<B, V> ofMember(StreamMemberEncoder<B, V> pa38298e8_2_0, StreamDecoder<B, V> pa38298e8_3_1) {
      return new StreamCodec<B, V>() {
         @Override
         public V decode(B pcd400376_2_0) {
            return pa38298e8_3_1.decode(pcd400376_2_0);
         }

         @Override
         public void encode(B pcd400376_3_0, V pcd400376_4_1) {
            pa38298e8_2_0.encode(pcd400376_4_1, pcd400376_3_0);
         }
      };
   }

   static <B, V> StreamCodec<B, V> unit(V pa38298e8_4_0) {
      return new StreamCodec<B, V>() {
         @Override
         public V decode(B pcd400377_1_0) {
            return pa38298e8_4_0;
         }

         @Override
         public void encode(B pcd400377_2_0, V pcd400377_3_1) {
            if (!pcd400377_3_1.equals(pa38298e8_4_0)) {
               throw new IllegalStateException("Can't encode '" + pcd400377_3_1 + "', expected '" + pa38298e8_4_0 + "'");
            }
         }
      };
   }

   default <O> StreamCodec<B, O> apply(StreamCodec.CodecOperation<B, V, O> pa38298e8_5_0) {
      return pa38298e8_5_0.apply(this);
   }

   default <O> StreamCodec<B, O> map(Function<? super V, ? extends O> pa38298e8_6_0, Function<? super O, ? extends V> pa38298e8_7_1) {
      return new StreamCodec<B, O>() {
         @Override
         public O decode(B pcd400378_3_0) {
            return (O)pa38298e8_6_0.apply(StreamCodec.this.decode(pcd400378_3_0));
         }

         @Override
         public void encode(B pcd400378_4_0, O pcd400378_5_1) {
            StreamCodec.this.encode(pcd400378_4_0, (V)pa38298e8_7_1.apply(pcd400378_5_1));
         }
      };
   }

   default <O extends ByteBuf> StreamCodec<O, V> mapStream(Function<O, ? extends B> pa38298e8_8_0) {
      return new StreamCodec<O, V>() {
         public V decode(O pcd400379_2_0) {
            B $$1 = (B)pa38298e8_8_0.apply(pcd400379_2_0);
            return StreamCodec.this.decode($$1);
         }

         public void encode(O pcd400379_3_0, V pcd400379_4_1) {
            B $$2 = (B)pa38298e8_8_0.apply(pcd400379_3_0);
            StreamCodec.this.encode($$2, pcd400379_4_1);
         }
      };
   }

   default <U> StreamCodec<B, U> dispatch(
      Function<? super U, ? extends V> pa38298e8_9_0, Function<? super V, ? extends StreamCodec<? super B, ? extends U>> pa38298e8_10_1
   ) {
      return new StreamCodec<B, U>() {
         @Override
         public U decode(B pcd40037a_3_0) {
            V $$1 = StreamCodec.this.decode(pcd40037a_3_0);
            StreamCodec<? super B, ? extends U> $$2 = (StreamCodec<? super B, ? extends U>)pa38298e8_10_1.apply($$1);
            return (U)$$2.decode(pcd40037a_3_0);
         }

         @Override
         public void encode(B pcd40037a_4_0, U pcd40037a_5_1) {
            V $$2 = (V)pa38298e8_9_0.apply(pcd40037a_5_1);
            StreamCodec<B, U> $$3 = (StreamCodec<B, U>)pa38298e8_10_1.apply($$2);
            StreamCodec.this.encode(pcd40037a_4_0, $$2);
            $$3.encode(pcd40037a_4_0, pcd40037a_5_1);
         }
      };
   }

   static <B, C, T1> StreamCodec<B, C> composite(StreamCodec<? super B, T1> pa38298e8_11_0, Function<C, T1> pa38298e8_12_1, Function<T1, C> pa38298e8_13_2) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pcd40037b_3_0) {
            T1 $$1 = pa38298e8_11_0.decode(pcd40037b_3_0);
            return pa38298e8_13_2.apply($$1);
         }

         @Override
         public void encode(B pcd40037b_4_0, C pcd40037b_5_1) {
            pa38298e8_11_0.encode(pcd40037b_4_0, pa38298e8_12_1.apply(pcd40037b_5_1));
         }
      };
   }

   static <B, C, T1, T2> StreamCodec<B, C> composite(
      StreamCodec<? super B, T1> pa38298e8_14_0,
      Function<C, T1> pa38298e8_15_1,
      StreamCodec<? super B, T2> pa38298e8_16_2,
      Function<C, T2> pa38298e8_17_3,
      BiFunction<T1, T2, C> pa38298e8_18_4
   ) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pcd40037c_5_0) {
            T1 $$1 = pa38298e8_14_0.decode(pcd40037c_5_0);
            T2 $$2 = pa38298e8_16_2.decode(pcd40037c_5_0);
            return pa38298e8_18_4.apply($$1, $$2);
         }

         @Override
         public void encode(B pcd40037c_6_0, C pcd40037c_7_1) {
            pa38298e8_14_0.encode(pcd40037c_6_0, pa38298e8_15_1.apply(pcd40037c_7_1));
            pa38298e8_16_2.encode(pcd40037c_6_0, pa38298e8_17_3.apply(pcd40037c_7_1));
         }
      };
   }

   static <B, C, T1, T2, T3> StreamCodec<B, C> composite(
      StreamCodec<? super B, T1> pa38298e8_19_0,
      Function<C, T1> pa38298e8_20_1,
      StreamCodec<? super B, T2> pa38298e8_21_2,
      Function<C, T2> pa38298e8_22_3,
      StreamCodec<? super B, T3> pa38298e8_23_4,
      Function<C, T3> pa38298e8_24_5,
      Function3<T1, T2, T3, C> pa38298e8_25_6
   ) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pcd40037d_7_0) {
            T1 $$1 = pa38298e8_19_0.decode(pcd40037d_7_0);
            T2 $$2 = pa38298e8_21_2.decode(pcd40037d_7_0);
            T3 $$3 = pa38298e8_23_4.decode(pcd40037d_7_0);
            return pa38298e8_25_6.apply($$1, $$2, $$3);
         }

         @Override
         public void encode(B pcd40037d_8_0, C pcd40037d_9_1) {
            pa38298e8_19_0.encode(pcd40037d_8_0, pa38298e8_20_1.apply(pcd40037d_9_1));
            pa38298e8_21_2.encode(pcd40037d_8_0, pa38298e8_22_3.apply(pcd40037d_9_1));
            pa38298e8_23_4.encode(pcd40037d_8_0, pa38298e8_24_5.apply(pcd40037d_9_1));
         }
      };
   }

   static <B, C, T1, T2, T3, T4> StreamCodec<B, C> composite(
      StreamCodec<? super B, T1> pa38298e8_26_0,
      Function<C, T1> pa38298e8_27_1,
      StreamCodec<? super B, T2> pa38298e8_28_2,
      Function<C, T2> pa38298e8_29_3,
      StreamCodec<? super B, T3> pa38298e8_30_4,
      Function<C, T3> pa38298e8_31_5,
      StreamCodec<? super B, T4> pa38298e8_32_6,
      Function<C, T4> pa38298e8_33_7,
      Function4<T1, T2, T3, T4, C> pa38298e8_34_8
   ) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pdac06b5b_9_0) {
            T1 $$1 = pa38298e8_26_0.decode(pdac06b5b_9_0);
            T2 $$2 = pa38298e8_28_2.decode(pdac06b5b_9_0);
            T3 $$3 = pa38298e8_30_4.decode(pdac06b5b_9_0);
            T4 $$4 = pa38298e8_32_6.decode(pdac06b5b_9_0);
            return pa38298e8_34_8.apply($$1, $$2, $$3, $$4);
         }

         @Override
         public void encode(B pdac06b5b_10_0, C pdac06b5b_11_1) {
            pa38298e8_26_0.encode(pdac06b5b_10_0, pa38298e8_27_1.apply(pdac06b5b_11_1));
            pa38298e8_28_2.encode(pdac06b5b_10_0, pa38298e8_29_3.apply(pdac06b5b_11_1));
            pa38298e8_30_4.encode(pdac06b5b_10_0, pa38298e8_31_5.apply(pdac06b5b_11_1));
            pa38298e8_32_6.encode(pdac06b5b_10_0, pa38298e8_33_7.apply(pdac06b5b_11_1));
         }
      };
   }

   static <B, C, T1, T2, T3, T4, T5> StreamCodec<B, C> composite(
      StreamCodec<? super B, T1> pa38298e8_35_0,
      Function<C, T1> pa38298e8_36_1,
      StreamCodec<? super B, T2> pa38298e8_37_2,
      Function<C, T2> pa38298e8_38_3,
      StreamCodec<? super B, T3> pa38298e8_39_4,
      Function<C, T3> pa38298e8_40_5,
      StreamCodec<? super B, T4> pa38298e8_41_6,
      Function<C, T4> pa38298e8_42_7,
      StreamCodec<? super B, T5> pa38298e8_43_8,
      Function<C, T5> pa38298e8_44_9,
      Function5<T1, T2, T3, T4, T5, C> pa38298e8_45_10
   ) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pdac06b5c_11_0) {
            T1 $$1 = pa38298e8_35_0.decode(pdac06b5c_11_0);
            T2 $$2 = pa38298e8_37_2.decode(pdac06b5c_11_0);
            T3 $$3 = pa38298e8_39_4.decode(pdac06b5c_11_0);
            T4 $$4 = pa38298e8_41_6.decode(pdac06b5c_11_0);
            T5 $$5 = pa38298e8_43_8.decode(pdac06b5c_11_0);
            return pa38298e8_45_10.apply($$1, $$2, $$3, $$4, $$5);
         }

         @Override
         public void encode(B pdac06b5c_12_0, C pdac06b5c_13_1) {
            pa38298e8_35_0.encode(pdac06b5c_12_0, pa38298e8_36_1.apply(pdac06b5c_13_1));
            pa38298e8_37_2.encode(pdac06b5c_12_0, pa38298e8_38_3.apply(pdac06b5c_13_1));
            pa38298e8_39_4.encode(pdac06b5c_12_0, pa38298e8_40_5.apply(pdac06b5c_13_1));
            pa38298e8_41_6.encode(pdac06b5c_12_0, pa38298e8_42_7.apply(pdac06b5c_13_1));
            pa38298e8_43_8.encode(pdac06b5c_12_0, pa38298e8_44_9.apply(pdac06b5c_13_1));
         }
      };
   }

   static <B, C, T1, T2, T3, T4, T5, T6> StreamCodec<B, C> composite(
      StreamCodec<? super B, T1> pa38298e8_46_0,
      Function<C, T1> pa38298e8_47_1,
      StreamCodec<? super B, T2> pa38298e8_48_2,
      Function<C, T2> pa38298e8_49_3,
      StreamCodec<? super B, T3> pa38298e8_50_4,
      Function<C, T3> pa38298e8_51_5,
      StreamCodec<? super B, T4> pa38298e8_52_6,
      Function<C, T4> pa38298e8_53_7,
      StreamCodec<? super B, T5> pa38298e8_54_8,
      Function<C, T5> pa38298e8_55_9,
      StreamCodec<? super B, T6> pa38298e8_56_10,
      Function<C, T6> pa38298e8_57_11,
      Function6<T1, T2, T3, T4, T5, T6, C> pa38298e8_58_12
   ) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pdac06b5d_13_0) {
            T1 $$1 = pa38298e8_46_0.decode(pdac06b5d_13_0);
            T2 $$2 = pa38298e8_48_2.decode(pdac06b5d_13_0);
            T3 $$3 = pa38298e8_50_4.decode(pdac06b5d_13_0);
            T4 $$4 = pa38298e8_52_6.decode(pdac06b5d_13_0);
            T5 $$5 = pa38298e8_54_8.decode(pdac06b5d_13_0);
            T6 $$6 = pa38298e8_56_10.decode(pdac06b5d_13_0);
            return pa38298e8_58_12.apply($$1, $$2, $$3, $$4, $$5, $$6);
         }

         @Override
         public void encode(B pdac06b5d_14_0, C pdac06b5d_15_1) {
            pa38298e8_46_0.encode(pdac06b5d_14_0, pa38298e8_47_1.apply(pdac06b5d_15_1));
            pa38298e8_48_2.encode(pdac06b5d_14_0, pa38298e8_49_3.apply(pdac06b5d_15_1));
            pa38298e8_50_4.encode(pdac06b5d_14_0, pa38298e8_51_5.apply(pdac06b5d_15_1));
            pa38298e8_52_6.encode(pdac06b5d_14_0, pa38298e8_53_7.apply(pdac06b5d_15_1));
            pa38298e8_54_8.encode(pdac06b5d_14_0, pa38298e8_55_9.apply(pdac06b5d_15_1));
            pa38298e8_56_10.encode(pdac06b5d_14_0, pa38298e8_57_11.apply(pdac06b5d_15_1));
         }
      };
   }

   static <B, C, T1, T2, T3, T4, T5, T6, T7> StreamCodec<B, C> composite(
      StreamCodec<? super B, T1> pa38298e8_59_0,
      Function<C, T1> pa38298e8_60_1,
      StreamCodec<? super B, T2> pa38298e8_61_2,
      Function<C, T2> pa38298e8_62_3,
      StreamCodec<? super B, T3> pa38298e8_63_4,
      Function<C, T3> pa38298e8_64_5,
      StreamCodec<? super B, T4> pa38298e8_65_6,
      Function<C, T4> pa38298e8_66_7,
      StreamCodec<? super B, T5> pa38298e8_67_8,
      Function<C, T5> pa38298e8_68_9,
      StreamCodec<? super B, T6> pa38298e8_69_10,
      Function<C, T6> pa38298e8_70_11,
      StreamCodec<? super B, T7> pa38298e8_71_12,
      Function<C, T7> pa38298e8_72_13,
      Function7<T1, T2, T3, T4, T5, T6, T7, C> pa38298e8_73_14
   ) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pdac06b5e_15_0) {
            T1 $$1 = pa38298e8_59_0.decode(pdac06b5e_15_0);
            T2 $$2 = pa38298e8_61_2.decode(pdac06b5e_15_0);
            T3 $$3 = pa38298e8_63_4.decode(pdac06b5e_15_0);
            T4 $$4 = pa38298e8_65_6.decode(pdac06b5e_15_0);
            T5 $$5 = pa38298e8_67_8.decode(pdac06b5e_15_0);
            T6 $$6 = pa38298e8_69_10.decode(pdac06b5e_15_0);
            T7 $$7 = pa38298e8_71_12.decode(pdac06b5e_15_0);
            return pa38298e8_73_14.apply($$1, $$2, $$3, $$4, $$5, $$6, $$7);
         }

         @Override
         public void encode(B pdac06b5e_16_0, C pdac06b5e_17_1) {
            pa38298e8_59_0.encode(pdac06b5e_16_0, pa38298e8_60_1.apply(pdac06b5e_17_1));
            pa38298e8_61_2.encode(pdac06b5e_16_0, pa38298e8_62_3.apply(pdac06b5e_17_1));
            pa38298e8_63_4.encode(pdac06b5e_16_0, pa38298e8_64_5.apply(pdac06b5e_17_1));
            pa38298e8_65_6.encode(pdac06b5e_16_0, pa38298e8_66_7.apply(pdac06b5e_17_1));
            pa38298e8_67_8.encode(pdac06b5e_16_0, pa38298e8_68_9.apply(pdac06b5e_17_1));
            pa38298e8_69_10.encode(pdac06b5e_16_0, pa38298e8_70_11.apply(pdac06b5e_17_1));
            pa38298e8_71_12.encode(pdac06b5e_16_0, pa38298e8_72_13.apply(pdac06b5e_17_1));
         }
      };
   }

   static <B, C, T1, T2, T3, T4, T5, T6, T7, T8> StreamCodec<B, C> composite(
      StreamCodec<? super B, T1> pa38298e8_74_0,
      Function<C, T1> pa38298e8_75_1,
      StreamCodec<? super B, T2> pa38298e8_76_2,
      Function<C, T2> pa38298e8_77_3,
      StreamCodec<? super B, T3> pa38298e8_78_4,
      Function<C, T3> pa38298e8_79_5,
      StreamCodec<? super B, T4> pa38298e8_80_6,
      Function<C, T4> pa38298e8_81_7,
      StreamCodec<? super B, T5> pa38298e8_82_8,
      Function<C, T5> pa38298e8_83_9,
      StreamCodec<? super B, T6> pa38298e8_84_10,
      Function<C, T6> pa38298e8_85_11,
      StreamCodec<? super B, T7> pa38298e8_86_12,
      Function<C, T7> pa38298e8_87_13,
      StreamCodec<? super B, T8> pa38298e8_88_14,
      Function<C, T8> pa38298e8_89_15,
      Function8<T1, T2, T3, T4, T5, T6, T7, T8, C> pa38298e8_90_16
   ) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pdac06b5f_17_0) {
            T1 $$1 = pa38298e8_74_0.decode(pdac06b5f_17_0);
            T2 $$2 = pa38298e8_76_2.decode(pdac06b5f_17_0);
            T3 $$3 = pa38298e8_78_4.decode(pdac06b5f_17_0);
            T4 $$4 = pa38298e8_80_6.decode(pdac06b5f_17_0);
            T5 $$5 = pa38298e8_82_8.decode(pdac06b5f_17_0);
            T6 $$6 = pa38298e8_84_10.decode(pdac06b5f_17_0);
            T7 $$7 = pa38298e8_86_12.decode(pdac06b5f_17_0);
            T8 $$8 = pa38298e8_88_14.decode(pdac06b5f_17_0);
            return pa38298e8_90_16.apply($$1, $$2, $$3, $$4, $$5, $$6, $$7, $$8);
         }

         @Override
         public void encode(B pdac06b5f_18_0, C pdac06b5f_19_1) {
            pa38298e8_74_0.encode(pdac06b5f_18_0, pa38298e8_75_1.apply(pdac06b5f_19_1));
            pa38298e8_76_2.encode(pdac06b5f_18_0, pa38298e8_77_3.apply(pdac06b5f_19_1));
            pa38298e8_78_4.encode(pdac06b5f_18_0, pa38298e8_79_5.apply(pdac06b5f_19_1));
            pa38298e8_80_6.encode(pdac06b5f_18_0, pa38298e8_81_7.apply(pdac06b5f_19_1));
            pa38298e8_82_8.encode(pdac06b5f_18_0, pa38298e8_83_9.apply(pdac06b5f_19_1));
            pa38298e8_84_10.encode(pdac06b5f_18_0, pa38298e8_85_11.apply(pdac06b5f_19_1));
            pa38298e8_86_12.encode(pdac06b5f_18_0, pa38298e8_87_13.apply(pdac06b5f_19_1));
            pa38298e8_88_14.encode(pdac06b5f_18_0, pa38298e8_89_15.apply(pdac06b5f_19_1));
         }
      };
   }

   static <B, C, T1, T2, T3, T4, T5, T6, T7, T8, T9> StreamCodec<B, C> composite(
      StreamCodec<? super B, T1> pa38298e8_91_0,
      Function<C, T1> pa38298e8_92_1,
      StreamCodec<? super B, T2> pa38298e8_93_2,
      Function<C, T2> pa38298e8_94_3,
      StreamCodec<? super B, T3> pa38298e8_95_4,
      Function<C, T3> pa38298e8_96_5,
      StreamCodec<? super B, T4> pa38298e8_97_6,
      Function<C, T4> pa38298e8_98_7,
      StreamCodec<? super B, T5> pa38298e8_99_8,
      Function<C, T5> pa38298e8_100_9,
      StreamCodec<? super B, T6> pa38298e8_101_10,
      Function<C, T6> pa38298e8_102_11,
      StreamCodec<? super B, T7> pa38298e8_103_12,
      Function<C, T7> pa38298e8_104_13,
      StreamCodec<? super B, T8> pa38298e8_105_14,
      Function<C, T8> pa38298e8_106_15,
      StreamCodec<? super B, T9> pa38298e8_107_16,
      Function<C, T9> pa38298e8_108_17,
      Function9<T1, T2, T3, T4, T5, T6, T7, T8, T9, C> pa38298e8_109_18
   ) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pdac06b60_19_0) {
            T1 $$1 = pa38298e8_91_0.decode(pdac06b60_19_0);
            T2 $$2 = pa38298e8_93_2.decode(pdac06b60_19_0);
            T3 $$3 = pa38298e8_95_4.decode(pdac06b60_19_0);
            T4 $$4 = pa38298e8_97_6.decode(pdac06b60_19_0);
            T5 $$5 = pa38298e8_99_8.decode(pdac06b60_19_0);
            T6 $$6 = pa38298e8_101_10.decode(pdac06b60_19_0);
            T7 $$7 = pa38298e8_103_12.decode(pdac06b60_19_0);
            T8 $$8 = pa38298e8_105_14.decode(pdac06b60_19_0);
            T9 $$9 = pa38298e8_107_16.decode(pdac06b60_19_0);
            return pa38298e8_109_18.apply($$1, $$2, $$3, $$4, $$5, $$6, $$7, $$8, $$9);
         }

         @Override
         public void encode(B pdac06b60_20_0, C pdac06b60_21_1) {
            pa38298e8_91_0.encode(pdac06b60_20_0, pa38298e8_92_1.apply(pdac06b60_21_1));
            pa38298e8_93_2.encode(pdac06b60_20_0, pa38298e8_94_3.apply(pdac06b60_21_1));
            pa38298e8_95_4.encode(pdac06b60_20_0, pa38298e8_96_5.apply(pdac06b60_21_1));
            pa38298e8_97_6.encode(pdac06b60_20_0, pa38298e8_98_7.apply(pdac06b60_21_1));
            pa38298e8_99_8.encode(pdac06b60_20_0, pa38298e8_100_9.apply(pdac06b60_21_1));
            pa38298e8_101_10.encode(pdac06b60_20_0, pa38298e8_102_11.apply(pdac06b60_21_1));
            pa38298e8_103_12.encode(pdac06b60_20_0, pa38298e8_104_13.apply(pdac06b60_21_1));
            pa38298e8_105_14.encode(pdac06b60_20_0, pa38298e8_106_15.apply(pdac06b60_21_1));
            pa38298e8_107_16.encode(pdac06b60_20_0, pa38298e8_108_17.apply(pdac06b60_21_1));
         }
      };
   }

   static <B, C, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> StreamCodec<B, C> composite(
      StreamCodec<? super B, T1> pa38298e8_110_0,
      Function<C, T1> pa38298e8_111_1,
      StreamCodec<? super B, T2> pa38298e8_112_2,
      Function<C, T2> pa38298e8_113_3,
      StreamCodec<? super B, T3> pa38298e8_114_4,
      Function<C, T3> pa38298e8_115_5,
      StreamCodec<? super B, T4> pa38298e8_116_6,
      Function<C, T4> pa38298e8_117_7,
      StreamCodec<? super B, T5> pa38298e8_118_8,
      Function<C, T5> pa38298e8_119_9,
      StreamCodec<? super B, T6> pa38298e8_120_10,
      Function<C, T6> pa38298e8_121_11,
      StreamCodec<? super B, T7> pa38298e8_122_12,
      Function<C, T7> pa38298e8_123_13,
      StreamCodec<? super B, T8> pa38298e8_124_14,
      Function<C, T8> pa38298e8_125_15,
      StreamCodec<? super B, T9> pa38298e8_126_16,
      Function<C, T9> pa38298e8_127_17,
      StreamCodec<? super B, T10> pa38298e8_128_18,
      Function<C, T10> pa38298e8_129_19,
      Function10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, C> pa38298e8_130_20
   ) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pdac06b61_21_0) {
            T1 $$1 = pa38298e8_110_0.decode(pdac06b61_21_0);
            T2 $$2 = pa38298e8_112_2.decode(pdac06b61_21_0);
            T3 $$3 = pa38298e8_114_4.decode(pdac06b61_21_0);
            T4 $$4 = pa38298e8_116_6.decode(pdac06b61_21_0);
            T5 $$5 = pa38298e8_118_8.decode(pdac06b61_21_0);
            T6 $$6 = pa38298e8_120_10.decode(pdac06b61_21_0);
            T7 $$7 = pa38298e8_122_12.decode(pdac06b61_21_0);
            T8 $$8 = pa38298e8_124_14.decode(pdac06b61_21_0);
            T9 $$9 = pa38298e8_126_16.decode(pdac06b61_21_0);
            T10 $$10 = pa38298e8_128_18.decode(pdac06b61_21_0);
            return pa38298e8_130_20.apply($$1, $$2, $$3, $$4, $$5, $$6, $$7, $$8, $$9, $$10);
         }

         @Override
         public void encode(B pdac06b61_22_0, C pdac06b61_23_1) {
            pa38298e8_110_0.encode(pdac06b61_22_0, pa38298e8_111_1.apply(pdac06b61_23_1));
            pa38298e8_112_2.encode(pdac06b61_22_0, pa38298e8_113_3.apply(pdac06b61_23_1));
            pa38298e8_114_4.encode(pdac06b61_22_0, pa38298e8_115_5.apply(pdac06b61_23_1));
            pa38298e8_116_6.encode(pdac06b61_22_0, pa38298e8_117_7.apply(pdac06b61_23_1));
            pa38298e8_118_8.encode(pdac06b61_22_0, pa38298e8_119_9.apply(pdac06b61_23_1));
            pa38298e8_120_10.encode(pdac06b61_22_0, pa38298e8_121_11.apply(pdac06b61_23_1));
            pa38298e8_122_12.encode(pdac06b61_22_0, pa38298e8_123_13.apply(pdac06b61_23_1));
            pa38298e8_124_14.encode(pdac06b61_22_0, pa38298e8_125_15.apply(pdac06b61_23_1));
            pa38298e8_126_16.encode(pdac06b61_22_0, pa38298e8_127_17.apply(pdac06b61_23_1));
            pa38298e8_128_18.encode(pdac06b61_22_0, pa38298e8_129_19.apply(pdac06b61_23_1));
         }
      };
   }

   static <B, C, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> StreamCodec<B, C> composite(
      StreamCodec<? super B, T1> pa38298e8_131_0,
      Function<C, T1> pa38298e8_132_1,
      StreamCodec<? super B, T2> pa38298e8_133_2,
      Function<C, T2> pa38298e8_134_3,
      StreamCodec<? super B, T3> pa38298e8_135_4,
      Function<C, T3> pa38298e8_136_5,
      StreamCodec<? super B, T4> pa38298e8_137_6,
      Function<C, T4> pa38298e8_138_7,
      StreamCodec<? super B, T5> pa38298e8_139_8,
      Function<C, T5> pa38298e8_140_9,
      StreamCodec<? super B, T6> pa38298e8_141_10,
      Function<C, T6> pa38298e8_142_11,
      StreamCodec<? super B, T7> pa38298e8_143_12,
      Function<C, T7> pa38298e8_144_13,
      StreamCodec<? super B, T8> pa38298e8_145_14,
      Function<C, T8> pa38298e8_146_15,
      StreamCodec<? super B, T9> pa38298e8_147_16,
      Function<C, T9> pa38298e8_148_17,
      StreamCodec<? super B, T10> pa38298e8_149_18,
      Function<C, T10> pa38298e8_150_19,
      StreamCodec<? super B, T11> pa38298e8_151_20,
      Function<C, T11> pa38298e8_152_21,
      Function11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, C> pa38298e8_153_22
   ) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pdac06b62_23_0) {
            T1 $$1 = pa38298e8_131_0.decode(pdac06b62_23_0);
            T2 $$2 = pa38298e8_133_2.decode(pdac06b62_23_0);
            T3 $$3 = pa38298e8_135_4.decode(pdac06b62_23_0);
            T4 $$4 = pa38298e8_137_6.decode(pdac06b62_23_0);
            T5 $$5 = pa38298e8_139_8.decode(pdac06b62_23_0);
            T6 $$6 = pa38298e8_141_10.decode(pdac06b62_23_0);
            T7 $$7 = pa38298e8_143_12.decode(pdac06b62_23_0);
            T8 $$8 = pa38298e8_145_14.decode(pdac06b62_23_0);
            T9 $$9 = pa38298e8_147_16.decode(pdac06b62_23_0);
            T10 $$10 = pa38298e8_149_18.decode(pdac06b62_23_0);
            T11 $$11 = pa38298e8_151_20.decode(pdac06b62_23_0);
            return pa38298e8_153_22.apply($$1, $$2, $$3, $$4, $$5, $$6, $$7, $$8, $$9, $$10, $$11);
         }

         @Override
         public void encode(B pdac06b62_24_0, C pdac06b62_25_1) {
            pa38298e8_131_0.encode(pdac06b62_24_0, pa38298e8_132_1.apply(pdac06b62_25_1));
            pa38298e8_133_2.encode(pdac06b62_24_0, pa38298e8_134_3.apply(pdac06b62_25_1));
            pa38298e8_135_4.encode(pdac06b62_24_0, pa38298e8_136_5.apply(pdac06b62_25_1));
            pa38298e8_137_6.encode(pdac06b62_24_0, pa38298e8_138_7.apply(pdac06b62_25_1));
            pa38298e8_139_8.encode(pdac06b62_24_0, pa38298e8_140_9.apply(pdac06b62_25_1));
            pa38298e8_141_10.encode(pdac06b62_24_0, pa38298e8_142_11.apply(pdac06b62_25_1));
            pa38298e8_143_12.encode(pdac06b62_24_0, pa38298e8_144_13.apply(pdac06b62_25_1));
            pa38298e8_145_14.encode(pdac06b62_24_0, pa38298e8_146_15.apply(pdac06b62_25_1));
            pa38298e8_147_16.encode(pdac06b62_24_0, pa38298e8_148_17.apply(pdac06b62_25_1));
            pa38298e8_149_18.encode(pdac06b62_24_0, pa38298e8_150_19.apply(pdac06b62_25_1));
            pa38298e8_151_20.encode(pdac06b62_24_0, pa38298e8_152_21.apply(pdac06b62_25_1));
         }
      };
   }

   static <B, C, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> StreamCodec<B, C> composite(
      StreamCodec<? super B, T1> pa38298e8_154_0,
      Function<C, T1> pa38298e8_155_1,
      StreamCodec<? super B, T2> pa38298e8_156_2,
      Function<C, T2> pa38298e8_157_3,
      StreamCodec<? super B, T3> pa38298e8_158_4,
      Function<C, T3> pa38298e8_159_5,
      StreamCodec<? super B, T4> pa38298e8_160_6,
      Function<C, T4> pa38298e8_161_7,
      StreamCodec<? super B, T5> pa38298e8_162_8,
      Function<C, T5> pa38298e8_163_9,
      StreamCodec<? super B, T6> pa38298e8_164_10,
      Function<C, T6> pa38298e8_165_11,
      StreamCodec<? super B, T7> pa38298e8_166_12,
      Function<C, T7> pa38298e8_167_13,
      StreamCodec<? super B, T8> pa38298e8_168_14,
      Function<C, T8> pa38298e8_169_15,
      StreamCodec<? super B, T9> pa38298e8_170_16,
      Function<C, T9> pa38298e8_171_17,
      StreamCodec<? super B, T10> pa38298e8_172_18,
      Function<C, T10> pa38298e8_173_19,
      StreamCodec<? super B, T11> pa38298e8_174_20,
      Function<C, T11> pa38298e8_175_21,
      StreamCodec<? super B, T12> pa38298e8_176_22,
      Function<C, T12> pa38298e8_177_23,
      Function12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, C> pa38298e8_178_24
   ) {
      return new StreamCodec<B, C>() {
         @Override
         public C decode(B pdac06b63_25_0) {
            T1 $$1 = pa38298e8_154_0.decode(pdac06b63_25_0);
            T2 $$2 = pa38298e8_156_2.decode(pdac06b63_25_0);
            T3 $$3 = pa38298e8_158_4.decode(pdac06b63_25_0);
            T4 $$4 = pa38298e8_160_6.decode(pdac06b63_25_0);
            T5 $$5 = pa38298e8_162_8.decode(pdac06b63_25_0);
            T6 $$6 = pa38298e8_164_10.decode(pdac06b63_25_0);
            T7 $$7 = pa38298e8_166_12.decode(pdac06b63_25_0);
            T8 $$8 = pa38298e8_168_14.decode(pdac06b63_25_0);
            T9 $$9 = pa38298e8_170_16.decode(pdac06b63_25_0);
            T10 $$10 = pa38298e8_172_18.decode(pdac06b63_25_0);
            T11 $$11 = pa38298e8_174_20.decode(pdac06b63_25_0);
            T12 $$12 = pa38298e8_176_22.decode(pdac06b63_25_0);
            return pa38298e8_178_24.apply($$1, $$2, $$3, $$4, $$5, $$6, $$7, $$8, $$9, $$10, $$11, $$12);
         }

         @Override
         public void encode(B pdac06b63_26_0, C pdac06b63_27_1) {
            pa38298e8_154_0.encode(pdac06b63_26_0, pa38298e8_155_1.apply(pdac06b63_27_1));
            pa38298e8_156_2.encode(pdac06b63_26_0, pa38298e8_157_3.apply(pdac06b63_27_1));
            pa38298e8_158_4.encode(pdac06b63_26_0, pa38298e8_159_5.apply(pdac06b63_27_1));
            pa38298e8_160_6.encode(pdac06b63_26_0, pa38298e8_161_7.apply(pdac06b63_27_1));
            pa38298e8_162_8.encode(pdac06b63_26_0, pa38298e8_163_9.apply(pdac06b63_27_1));
            pa38298e8_164_10.encode(pdac06b63_26_0, pa38298e8_165_11.apply(pdac06b63_27_1));
            pa38298e8_166_12.encode(pdac06b63_26_0, pa38298e8_167_13.apply(pdac06b63_27_1));
            pa38298e8_168_14.encode(pdac06b63_26_0, pa38298e8_169_15.apply(pdac06b63_27_1));
            pa38298e8_170_16.encode(pdac06b63_26_0, pa38298e8_171_17.apply(pdac06b63_27_1));
            pa38298e8_172_18.encode(pdac06b63_26_0, pa38298e8_173_19.apply(pdac06b63_27_1));
            pa38298e8_174_20.encode(pdac06b63_26_0, pa38298e8_175_21.apply(pdac06b63_27_1));
            pa38298e8_176_22.encode(pdac06b63_26_0, pa38298e8_177_23.apply(pdac06b63_27_1));
         }
      };
   }

   static <B, T> StreamCodec<B, T> recursive(UnaryOperator<StreamCodec<B, T>> pa38298e8_179_0) {
      return new StreamCodec<B, T>() {
         private final Supplier<StreamCodec<B, T>> inner = Suppliers.memoize(() -> pa38298e8_179_0.apply(this));

         @Override
         public T decode(B pdac06b64_1_0) {
            return this.inner.get().decode(pdac06b64_1_0);
         }

         @Override
         public void encode(B pdac06b64_2_0, T pdac06b64_3_1) {
            this.inner.get().encode(pdac06b64_2_0, pdac06b64_3_1);
         }
      };
   }

   default <S extends B> StreamCodec<S, V> cast() {
      return (StreamCodec<S, V>) this;
   }

   @FunctionalInterface
   interface CodecOperation<B, S, T> {
      StreamCodec<B, T> apply(StreamCodec<B, S> var1);
   }
}
