package net.minecraft.network.codec;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.ImmutableMultimap.Builder;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonSyntaxException;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.Supplier;
import java.util.function.ToIntFunction;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.IdMap;
import net.minecraft.core.Registry;
import net.minecraft.core.UUIDUtil;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.EndTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.Utf8String;
import net.minecraft.network.VarInt;
import net.minecraft.network.VarLong;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.util.ARGB;
import net.minecraft.util.LenientJsonParser;
import net.minecraft.util.Mth;
import org.joml.Quaternionfc;
import org.joml.Vector3fc;

public interface ByteBufCodecs {
   int MAX_INITIAL_COLLECTION_SIZE = 65536;
   StreamCodec<ByteBuf, Boolean> BOOL = new StreamCodec<ByteBuf, Boolean>() {
      public Boolean decode(ByteBuf p15c0c547_0_0) {
         return p15c0c547_0_0.readBoolean();
      }

      public void encode(ByteBuf p15c0c547_1_0, Boolean p15c0c547_2_1) {
         p15c0c547_1_0.writeBoolean(p15c0c547_2_1);
      }
   };
   StreamCodec<ByteBuf, Byte> BYTE = new StreamCodec<ByteBuf, Byte>() {
      public Byte decode(ByteBuf p15c0c548_0_0) {
         return p15c0c548_0_0.readByte();
      }

      public void encode(ByteBuf p15c0c548_1_0, Byte p15c0c548_2_1) {
         p15c0c548_1_0.writeByte(p15c0c548_2_1);
      }
   };
   StreamCodec<ByteBuf, Float> ROTATION_BYTE = BYTE.map(Mth::unpackDegrees, Mth::packDegrees);
   StreamCodec<ByteBuf, Short> SHORT = new StreamCodec<ByteBuf, Short>() {
      public Short decode(ByteBuf p15c0c549_0_0) {
         return p15c0c549_0_0.readShort();
      }

      public void encode(ByteBuf p15c0c549_1_0, Short p15c0c549_2_1) {
         p15c0c549_1_0.writeShort(p15c0c549_2_1);
      }
   };
   StreamCodec<ByteBuf, Integer> UNSIGNED_SHORT = new StreamCodec<ByteBuf, Integer>() {
      public Integer decode(ByteBuf p15c0c54a_0_0) {
         return p15c0c54a_0_0.readUnsignedShort();
      }

      public void encode(ByteBuf p15c0c54a_1_0, Integer p15c0c54a_2_1) {
         p15c0c54a_1_0.writeShort(p15c0c54a_2_1);
      }
   };
   StreamCodec<ByteBuf, Integer> INT = new StreamCodec<ByteBuf, Integer>() {
      public Integer decode(ByteBuf p15c0c54b_0_0) {
         return p15c0c54b_0_0.readInt();
      }

      public void encode(ByteBuf p15c0c54b_1_0, Integer p15c0c54b_2_1) {
         p15c0c54b_1_0.writeInt(p15c0c54b_2_1);
      }
   };
   StreamCodec<ByteBuf, Integer> VAR_INT = new StreamCodec<ByteBuf, Integer>() {
      public Integer decode(ByteBuf p15c0c54c_0_0) {
         return VarInt.read(p15c0c54c_0_0);
      }

      public void encode(ByteBuf p15c0c54c_1_0, Integer p15c0c54c_2_1) {
         VarInt.write(p15c0c54c_1_0, p15c0c54c_2_1);
      }
   };
   StreamCodec<ByteBuf, OptionalInt> OPTIONAL_VAR_INT = VAR_INT.map(
      p828da73a_71_0 -> p828da73a_71_0 == 0 ? OptionalInt.empty() : OptionalInt.of(p828da73a_71_0 - 1),
      p828da73a_70_0 -> p828da73a_70_0.isPresent() ? p828da73a_70_0.getAsInt() + 1 : 0
   );
   StreamCodec<ByteBuf, Long> LONG = new StreamCodec<ByteBuf, Long>() {
      public Long decode(ByteBuf p15c0c54d_0_0) {
         return p15c0c54d_0_0.readLong();
      }

      public void encode(ByteBuf p15c0c54d_1_0, Long p15c0c54d_2_1) {
         p15c0c54d_1_0.writeLong(p15c0c54d_2_1);
      }
   };
   StreamCodec<ByteBuf, Long> VAR_LONG = new StreamCodec<ByteBuf, Long>() {
      public Long decode(ByteBuf p15c0c54e_0_0) {
         return VarLong.read(p15c0c54e_0_0);
      }

      public void encode(ByteBuf p15c0c54e_1_0, Long p15c0c54e_2_1) {
         VarLong.write(p15c0c54e_1_0, p15c0c54e_2_1);
      }
   };
   StreamCodec<ByteBuf, Float> FLOAT = new StreamCodec<ByteBuf, Float>() {
      public Float decode(ByteBuf p15c0c54f_0_0) {
         return p15c0c54f_0_0.readFloat();
      }

      public void encode(ByteBuf p15c0c54f_1_0, Float p15c0c54f_2_1) {
         p15c0c54f_1_0.writeFloat(p15c0c54f_2_1);
      }
   };
   StreamCodec<ByteBuf, Double> DOUBLE = new StreamCodec<ByteBuf, Double>() {
      public Double decode(ByteBuf pa257e3c9_0_0) {
         return pa257e3c9_0_0.readDouble();
      }

      public void encode(ByteBuf pa257e3c9_1_0, Double pa257e3c9_2_1) {
         pa257e3c9_1_0.writeDouble(pa257e3c9_2_1);
      }
   };
   StreamCodec<ByteBuf, byte[]> BYTE_ARRAY = new StreamCodec<ByteBuf, byte[]>() {
      public byte[] decode(ByteBuf pa257e3cb_0_0) {
         return FriendlyByteBuf.readByteArray(pa257e3cb_0_0);
      }

      public void encode(ByteBuf pa257e3cb_1_0, byte[] pa257e3cb_2_1) {
         FriendlyByteBuf.writeByteArray(pa257e3cb_1_0, pa257e3cb_2_1);
      }
   };
   StreamCodec<ByteBuf, long[]> LONG_ARRAY = new StreamCodec<ByteBuf, long[]>() {
      public long[] decode(ByteBuf pa257e3cc_0_0) {
         return FriendlyByteBuf.readLongArray(pa257e3cc_0_0);
      }

      public void encode(ByteBuf pa257e3cc_1_0, long[] pa257e3cc_2_1) {
         FriendlyByteBuf.writeLongArray(pa257e3cc_1_0, pa257e3cc_2_1);
      }
   };
   StreamCodec<ByteBuf, String> STRING_UTF8 = stringUtf8(32767);
   StreamCodec<ByteBuf, Tag> TAG = tagCodec(NbtAccounter::defaultQuota);
   StreamCodec<ByteBuf, Tag> TRUSTED_TAG = tagCodec(NbtAccounter::unlimitedHeap);
   StreamCodec<ByteBuf, CompoundTag> COMPOUND_TAG = compoundTagCodec(NbtAccounter::defaultQuota);
   StreamCodec<ByteBuf, CompoundTag> TRUSTED_COMPOUND_TAG = compoundTagCodec(NbtAccounter::unlimitedHeap);
   StreamCodec<ByteBuf, Optional<CompoundTag>> OPTIONAL_COMPOUND_TAG = new StreamCodec<ByteBuf, Optional<CompoundTag>>() {
      public Optional<CompoundTag> decode(ByteBuf pa257e3d2_0_0) {
         return Optional.ofNullable(FriendlyByteBuf.readNbt(pa257e3d2_0_0));
      }

      public void encode(ByteBuf pa257e3d2_1_0, Optional<CompoundTag> pa257e3d2_2_1) {
         FriendlyByteBuf.writeNbt(pa257e3d2_1_0, pa257e3d2_2_1.orElse(null));
      }
   };
   StreamCodec<ByteBuf, Vector3fc> VECTOR3F = new StreamCodec<ByteBuf, Vector3fc>() {
      public Vector3fc decode(ByteBuf pa257e3e8_0_0) {
         return FriendlyByteBuf.readVector3f(pa257e3e8_0_0);
      }

      public void encode(ByteBuf pa257e3e8_1_0, Vector3fc pa257e3e8_2_1) {
         FriendlyByteBuf.writeVector3f(pa257e3e8_1_0, pa257e3e8_2_1);
      }
   };
   StreamCodec<ByteBuf, Quaternionfc> QUATERNIONF = new StreamCodec<ByteBuf, Quaternionfc>() {
      public Quaternionfc decode(ByteBuf pa257e3e9_0_0) {
         return FriendlyByteBuf.readQuaternion(pa257e3e9_0_0);
      }

      public void encode(ByteBuf pa257e3e9_1_0, Quaternionfc pa257e3e9_2_1) {
         FriendlyByteBuf.writeQuaternion(pa257e3e9_1_0, pa257e3e9_2_1);
      }
   };
   StreamCodec<ByteBuf, Integer> CONTAINER_ID = new StreamCodec<ByteBuf, Integer>() {
      public Integer decode(ByteBuf pa257e3ea_0_0) {
         return FriendlyByteBuf.readContainerId(pa257e3ea_0_0);
      }

      public void encode(ByteBuf pa257e3ea_1_0, Integer pa257e3ea_2_1) {
         FriendlyByteBuf.writeContainerId(pa257e3ea_1_0, pa257e3ea_2_1);
      }
   };
   StreamCodec<ByteBuf, PropertyMap> GAME_PROFILE_PROPERTIES = new StreamCodec<ByteBuf, PropertyMap>() {
      public PropertyMap decode(ByteBuf pa257e409_0_0) {
         int $$1 = ByteBufCodecs.readCount(pa257e409_0_0, 16);
         Builder<String, Property> $$2 = ImmutableMultimap.builder();

         for (int $$3 = 0; $$3 < $$1; $$3++) {
            String $$4 = Utf8String.read(pa257e409_0_0, 64);
            String $$5 = Utf8String.read(pa257e409_0_0, 32767);
            String $$6 = FriendlyByteBuf.readNullable(pa257e409_0_0, pa257e409_8_0 -> Utf8String.read(pa257e409_8_0, 1024));
            Property $$7 = new Property($$4, $$5, $$6);
            $$2.put($$7.name(), $$7);
         }

         return new PropertyMap($$2.build());
      }

      public void encode(ByteBuf pa257e409_1_0, PropertyMap pa257e409_2_1) {
         ByteBufCodecs.writeCount(pa257e409_1_0, pa257e409_2_1.size(), 16);

         for (Property $$2 : pa257e409_2_1.values()) {
            Utf8String.write(pa257e409_1_0, $$2.name(), 64);
            Utf8String.write(pa257e409_1_0, $$2.value(), 32767);
            FriendlyByteBuf.writeNullable(
               pa257e409_1_0, $$2.signature(), (pa257e409_6_0, pa257e409_7_1) -> Utf8String.write(pa257e409_6_0, pa257e409_7_1, 1024)
            );
         }
      }
   };
   StreamCodec<ByteBuf, String> PLAYER_NAME = stringUtf8(16);
   StreamCodec<ByteBuf, GameProfile> GAME_PROFILE = StreamCodec.composite(
      UUIDUtil.STREAM_CODEC, GameProfile::id, PLAYER_NAME, GameProfile::name, GAME_PROFILE_PROPERTIES, GameProfile::properties, GameProfile::new
   );
   StreamCodec<ByteBuf, Integer> RGB_COLOR = new StreamCodec<ByteBuf, Integer>() {
      public Integer decode(ByteBuf pa257e40a_0_0) {
         return ARGB.color(pa257e40a_0_0.readByte() & 0xFF, pa257e40a_0_0.readByte() & 0xFF, pa257e40a_0_0.readByte() & 0xFF);
      }

      public void encode(ByteBuf pa257e40a_1_0, Integer pa257e40a_2_1) {
         pa257e40a_1_0.writeByte(ARGB.red(pa257e40a_2_1));
         pa257e40a_1_0.writeByte(ARGB.green(pa257e40a_2_1));
         pa257e40a_1_0.writeByte(ARGB.blue(pa257e40a_2_1));
      }
   };

   static StreamCodec<ByteBuf, byte[]> byteArray(int p828da73a_0_0) {
      return new StreamCodec<ByteBuf, byte[]>() {
         public byte[] decode(ByteBuf pa257e3ca_1_0) {
            return FriendlyByteBuf.readByteArray(pa257e3ca_1_0, p828da73a_0_0);
         }

         public void encode(ByteBuf pa257e3ca_2_0, byte[] pa257e3ca_3_1) {
            if (pa257e3ca_3_1.length > p828da73a_0_0) {
               throw new EncoderException("ByteArray with size " + pa257e3ca_3_1.length + " is bigger than allowed " + p828da73a_0_0);
            }

            FriendlyByteBuf.writeByteArray(pa257e3ca_2_0, pa257e3ca_3_1);
         }
      };
   }

   static StreamCodec<ByteBuf, String> stringUtf8(int p828da73a_1_0) {
      return new StreamCodec<ByteBuf, String>() {
         public String decode(ByteBuf pa257e3cd_1_0) {
            return Utf8String.read(pa257e3cd_1_0, p828da73a_1_0);
         }

         public void encode(ByteBuf pa257e3cd_2_0, String pa257e3cd_3_1) {
            Utf8String.write(pa257e3cd_2_0, pa257e3cd_3_1, p828da73a_1_0);
         }
      };
   }

   static StreamCodec<ByteBuf, Optional<Tag>> optionalTagCodec(Supplier<NbtAccounter> p828da73a_2_0) {
      return new StreamCodec<ByteBuf, Optional<Tag>>() {
         public Optional<Tag> decode(ByteBuf pa257e3ce_1_0) {
            return Optional.ofNullable(FriendlyByteBuf.readNbt(pa257e3ce_1_0, p828da73a_2_0.get()));
         }

         public void encode(ByteBuf pa257e3ce_2_0, Optional<Tag> pa257e3ce_3_1) {
            FriendlyByteBuf.writeNbt(pa257e3ce_2_0, pa257e3ce_3_1.orElse(null));
         }
      };
   }

   static StreamCodec<ByteBuf, Tag> tagCodec(Supplier<NbtAccounter> p828da73a_3_0) {
      return new StreamCodec<ByteBuf, Tag>() {
         public Tag decode(ByteBuf pa257e3cf_1_0) {
            Tag $$1 = FriendlyByteBuf.readNbt(pa257e3cf_1_0, p828da73a_3_0.get());
            if ($$1 == null) {
               throw new DecoderException("Expected non-null compound tag");
            } else {
               return $$1;
            }
         }

         public void encode(ByteBuf pa257e3cf_2_0, Tag pa257e3cf_3_1) {
            if (pa257e3cf_3_1 == EndTag.INSTANCE) {
               throw new EncoderException("Expected non-null compound tag");
            }

            FriendlyByteBuf.writeNbt(pa257e3cf_2_0, pa257e3cf_3_1);
         }
      };
   }

   static StreamCodec<ByteBuf, CompoundTag> compoundTagCodec(Supplier<NbtAccounter> p828da73a_4_0) {
      return tagCodec(p828da73a_4_0).map(p828da73a_69_0 -> {
         if (p828da73a_69_0 instanceof CompoundTag $$1) {
            return $$1;
         } else {
            throw new DecoderException("Not a compound tag: " + p828da73a_69_0);
         }
      }, p828da73a_68_0 -> (Tag)p828da73a_68_0);
   }

   static <T> StreamCodec<ByteBuf, T> fromCodecTrusted(Codec<T> p828da73a_5_0) {
      return fromCodec(p828da73a_5_0, NbtAccounter::unlimitedHeap);
   }

   static <T> StreamCodec<ByteBuf, T> fromCodec(Codec<T> p828da73a_6_0) {
      return fromCodec(p828da73a_6_0, NbtAccounter::defaultQuota);
   }

   static <T, B extends ByteBuf, V> StreamCodec.CodecOperation<B, T, V> fromCodec(DynamicOps<T> p828da73a_7_0, Codec<V> p828da73a_8_1) {
      return p828da73a_67_2 -> new StreamCodec<B, V>() {
         public V decode(B pa257e3d0_3_0) {
            T $$1 = (T)p828da73a_67_2.decode(pa257e3d0_3_0);
            return (V)p828da73a_8_1.parse(p828da73a_7_0, $$1)
               .getOrThrow(pa257e3d0_12_1 -> new DecoderException("Failed to decode: " + pa257e3d0_12_1 + " " + $$1));
         }

         public void encode(B pa257e3d0_4_0, V pa257e3d0_5_1) {
            T $$2 = (T)p828da73a_8_1.encodeStart(p828da73a_7_0, pa257e3d0_5_1)
               .getOrThrow(pa257e3d0_10_1 -> new EncoderException("Failed to encode: " + pa257e3d0_10_1 + " " + pa257e3d0_5_1));
            p828da73a_67_2.encode(pa257e3d0_4_0, $$2);
         }
      };
   }

   static <T> StreamCodec<ByteBuf, T> fromCodec(Codec<T> p828da73a_9_0, Supplier<NbtAccounter> p828da73a_10_1) {
      return tagCodec(p828da73a_10_1).apply(fromCodec(NbtOps.INSTANCE, p828da73a_9_0));
   }

   static <T> StreamCodec<RegistryFriendlyByteBuf, T> fromCodecWithRegistriesTrusted(Codec<T> p828da73a_11_0) {
      return fromCodecWithRegistries(p828da73a_11_0, NbtAccounter::unlimitedHeap);
   }

   static <T> StreamCodec<RegistryFriendlyByteBuf, T> fromCodecWithRegistries(Codec<T> p828da73a_12_0) {
      return fromCodecWithRegistries(p828da73a_12_0, NbtAccounter::defaultQuota);
   }

   static <T> StreamCodec<RegistryFriendlyByteBuf, T> fromCodecWithRegistries(Codec<T> p828da73a_13_0, Supplier<NbtAccounter> p828da73a_14_1) {
      final StreamCodec<ByteBuf, Tag> $$2 = tagCodec(p828da73a_14_1);
      return new StreamCodec<RegistryFriendlyByteBuf, T>() {
         public T decode(RegistryFriendlyByteBuf pa257e3d1_2_0) {
            Tag $$1 = $$2.decode(pa257e3d1_2_0);
            RegistryOps<Tag> $$2x = pa257e3d1_2_0.registryAccess().createSerializationContext(NbtOps.INSTANCE);
            return p828da73a_13_0.parse($$2x, $$1).getOrThrow(pa257e3d1_11_1 -> new DecoderException("Failed to decode: " + pa257e3d1_11_1 + " " + $$1));
         }

         public void encode(RegistryFriendlyByteBuf pa257e3d1_3_0, T pa257e3d1_4_1) {
            RegistryOps<Tag> $$2x = pa257e3d1_3_0.registryAccess().createSerializationContext(NbtOps.INSTANCE);
            Tag $$3 = p828da73a_13_0.encodeStart($$2x, pa257e3d1_4_1)
               .getOrThrow(pa257e3d1_9_1 -> new EncoderException("Failed to encode: " + pa257e3d1_9_1 + " " + pa257e3d1_4_1));
            $$2.encode(pa257e3d1_3_0, $$3);
         }
      };
   }

   static <B extends ByteBuf, V> StreamCodec<B, Optional<V>> optional(StreamCodec<? super B, V> p828da73a_15_0) {
      return new StreamCodec<B, Optional<V>>() {
         public Optional<V> decode(B pa257e3eb_1_0) {
            return pa257e3eb_1_0.readBoolean() ? Optional.of(p828da73a_15_0.decode(pa257e3eb_1_0)) : Optional.empty();
         }

         public void encode(B pa257e3eb_2_0, Optional<V> pa257e3eb_3_1) {
            if (pa257e3eb_3_1.isPresent()) {
               pa257e3eb_2_0.writeBoolean(true);
               p828da73a_15_0.encode(pa257e3eb_2_0, pa257e3eb_3_1.get());
            } else {
               pa257e3eb_2_0.writeBoolean(false);
            }
         }
      };
   }

   static int readCount(ByteBuf p828da73a_16_0, int p828da73a_17_1) {
      int $$2 = VarInt.read(p828da73a_16_0);
      if ($$2 > p828da73a_17_1) {
         throw new DecoderException($$2 + " elements exceeded max size of: " + p828da73a_17_1);
      } else {
         return $$2;
      }
   }

   static void writeCount(ByteBuf p828da73a_18_0, int p828da73a_19_1, int p828da73a_20_2) {
      if (p828da73a_19_1 > p828da73a_20_2) {
         throw new EncoderException(p828da73a_19_1 + " elements exceeded max size of: " + p828da73a_20_2);
      }

      VarInt.write(p828da73a_18_0, p828da73a_19_1);
   }

   static <B extends ByteBuf, V, C extends Collection<V>> StreamCodec<B, C> collection(IntFunction<C> p828da73a_21_0, StreamCodec<? super B, V> p828da73a_22_1) {
      return collection(p828da73a_21_0, p828da73a_22_1, Integer.MAX_VALUE);
   }

   static <B extends ByteBuf, V, C extends Collection<V>> StreamCodec<B, C> collection(
      IntFunction<C> p828da73a_23_0, StreamCodec<? super B, V> p828da73a_24_1, int p828da73a_25_2
   ) {
      return new StreamCodec<B, C>() {
         public C decode(B pa257e3ec_3_0) {
            int $$1 = ByteBufCodecs.readCount(pa257e3ec_3_0, p828da73a_25_2);
            C $$2 = p828da73a_23_0.apply(Math.min($$1, 65536));

            for (int $$3 = 0; $$3 < $$1; $$3++) {
               $$2.add(p828da73a_24_1.decode(pa257e3ec_3_0));
            }

            return $$2;
         }

         public void encode(B pa257e3ec_4_0, C pa257e3ec_5_1) {
            ByteBufCodecs.writeCount(pa257e3ec_4_0, pa257e3ec_5_1.size(), p828da73a_25_2);

            for (V $$2 : pa257e3ec_5_1) {
               p828da73a_24_1.encode(pa257e3ec_4_0, $$2);
            }
         }
      };
   }

   static <B extends ByteBuf, V, C extends Collection<V>> StreamCodec.CodecOperation<B, V, C> collection(IntFunction<C> p828da73a_26_0) {
      return p828da73a_64_1 -> collection(p828da73a_26_0, p828da73a_64_1);
   }

   static <B extends ByteBuf, V> StreamCodec.CodecOperation<B, V, List<V>> list() {
      return p828da73a_62_0 -> collection(ArrayList::new, p828da73a_62_0);
   }

   static <B extends ByteBuf, V> StreamCodec.CodecOperation<B, V, List<V>> list(int p828da73a_27_0) {
      return p828da73a_61_1 -> collection(ArrayList::new, p828da73a_61_1, p828da73a_27_0);
   }

   static <B extends ByteBuf, K, V, M extends Map<K, V>> StreamCodec<B, M> map(
      IntFunction<? extends M> p828da73a_28_0, StreamCodec<? super B, K> p828da73a_29_1, StreamCodec<? super B, V> p828da73a_30_2
   ) {
      return map(p828da73a_28_0, p828da73a_29_1, p828da73a_30_2, Integer.MAX_VALUE);
   }

   static <B extends ByteBuf, K, V, M extends Map<K, V>> StreamCodec<B, M> map(
      IntFunction<? extends M> p828da73a_31_0, StreamCodec<? super B, K> p828da73a_32_1, StreamCodec<? super B, V> p828da73a_33_2, int p828da73a_34_3
   ) {
      return new StreamCodec<B, M>() {
         public void encode(B pa257e3ed_4_0, M pa257e3ed_5_1) {
            ByteBufCodecs.writeCount(pa257e3ed_4_0, pa257e3ed_5_1.size(), p828da73a_34_3);
            pa257e3ed_5_1.forEach((pa257e3ed_13_3, pa257e3ed_14_4) -> {
               p828da73a_32_1.encode(pa257e3ed_4_0, (K)pa257e3ed_13_3);
               p828da73a_33_2.encode(pa257e3ed_4_0, (V)pa257e3ed_14_4);
            });
         }

         public M decode(B pa257e3ed_6_0) {
            int $$1 = ByteBufCodecs.readCount(pa257e3ed_6_0, p828da73a_34_3);
            M $$2 = (M)p828da73a_31_0.apply(Math.min($$1, 65536));

            for (int $$3 = 0; $$3 < $$1; $$3++) {
               K $$4 = p828da73a_32_1.decode(pa257e3ed_6_0);
               V $$5 = p828da73a_33_2.decode(pa257e3ed_6_0);
               $$2.put($$4, $$5);
            }

            return $$2;
         }
      };
   }

   static <B extends ByteBuf, L, R> StreamCodec<B, Either<L, R>> either(StreamCodec<? super B, L> p828da73a_35_0, StreamCodec<? super B, R> p828da73a_36_1) {
      return new StreamCodec<B, Either<L, R>>() {
         public Either<L, R> decode(B pa257e3ee_2_0) {
            return pa257e3ee_2_0.readBoolean() ? Either.left(p828da73a_35_0.decode(pa257e3ee_2_0)) : Either.right(p828da73a_36_1.decode(pa257e3ee_2_0));
         }

         public void encode(B pa257e3ee_3_0, Either<L, R> pa257e3ee_4_1) {
            pa257e3ee_4_1.ifLeft(pa257e3ee_13_2 -> {
               pa257e3ee_3_0.writeBoolean(true);
               p828da73a_35_0.encode(pa257e3ee_3_0, (L)pa257e3ee_13_2);
            }).ifRight(pa257e3ee_10_2 -> {
               pa257e3ee_3_0.writeBoolean(false);
               p828da73a_36_1.encode(pa257e3ee_3_0, (R)pa257e3ee_10_2);
            });
         }
      };
   }

   static <B extends ByteBuf, V> StreamCodec.CodecOperation<B, V, V> lengthPrefixed(int p828da73a_37_0, BiFunction<B, ByteBuf, B> p828da73a_38_1) {
      return p828da73a_59_2 -> new StreamCodec<B, V>() {
         public V decode(B pa257e3ef_3_0) {
            int $$1 = VarInt.read(pa257e3ef_3_0);
            if ($$1 > p828da73a_37_0) {
               throw new DecoderException("Buffer size " + $$1 + " is larger than allowed limit of " + p828da73a_37_0);
            }

            int $$2 = pa257e3ef_3_0.readerIndex();
            B $$3 = (B)((ByteBuf)p828da73a_38_1.apply(pa257e3ef_3_0, pa257e3ef_3_0.slice($$2, $$1)));
            pa257e3ef_3_0.readerIndex($$2 + $$1);
            return (V)p828da73a_59_2.decode($$3);
         }

         public void encode(B pa257e3ef_4_0, V pa257e3ef_5_1) {
            B $$2 = (B)((ByteBuf)p828da73a_38_1.apply(pa257e3ef_4_0, pa257e3ef_4_0.alloc().buffer()));

            try {
               p828da73a_59_2.encode($$2, pa257e3ef_5_1);
               int $$3 = $$2.readableBytes();
               if ($$3 > p828da73a_37_0) {
                  throw new EncoderException("Buffer size " + $$3 + " is  larger than allowed limit of " + p828da73a_37_0);
               }

               VarInt.write(pa257e3ef_4_0, $$3);
               pa257e3ef_4_0.writeBytes($$2);
            } finally {
               $$2.release();
            }
         }
      };
   }

   static <V> StreamCodec.CodecOperation<ByteBuf, V, V> lengthPrefixed(int p828da73a_39_0) {
      return lengthPrefixed(p828da73a_39_0, (p828da73a_55_0, p828da73a_56_1) -> p828da73a_56_1);
   }

   static <V> StreamCodec.CodecOperation<RegistryFriendlyByteBuf, V, V> registryFriendlyLengthPrefixed(int p828da73a_40_0) {
      return lengthPrefixed(p828da73a_40_0, (p828da73a_53_0, p828da73a_54_1) -> new RegistryFriendlyByteBuf(p828da73a_54_1, p828da73a_53_0.registryAccess()));
   }

   static <T> StreamCodec<ByteBuf, T> idMapper(IntFunction<T> p828da73a_41_0, ToIntFunction<T> p828da73a_42_1) {
      return new StreamCodec<ByteBuf, T>() {
         public T decode(ByteBuf pa257e3f0_2_0) {
            int $$1 = VarInt.read(pa257e3f0_2_0);
            return p828da73a_41_0.apply($$1);
         }

         public void encode(ByteBuf pa257e3f0_3_0, T pa257e3f0_4_1) {
            int $$2 = p828da73a_42_1.applyAsInt(pa257e3f0_4_1);
            VarInt.write(pa257e3f0_3_0, $$2);
         }
      };
   }

   static <T> StreamCodec<ByteBuf, T> idMapper(IdMap<T> p828da73a_43_0) {
      return idMapper(p828da73a_43_0::byIdOrThrow, p828da73a_43_0::getIdOrThrow);
   }

   private static <T, R> StreamCodec<RegistryFriendlyByteBuf, R> registry(
      ResourceKey<? extends Registry<T>> p828da73a_44_0, Function<Registry<T>, IdMap<R>> p828da73a_45_1
   ) {
      return new StreamCodec<RegistryFriendlyByteBuf, R>() {
         private IdMap<R> getRegistryOrThrow(RegistryFriendlyByteBuf pa257e3f1_2_0) {
            return p828da73a_45_1.apply(pa257e3f1_2_0.registryAccess().lookupOrThrow(p828da73a_44_0));
         }

         public R decode(RegistryFriendlyByteBuf pa257e3f1_3_0) {
            int $$1 = VarInt.read(pa257e3f1_3_0);
            return (R)this.getRegistryOrThrow(pa257e3f1_3_0).byIdOrThrow($$1);
         }

         public void encode(RegistryFriendlyByteBuf pa257e3f1_4_0, R pa257e3f1_5_1) {
            int $$2 = this.getRegistryOrThrow(pa257e3f1_4_0).getIdOrThrow(pa257e3f1_5_1);
            VarInt.write(pa257e3f1_4_0, $$2);
         }
      };
   }

   static <T> StreamCodec<RegistryFriendlyByteBuf, T> registry(ResourceKey<? extends Registry<T>> p828da73a_46_0) {
      return registry(p828da73a_46_0, p828da73a_52_0 -> p828da73a_52_0);
   }

   static <T> StreamCodec<RegistryFriendlyByteBuf, Holder<T>> holderRegistry(ResourceKey<? extends Registry<T>> p828da73a_47_0) {
      return registry(p828da73a_47_0, Registry::asHolderIdMap);
   }

   static <T> StreamCodec<RegistryFriendlyByteBuf, Holder<T>> holder(
      ResourceKey<? extends Registry<T>> p828da73a_48_0, StreamCodec<? super RegistryFriendlyByteBuf, T> p828da73a_49_1
   ) {
      return new StreamCodec<RegistryFriendlyByteBuf, Holder<T>>() {
         private static final int DIRECT_HOLDER_ID = 0;

         private IdMap<Holder<T>> getRegistryOrThrow(RegistryFriendlyByteBuf pa257e407_2_0) {
            return pa257e407_2_0.registryAccess().lookupOrThrow(p828da73a_48_0).asHolderIdMap();
         }

         public Holder<T> decode(RegistryFriendlyByteBuf pa257e407_3_0) {
            int $$1 = VarInt.read(pa257e407_3_0);
            return $$1 == 0 ? Holder.direct(p828da73a_49_1.decode(pa257e407_3_0)) : (Holder)this.getRegistryOrThrow(pa257e407_3_0).byIdOrThrow($$1 - 1);
         }

         public void encode(RegistryFriendlyByteBuf pa257e407_4_0, Holder<T> pa257e407_5_1) {
            switch (pa257e407_5_1.kind()) {
               case REFERENCE:
                  int $$2 = this.getRegistryOrThrow(pa257e407_4_0).getIdOrThrow(pa257e407_5_1);
                  VarInt.write(pa257e407_4_0, $$2 + 1);
                  break;
               case DIRECT:
                  VarInt.write(pa257e407_4_0, 0);
                  p828da73a_49_1.encode(pa257e407_4_0, pa257e407_5_1.value());
            }
         }
      };
   }

   static <T> StreamCodec<RegistryFriendlyByteBuf, HolderSet<T>> holderSet(ResourceKey<? extends Registry<T>> p828da73a_50_0) {
      return new StreamCodec<RegistryFriendlyByteBuf, HolderSet<T>>() {
         private static final int NAMED_SET = -1;
         private final StreamCodec<RegistryFriendlyByteBuf, Holder<T>> holderCodec = ByteBufCodecs.holderRegistry(p828da73a_50_0);

         public HolderSet<T> decode(RegistryFriendlyByteBuf pa257e408_1_0) {
            int $$1 = VarInt.read(pa257e408_1_0) - 1;
            if ($$1 == -1) {
               Registry<T> $$2 = pa257e408_1_0.registryAccess().lookupOrThrow(p828da73a_50_0);
               return $$2.get(TagKey.create(p828da73a_50_0, Identifier.STREAM_CODEC.decode(pa257e408_1_0))).orElseThrow();
            }

            List<Holder<T>> $$3 = new ArrayList<>(Math.min($$1, 65536));

            for (int $$4 = 0; $$4 < $$1; $$4++) {
               $$3.add(this.holderCodec.decode(pa257e408_1_0));
            }

            return HolderSet.direct($$3);
         }

         public void encode(RegistryFriendlyByteBuf pa257e408_2_0, HolderSet<T> pa257e408_3_1) {
            Optional<TagKey<T>> $$2 = pa257e408_3_1.unwrapKey();
            if ($$2.isPresent()) {
               VarInt.write(pa257e408_2_0, 0);
               Identifier.STREAM_CODEC.encode(pa257e408_2_0, $$2.get().location());
            } else {
               VarInt.write(pa257e408_2_0, pa257e408_3_1.size() + 1);

               for (Holder<T> $$3 : pa257e408_3_1) {
                  this.holderCodec.encode(pa257e408_2_0, $$3);
               }
            }
         }
      };
   }

   static StreamCodec<ByteBuf, JsonElement> lenientJson(int p828da73a_51_0) {
      return new StreamCodec<ByteBuf, JsonElement>() {
         private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();

         public JsonElement decode(ByteBuf pa257e40b_1_0) {
            String $$1 = Utf8String.read(pa257e40b_1_0, p828da73a_51_0);

            try {
               return LenientJsonParser.parse($$1);
            } catch (JsonSyntaxException $$2) {
               throw new DecoderException("Failed to parse JSON", $$2);
            }
         }

         public void encode(ByteBuf pa257e40b_2_0, JsonElement pa257e40b_3_1) {
            String $$2 = GSON.toJson(pa257e40b_3_1);
            Utf8String.write(pa257e40b_2_0, $$2, p828da73a_51_0);
         }
      };
   }
}
