package net.minecraft.network.codec;

import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.minecraft.network.VarInt;

public class IdDispatchCodec<B extends ByteBuf, V, T> implements StreamCodec<B, V> {
   private static final int UNKNOWN_TYPE = -1;
   private final Function<V, ? extends T> typeGetter;
   private final List<IdDispatchCodec.Entry<B, V, T>> byId;
   private final Object2IntMap<T> toId;

   IdDispatchCodec(Function<V, ? extends T> pab0dadd3_0_0, List<IdDispatchCodec.Entry<B, V, T>> pab0dadd3_1_1, Object2IntMap<T> pab0dadd3_2_2) {
      this.typeGetter = pab0dadd3_0_0;
      this.byId = pab0dadd3_1_1;
      this.toId = pab0dadd3_2_2;
   }

   public V decode(B pab0dadd3_3_0) {
      int $$1 = VarInt.read(pab0dadd3_3_0);
      if ($$1 >= 0 && $$1 < this.byId.size()) {
         IdDispatchCodec.Entry<B, V, T> $$2 = this.byId.get($$1);

         try {
            return (V)$$2.serializer.decode(pab0dadd3_3_0);
         } catch (Exception $$3) {
            if ($$3 instanceof IdDispatchCodec.DontDecorateException) {
               throw $$3;
            } else {
               throw new DecoderException("Failed to decode packet '" + $$2.type + "'", $$3);
            }
         }
      } else {
         throw new DecoderException("Received unknown packet id " + $$1);
      }
   }

   public void encode(B pab0dadd3_4_0, V pab0dadd3_5_1) {
      T $$2 = (T)this.typeGetter.apply(pab0dadd3_5_1);
      int $$3 = this.toId.getOrDefault($$2, -1);
      if ($$3 == -1) {
         throw new EncoderException("Sending unknown packet '" + $$2 + "'");
      }

      VarInt.write(pab0dadd3_4_0, $$3);
      IdDispatchCodec.Entry<B, V, T> $$4 = this.byId.get($$3);

      try {
         StreamCodec<? super B, V> $$5 = (StreamCodec<? super B, V>)$$4.serializer;
         $$5.encode(pab0dadd3_4_0, pab0dadd3_5_1);
      } catch (Exception $$6) {
         if ($$6 instanceof IdDispatchCodec.DontDecorateException) {
            throw $$6;
         } else {
            throw new EncoderException("Failed to encode packet '" + $$2 + "'", $$6);
         }
      }
   }

   public static <B extends ByteBuf, V, T> IdDispatchCodec.Builder<B, V, T> builder(Function<V, ? extends T> pab0dadd3_6_0) {
      return new IdDispatchCodec.Builder<>(pab0dadd3_6_0);
   }

   public static class Builder<B extends ByteBuf, V, T> {
      private final List<IdDispatchCodec.Entry<B, V, T>> entries = new ArrayList<>();
      private final Function<V, ? extends T> typeGetter;

      Builder(Function<V, ? extends T> pce1f01aa_0_0) {
         this.typeGetter = pce1f01aa_0_0;
      }

      public IdDispatchCodec.Builder<B, V, T> add(T pce1f01aa_1_0, StreamCodec<? super B, ? extends V> pce1f01aa_2_1) {
         this.entries.add(new IdDispatchCodec.Entry<>(pce1f01aa_2_1, pce1f01aa_1_0));
         return this;
      }

      public IdDispatchCodec<B, V, T> build() {
         Object2IntOpenHashMap<T> $$0 = new Object2IntOpenHashMap<>();
         $$0.defaultReturnValue(-2);

         for (IdDispatchCodec.Entry<B, V, T> $$1 : this.entries) {
            int $$2 = $$0.size();
            int $$3 = $$0.putIfAbsent($$1.type, $$2);
            if ($$3 != -2) {
               throw new IllegalStateException("Duplicate registration for type " + $$1.type);
            }
         }

         return new IdDispatchCodec<>(this.typeGetter, List.copyOf(this.entries), $$0);
      }
   }

   public interface DontDecorateException {
   }

   record Entry<B, V, T>(StreamCodec<? super B, ? extends V> serializer, T type) {
   }
}
