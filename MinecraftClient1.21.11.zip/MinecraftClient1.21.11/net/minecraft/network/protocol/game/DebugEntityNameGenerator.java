package net.minecraft.network.protocol.game;

import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Util;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public class DebugEntityNameGenerator {
   private static final String[] NAMES_FIRST_PART = new String[]{
      "Slim",
      "Far",
      "River",
      "Silly",
      "Fat",
      "Thin",
      "Fish",
      "Bat",
      "Dark",
      "Oak",
      "Sly",
      "Bush",
      "Zen",
      "Bark",
      "Cry",
      "Slack",
      "Soup",
      "Grim",
      "Hook",
      "Dirt",
      "Mud",
      "Sad",
      "Hard",
      "Crook",
      "Sneak",
      "Stink",
      "Weird",
      "Fire",
      "Soot",
      "Soft",
      "Rough",
      "Cling",
      "Scar"
   };
   private static final String[] NAMES_SECOND_PART = new String[]{
      "Fox",
      "Tail",
      "Jaw",
      "Whisper",
      "Twig",
      "Root",
      "Finder",
      "Nose",
      "Brow",
      "Blade",
      "Fry",
      "Seek",
      "Wart",
      "Tooth",
      "Foot",
      "Leaf",
      "Stone",
      "Fall",
      "Face",
      "Tongue",
      "Voice",
      "Lip",
      "Mouth",
      "Snail",
      "Toe",
      "Ear",
      "Hair",
      "Beard",
      "Shirt",
      "Fist"
   };

   public static String getEntityName(Entity pc9f2ea4d_0_0) {
      if (pc9f2ea4d_0_0 instanceof Player) {
         return pc9f2ea4d_0_0.getPlainTextName();
      }

      Component $$1 = pc9f2ea4d_0_0.getCustomName();
      return $$1 != null ? $$1.getString() : getEntityName(pc9f2ea4d_0_0.getUUID());
   }

   public static String getEntityName(UUID pc9f2ea4d_1_0) {
      RandomSource $$1 = getRandom(pc9f2ea4d_1_0);
      return getRandomString($$1, NAMES_FIRST_PART) + getRandomString($$1, NAMES_SECOND_PART);
   }

   private static String getRandomString(RandomSource pc9f2ea4d_2_0, String[] pc9f2ea4d_3_1) {
      return Util.getRandom(pc9f2ea4d_3_1, pc9f2ea4d_2_0);
   }

   private static RandomSource getRandom(UUID pc9f2ea4d_4_0) {
      return RandomSource.create(pc9f2ea4d_4_0.hashCode() >> 2);
   }
}
