package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;

public class ClientboundRotateHeadPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundRotateHeadPacket> STREAM_CODEC = Packet.codec(
      ClientboundRotateHeadPacket::write, ClientboundRotateHeadPacket::new
   );
   private final int entityId;
   private final byte yHeadRot;

   public ClientboundRotateHeadPacket(Entity p3083c8db_0_0, byte p3083c8db_1_1) {
      this.entityId = p3083c8db_0_0.getId();
      this.yHeadRot = p3083c8db_1_1;
   }

   private ClientboundRotateHeadPacket(FriendlyByteBuf p3083c8db_2_0) {
      this.entityId = p3083c8db_2_0.readVarInt();
      this.yHeadRot = p3083c8db_2_0.readByte();
   }

   private void write(FriendlyByteBuf p3083c8db_3_0) {
      p3083c8db_3_0.writeVarInt(this.entityId);
      p3083c8db_3_0.writeByte(this.yHeadRot);
   }

   @Override
   public PacketType<ClientboundRotateHeadPacket> type() {
      return GamePacketTypes.CLIENTBOUND_ROTATE_HEAD;
   }

   public void handle(ClientGamePacketListener p3083c8db_4_0) {
      p3083c8db_4_0.handleRotateMob(this);
   }

   public @Nullable Entity getEntity(Level p3083c8db_5_0) {
      return p3083c8db_5_0.getEntity(this.entityId);
   }

   public float getYHeadRot() {
      return Mth.unpackDegrees(this.yHeadRot);
   }
}
