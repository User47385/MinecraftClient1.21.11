package net.minecraft.network.protocol.game;

import it.unimi.dsi.fastutil.shorts.ShortSet;
import java.util.function.BiConsumer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunkSection;

public class ClientboundSectionBlocksUpdatePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSectionBlocksUpdatePacket> STREAM_CODEC = Packet.codec(
      ClientboundSectionBlocksUpdatePacket::write, ClientboundSectionBlocksUpdatePacket::new
   );
   private static final int POS_IN_SECTION_BITS = 12;
   private final SectionPos sectionPos;
   private final short[] positions;
   private final BlockState[] states;

   public ClientboundSectionBlocksUpdatePacket(SectionPos pa56d6f84_0_0, ShortSet pa56d6f84_1_1, LevelChunkSection pa56d6f84_2_2) {
      this.sectionPos = pa56d6f84_0_0;
      int $$3 = pa56d6f84_1_1.size();
      this.positions = new short[$$3];
      this.states = new BlockState[$$3];
      int $$4 = 0;

      for (short $$5 : pa56d6f84_1_1) {
         this.positions[$$4] = $$5;
         this.states[$$4] = pa56d6f84_2_2.getBlockState(SectionPos.sectionRelativeX($$5), SectionPos.sectionRelativeY($$5), SectionPos.sectionRelativeZ($$5));
         $$4++;
      }
   }

   private ClientboundSectionBlocksUpdatePacket(FriendlyByteBuf pa56d6f84_3_0) {
      this.sectionPos = SectionPos.STREAM_CODEC.decode(pa56d6f84_3_0);
      int $$1 = pa56d6f84_3_0.readVarInt();
      this.positions = new short[$$1];
      this.states = new BlockState[$$1];

      for (int $$2 = 0; $$2 < $$1; $$2++) {
         long $$3 = pa56d6f84_3_0.readVarLong();
         this.positions[$$2] = (short)($$3 & 4095L);
         this.states[$$2] = Block.BLOCK_STATE_REGISTRY.byId((int)($$3 >>> 12));
      }
   }

   private void write(FriendlyByteBuf pa56d6f84_4_0) {
      SectionPos.STREAM_CODEC.encode(pa56d6f84_4_0, this.sectionPos);
      pa56d6f84_4_0.writeVarInt(this.positions.length);

      for (int $$1 = 0; $$1 < this.positions.length; $$1++) {
         pa56d6f84_4_0.writeVarLong((long)Block.getId(this.states[$$1]) << 12 | this.positions[$$1]);
      }
   }

   @Override
   public PacketType<ClientboundSectionBlocksUpdatePacket> type() {
      return GamePacketTypes.CLIENTBOUND_SECTION_BLOCKS_UPDATE;
   }

   public void handle(ClientGamePacketListener pa56d6f84_5_0) {
      pa56d6f84_5_0.handleChunkBlocksUpdate(this);
   }

   public void runUpdates(BiConsumer<BlockPos, BlockState> pa56d6f84_6_0) {
      BlockPos.MutableBlockPos $$1 = new BlockPos.MutableBlockPos();

      for (int $$2 = 0; $$2 < this.positions.length; $$2++) {
         short $$3 = this.positions[$$2];
         $$1.set(this.sectionPos.relativeToBlockX($$3), this.sectionPos.relativeToBlockY($$3), this.sectionPos.relativeToBlockZ($$3));
         pa56d6f84_6_0.accept($$1, this.states[$$2]);
      }
   }
}
