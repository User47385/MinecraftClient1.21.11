package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundSource;
import org.jspecify.annotations.Nullable;

public class ClientboundStopSoundPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundStopSoundPacket> STREAM_CODEC = Packet.codec(
      ClientboundStopSoundPacket::write, ClientboundStopSoundPacket::new
   );
   private static final int HAS_SOURCE = 1;
   private static final int HAS_SOUND = 2;
   private final @Nullable Identifier name;
   private final @Nullable SoundSource source;

   public ClientboundStopSoundPacket(@Nullable Identifier pd31fcb7d_0_0, @Nullable SoundSource pd31fcb7d_1_1) {
      this.name = pd31fcb7d_0_0;
      this.source = pd31fcb7d_1_1;
   }

   private ClientboundStopSoundPacket(FriendlyByteBuf pd31fcb7d_2_0) {
      int $$1 = pd31fcb7d_2_0.readByte();
      if (($$1 & 1) > 0) {
         this.source = pd31fcb7d_2_0.readEnum(SoundSource.class);
      } else {
         this.source = null;
      }

      if (($$1 & 2) > 0) {
         this.name = pd31fcb7d_2_0.readIdentifier();
      } else {
         this.name = null;
      }
   }

   private void write(FriendlyByteBuf pd31fcb7d_3_0) {
      if (this.source != null) {
         if (this.name != null) {
            pd31fcb7d_3_0.writeByte(3);
            pd31fcb7d_3_0.writeEnum(this.source);
            pd31fcb7d_3_0.writeIdentifier(this.name);
         } else {
            pd31fcb7d_3_0.writeByte(1);
            pd31fcb7d_3_0.writeEnum(this.source);
         }
      } else if (this.name != null) {
         pd31fcb7d_3_0.writeByte(2);
         pd31fcb7d_3_0.writeIdentifier(this.name);
      } else {
         pd31fcb7d_3_0.writeByte(0);
      }
   }

   @Override
   public PacketType<ClientboundStopSoundPacket> type() {
      return GamePacketTypes.CLIENTBOUND_STOP_SOUND;
   }

   public void handle(ClientGamePacketListener pd31fcb7d_4_0) {
      pd31fcb7d_4_0.handleStopSoundEvent(this);
   }

   public @Nullable Identifier getName() {
      return this.name;
   }

   public @Nullable SoundSource getSource() {
      return this.source;
   }
}
