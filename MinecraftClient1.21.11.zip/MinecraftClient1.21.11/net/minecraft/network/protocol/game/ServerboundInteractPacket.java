package net.minecraft.network.protocol.game;

import java.util.function.Function;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

public class ServerboundInteractPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundInteractPacket> STREAM_CODEC = Packet.codec(
      ServerboundInteractPacket::write, ServerboundInteractPacket::new
   );
   private final int entityId;
   private final ServerboundInteractPacket.Action action;
   private final boolean usingSecondaryAction;
   static final ServerboundInteractPacket.Action ATTACK_ACTION = new ServerboundInteractPacket.Action() {
      @Override
      public ServerboundInteractPacket.ActionType getType() {
         return ServerboundInteractPacket.ActionType.ATTACK;
      }

      @Override
      public void dispatch(ServerboundInteractPacket.Handler p90d5798b_0_0) {
         p90d5798b_0_0.onAttack();
      }

      @Override
      public void write(FriendlyByteBuf p90d5798b_1_0) {
      }
   };

   private ServerboundInteractPacket(int pa90a9c7e_0_0, boolean pa90a9c7e_1_1, ServerboundInteractPacket.Action pa90a9c7e_2_2) {
      this.entityId = pa90a9c7e_0_0;
      this.action = pa90a9c7e_2_2;
      this.usingSecondaryAction = pa90a9c7e_1_1;
   }

   public static ServerboundInteractPacket createAttackPacket(Entity pa90a9c7e_3_0, boolean pa90a9c7e_4_1) {
      return new ServerboundInteractPacket(pa90a9c7e_3_0.getId(), pa90a9c7e_4_1, ATTACK_ACTION);
   }

   public static ServerboundInteractPacket createInteractionPacket(Entity pa90a9c7e_5_0, boolean pa90a9c7e_6_1, InteractionHand pa90a9c7e_7_2) {
      return new ServerboundInteractPacket(pa90a9c7e_5_0.getId(), pa90a9c7e_6_1, new ServerboundInteractPacket.InteractionAction(pa90a9c7e_7_2));
   }

   public static ServerboundInteractPacket createInteractionPacket(
      Entity pa90a9c7e_8_0, boolean pa90a9c7e_9_1, InteractionHand pa90a9c7e_10_2, Vec3 pa90a9c7e_11_3
   ) {
      return new ServerboundInteractPacket(
         pa90a9c7e_8_0.getId(), pa90a9c7e_9_1, new ServerboundInteractPacket.InteractionAtLocationAction(pa90a9c7e_10_2, pa90a9c7e_11_3)
      );
   }

   private ServerboundInteractPacket(FriendlyByteBuf pa90a9c7e_12_0) {
      this.entityId = pa90a9c7e_12_0.readVarInt();
      ServerboundInteractPacket.ActionType $$1 = pa90a9c7e_12_0.readEnum(ServerboundInteractPacket.ActionType.class);
      this.action = $$1.reader.apply(pa90a9c7e_12_0);
      this.usingSecondaryAction = pa90a9c7e_12_0.readBoolean();
   }

   private void write(FriendlyByteBuf pa90a9c7e_13_0) {
      pa90a9c7e_13_0.writeVarInt(this.entityId);
      pa90a9c7e_13_0.writeEnum(this.action.getType());
      this.action.write(pa90a9c7e_13_0);
      pa90a9c7e_13_0.writeBoolean(this.usingSecondaryAction);
   }

   @Override
   public PacketType<ServerboundInteractPacket> type() {
      return GamePacketTypes.SERVERBOUND_INTERACT;
   }

   public void handle(ServerGamePacketListener pa90a9c7e_14_0) {
      pa90a9c7e_14_0.handleInteract(this);
   }

   public @Nullable Entity getTarget(ServerLevel pa90a9c7e_15_0) {
      return pa90a9c7e_15_0.getEntityOrPart(this.entityId);
   }

   public boolean isUsingSecondaryAction() {
      return this.usingSecondaryAction;
   }

   public boolean isWithinRange(ServerPlayer pa90a9c7e_16_0, AABB pa90a9c7e_17_1, double pa90a9c7e_18_2) {
      return this.action.getType() == ServerboundInteractPacket.ActionType.ATTACK
         ? pa90a9c7e_16_0.isWithinAttackRange(pa90a9c7e_17_1, pa90a9c7e_18_2)
         : pa90a9c7e_16_0.isWithinEntityInteractionRange(pa90a9c7e_17_1, pa90a9c7e_18_2);
   }

   public void dispatch(ServerboundInteractPacket.Handler pa90a9c7e_19_0) {
      this.action.dispatch(pa90a9c7e_19_0);
   }

   interface Action {
      ServerboundInteractPacket.ActionType getType();

      void dispatch(ServerboundInteractPacket.Handler var1);

      void write(FriendlyByteBuf var1);
   }

   enum ActionType {
      INTERACT(ServerboundInteractPacket.InteractionAction::new),
      ATTACK(pc47be96_4_0 -> ServerboundInteractPacket.ATTACK_ACTION),
      INTERACT_AT(ServerboundInteractPacket.InteractionAtLocationAction::new);

      final Function<FriendlyByteBuf, ServerboundInteractPacket.Action> reader;

      ActionType(final Function<FriendlyByteBuf, ServerboundInteractPacket.Action> pc47be96_3_2) {
         this.reader = pc47be96_3_2;
      }
   }

   public interface Handler {
      void onInteraction(InteractionHand var1);

      void onInteraction(InteractionHand var1, Vec3 var2);

      void onAttack();
   }

   static class InteractionAction implements ServerboundInteractPacket.Action {
      private final InteractionHand hand;

      InteractionAction(InteractionHand p1e1ca822_0_0) {
         this.hand = p1e1ca822_0_0;
      }

      private InteractionAction(FriendlyByteBuf p1e1ca822_1_0) {
         this.hand = p1e1ca822_1_0.readEnum(InteractionHand.class);
      }

      @Override
      public ServerboundInteractPacket.ActionType getType() {
         return ServerboundInteractPacket.ActionType.INTERACT;
      }

      @Override
      public void dispatch(ServerboundInteractPacket.Handler p1e1ca822_2_0) {
         p1e1ca822_2_0.onInteraction(this.hand);
      }

      @Override
      public void write(FriendlyByteBuf p1e1ca822_3_0) {
         p1e1ca822_3_0.writeEnum(this.hand);
      }
   }

   static class InteractionAtLocationAction implements ServerboundInteractPacket.Action {
      private final InteractionHand hand;
      private final Vec3 location;

      InteractionAtLocationAction(InteractionHand p1a53644a_0_0, Vec3 p1a53644a_1_1) {
         this.hand = p1a53644a_0_0;
         this.location = p1a53644a_1_1;
      }

      private InteractionAtLocationAction(FriendlyByteBuf p1a53644a_2_0) {
         this.location = new Vec3(p1a53644a_2_0.readFloat(), p1a53644a_2_0.readFloat(), p1a53644a_2_0.readFloat());
         this.hand = p1a53644a_2_0.readEnum(InteractionHand.class);
      }

      @Override
      public ServerboundInteractPacket.ActionType getType() {
         return ServerboundInteractPacket.ActionType.INTERACT_AT;
      }

      @Override
      public void dispatch(ServerboundInteractPacket.Handler p1a53644a_3_0) {
         p1a53644a_3_0.onInteraction(this.hand, this.location);
      }

      @Override
      public void write(FriendlyByteBuf p1a53644a_4_0) {
         p1a53644a_4_0.writeFloat((float)this.location.x);
         p1a53644a_4_0.writeFloat((float)this.location.y);
         p1a53644a_4_0.writeFloat((float)this.location.z);
         p1a53644a_4_0.writeEnum(this.hand);
      }
   }
}
