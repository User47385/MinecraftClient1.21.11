package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ClientboundSetSimulationDistancePacket(int simulationDistance) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetSimulationDistancePacket> STREAM_CODEC = Packet.codec(
      ClientboundSetSimulationDistancePacket::write, ClientboundSetSimulationDistancePacket::new
   );

   private ClientboundSetSimulationDistancePacket(FriendlyByteBuf pb85eb7ae_0_0) {
      this(pb85eb7ae_0_0.readVarInt());
   }

   private void write(FriendlyByteBuf pb85eb7ae_2_0) {
      pb85eb7ae_2_0.writeVarInt(this.simulationDistance);
   }

   @Override
   public PacketType<ClientboundSetSimulationDistancePacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_SIMULATION_DISTANCE;
   }

   public void handle(ClientGamePacketListener pb85eb7ae_3_0) {
      pb85eb7ae_3_0.handleSetSimulationDistance(this);
   }
}
