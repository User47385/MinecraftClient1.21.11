package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundLevelEventPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundLevelEventPacket> STREAM_CODEC = Packet.codec(
      ClientboundLevelEventPacket::write, ClientboundLevelEventPacket::new
   );
   private final int type;
   private final BlockPos pos;
   private final int data;
   private final boolean globalEvent;

   public ClientboundLevelEventPacket(int p822fe836_0_0, BlockPos p822fe836_1_1, int p822fe836_2_2, boolean p822fe836_3_3) {
      this.type = p822fe836_0_0;
      this.pos = p822fe836_1_1.immutable();
      this.data = p822fe836_2_2;
      this.globalEvent = p822fe836_3_3;
   }

   private ClientboundLevelEventPacket(FriendlyByteBuf p822fe836_4_0) {
      this.type = p822fe836_4_0.readInt();
      this.pos = p822fe836_4_0.readBlockPos();
      this.data = p822fe836_4_0.readInt();
      this.globalEvent = p822fe836_4_0.readBoolean();
   }

   private void write(FriendlyByteBuf p822fe836_5_0) {
      p822fe836_5_0.writeInt(this.type);
      p822fe836_5_0.writeBlockPos(this.pos);
      p822fe836_5_0.writeInt(this.data);
      p822fe836_5_0.writeBoolean(this.globalEvent);
   }

   @Override
   public PacketType<ClientboundLevelEventPacket> type() {
      return GamePacketTypes.CLIENTBOUND_LEVEL_EVENT;
   }

   public void handle(ClientGamePacketListener p822fe836_6_0) {
      p822fe836_6_0.handleLevelEvent(this);
   }

   public boolean isGlobalEvent() {
      return this.globalEvent;
   }

   public int getType() {
      return this.type;
   }

   public int getData() {
      return this.data;
   }

   public BlockPos getPos() {
      return this.pos;
   }
}
