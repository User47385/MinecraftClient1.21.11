package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public class ClientboundSetEntityMotionPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetEntityMotionPacket> STREAM_CODEC = Packet.codec(
      ClientboundSetEntityMotionPacket::write, ClientboundSetEntityMotionPacket::new
   );
   private final int id;
   private final Vec3 movement;

   public ClientboundSetEntityMotionPacket(Entity p9f3eefcb_0_0) {
      this(p9f3eefcb_0_0.getId(), p9f3eefcb_0_0.getDeltaMovement());
   }

   public ClientboundSetEntityMotionPacket(int p9f3eefcb_1_0, Vec3 p9f3eefcb_2_1) {
      this.id = p9f3eefcb_1_0;
      this.movement = p9f3eefcb_2_1;
   }

   private ClientboundSetEntityMotionPacket(FriendlyByteBuf p9f3eefcb_3_0) {
      this.id = p9f3eefcb_3_0.readVarInt();
      this.movement = p9f3eefcb_3_0.readLpVec3();
   }

   private void write(FriendlyByteBuf p9f3eefcb_4_0) {
      p9f3eefcb_4_0.writeVarInt(this.id);
      p9f3eefcb_4_0.writeLpVec3(this.movement);
   }

   @Override
   public PacketType<ClientboundSetEntityMotionPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_ENTITY_MOTION;
   }

   public void handle(ClientGamePacketListener p9f3eefcb_5_0) {
      p9f3eefcb_5_0.handleSetEntityMotion(this);
   }

   public int getId() {
      return this.id;
   }

   public Vec3 getMovement() {
      return this.movement;
   }
}
