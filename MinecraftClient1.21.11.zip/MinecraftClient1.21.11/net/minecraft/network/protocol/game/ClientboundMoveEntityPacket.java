package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;

public abstract class ClientboundMoveEntityPacket implements Packet<ClientGamePacketListener> {
   protected final int entityId;
   protected final short xa;
   protected final short ya;
   protected final short za;
   protected final byte yRot;
   protected final byte xRot;
   protected final boolean onGround;
   protected final boolean hasRot;
   protected final boolean hasPos;

   protected ClientboundMoveEntityPacket(
      int p73296b54_0_0,
      short p73296b54_1_1,
      short p73296b54_2_2,
      short p73296b54_3_3,
      byte p73296b54_4_4,
      byte p73296b54_5_5,
      boolean p73296b54_6_6,
      boolean p73296b54_7_7,
      boolean p73296b54_8_8
   ) {
      this.entityId = p73296b54_0_0;
      this.xa = p73296b54_1_1;
      this.ya = p73296b54_2_2;
      this.za = p73296b54_3_3;
      this.yRot = p73296b54_4_4;
      this.xRot = p73296b54_5_5;
      this.onGround = p73296b54_6_6;
      this.hasRot = p73296b54_7_7;
      this.hasPos = p73296b54_8_8;
   }

   @Override
   public abstract PacketType<? extends ClientboundMoveEntityPacket> type();

   public void handle(ClientGamePacketListener p73296b54_9_0) {
      p73296b54_9_0.handleMoveEntity(this);
   }

   @Override
   public String toString() {
      return "Entity_" + super.toString();
   }

   public @Nullable Entity getEntity(Level p73296b54_10_0) {
      return p73296b54_10_0.getEntity(this.entityId);
   }

   public short getXa() {
      return this.xa;
   }

   public short getYa() {
      return this.ya;
   }

   public short getZa() {
      return this.za;
   }

   public float getYRot() {
      return Mth.unpackDegrees(this.yRot);
   }

   public float getXRot() {
      return Mth.unpackDegrees(this.xRot);
   }

   public boolean hasRotation() {
      return this.hasRot;
   }

   public boolean hasPosition() {
      return this.hasPos;
   }

   public boolean isOnGround() {
      return this.onGround;
   }

   public static class Pos extends ClientboundMoveEntityPacket {
      public static final StreamCodec<FriendlyByteBuf, ClientboundMoveEntityPacket.Pos> STREAM_CODEC = Packet.codec(
         ClientboundMoveEntityPacket.Pos::write, ClientboundMoveEntityPacket.Pos::read
      );

      public Pos(int p9f2d38e4_0_0, short p9f2d38e4_1_1, short p9f2d38e4_2_2, short p9f2d38e4_3_3, boolean p9f2d38e4_4_4) {
         super(p9f2d38e4_0_0, p9f2d38e4_1_1, p9f2d38e4_2_2, p9f2d38e4_3_3, (byte)0, (byte)0, p9f2d38e4_4_4, false, true);
      }

      private static ClientboundMoveEntityPacket.Pos read(FriendlyByteBuf p9f2d38e4_5_0) {
         int $$1 = p9f2d38e4_5_0.readVarInt();
         short $$2 = p9f2d38e4_5_0.readShort();
         short $$3 = p9f2d38e4_5_0.readShort();
         short $$4 = p9f2d38e4_5_0.readShort();
         boolean $$5 = p9f2d38e4_5_0.readBoolean();
         return new ClientboundMoveEntityPacket.Pos($$1, $$2, $$3, $$4, $$5);
      }

      private void write(FriendlyByteBuf p9f2d38e4_6_0) {
         p9f2d38e4_6_0.writeVarInt(this.entityId);
         p9f2d38e4_6_0.writeShort(this.xa);
         p9f2d38e4_6_0.writeShort(this.ya);
         p9f2d38e4_6_0.writeShort(this.za);
         p9f2d38e4_6_0.writeBoolean(this.onGround);
      }

      @Override
      public PacketType<ClientboundMoveEntityPacket.Pos> type() {
         return GamePacketTypes.CLIENTBOUND_MOVE_ENTITY_POS;
      }
   }

   public static class PosRot extends ClientboundMoveEntityPacket {
      public static final StreamCodec<FriendlyByteBuf, ClientboundMoveEntityPacket.PosRot> STREAM_CODEC = Packet.codec(
         ClientboundMoveEntityPacket.PosRot::write, ClientboundMoveEntityPacket.PosRot::read
      );

      public PosRot(
         int p8f90ae53_0_0, short p8f90ae53_1_1, short p8f90ae53_2_2, short p8f90ae53_3_3, byte p8f90ae53_4_4, byte p8f90ae53_5_5, boolean p8f90ae53_6_6
      ) {
         super(p8f90ae53_0_0, p8f90ae53_1_1, p8f90ae53_2_2, p8f90ae53_3_3, p8f90ae53_4_4, p8f90ae53_5_5, p8f90ae53_6_6, true, true);
      }

      private static ClientboundMoveEntityPacket.PosRot read(FriendlyByteBuf p8f90ae53_7_0) {
         int $$1 = p8f90ae53_7_0.readVarInt();
         short $$2 = p8f90ae53_7_0.readShort();
         short $$3 = p8f90ae53_7_0.readShort();
         short $$4 = p8f90ae53_7_0.readShort();
         byte $$5 = p8f90ae53_7_0.readByte();
         byte $$6 = p8f90ae53_7_0.readByte();
         boolean $$7 = p8f90ae53_7_0.readBoolean();
         return new ClientboundMoveEntityPacket.PosRot($$1, $$2, $$3, $$4, $$5, $$6, $$7);
      }

      private void write(FriendlyByteBuf p8f90ae53_8_0) {
         p8f90ae53_8_0.writeVarInt(this.entityId);
         p8f90ae53_8_0.writeShort(this.xa);
         p8f90ae53_8_0.writeShort(this.ya);
         p8f90ae53_8_0.writeShort(this.za);
         p8f90ae53_8_0.writeByte(this.yRot);
         p8f90ae53_8_0.writeByte(this.xRot);
         p8f90ae53_8_0.writeBoolean(this.onGround);
      }

      @Override
      public PacketType<ClientboundMoveEntityPacket.PosRot> type() {
         return GamePacketTypes.CLIENTBOUND_MOVE_ENTITY_POS_ROT;
      }
   }

   public static class Rot extends ClientboundMoveEntityPacket {
      public static final StreamCodec<FriendlyByteBuf, ClientboundMoveEntityPacket.Rot> STREAM_CODEC = Packet.codec(
         ClientboundMoveEntityPacket.Rot::write, ClientboundMoveEntityPacket.Rot::read
      );

      public Rot(int p9f2d4067_0_0, byte p9f2d4067_1_1, byte p9f2d4067_2_2, boolean p9f2d4067_3_3) {
         super(p9f2d4067_0_0, (short)0, (short)0, (short)0, p9f2d4067_1_1, p9f2d4067_2_2, p9f2d4067_3_3, true, false);
      }

      private static ClientboundMoveEntityPacket.Rot read(FriendlyByteBuf p9f2d4067_4_0) {
         int $$1 = p9f2d4067_4_0.readVarInt();
         byte $$2 = p9f2d4067_4_0.readByte();
         byte $$3 = p9f2d4067_4_0.readByte();
         boolean $$4 = p9f2d4067_4_0.readBoolean();
         return new ClientboundMoveEntityPacket.Rot($$1, $$2, $$3, $$4);
      }

      private void write(FriendlyByteBuf p9f2d4067_5_0) {
         p9f2d4067_5_0.writeVarInt(this.entityId);
         p9f2d4067_5_0.writeByte(this.yRot);
         p9f2d4067_5_0.writeByte(this.xRot);
         p9f2d4067_5_0.writeBoolean(this.onGround);
      }

      @Override
      public PacketType<ClientboundMoveEntityPacket.Rot> type() {
         return GamePacketTypes.CLIENTBOUND_MOVE_ENTITY_ROT;
      }
   }
}
