package net.minecraft.network.protocol.game;

import java.util.Optional;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;
import org.jspecify.annotations.Nullable;

public record CommonPlayerSpawnInfo(
   Holder<DimensionType> dimensionType,
   ResourceKey<Level> dimension,
   long seed,
   GameType gameType,
   @Nullable GameType previousGameType,
   boolean isDebug,
   boolean isFlat,
   Optional<GlobalPos> lastDeathLocation,
   int portalCooldown,
   int seaLevel
) {
   public CommonPlayerSpawnInfo(RegistryFriendlyByteBuf p1656ef22_0_0) {
      this(
         DimensionType.STREAM_CODEC.decode(p1656ef22_0_0),
         p1656ef22_0_0.readResourceKey(Registries.DIMENSION),
         p1656ef22_0_0.readLong(),
         GameType.byId(p1656ef22_0_0.readByte()),
         GameType.byNullableId(p1656ef22_0_0.readByte()),
         p1656ef22_0_0.readBoolean(),
         p1656ef22_0_0.readBoolean(),
         p1656ef22_0_0.readOptional(FriendlyByteBuf::readGlobalPos),
         p1656ef22_0_0.readVarInt(),
         p1656ef22_0_0.readVarInt()
      );
   }

   public void write(RegistryFriendlyByteBuf p1656ef22_11_0) {
      DimensionType.STREAM_CODEC.encode(p1656ef22_11_0, this.dimensionType);
      p1656ef22_11_0.writeResourceKey(this.dimension);
      p1656ef22_11_0.writeLong(this.seed);
      p1656ef22_11_0.writeByte(this.gameType.getId());
      p1656ef22_11_0.writeByte(GameType.getNullableId(this.previousGameType));
      p1656ef22_11_0.writeBoolean(this.isDebug);
      p1656ef22_11_0.writeBoolean(this.isFlat);
      p1656ef22_11_0.writeOptional(this.lastDeathLocation, FriendlyByteBuf::writeGlobalPos);
      p1656ef22_11_0.writeVarInt(this.portalCooldown);
      p1656ef22_11_0.writeVarInt(this.seaLevel);
   }
}
