package net.minecraft.network.protocol.game;

import io.netty.buffer.ByteBuf;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.IntFunction;
import net.minecraft.core.Vec3i;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.util.ByIdMap;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.waypoints.TrackedWaypoint;
import net.minecraft.world.waypoints.TrackedWaypointManager;
import net.minecraft.world.waypoints.Waypoint;
import net.minecraft.world.waypoints.WaypointManager;

public record ClientboundTrackedWaypointPacket(ClientboundTrackedWaypointPacket.Operation operation, TrackedWaypoint waypoint)
   implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundTrackedWaypointPacket> STREAM_CODEC = StreamCodec.composite(
      ClientboundTrackedWaypointPacket.Operation.STREAM_CODEC,
      ClientboundTrackedWaypointPacket::operation,
      TrackedWaypoint.STREAM_CODEC,
      ClientboundTrackedWaypointPacket::waypoint,
      ClientboundTrackedWaypointPacket::new
   );

   public static ClientboundTrackedWaypointPacket removeWaypoint(UUID p4eca061b_2_0) {
      return new ClientboundTrackedWaypointPacket(ClientboundTrackedWaypointPacket.Operation.UNTRACK, TrackedWaypoint.empty(p4eca061b_2_0));
   }

   public static ClientboundTrackedWaypointPacket addWaypointPosition(UUID p4eca061b_3_0, Waypoint.Icon p4eca061b_4_1, Vec3i p4eca061b_5_2) {
      return new ClientboundTrackedWaypointPacket(
         ClientboundTrackedWaypointPacket.Operation.TRACK, TrackedWaypoint.setPosition(p4eca061b_3_0, p4eca061b_4_1, p4eca061b_5_2)
      );
   }

   public static ClientboundTrackedWaypointPacket updateWaypointPosition(UUID p4eca061b_6_0, Waypoint.Icon p4eca061b_7_1, Vec3i p4eca061b_8_2) {
      return new ClientboundTrackedWaypointPacket(
         ClientboundTrackedWaypointPacket.Operation.UPDATE, TrackedWaypoint.setPosition(p4eca061b_6_0, p4eca061b_7_1, p4eca061b_8_2)
      );
   }

   public static ClientboundTrackedWaypointPacket addWaypointChunk(UUID p4eca061b_9_0, Waypoint.Icon p4eca061b_10_1, ChunkPos p4eca061b_11_2) {
      return new ClientboundTrackedWaypointPacket(
         ClientboundTrackedWaypointPacket.Operation.TRACK, TrackedWaypoint.setChunk(p4eca061b_9_0, p4eca061b_10_1, p4eca061b_11_2)
      );
   }

   public static ClientboundTrackedWaypointPacket updateWaypointChunk(UUID p4eca061b_12_0, Waypoint.Icon p4eca061b_13_1, ChunkPos p4eca061b_14_2) {
      return new ClientboundTrackedWaypointPacket(
         ClientboundTrackedWaypointPacket.Operation.UPDATE, TrackedWaypoint.setChunk(p4eca061b_12_0, p4eca061b_13_1, p4eca061b_14_2)
      );
   }

   public static ClientboundTrackedWaypointPacket addWaypointAzimuth(UUID p4eca061b_15_0, Waypoint.Icon p4eca061b_16_1, float p4eca061b_17_2) {
      return new ClientboundTrackedWaypointPacket(
         ClientboundTrackedWaypointPacket.Operation.TRACK, TrackedWaypoint.setAzimuth(p4eca061b_15_0, p4eca061b_16_1, p4eca061b_17_2)
      );
   }

   public static ClientboundTrackedWaypointPacket updateWaypointAzimuth(UUID p4eca061b_18_0, Waypoint.Icon p4eca061b_19_1, float p4eca061b_20_2) {
      return new ClientboundTrackedWaypointPacket(
         ClientboundTrackedWaypointPacket.Operation.UPDATE, TrackedWaypoint.setAzimuth(p4eca061b_18_0, p4eca061b_19_1, p4eca061b_20_2)
      );
   }

   @Override
   public PacketType<ClientboundTrackedWaypointPacket> type() {
      return GamePacketTypes.CLIENTBOUND_WAYPOINT;
   }

   public void handle(ClientGamePacketListener p4eca061b_21_0) {
      p4eca061b_21_0.handleWaypoint(this);
   }

   public void apply(TrackedWaypointManager p4eca061b_22_0) {
      this.operation.action.accept(p4eca061b_22_0, this.waypoint);
   }

   enum Operation {
      TRACK(WaypointManager::trackWaypoint),
      UNTRACK(WaypointManager::untrackWaypoint),
      UPDATE(WaypointManager::updateWaypoint);

      final BiConsumer<TrackedWaypointManager, TrackedWaypoint> action;
      public static final IntFunction<ClientboundTrackedWaypointPacket.Operation> BY_ID = ByIdMap.continuous(
         Enum::ordinal, values(), ByIdMap.OutOfBoundsStrategy.WRAP
      );
      public static final StreamCodec<ByteBuf, ClientboundTrackedWaypointPacket.Operation> STREAM_CODEC = ByteBufCodecs.idMapper(BY_ID, Enum::ordinal);

      Operation(final BiConsumer<TrackedWaypointManager, TrackedWaypoint> p1f7a3dfe_3_2) {
         this.action = p1f7a3dfe_3_2;
      }
   }
}
