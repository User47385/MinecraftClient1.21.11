package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.border.WorldBorder;

public class ClientboundSetBorderCenterPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetBorderCenterPacket> STREAM_CODEC = Packet.codec(
      ClientboundSetBorderCenterPacket::write, ClientboundSetBorderCenterPacket::new
   );
   private final double newCenterX;
   private final double newCenterZ;

   public ClientboundSetBorderCenterPacket(WorldBorder pa85833f3_0_0) {
      this.newCenterX = pa85833f3_0_0.getCenterX();
      this.newCenterZ = pa85833f3_0_0.getCenterZ();
   }

   private ClientboundSetBorderCenterPacket(FriendlyByteBuf pa85833f3_1_0) {
      this.newCenterX = pa85833f3_1_0.readDouble();
      this.newCenterZ = pa85833f3_1_0.readDouble();
   }

   private void write(FriendlyByteBuf pa85833f3_2_0) {
      pa85833f3_2_0.writeDouble(this.newCenterX);
      pa85833f3_2_0.writeDouble(this.newCenterZ);
   }

   @Override
   public PacketType<ClientboundSetBorderCenterPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_BORDER_CENTER;
   }

   public void handle(ClientGamePacketListener pa85833f3_3_0) {
      pa85833f3_3_0.handleSetBorderCenter(this);
   }

   public double getNewCenterZ() {
      return this.newCenterZ;
   }

   public double getNewCenterX() {
      return this.newCenterX;
   }
}
