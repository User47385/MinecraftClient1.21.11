package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ServerboundSelectBundleItemPacket(int slotId, int selectedItemIndex) implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundSelectBundleItemPacket> STREAM_CODEC = Packet.codec(
      ServerboundSelectBundleItemPacket::write, ServerboundSelectBundleItemPacket::new
   );

   private ServerboundSelectBundleItemPacket(FriendlyByteBuf p608c5ad9_0_0) {
      this(p608c5ad9_0_0.readVarInt(), p608c5ad9_0_0.readVarInt());
      if (this.selectedItemIndex < 0 && this.selectedItemIndex != -1) {
         throw new IllegalArgumentException("Invalid selectedItemIndex: " + this.selectedItemIndex);
      }
   }

   private void write(FriendlyByteBuf p608c5ad9_3_0) {
      p608c5ad9_3_0.writeVarInt(this.slotId);
      p608c5ad9_3_0.writeVarInt(this.selectedItemIndex);
   }

   @Override
   public PacketType<ServerboundSelectBundleItemPacket> type() {
      return GamePacketTypes.SERVERBOUND_BUNDLE_ITEM_SELECTED;
   }

   public void handle(ServerGamePacketListener p608c5ad9_4_0) {
      p608c5ad9_4_0.handleBundleItemSelectedPacket(this);
   }
}
