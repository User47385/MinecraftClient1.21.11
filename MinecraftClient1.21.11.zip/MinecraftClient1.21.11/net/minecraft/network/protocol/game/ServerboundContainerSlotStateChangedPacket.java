package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ServerboundContainerSlotStateChangedPacket(int slotId, int containerId, boolean newState) implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundContainerSlotStateChangedPacket> STREAM_CODEC = Packet.codec(
      ServerboundContainerSlotStateChangedPacket::write, ServerboundContainerSlotStateChangedPacket::new
   );

   private ServerboundContainerSlotStateChangedPacket(FriendlyByteBuf pac54adaa_0_0) {
      this(pac54adaa_0_0.readVarInt(), pac54adaa_0_0.readContainerId(), pac54adaa_0_0.readBoolean());
   }

   private void write(FriendlyByteBuf pac54adaa_4_0) {
      pac54adaa_4_0.writeVarInt(this.slotId);
      pac54adaa_4_0.writeContainerId(this.containerId);
      pac54adaa_4_0.writeBoolean(this.newState);
   }

   @Override
   public PacketType<ServerboundContainerSlotStateChangedPacket> type() {
      return GamePacketTypes.SERVERBOUND_CONTAINER_SLOT_STATE_CHANGED;
   }

   public void handle(ServerGamePacketListener pac54adaa_5_0) {
      pac54adaa_5_0.handleContainerSlotStateChanged(this);
   }
}
