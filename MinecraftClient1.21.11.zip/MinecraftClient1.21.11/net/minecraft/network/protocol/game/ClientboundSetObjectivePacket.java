package net.minecraft.network.protocol.game;

import java.util.Optional;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.chat.numbers.NumberFormat;
import net.minecraft.network.chat.numbers.NumberFormatTypes;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.criteria.ObjectiveCriteria;

public class ClientboundSetObjectivePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundSetObjectivePacket> STREAM_CODEC = Packet.codec(
      ClientboundSetObjectivePacket::write, ClientboundSetObjectivePacket::new
   );
   public static final int METHOD_ADD = 0;
   public static final int METHOD_REMOVE = 1;
   public static final int METHOD_CHANGE = 2;
   private final String objectiveName;
   private final Component displayName;
   private final ObjectiveCriteria.RenderType renderType;
   private final Optional<NumberFormat> numberFormat;
   private final int method;

   public ClientboundSetObjectivePacket(Objective pc592ef7_0_0, int pc592ef7_1_1) {
      this.objectiveName = pc592ef7_0_0.getName();
      this.displayName = pc592ef7_0_0.getDisplayName();
      this.renderType = pc592ef7_0_0.getRenderType();
      this.numberFormat = Optional.ofNullable(pc592ef7_0_0.numberFormat());
      this.method = pc592ef7_1_1;
   }

   private ClientboundSetObjectivePacket(RegistryFriendlyByteBuf pc592ef7_2_0) {
      this.objectiveName = pc592ef7_2_0.readUtf();
      this.method = pc592ef7_2_0.readByte();
      if (this.method != 0 && this.method != 2) {
         this.displayName = CommonComponents.EMPTY;
         this.renderType = ObjectiveCriteria.RenderType.INTEGER;
         this.numberFormat = Optional.empty();
      } else {
         this.displayName = ComponentSerialization.TRUSTED_STREAM_CODEC.decode(pc592ef7_2_0);
         this.renderType = pc592ef7_2_0.readEnum(ObjectiveCriteria.RenderType.class);
         this.numberFormat = NumberFormatTypes.OPTIONAL_STREAM_CODEC.decode(pc592ef7_2_0);
      }
   }

   private void write(RegistryFriendlyByteBuf pc592ef7_3_0) {
      pc592ef7_3_0.writeUtf(this.objectiveName);
      pc592ef7_3_0.writeByte(this.method);
      if (this.method == 0 || this.method == 2) {
         ComponentSerialization.TRUSTED_STREAM_CODEC.encode(pc592ef7_3_0, this.displayName);
         pc592ef7_3_0.writeEnum(this.renderType);
         NumberFormatTypes.OPTIONAL_STREAM_CODEC.encode(pc592ef7_3_0, this.numberFormat);
      }
   }

   @Override
   public PacketType<ClientboundSetObjectivePacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_OBJECTIVE;
   }

   public void handle(ClientGamePacketListener pc592ef7_4_0) {
      pc592ef7_4_0.handleAddObjective(this);
   }

   public String getObjectiveName() {
      return this.objectiveName;
   }

   public Component getDisplayName() {
      return this.displayName;
   }

   public int getMethod() {
      return this.method;
   }

   public ObjectiveCriteria.RenderType getRenderType() {
      return this.renderType;
   }

   public Optional<NumberFormat> getNumberFormat() {
      return this.numberFormat;
   }
}
