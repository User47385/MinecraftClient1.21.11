package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.border.WorldBorder;

public class ClientboundSetBorderWarningDistancePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetBorderWarningDistancePacket> STREAM_CODEC = Packet.codec(
      ClientboundSetBorderWarningDistancePacket::write, ClientboundSetBorderWarningDistancePacket::new
   );
   private final int warningBlocks;

   public ClientboundSetBorderWarningDistancePacket(WorldBorder paa755da3_0_0) {
      this.warningBlocks = paa755da3_0_0.getWarningBlocks();
   }

   private ClientboundSetBorderWarningDistancePacket(FriendlyByteBuf paa755da3_1_0) {
      this.warningBlocks = paa755da3_1_0.readVarInt();
   }

   private void write(FriendlyByteBuf paa755da3_2_0) {
      paa755da3_2_0.writeVarInt(this.warningBlocks);
   }

   @Override
   public PacketType<ClientboundSetBorderWarningDistancePacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_BORDER_WARNING_DISTANCE;
   }

   public void handle(ClientGamePacketListener paa755da3_3_0) {
      paa755da3_3_0.handleSetBorderWarningDistance(this);
   }

   public int getWarningBlocks() {
      return this.warningBlocks;
   }
}
