package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.Entity;

public class ClientboundAnimatePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundAnimatePacket> STREAM_CODEC = Packet.codec(
      ClientboundAnimatePacket::write, ClientboundAnimatePacket::new
   );
   public static final int SWING_MAIN_HAND = 0;
   public static final int WAKE_UP = 2;
   public static final int SWING_OFF_HAND = 3;
   public static final int CRITICAL_HIT = 4;
   public static final int MAGIC_CRITICAL_HIT = 5;
   private final int id;
   private final int action;

   public ClientboundAnimatePacket(Entity pb1d19f31_0_0, int pb1d19f31_1_1) {
      this.id = pb1d19f31_0_0.getId();
      this.action = pb1d19f31_1_1;
   }

   private ClientboundAnimatePacket(FriendlyByteBuf pb1d19f31_2_0) {
      this.id = pb1d19f31_2_0.readVarInt();
      this.action = pb1d19f31_2_0.readUnsignedByte();
   }

   private void write(FriendlyByteBuf pb1d19f31_3_0) {
      pb1d19f31_3_0.writeVarInt(this.id);
      pb1d19f31_3_0.writeByte(this.action);
   }

   @Override
   public PacketType<ClientboundAnimatePacket> type() {
      return GamePacketTypes.CLIENTBOUND_ANIMATE;
   }

   public void handle(ClientGamePacketListener pb1d19f31_4_0) {
      pb1d19f31_4_0.handleAnimate(this);
   }

   public int getId() {
      return this.id;
   }

   public int getAction() {
      return this.action;
   }
}
