package net.minecraft.network.protocol.game;

import com.google.common.collect.ImmutableList;
import java.util.Collection;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Team;
import org.jspecify.annotations.Nullable;

public class ClientboundSetPlayerTeamPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundSetPlayerTeamPacket> STREAM_CODEC = Packet.codec(
      ClientboundSetPlayerTeamPacket::write, ClientboundSetPlayerTeamPacket::new
   );
   private static final int METHOD_ADD = 0;
   private static final int METHOD_REMOVE = 1;
   private static final int METHOD_CHANGE = 2;
   private static final int METHOD_JOIN = 3;
   private static final int METHOD_LEAVE = 4;
   private static final int MAX_VISIBILITY_LENGTH = 40;
   private static final int MAX_COLLISION_LENGTH = 40;
   private final int method;
   private final String name;
   private final Collection<String> players;
   private final Optional<ClientboundSetPlayerTeamPacket.Parameters> parameters;

   private ClientboundSetPlayerTeamPacket(
      String pd8d741f0_0_0, int pd8d741f0_1_1, Optional<ClientboundSetPlayerTeamPacket.Parameters> pd8d741f0_2_2, Collection<String> pd8d741f0_3_3
   ) {
      this.name = pd8d741f0_0_0;
      this.method = pd8d741f0_1_1;
      this.parameters = pd8d741f0_2_2;
      this.players = ImmutableList.copyOf(pd8d741f0_3_3);
   }

   public static ClientboundSetPlayerTeamPacket createAddOrModifyPacket(PlayerTeam pd8d741f0_4_0, boolean pd8d741f0_5_1) {
      return new ClientboundSetPlayerTeamPacket(
         pd8d741f0_4_0.getName(),
         pd8d741f0_5_1 ? 0 : 2,
         Optional.of(new ClientboundSetPlayerTeamPacket.Parameters(pd8d741f0_4_0)),
         pd8d741f0_5_1 ? pd8d741f0_4_0.getPlayers() : ImmutableList.of()
      );
   }

   public static ClientboundSetPlayerTeamPacket createRemovePacket(PlayerTeam pd8d741f0_6_0) {
      return new ClientboundSetPlayerTeamPacket(pd8d741f0_6_0.getName(), 1, Optional.empty(), ImmutableList.of());
   }

   public static ClientboundSetPlayerTeamPacket createPlayerPacket(
      PlayerTeam pd8d741f0_7_0, String pd8d741f0_8_1, ClientboundSetPlayerTeamPacket.Action pd8d741f0_9_2
   ) {
      return new ClientboundSetPlayerTeamPacket(
         pd8d741f0_7_0.getName(), pd8d741f0_9_2 == ClientboundSetPlayerTeamPacket.Action.ADD ? 3 : 4, Optional.empty(), ImmutableList.of(pd8d741f0_8_1)
      );
   }

   private ClientboundSetPlayerTeamPacket(RegistryFriendlyByteBuf pd8d741f0_10_0) {
      this.name = pd8d741f0_10_0.readUtf();
      this.method = pd8d741f0_10_0.readByte();
      if (shouldHaveParameters(this.method)) {
         this.parameters = Optional.of(new ClientboundSetPlayerTeamPacket.Parameters(pd8d741f0_10_0));
      } else {
         this.parameters = Optional.empty();
      }

      if (shouldHavePlayerList(this.method)) {
         this.players = pd8d741f0_10_0.readList(FriendlyByteBuf::readUtf);
      } else {
         this.players = ImmutableList.of();
      }
   }

   private void write(RegistryFriendlyByteBuf pd8d741f0_11_0) {
      pd8d741f0_11_0.writeUtf(this.name);
      pd8d741f0_11_0.writeByte(this.method);
      if (shouldHaveParameters(this.method)) {
         this.parameters.orElseThrow(() -> new IllegalStateException("Parameters not present, but method is" + this.method)).write(pd8d741f0_11_0);
      }

      if (shouldHavePlayerList(this.method)) {
         pd8d741f0_11_0.writeCollection(this.players, FriendlyByteBuf::writeUtf);
      }
   }

   private static boolean shouldHavePlayerList(int pd8d741f0_12_0) {
      return pd8d741f0_12_0 == 0 || pd8d741f0_12_0 == 3 || pd8d741f0_12_0 == 4;
   }

   private static boolean shouldHaveParameters(int pd8d741f0_13_0) {
      return pd8d741f0_13_0 == 0 || pd8d741f0_13_0 == 2;
   }

   public ClientboundSetPlayerTeamPacket.@Nullable Action getPlayerAction() {
      return switch (this.method) {
         case 0, 3 -> ClientboundSetPlayerTeamPacket.Action.ADD;
         default -> null;
         case 4 -> ClientboundSetPlayerTeamPacket.Action.REMOVE;
      };
   }

   public ClientboundSetPlayerTeamPacket.@Nullable Action getTeamAction() {
      return switch (this.method) {
         case 0 -> ClientboundSetPlayerTeamPacket.Action.ADD;
         case 1 -> ClientboundSetPlayerTeamPacket.Action.REMOVE;
         default -> null;
      };
   }

   @Override
   public PacketType<ClientboundSetPlayerTeamPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_PLAYER_TEAM;
   }

   public void handle(ClientGamePacketListener pd8d741f0_14_0) {
      pd8d741f0_14_0.handleSetPlayerTeamPacket(this);
   }

   public String getName() {
      return this.name;
   }

   public Collection<String> getPlayers() {
      return this.players;
   }

   public Optional<ClientboundSetPlayerTeamPacket.Parameters> getParameters() {
      return this.parameters;
   }

   public enum Action {
      ADD,
      REMOVE;
   }

   public static class Parameters {
      private final Component displayName;
      private final Component playerPrefix;
      private final Component playerSuffix;
      private final Team.Visibility nametagVisibility;
      private final Team.CollisionRule collisionRule;
      private final ChatFormatting color;
      private final int options;

      public Parameters(PlayerTeam pdea3e93e_0_0) {
         this.displayName = pdea3e93e_0_0.getDisplayName();
         this.options = pdea3e93e_0_0.packOptions();
         this.nametagVisibility = pdea3e93e_0_0.getNameTagVisibility();
         this.collisionRule = pdea3e93e_0_0.getCollisionRule();
         this.color = pdea3e93e_0_0.getColor();
         this.playerPrefix = pdea3e93e_0_0.getPlayerPrefix();
         this.playerSuffix = pdea3e93e_0_0.getPlayerSuffix();
      }

      public Parameters(RegistryFriendlyByteBuf pdea3e93e_1_0) {
         this.displayName = ComponentSerialization.TRUSTED_STREAM_CODEC.decode(pdea3e93e_1_0);
         this.options = pdea3e93e_1_0.readByte();
         this.nametagVisibility = Team.Visibility.STREAM_CODEC.decode(pdea3e93e_1_0);
         this.collisionRule = Team.CollisionRule.STREAM_CODEC.decode(pdea3e93e_1_0);
         this.color = pdea3e93e_1_0.readEnum(ChatFormatting.class);
         this.playerPrefix = ComponentSerialization.TRUSTED_STREAM_CODEC.decode(pdea3e93e_1_0);
         this.playerSuffix = ComponentSerialization.TRUSTED_STREAM_CODEC.decode(pdea3e93e_1_0);
      }

      public Component getDisplayName() {
         return this.displayName;
      }

      public int getOptions() {
         return this.options;
      }

      public ChatFormatting getColor() {
         return this.color;
      }

      public Team.Visibility getNametagVisibility() {
         return this.nametagVisibility;
      }

      public Team.CollisionRule getCollisionRule() {
         return this.collisionRule;
      }

      public Component getPlayerPrefix() {
         return this.playerPrefix;
      }

      public Component getPlayerSuffix() {
         return this.playerSuffix;
      }

      public void write(RegistryFriendlyByteBuf pdea3e93e_2_0) {
         ComponentSerialization.TRUSTED_STREAM_CODEC.encode(pdea3e93e_2_0, this.displayName);
         pdea3e93e_2_0.writeByte(this.options);
         Team.Visibility.STREAM_CODEC.encode(pdea3e93e_2_0, this.nametagVisibility);
         Team.CollisionRule.STREAM_CODEC.encode(pdea3e93e_2_0, this.collisionRule);
         pdea3e93e_2_0.writeEnum(this.color);
         ComponentSerialization.TRUSTED_STREAM_CODEC.encode(pdea3e93e_2_0, this.playerPrefix);
         ComponentSerialization.TRUSTED_STREAM_CODEC.encode(pdea3e93e_2_0, this.playerSuffix);
      }
   }
}
