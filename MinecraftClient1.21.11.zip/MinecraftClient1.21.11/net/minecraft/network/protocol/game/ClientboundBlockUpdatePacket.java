package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class ClientboundBlockUpdatePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundBlockUpdatePacket> STREAM_CODEC = StreamCodec.composite(
      BlockPos.STREAM_CODEC,
      ClientboundBlockUpdatePacket::getPos,
      ByteBufCodecs.idMapper(Block.BLOCK_STATE_REGISTRY),
      ClientboundBlockUpdatePacket::getBlockState,
      ClientboundBlockUpdatePacket::new
   );
   private final BlockPos pos;
   private final BlockState blockState;

   public ClientboundBlockUpdatePacket(BlockPos p5ca4d046_0_0, BlockState p5ca4d046_1_1) {
      this.pos = p5ca4d046_0_0;
      this.blockState = p5ca4d046_1_1;
   }

   public ClientboundBlockUpdatePacket(BlockGetter p5ca4d046_2_0, BlockPos p5ca4d046_3_1) {
      this(p5ca4d046_3_1, p5ca4d046_2_0.getBlockState(p5ca4d046_3_1));
   }

   @Override
   public PacketType<ClientboundBlockUpdatePacket> type() {
      return GamePacketTypes.CLIENTBOUND_BLOCK_UPDATE;
   }

   public void handle(ClientGamePacketListener p5ca4d046_4_0) {
      p5ca4d046_4_0.handleBlockUpdate(this);
   }

   public BlockState getBlockState() {
      return this.blockState;
   }

   public BlockPos getPos() {
      return this.pos;
   }
}
