package net.minecraft.network.protocol.game;

import java.util.Objects;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import org.jspecify.annotations.Nullable;

public class ClientboundSetDisplayObjectivePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetDisplayObjectivePacket> STREAM_CODEC = Packet.codec(
      ClientboundSetDisplayObjectivePacket::write, ClientboundSetDisplayObjectivePacket::new
   );
   private final DisplaySlot slot;
   private final String objectiveName;

   public ClientboundSetDisplayObjectivePacket(DisplaySlot p75457d69_0_0, @Nullable Objective p75457d69_1_1) {
      this.slot = p75457d69_0_0;
      if (p75457d69_1_1 == null) {
         this.objectiveName = "";
      } else {
         this.objectiveName = p75457d69_1_1.getName();
      }
   }

   private ClientboundSetDisplayObjectivePacket(FriendlyByteBuf p75457d69_2_0) {
      this.slot = p75457d69_2_0.readById(DisplaySlot.BY_ID);
      this.objectiveName = p75457d69_2_0.readUtf();
   }

   private void write(FriendlyByteBuf p75457d69_3_0) {
      p75457d69_3_0.writeById(DisplaySlot::id, this.slot);
      p75457d69_3_0.writeUtf(this.objectiveName);
   }

   @Override
   public PacketType<ClientboundSetDisplayObjectivePacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_DISPLAY_OBJECTIVE;
   }

   public void handle(ClientGamePacketListener p75457d69_4_0) {
      p75457d69_4_0.handleSetDisplayObjective(this);
   }

   public DisplaySlot getSlot() {
      return this.slot;
   }

   public @Nullable String getObjectiveName() {
      return Objects.equals(this.objectiveName, "") ? null : this.objectiveName;
   }
}
