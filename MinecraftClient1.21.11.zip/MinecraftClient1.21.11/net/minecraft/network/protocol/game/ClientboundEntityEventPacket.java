package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;

public class ClientboundEntityEventPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundEntityEventPacket> STREAM_CODEC = Packet.codec(
      ClientboundEntityEventPacket::write, ClientboundEntityEventPacket::new
   );
   private final int entityId;
   private final byte eventId;

   public ClientboundEntityEventPacket(Entity pbbe08447_0_0, byte pbbe08447_1_1) {
      this.entityId = pbbe08447_0_0.getId();
      this.eventId = pbbe08447_1_1;
   }

   private ClientboundEntityEventPacket(FriendlyByteBuf pbbe08447_2_0) {
      this.entityId = pbbe08447_2_0.readInt();
      this.eventId = pbbe08447_2_0.readByte();
   }

   private void write(FriendlyByteBuf pbbe08447_3_0) {
      pbbe08447_3_0.writeInt(this.entityId);
      pbbe08447_3_0.writeByte(this.eventId);
   }

   @Override
   public PacketType<ClientboundEntityEventPacket> type() {
      return GamePacketTypes.CLIENTBOUND_ENTITY_EVENT;
   }

   public void handle(ClientGamePacketListener pbbe08447_4_0) {
      pbbe08447_4_0.handleEntityEvent(this);
   }

   public @Nullable Entity getEntity(Level pbbe08447_5_0) {
      return pbbe08447_5_0.getEntity(this.entityId);
   }

   public byte getEventId() {
      return this.eventId;
   }
}
