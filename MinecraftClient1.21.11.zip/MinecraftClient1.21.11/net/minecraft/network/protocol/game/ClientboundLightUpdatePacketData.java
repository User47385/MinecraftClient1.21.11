package net.minecraft.network.protocol.game;

import com.google.common.collect.Lists;
import io.netty.buffer.ByteBuf;
import java.util.BitSet;
import java.util.List;
import net.minecraft.core.SectionPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.chunk.DataLayer;
import net.minecraft.world.level.lighting.LevelLightEngine;
import org.jspecify.annotations.Nullable;

public class ClientboundLightUpdatePacketData {
   private static final StreamCodec<ByteBuf, byte[]> DATA_LAYER_STREAM_CODEC = ByteBufCodecs.byteArray(2048);
   private final BitSet skyYMask;
   private final BitSet blockYMask;
   private final BitSet emptySkyYMask;
   private final BitSet emptyBlockYMask;
   private final List<byte[]> skyUpdates;
   private final List<byte[]> blockUpdates;

   public ClientboundLightUpdatePacketData(
      ChunkPos pe84adf99_0_0, LevelLightEngine pe84adf99_1_1, @Nullable BitSet pe84adf99_2_2, @Nullable BitSet pe84adf99_3_3
   ) {
      this.skyYMask = new BitSet();
      this.blockYMask = new BitSet();
      this.emptySkyYMask = new BitSet();
      this.emptyBlockYMask = new BitSet();
      this.skyUpdates = Lists.newArrayList();
      this.blockUpdates = Lists.newArrayList();

      for (int $$4 = 0; $$4 < pe84adf99_1_1.getLightSectionCount(); $$4++) {
         if (pe84adf99_2_2 == null || pe84adf99_2_2.get($$4)) {
            this.prepareSectionData(pe84adf99_0_0, pe84adf99_1_1, LightLayer.SKY, $$4, this.skyYMask, this.emptySkyYMask, this.skyUpdates);
         }

         if (pe84adf99_3_3 == null || pe84adf99_3_3.get($$4)) {
            this.prepareSectionData(pe84adf99_0_0, pe84adf99_1_1, LightLayer.BLOCK, $$4, this.blockYMask, this.emptyBlockYMask, this.blockUpdates);
         }
      }
   }

   public ClientboundLightUpdatePacketData(FriendlyByteBuf pe84adf99_4_0, int pe84adf99_5_1, int pe84adf99_6_2) {
      this.skyYMask = pe84adf99_4_0.readBitSet();
      this.blockYMask = pe84adf99_4_0.readBitSet();
      this.emptySkyYMask = pe84adf99_4_0.readBitSet();
      this.emptyBlockYMask = pe84adf99_4_0.readBitSet();
      this.skyUpdates = pe84adf99_4_0.readList(DATA_LAYER_STREAM_CODEC);
      this.blockUpdates = pe84adf99_4_0.readList(DATA_LAYER_STREAM_CODEC);
   }

   public void write(FriendlyByteBuf pe84adf99_7_0) {
      pe84adf99_7_0.writeBitSet(this.skyYMask);
      pe84adf99_7_0.writeBitSet(this.blockYMask);
      pe84adf99_7_0.writeBitSet(this.emptySkyYMask);
      pe84adf99_7_0.writeBitSet(this.emptyBlockYMask);
      pe84adf99_7_0.writeCollection(this.skyUpdates, DATA_LAYER_STREAM_CODEC);
      pe84adf99_7_0.writeCollection(this.blockUpdates, DATA_LAYER_STREAM_CODEC);
   }

   private void prepareSectionData(
      ChunkPos pe84adf99_8_0,
      LevelLightEngine pe84adf99_9_1,
      LightLayer pe84adf99_10_2,
      int pe84adf99_11_3,
      BitSet pe84adf99_12_4,
      BitSet pe84adf99_13_5,
      List<byte[]> pe84adf99_14_6
   ) {
      DataLayer $$7 = pe84adf99_9_1.getLayerListener(pe84adf99_10_2)
         .getDataLayerData(SectionPos.of(pe84adf99_8_0, pe84adf99_9_1.getMinLightSection() + pe84adf99_11_3));
      if ($$7 != null) {
         if ($$7.isEmpty()) {
            pe84adf99_13_5.set(pe84adf99_11_3);
         } else {
            pe84adf99_12_4.set(pe84adf99_11_3);
            pe84adf99_14_6.add($$7.copy().getData());
         }
      }
   }

   public BitSet getSkyYMask() {
      return this.skyYMask;
   }

   public BitSet getEmptySkyYMask() {
      return this.emptySkyYMask;
   }

   public List<byte[]> getSkyUpdates() {
      return this.skyUpdates;
   }

   public BitSet getBlockYMask() {
      return this.blockYMask;
   }

   public BitSet getEmptyBlockYMask() {
      return this.emptyBlockYMask;
   }

   public List<byte[]> getBlockUpdates() {
      return this.blockUpdates;
   }
}
