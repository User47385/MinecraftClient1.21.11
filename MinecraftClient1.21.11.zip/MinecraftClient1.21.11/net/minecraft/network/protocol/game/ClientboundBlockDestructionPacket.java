package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundBlockDestructionPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundBlockDestructionPacket> STREAM_CODEC = Packet.codec(
      ClientboundBlockDestructionPacket::write, ClientboundBlockDestructionPacket::new
   );
   private final int id;
   private final BlockPos pos;
   private final int progress;

   public ClientboundBlockDestructionPacket(int pd5e4bb65_0_0, BlockPos pd5e4bb65_1_1, int pd5e4bb65_2_2) {
      this.id = pd5e4bb65_0_0;
      this.pos = pd5e4bb65_1_1;
      this.progress = pd5e4bb65_2_2;
   }

   private ClientboundBlockDestructionPacket(FriendlyByteBuf pd5e4bb65_3_0) {
      this.id = pd5e4bb65_3_0.readVarInt();
      this.pos = pd5e4bb65_3_0.readBlockPos();
      this.progress = pd5e4bb65_3_0.readUnsignedByte();
   }

   private void write(FriendlyByteBuf pd5e4bb65_4_0) {
      pd5e4bb65_4_0.writeVarInt(this.id);
      pd5e4bb65_4_0.writeBlockPos(this.pos);
      pd5e4bb65_4_0.writeByte(this.progress);
   }

   @Override
   public PacketType<ClientboundBlockDestructionPacket> type() {
      return GamePacketTypes.CLIENTBOUND_BLOCK_DESTRUCTION;
   }

   public void handle(ClientGamePacketListener pd5e4bb65_5_0) {
      pd5e4bb65_5_0.handleBlockDestruction(this);
   }

   public int getId() {
      return this.id;
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public int getProgress() {
      return this.progress;
   }
}
