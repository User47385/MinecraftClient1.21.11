package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.vehicle.minecart.MinecartCommandBlock;
import net.minecraft.world.level.BaseCommandBlock;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;

public class ServerboundSetCommandMinecartPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundSetCommandMinecartPacket> STREAM_CODEC = Packet.codec(
      ServerboundSetCommandMinecartPacket::write, ServerboundSetCommandMinecartPacket::new
   );
   private final int entity;
   private final String command;
   private final boolean trackOutput;

   public ServerboundSetCommandMinecartPacket(int p699aab64_0_0, String p699aab64_1_1, boolean p699aab64_2_2) {
      this.entity = p699aab64_0_0;
      this.command = p699aab64_1_1;
      this.trackOutput = p699aab64_2_2;
   }

   private ServerboundSetCommandMinecartPacket(FriendlyByteBuf p699aab64_3_0) {
      this.entity = p699aab64_3_0.readVarInt();
      this.command = p699aab64_3_0.readUtf();
      this.trackOutput = p699aab64_3_0.readBoolean();
   }

   private void write(FriendlyByteBuf p699aab64_4_0) {
      p699aab64_4_0.writeVarInt(this.entity);
      p699aab64_4_0.writeUtf(this.command);
      p699aab64_4_0.writeBoolean(this.trackOutput);
   }

   @Override
   public PacketType<ServerboundSetCommandMinecartPacket> type() {
      return GamePacketTypes.SERVERBOUND_SET_COMMAND_MINECART;
   }

   public void handle(ServerGamePacketListener p699aab64_5_0) {
      p699aab64_5_0.handleSetCommandMinecart(this);
   }

   public @Nullable BaseCommandBlock getCommandBlock(Level p699aab64_6_0) {
      Entity $$1 = p699aab64_6_0.getEntity(this.entity);
      return $$1 instanceof MinecartCommandBlock ? ((MinecartCommandBlock)$$1).getCommandBlock() : null;
   }

   public String getCommand() {
      return this.command;
   }

   public boolean isTrackOutput() {
      return this.trackOutput;
   }
}
