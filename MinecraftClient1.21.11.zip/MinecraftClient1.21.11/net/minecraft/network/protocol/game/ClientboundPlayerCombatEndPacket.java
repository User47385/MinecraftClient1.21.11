package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.damagesource.CombatTracker;

public class ClientboundPlayerCombatEndPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundPlayerCombatEndPacket> STREAM_CODEC = Packet.codec(
      ClientboundPlayerCombatEndPacket::write, ClientboundPlayerCombatEndPacket::new
   );
   private final int duration;

   public ClientboundPlayerCombatEndPacket(CombatTracker p1c47bbf6_0_0) {
      this(p1c47bbf6_0_0.getCombatDuration());
   }

   public ClientboundPlayerCombatEndPacket(int p1c47bbf6_1_0) {
      this.duration = p1c47bbf6_1_0;
   }

   private ClientboundPlayerCombatEndPacket(FriendlyByteBuf p1c47bbf6_2_0) {
      this.duration = p1c47bbf6_2_0.readVarInt();
   }

   private void write(FriendlyByteBuf p1c47bbf6_3_0) {
      p1c47bbf6_3_0.writeVarInt(this.duration);
   }

   @Override
   public PacketType<ClientboundPlayerCombatEndPacket> type() {
      return GamePacketTypes.CLIENTBOUND_PLAYER_COMBAT_END;
   }

   public void handle(ClientGamePacketListener p1c47bbf6_4_0) {
      p1c47bbf6_4_0.handlePlayerCombatEnd(this);
   }
}
