package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;

public class ClientboundSelectAdvancementsTabPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSelectAdvancementsTabPacket> STREAM_CODEC = Packet.codec(
      ClientboundSelectAdvancementsTabPacket::write, ClientboundSelectAdvancementsTabPacket::new
   );
   private final @Nullable Identifier tab;

   public ClientboundSelectAdvancementsTabPacket(@Nullable Identifier p8f0354f6_0_0) {
      this.tab = p8f0354f6_0_0;
   }

   private ClientboundSelectAdvancementsTabPacket(FriendlyByteBuf p8f0354f6_1_0) {
      this.tab = p8f0354f6_1_0.readNullable(FriendlyByteBuf::readIdentifier);
   }

   private void write(FriendlyByteBuf p8f0354f6_2_0) {
      p8f0354f6_2_0.writeNullable(this.tab, FriendlyByteBuf::writeIdentifier);
   }

   @Override
   public PacketType<ClientboundSelectAdvancementsTabPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SELECT_ADVANCEMENTS_TAB;
   }

   public void handle(ClientGamePacketListener p8f0354f6_3_0) {
      p8f0354f6_3_0.handleSelectAdvancementsTab(this);
   }

   public @Nullable Identifier getTab() {
      return this.tab;
   }
}
