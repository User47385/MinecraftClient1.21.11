package net.minecraft.network.protocol.game;

import com.google.common.collect.Lists;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;
import org.jspecify.annotations.Nullable;

public class ClientboundLevelChunkPacketData {
   private static final StreamCodec<ByteBuf, Map<Heightmap.Types, long[]>> HEIGHTMAPS_STREAM_CODEC = ByteBufCodecs.map(
      p39638513_18_0 -> new EnumMap<>(Heightmap.Types.class), Heightmap.Types.STREAM_CODEC, ByteBufCodecs.LONG_ARRAY
   );
   private static final int TWO_MEGABYTES = 2097152;
   private final Map<Heightmap.Types, long[]> heightmaps;
   private final byte[] buffer;
   private final List<ClientboundLevelChunkPacketData.BlockEntityInfo> blockEntitiesData;

   public ClientboundLevelChunkPacketData(LevelChunk p39638513_0_0) {
      this.heightmaps = p39638513_0_0.getHeightmaps()
         .stream()
         .filter(p39638513_17_0 -> p39638513_17_0.getKey().sendToClient())
         .collect(Collectors.toMap(Entry::getKey, p39638513_16_0 -> (long[])p39638513_16_0.getValue().getRawData().clone()));
      this.buffer = new byte[calculateChunkSize(p39638513_0_0)];
      extractChunkData(new FriendlyByteBuf(this.getWriteBuffer()), p39638513_0_0);
      this.blockEntitiesData = Lists.newArrayList();

      for (Entry<BlockPos, BlockEntity> $$1 : p39638513_0_0.getBlockEntities().entrySet()) {
         this.blockEntitiesData.add(ClientboundLevelChunkPacketData.BlockEntityInfo.create($$1.getValue()));
      }
   }

   public ClientboundLevelChunkPacketData(RegistryFriendlyByteBuf p39638513_1_0, int p39638513_2_1, int p39638513_3_2) {
      this.heightmaps = HEIGHTMAPS_STREAM_CODEC.decode(p39638513_1_0);
      int $$3 = p39638513_1_0.readVarInt();
      if ($$3 > 2097152) {
         throw new RuntimeException("Chunk Packet trying to allocate too much memory on read.");
      }

      this.buffer = new byte[$$3];
      p39638513_1_0.readBytes(this.buffer);
      this.blockEntitiesData = ClientboundLevelChunkPacketData.BlockEntityInfo.LIST_STREAM_CODEC.decode(p39638513_1_0);
   }

   public void write(RegistryFriendlyByteBuf p39638513_4_0) {
      HEIGHTMAPS_STREAM_CODEC.encode(p39638513_4_0, this.heightmaps);
      p39638513_4_0.writeVarInt(this.buffer.length);
      p39638513_4_0.writeBytes(this.buffer);
      ClientboundLevelChunkPacketData.BlockEntityInfo.LIST_STREAM_CODEC.encode(p39638513_4_0, this.blockEntitiesData);
   }

   private static int calculateChunkSize(LevelChunk p39638513_5_0) {
      int $$1 = 0;

      for (LevelChunkSection $$2 : p39638513_5_0.getSections()) {
         $$1 += $$2.getSerializedSize();
      }

      return $$1;
   }

   private ByteBuf getWriteBuffer() {
      ByteBuf $$0 = Unpooled.wrappedBuffer(this.buffer);
      $$0.writerIndex(0);
      return $$0;
   }

   public static void extractChunkData(FriendlyByteBuf p39638513_6_0, LevelChunk p39638513_7_1) {
      for (LevelChunkSection $$2 : p39638513_7_1.getSections()) {
         $$2.write(p39638513_6_0);
      }

      if (p39638513_6_0.writerIndex() != p39638513_6_0.capacity()) {
         throw new IllegalStateException("Didn't fill chunk buffer: expected " + p39638513_6_0.capacity() + " bytes, got " + p39638513_6_0.writerIndex());
      }
   }

   public Consumer<ClientboundLevelChunkPacketData.BlockEntityTagOutput> getBlockEntitiesTagsConsumer(int p39638513_8_0, int p39638513_9_1) {
      return p39638513_15_2 -> this.getBlockEntitiesTags(p39638513_15_2, p39638513_8_0, p39638513_9_1);
   }

   private void getBlockEntitiesTags(ClientboundLevelChunkPacketData.BlockEntityTagOutput p39638513_10_0, int p39638513_11_1, int p39638513_12_2) {
      int $$3 = 16 * p39638513_11_1;
      int $$4 = 16 * p39638513_12_2;
      BlockPos.MutableBlockPos $$5 = new BlockPos.MutableBlockPos();

      for (ClientboundLevelChunkPacketData.BlockEntityInfo $$6 : this.blockEntitiesData) {
         int $$7 = $$3 + SectionPos.sectionRelative($$6.packedXZ >> 4);
         int $$8 = $$4 + SectionPos.sectionRelative($$6.packedXZ);
         $$5.set($$7, $$6.y, $$8);
         p39638513_10_0.accept($$5, $$6.type, $$6.tag);
      }
   }

   public FriendlyByteBuf getReadBuffer() {
      return new FriendlyByteBuf(Unpooled.wrappedBuffer(this.buffer));
   }

   public Map<Heightmap.Types, long[]> getHeightmaps() {
      return this.heightmaps;
   }

   static class BlockEntityInfo {
      public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundLevelChunkPacketData.BlockEntityInfo> STREAM_CODEC = StreamCodec.ofMember(
         ClientboundLevelChunkPacketData.BlockEntityInfo::write, ClientboundLevelChunkPacketData.BlockEntityInfo::new
      );
      public static final StreamCodec<RegistryFriendlyByteBuf, List<ClientboundLevelChunkPacketData.BlockEntityInfo>> LIST_STREAM_CODEC = STREAM_CODEC.apply(
         ByteBufCodecs.list()
      );
      final int packedXZ;
      final int y;
      final BlockEntityType<?> type;
      final @Nullable CompoundTag tag;

      private BlockEntityInfo(int p3b7c11ed_0_0, int p3b7c11ed_1_1, BlockEntityType<?> p3b7c11ed_2_2, @Nullable CompoundTag p3b7c11ed_3_3) {
         this.packedXZ = p3b7c11ed_0_0;
         this.y = p3b7c11ed_1_1;
         this.type = p3b7c11ed_2_2;
         this.tag = p3b7c11ed_3_3;
      }

      private BlockEntityInfo(RegistryFriendlyByteBuf p3b7c11ed_4_0) {
         this.packedXZ = p3b7c11ed_4_0.readByte();
         this.y = p3b7c11ed_4_0.readShort();
         this.type = ByteBufCodecs.registry(Registries.BLOCK_ENTITY_TYPE).decode(p3b7c11ed_4_0);
         this.tag = p3b7c11ed_4_0.readNbt();
      }

      private void write(RegistryFriendlyByteBuf p3b7c11ed_5_0) {
         p3b7c11ed_5_0.writeByte(this.packedXZ);
         p3b7c11ed_5_0.writeShort(this.y);
         ByteBufCodecs.registry(Registries.BLOCK_ENTITY_TYPE).encode(p3b7c11ed_5_0, this.type);
         p3b7c11ed_5_0.writeNbt(this.tag);
      }

      static ClientboundLevelChunkPacketData.BlockEntityInfo create(BlockEntity p3b7c11ed_6_0) {
         CompoundTag $$1 = p3b7c11ed_6_0.getUpdateTag(p3b7c11ed_6_0.getLevel().registryAccess());
         BlockPos $$2 = p3b7c11ed_6_0.getBlockPos();
         int $$3 = SectionPos.sectionRelative($$2.getX()) << 4 | SectionPos.sectionRelative($$2.getZ());
         return new ClientboundLevelChunkPacketData.BlockEntityInfo($$3, $$2.getY(), p3b7c11ed_6_0.getType(), $$1.isEmpty() ? null : $$1);
      }
   }

   @FunctionalInterface
   public interface BlockEntityTagOutput {
      void accept(BlockPos var1, BlockEntityType<?> var2, @Nullable CompoundTag var3);
   }
}
