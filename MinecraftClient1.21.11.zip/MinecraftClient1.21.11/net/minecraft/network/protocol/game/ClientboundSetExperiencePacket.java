package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundSetExperiencePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetExperiencePacket> STREAM_CODEC = Packet.codec(
      ClientboundSetExperiencePacket::write, ClientboundSetExperiencePacket::new
   );
   private final float experienceProgress;
   private final int totalExperience;
   private final int experienceLevel;

   public ClientboundSetExperiencePacket(float pb772097c_0_0, int pb772097c_1_1, int pb772097c_2_2) {
      this.experienceProgress = pb772097c_0_0;
      this.totalExperience = pb772097c_1_1;
      this.experienceLevel = pb772097c_2_2;
   }

   private ClientboundSetExperiencePacket(FriendlyByteBuf pb772097c_3_0) {
      this.experienceProgress = pb772097c_3_0.readFloat();
      this.experienceLevel = pb772097c_3_0.readVarInt();
      this.totalExperience = pb772097c_3_0.readVarInt();
   }

   private void write(FriendlyByteBuf pb772097c_4_0) {
      pb772097c_4_0.writeFloat(this.experienceProgress);
      pb772097c_4_0.writeVarInt(this.experienceLevel);
      pb772097c_4_0.writeVarInt(this.totalExperience);
   }

   @Override
   public PacketType<ClientboundSetExperiencePacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_EXPERIENCE;
   }

   public void handle(ClientGamePacketListener pb772097c_5_0) {
      pb772097c_5_0.handleSetExperience(this);
   }

   public float getExperienceProgress() {
      return this.experienceProgress;
   }

   public int getTotalExperience() {
      return this.totalExperience;
   }

   public int getExperienceLevel() {
      return this.experienceLevel;
   }
}
