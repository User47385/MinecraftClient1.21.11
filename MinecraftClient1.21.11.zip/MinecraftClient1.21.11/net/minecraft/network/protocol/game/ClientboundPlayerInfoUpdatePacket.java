package net.minecraft.network.protocol.game;

import com.google.common.base.MoreObjects;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.PropertyMap;
import java.util.Collection;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.Optionull;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.chat.RemoteChatSession;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraft.world.level.GameType;
import org.jspecify.annotations.Nullable;

public class ClientboundPlayerInfoUpdatePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundPlayerInfoUpdatePacket> STREAM_CODEC = Packet.codec(
      ClientboundPlayerInfoUpdatePacket::write, ClientboundPlayerInfoUpdatePacket::new
   );
   private final EnumSet<ClientboundPlayerInfoUpdatePacket.Action> actions;
   private final List<ClientboundPlayerInfoUpdatePacket.Entry> entries;

   public ClientboundPlayerInfoUpdatePacket(EnumSet<ClientboundPlayerInfoUpdatePacket.Action> p612e6c18_0_0, Collection<ServerPlayer> p612e6c18_1_1) {
      this.actions = p612e6c18_0_0;
      this.entries = p612e6c18_1_1.stream().map(ClientboundPlayerInfoUpdatePacket.Entry::new).toList();
   }

   public ClientboundPlayerInfoUpdatePacket(ClientboundPlayerInfoUpdatePacket.Action p612e6c18_2_0, ServerPlayer p612e6c18_3_1) {
      this.actions = EnumSet.of(p612e6c18_2_0);
      this.entries = List.of(new ClientboundPlayerInfoUpdatePacket.Entry(p612e6c18_3_1));
   }

   public static ClientboundPlayerInfoUpdatePacket createPlayerInitializing(Collection<ServerPlayer> p612e6c18_4_0) {
      EnumSet<ClientboundPlayerInfoUpdatePacket.Action> $$1 = EnumSet.of(
         ClientboundPlayerInfoUpdatePacket.Action.ADD_PLAYER,
         ClientboundPlayerInfoUpdatePacket.Action.INITIALIZE_CHAT,
         ClientboundPlayerInfoUpdatePacket.Action.UPDATE_GAME_MODE,
         ClientboundPlayerInfoUpdatePacket.Action.UPDATE_LISTED,
         ClientboundPlayerInfoUpdatePacket.Action.UPDATE_LATENCY,
         ClientboundPlayerInfoUpdatePacket.Action.UPDATE_DISPLAY_NAME,
         ClientboundPlayerInfoUpdatePacket.Action.UPDATE_HAT,
         ClientboundPlayerInfoUpdatePacket.Action.UPDATE_LIST_ORDER
      );
      return new ClientboundPlayerInfoUpdatePacket($$1, p612e6c18_4_0);
   }

   private ClientboundPlayerInfoUpdatePacket(RegistryFriendlyByteBuf p612e6c18_5_0) {
      this.actions = p612e6c18_5_0.readEnumSet(ClientboundPlayerInfoUpdatePacket.Action.class);
      this.entries = p612e6c18_5_0.readList(p612e6c18_11_0 -> {
         ClientboundPlayerInfoUpdatePacket.EntryBuilder $$1 = new ClientboundPlayerInfoUpdatePacket.EntryBuilder(p612e6c18_11_0.readUUID());

         for (ClientboundPlayerInfoUpdatePacket.Action $$2 : this.actions) {
            $$2.reader.read($$1, (RegistryFriendlyByteBuf)p612e6c18_11_0);
         }

         return $$1.build();
      });
   }

   private void write(RegistryFriendlyByteBuf p612e6c18_6_0) {
      p612e6c18_6_0.writeEnumSet(this.actions, ClientboundPlayerInfoUpdatePacket.Action.class);
      p612e6c18_6_0.writeCollection(this.entries, (p612e6c18_9_0, p612e6c18_10_1) -> {
         p612e6c18_9_0.writeUUID(p612e6c18_10_1.profileId());

         for (ClientboundPlayerInfoUpdatePacket.Action $$2 : this.actions) {
            $$2.writer.write((RegistryFriendlyByteBuf)p612e6c18_9_0, p612e6c18_10_1);
         }
      });
   }

   @Override
   public PacketType<ClientboundPlayerInfoUpdatePacket> type() {
      return GamePacketTypes.CLIENTBOUND_PLAYER_INFO_UPDATE;
   }

   public void handle(ClientGamePacketListener p612e6c18_7_0) {
      p612e6c18_7_0.handlePlayerInfoUpdate(this);
   }

   public EnumSet<ClientboundPlayerInfoUpdatePacket.Action> actions() {
      return this.actions;
   }

   public List<ClientboundPlayerInfoUpdatePacket.Entry> entries() {
      return this.entries;
   }

   public List<ClientboundPlayerInfoUpdatePacket.Entry> newEntries() {
      return this.actions.contains(ClientboundPlayerInfoUpdatePacket.Action.ADD_PLAYER) ? this.entries : List.of();
   }

   @Override
   public String toString() {
      return MoreObjects.toStringHelper(this).add("actions", this.actions).add("entries", this.entries).toString();
   }

   public enum Action {
      ADD_PLAYER((p30110862_35_0, p30110862_36_1) -> {
         String $$2 = ByteBufCodecs.PLAYER_NAME.decode(p30110862_36_1);
         PropertyMap $$3 = ByteBufCodecs.GAME_PROFILE_PROPERTIES.decode(p30110862_36_1);
         p30110862_35_0.profile = new GameProfile(p30110862_35_0.profileId, $$2, $$3);
      }, (p30110862_33_0, p30110862_34_1) -> {
         GameProfile $$2 = Objects.requireNonNull(p30110862_34_1.profile());
         ByteBufCodecs.PLAYER_NAME.encode(p30110862_33_0, $$2.name());
         ByteBufCodecs.GAME_PROFILE_PROPERTIES.encode(p30110862_33_0, $$2.properties());
      }),
      INITIALIZE_CHAT(
         (p30110862_31_0, p30110862_32_1) -> p30110862_31_0.chatSession = p30110862_32_1.readNullable(RemoteChatSession.Data::read),
         (p30110862_29_0, p30110862_30_1) -> p30110862_29_0.writeNullable(p30110862_30_1.chatSession, RemoteChatSession.Data::write)
      ),
      UPDATE_GAME_MODE(
         (p30110862_27_0, p30110862_28_1) -> p30110862_27_0.gameMode = GameType.byId(p30110862_28_1.readVarInt()),
         (p30110862_25_0, p30110862_26_1) -> p30110862_25_0.writeVarInt(p30110862_26_1.gameMode().getId())
      ),
      UPDATE_LISTED(
         (p30110862_23_0, p30110862_24_1) -> p30110862_23_0.listed = p30110862_24_1.readBoolean(),
         (p30110862_21_0, p30110862_22_1) -> p30110862_21_0.writeBoolean(p30110862_22_1.listed())
      ),
      UPDATE_LATENCY(
         (p30110862_19_0, p30110862_20_1) -> p30110862_19_0.latency = p30110862_20_1.readVarInt(),
         (p30110862_17_0, p30110862_18_1) -> p30110862_17_0.writeVarInt(p30110862_18_1.latency())
      ),
      UPDATE_DISPLAY_NAME(
         (p30110862_15_0, p30110862_16_1) -> p30110862_15_0.displayName = FriendlyByteBuf.readNullable(
            p30110862_16_1, ComponentSerialization.TRUSTED_STREAM_CODEC
         ),
         (p30110862_13_0, p30110862_14_1) -> FriendlyByteBuf.writeNullable(
            p30110862_13_0, p30110862_14_1.displayName(), ComponentSerialization.TRUSTED_STREAM_CODEC
         )
      ),
      UPDATE_LIST_ORDER(
         (p30110862_11_0, p30110862_12_1) -> p30110862_11_0.listOrder = p30110862_12_1.readVarInt(),
         (p30110862_9_0, p30110862_10_1) -> p30110862_9_0.writeVarInt(p30110862_10_1.listOrder)
      ),
      UPDATE_HAT(
         (p30110862_7_0, p30110862_8_1) -> p30110862_7_0.showHat = p30110862_8_1.readBoolean(),
         (p30110862_5_0, p30110862_6_1) -> p30110862_5_0.writeBoolean(p30110862_6_1.showHat)
      );

      final ClientboundPlayerInfoUpdatePacket.Action.Reader reader;
      final ClientboundPlayerInfoUpdatePacket.Action.Writer writer;

      Action(final ClientboundPlayerInfoUpdatePacket.Action.Reader p30110862_3_2, final ClientboundPlayerInfoUpdatePacket.Action.Writer p30110862_4_3) {
         this.reader = p30110862_3_2;
         this.writer = p30110862_4_3;
      }

      public interface Reader {
         void read(ClientboundPlayerInfoUpdatePacket.EntryBuilder var1, RegistryFriendlyByteBuf var2);
      }

      public interface Writer {
         void write(RegistryFriendlyByteBuf var1, ClientboundPlayerInfoUpdatePacket.Entry var2);
      }
   }

   public record Entry(
      UUID profileId,
      @Nullable GameProfile profile,
      boolean listed,
      int latency,
      GameType gameMode,
      @Nullable Component displayName,
      boolean showHat,
      int listOrder,
      RemoteChatSession.@Nullable Data chatSession
   ) {

      Entry(ServerPlayer p9eb188c6_0_0) {
         this(
            p9eb188c6_0_0.getUUID(),
            p9eb188c6_0_0.getGameProfile(),
            true,
            p9eb188c6_0_0.connection.latency(),
            p9eb188c6_0_0.gameMode(),
            p9eb188c6_0_0.getTabListDisplayName(),
            p9eb188c6_0_0.isModelPartShown(PlayerModelPart.HAT),
            p9eb188c6_0_0.getTabListOrder(),
            Optionull.map(p9eb188c6_0_0.getChatSession(), RemoteChatSession::asData)
         );
      }
   }

   static class EntryBuilder {
      final UUID profileId;
      @Nullable GameProfile profile;
      boolean listed;
      int latency;
      GameType gameMode = GameType.DEFAULT_MODE;
      @Nullable Component displayName;
      boolean showHat;
      int listOrder;
      RemoteChatSession.@Nullable Data chatSession;

      EntryBuilder(UUID p112ab3f5_0_0) {
         this.profileId = p112ab3f5_0_0;
      }

      ClientboundPlayerInfoUpdatePacket.Entry build() {
         return new ClientboundPlayerInfoUpdatePacket.Entry(
            this.profileId, this.profile, this.listed, this.latency, this.gameMode, this.displayName, this.showHat, this.listOrder, this.chatSession
         );
      }
   }
}
