package net.minecraft.network.protocol.game;

import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public record ClientboundDamageEventPacket(int entityId, Holder<DamageType> sourceType, int sourceCauseId, int sourceDirectId, Optional<Vec3> sourcePosition)
   implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundDamageEventPacket> STREAM_CODEC = Packet.codec(
      ClientboundDamageEventPacket::write, ClientboundDamageEventPacket::new
   );

   public ClientboundDamageEventPacket(Entity pbc57ed3b_0_0, DamageSource pbc57ed3b_1_1) {
      this(
         pbc57ed3b_0_0.getId(),
         pbc57ed3b_1_1.typeHolder(),
         pbc57ed3b_1_1.getEntity() != null ? pbc57ed3b_1_1.getEntity().getId() : -1,
         pbc57ed3b_1_1.getDirectEntity() != null ? pbc57ed3b_1_1.getDirectEntity().getId() : -1,
         Optional.ofNullable(pbc57ed3b_1_1.sourcePositionRaw())
      );
   }

   private ClientboundDamageEventPacket(RegistryFriendlyByteBuf pbc57ed3b_2_0) {
      this(
         pbc57ed3b_2_0.readVarInt(),
         DamageType.STREAM_CODEC.decode(pbc57ed3b_2_0),
         readOptionalEntityId(pbc57ed3b_2_0),
         readOptionalEntityId(pbc57ed3b_2_0),
         pbc57ed3b_2_0.readOptional(pbc57ed3b_18_0 -> new Vec3(pbc57ed3b_18_0.readDouble(), pbc57ed3b_18_0.readDouble(), pbc57ed3b_18_0.readDouble()))
      );
   }

   private static void writeOptionalEntityId(FriendlyByteBuf pbc57ed3b_8_0, int pbc57ed3b_9_1) {
      pbc57ed3b_8_0.writeVarInt(pbc57ed3b_9_1 + 1);
   }

   private static int readOptionalEntityId(FriendlyByteBuf pbc57ed3b_10_0) {
      return pbc57ed3b_10_0.readVarInt() - 1;
   }

   private void write(RegistryFriendlyByteBuf pbc57ed3b_11_0) {
      pbc57ed3b_11_0.writeVarInt(this.entityId);
      DamageType.STREAM_CODEC.encode(pbc57ed3b_11_0, this.sourceType);
      writeOptionalEntityId(pbc57ed3b_11_0, this.sourceCauseId);
      writeOptionalEntityId(pbc57ed3b_11_0, this.sourceDirectId);
      pbc57ed3b_11_0.writeOptional(this.sourcePosition, (pbc57ed3b_16_0, pbc57ed3b_17_1) -> {
         pbc57ed3b_16_0.writeDouble(pbc57ed3b_17_1.x());
         pbc57ed3b_16_0.writeDouble(pbc57ed3b_17_1.y());
         pbc57ed3b_16_0.writeDouble(pbc57ed3b_17_1.z());
      });
   }

   @Override
   public PacketType<ClientboundDamageEventPacket> type() {
      return GamePacketTypes.CLIENTBOUND_DAMAGE_EVENT;
   }

   public void handle(ClientGamePacketListener pbc57ed3b_12_0) {
      pbc57ed3b_12_0.handleDamageEvent(this);
   }

   public DamageSource getSource(Level pbc57ed3b_13_0) {
      if (this.sourcePosition.isPresent()) {
         return new DamageSource(this.sourceType, this.sourcePosition.get());
      }

      Entity $$1 = pbc57ed3b_13_0.getEntity(this.sourceCauseId);
      Entity $$2 = pbc57ed3b_13_0.getEntity(this.sourceDirectId);
      return new DamageSource(this.sourceType, $$2, $$1);
   }
}
