package net.minecraft.network.protocol.game;

import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.resources.Identifier;

public class ClientboundUpdateAdvancementsPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundUpdateAdvancementsPacket> STREAM_CODEC = Packet.codec(
      ClientboundUpdateAdvancementsPacket::write, ClientboundUpdateAdvancementsPacket::new
   );
   private final boolean reset;
   private final List<AdvancementHolder> added;
   private final Set<Identifier> removed;
   private final Map<Identifier, AdvancementProgress> progress;
   private final boolean showAdvancements;

   public ClientboundUpdateAdvancementsPacket(
      boolean p5b73313c_0_0,
      Collection<AdvancementHolder> p5b73313c_1_1,
      Set<Identifier> p5b73313c_2_2,
      Map<Identifier, AdvancementProgress> p5b73313c_3_3,
      boolean p5b73313c_4_4
   ) {
      this.reset = p5b73313c_0_0;
      this.added = List.copyOf(p5b73313c_1_1);
      this.removed = Set.copyOf(p5b73313c_2_2);
      this.progress = Map.copyOf(p5b73313c_3_3);
      this.showAdvancements = p5b73313c_4_4;
   }

   private ClientboundUpdateAdvancementsPacket(RegistryFriendlyByteBuf p5b73313c_5_0) {
      this.reset = p5b73313c_5_0.readBoolean();
      this.added = AdvancementHolder.LIST_STREAM_CODEC.decode(p5b73313c_5_0);
      this.removed = p5b73313c_5_0.readCollection(Sets::newLinkedHashSetWithExpectedSize, FriendlyByteBuf::readIdentifier);
      this.progress = p5b73313c_5_0.readMap(FriendlyByteBuf::readIdentifier, AdvancementProgress::fromNetwork);
      this.showAdvancements = p5b73313c_5_0.readBoolean();
   }

   private void write(RegistryFriendlyByteBuf p5b73313c_6_0) {
      p5b73313c_6_0.writeBoolean(this.reset);
      AdvancementHolder.LIST_STREAM_CODEC.encode(p5b73313c_6_0, this.added);
      p5b73313c_6_0.writeCollection(this.removed, FriendlyByteBuf::writeIdentifier);
      p5b73313c_6_0.writeMap(
         this.progress, FriendlyByteBuf::writeIdentifier, (p5b73313c_9_0, p5b73313c_10_1) -> p5b73313c_10_1.serializeToNetwork(p5b73313c_9_0)
      );
      p5b73313c_6_0.writeBoolean(this.showAdvancements);
   }

   @Override
   public PacketType<ClientboundUpdateAdvancementsPacket> type() {
      return GamePacketTypes.CLIENTBOUND_UPDATE_ADVANCEMENTS;
   }

   public void handle(ClientGamePacketListener p5b73313c_7_0) {
      p5b73313c_7_0.handleUpdateAdvancementsPacket(this);
   }

   public List<AdvancementHolder> getAdded() {
      return this.added;
   }

   public Set<Identifier> getRemoved() {
      return this.removed;
   }

   public Map<Identifier, AdvancementProgress> getProgress() {
      return this.progress;
   }

   public boolean shouldReset() {
      return this.reset;
   }

   public boolean shouldShowAdvancements() {
      return this.showAdvancements;
   }
}
