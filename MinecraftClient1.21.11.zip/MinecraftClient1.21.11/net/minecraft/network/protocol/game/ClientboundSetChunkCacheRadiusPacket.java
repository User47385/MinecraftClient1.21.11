package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundSetChunkCacheRadiusPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetChunkCacheRadiusPacket> STREAM_CODEC = Packet.codec(
      ClientboundSetChunkCacheRadiusPacket::write, ClientboundSetChunkCacheRadiusPacket::new
   );
   private final int radius;

   public ClientboundSetChunkCacheRadiusPacket(int pdbdd3cd9_0_0) {
      this.radius = pdbdd3cd9_0_0;
   }

   private ClientboundSetChunkCacheRadiusPacket(FriendlyByteBuf pdbdd3cd9_1_0) {
      this.radius = pdbdd3cd9_1_0.readVarInt();
   }

   private void write(FriendlyByteBuf pdbdd3cd9_2_0) {
      pdbdd3cd9_2_0.writeVarInt(this.radius);
   }

   @Override
   public PacketType<ClientboundSetChunkCacheRadiusPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_CHUNK_CACHE_RADIUS;
   }

   public void handle(ClientGamePacketListener pdbdd3cd9_3_0) {
      pdbdd3cd9_3_0.handleSetChunkCacheRadius(this);
   }

   public int getRadius() {
      return this.radius;
   }
}
