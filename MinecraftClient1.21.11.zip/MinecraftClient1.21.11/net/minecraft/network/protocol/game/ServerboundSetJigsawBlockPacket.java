package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.entity.JigsawBlockEntity;

public class ServerboundSetJigsawBlockPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundSetJigsawBlockPacket> STREAM_CODEC = Packet.codec(
      ServerboundSetJigsawBlockPacket::write, ServerboundSetJigsawBlockPacket::new
   );
   private final BlockPos pos;
   private final Identifier name;
   private final Identifier target;
   private final Identifier pool;
   private final String finalState;
   private final JigsawBlockEntity.JointType joint;
   private final int selectionPriority;
   private final int placementPriority;

   public ServerboundSetJigsawBlockPacket(
      BlockPos p63bc26b2_0_0,
      Identifier p63bc26b2_1_1,
      Identifier p63bc26b2_2_2,
      Identifier p63bc26b2_3_3,
      String p63bc26b2_4_4,
      JigsawBlockEntity.JointType p63bc26b2_5_5,
      int p63bc26b2_6_6,
      int p63bc26b2_7_7
   ) {
      this.pos = p63bc26b2_0_0;
      this.name = p63bc26b2_1_1;
      this.target = p63bc26b2_2_2;
      this.pool = p63bc26b2_3_3;
      this.finalState = p63bc26b2_4_4;
      this.joint = p63bc26b2_5_5;
      this.selectionPriority = p63bc26b2_6_6;
      this.placementPriority = p63bc26b2_7_7;
   }

   private ServerboundSetJigsawBlockPacket(FriendlyByteBuf p63bc26b2_8_0) {
      this.pos = p63bc26b2_8_0.readBlockPos();
      this.name = p63bc26b2_8_0.readIdentifier();
      this.target = p63bc26b2_8_0.readIdentifier();
      this.pool = p63bc26b2_8_0.readIdentifier();
      this.finalState = p63bc26b2_8_0.readUtf();
      this.joint = JigsawBlockEntity.JointType.CODEC.byName(p63bc26b2_8_0.readUtf(), JigsawBlockEntity.JointType.ALIGNED);
      this.selectionPriority = p63bc26b2_8_0.readVarInt();
      this.placementPriority = p63bc26b2_8_0.readVarInt();
   }

   private void write(FriendlyByteBuf p63bc26b2_9_0) {
      p63bc26b2_9_0.writeBlockPos(this.pos);
      p63bc26b2_9_0.writeIdentifier(this.name);
      p63bc26b2_9_0.writeIdentifier(this.target);
      p63bc26b2_9_0.writeIdentifier(this.pool);
      p63bc26b2_9_0.writeUtf(this.finalState);
      p63bc26b2_9_0.writeUtf(this.joint.getSerializedName());
      p63bc26b2_9_0.writeVarInt(this.selectionPriority);
      p63bc26b2_9_0.writeVarInt(this.placementPriority);
   }

   @Override
   public PacketType<ServerboundSetJigsawBlockPacket> type() {
      return GamePacketTypes.SERVERBOUND_SET_JIGSAW_BLOCK;
   }

   public void handle(ServerGamePacketListener p63bc26b2_10_0) {
      p63bc26b2_10_0.handleSetJigsawBlock(this);
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public Identifier getName() {
      return this.name;
   }

   public Identifier getTarget() {
      return this.target;
   }

   public Identifier getPool() {
      return this.pool;
   }

   public String getFinalState() {
      return this.finalState;
   }

   public JigsawBlockEntity.JointType getJoint() {
      return this.joint;
   }

   public int getSelectionPriority() {
      return this.selectionPriority;
   }

   public int getPlacementPriority() {
      return this.placementPriority;
   }
}
