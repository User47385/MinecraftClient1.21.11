package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.StructureBlockEntity;
import net.minecraft.world.level.block.state.properties.StructureMode;

public class ServerboundSetStructureBlockPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundSetStructureBlockPacket> STREAM_CODEC = Packet.codec(
      ServerboundSetStructureBlockPacket::write, ServerboundSetStructureBlockPacket::new
   );
   private static final int FLAG_IGNORE_ENTITIES = 1;
   private static final int FLAG_SHOW_AIR = 2;
   private static final int FLAG_SHOW_BOUNDING_BOX = 4;
   private static final int FLAG_STRICT = 8;
   private final BlockPos pos;
   private final StructureBlockEntity.UpdateType updateType;
   private final StructureMode mode;
   private final String name;
   private final BlockPos offset;
   private final Vec3i size;
   private final Mirror mirror;
   private final Rotation rotation;
   private final String data;
   private final boolean ignoreEntities;
   private final boolean strict;
   private final boolean showAir;
   private final boolean showBoundingBox;
   private final float integrity;
   private final long seed;

   public ServerboundSetStructureBlockPacket(
      BlockPos p51934564_0_0,
      StructureBlockEntity.UpdateType p51934564_1_1,
      StructureMode p51934564_2_2,
      String p51934564_3_3,
      BlockPos p51934564_4_4,
      Vec3i p51934564_5_5,
      Mirror p51934564_6_6,
      Rotation p51934564_7_7,
      String p51934564_8_8,
      boolean p51934564_9_9,
      boolean p51934564_10_10,
      boolean p51934564_11_11,
      boolean p51934564_12_12,
      float p51934564_13_13,
      long p51934564_14_14
   ) {
      this.pos = p51934564_0_0;
      this.updateType = p51934564_1_1;
      this.mode = p51934564_2_2;
      this.name = p51934564_3_3;
      this.offset = p51934564_4_4;
      this.size = p51934564_5_5;
      this.mirror = p51934564_6_6;
      this.rotation = p51934564_7_7;
      this.data = p51934564_8_8;
      this.ignoreEntities = p51934564_9_9;
      this.strict = p51934564_10_10;
      this.showAir = p51934564_11_11;
      this.showBoundingBox = p51934564_12_12;
      this.integrity = p51934564_13_13;
      this.seed = p51934564_14_14;
   }

   private ServerboundSetStructureBlockPacket(FriendlyByteBuf p51934564_15_0) {
      this.pos = p51934564_15_0.readBlockPos();
      this.updateType = p51934564_15_0.readEnum(StructureBlockEntity.UpdateType.class);
      this.mode = p51934564_15_0.readEnum(StructureMode.class);
      this.name = p51934564_15_0.readUtf();
      int $$1 = 48;
      this.offset = new BlockPos(
         Mth.clamp(p51934564_15_0.readByte(), -48, 48), Mth.clamp(p51934564_15_0.readByte(), -48, 48), Mth.clamp(p51934564_15_0.readByte(), -48, 48)
      );
      int $$2 = 48;
      this.size = new Vec3i(
         Mth.clamp(p51934564_15_0.readByte(), 0, 48), Mth.clamp(p51934564_15_0.readByte(), 0, 48), Mth.clamp(p51934564_15_0.readByte(), 0, 48)
      );
      this.mirror = p51934564_15_0.readEnum(Mirror.class);
      this.rotation = p51934564_15_0.readEnum(Rotation.class);
      this.data = p51934564_15_0.readUtf(128);
      this.integrity = Mth.clamp(p51934564_15_0.readFloat(), 0.0F, 1.0F);
      this.seed = p51934564_15_0.readVarLong();
      int $$3 = p51934564_15_0.readByte();
      this.ignoreEntities = ($$3 & 1) != 0;
      this.strict = ($$3 & 8) != 0;
      this.showAir = ($$3 & 2) != 0;
      this.showBoundingBox = ($$3 & 4) != 0;
   }

   private void write(FriendlyByteBuf p51934564_16_0) {
      p51934564_16_0.writeBlockPos(this.pos);
      p51934564_16_0.writeEnum(this.updateType);
      p51934564_16_0.writeEnum(this.mode);
      p51934564_16_0.writeUtf(this.name);
      p51934564_16_0.writeByte(this.offset.getX());
      p51934564_16_0.writeByte(this.offset.getY());
      p51934564_16_0.writeByte(this.offset.getZ());
      p51934564_16_0.writeByte(this.size.getX());
      p51934564_16_0.writeByte(this.size.getY());
      p51934564_16_0.writeByte(this.size.getZ());
      p51934564_16_0.writeEnum(this.mirror);
      p51934564_16_0.writeEnum(this.rotation);
      p51934564_16_0.writeUtf(this.data);
      p51934564_16_0.writeFloat(this.integrity);
      p51934564_16_0.writeVarLong(this.seed);
      int $$1 = 0;
      if (this.ignoreEntities) {
         $$1 |= 1;
      }

      if (this.showAir) {
         $$1 |= 2;
      }

      if (this.showBoundingBox) {
         $$1 |= 4;
      }

      if (this.strict) {
         $$1 |= 8;
      }

      p51934564_16_0.writeByte($$1);
   }

   @Override
   public PacketType<ServerboundSetStructureBlockPacket> type() {
      return GamePacketTypes.SERVERBOUND_SET_STRUCTURE_BLOCK;
   }

   public void handle(ServerGamePacketListener p51934564_17_0) {
      p51934564_17_0.handleSetStructureBlock(this);
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public StructureBlockEntity.UpdateType getUpdateType() {
      return this.updateType;
   }

   public StructureMode getMode() {
      return this.mode;
   }

   public String getName() {
      return this.name;
   }

   public BlockPos getOffset() {
      return this.offset;
   }

   public Vec3i getSize() {
      return this.size;
   }

   public Mirror getMirror() {
      return this.mirror;
   }

   public Rotation getRotation() {
      return this.rotation;
   }

   public String getData() {
      return this.data;
   }

   public boolean isIgnoreEntities() {
      return this.ignoreEntities;
   }

   public boolean isStrict() {
      return this.strict;
   }

   public boolean isShowAir() {
      return this.showAir;
   }

   public boolean isShowBoundingBox() {
      return this.showBoundingBox;
   }

   public float getIntegrity() {
      return this.integrity;
   }

   public long getSeed() {
      return this.seed;
   }
}
