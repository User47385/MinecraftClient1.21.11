package net.minecraft.network.protocol.game;

import java.util.List;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.Entity;

public class ClientboundSetPassengersPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetPassengersPacket> STREAM_CODEC = Packet.codec(
      ClientboundSetPassengersPacket::write, ClientboundSetPassengersPacket::new
   );
   private final int vehicle;
   private final int[] passengers;

   public ClientboundSetPassengersPacket(Entity p3829afeb_0_0) {
      this.vehicle = p3829afeb_0_0.getId();
      List<Entity> $$1 = p3829afeb_0_0.getPassengers();
      this.passengers = new int[$$1.size()];

      for (int $$2 = 0; $$2 < $$1.size(); $$2++) {
         this.passengers[$$2] = $$1.get($$2).getId();
      }
   }

   private ClientboundSetPassengersPacket(FriendlyByteBuf p3829afeb_1_0) {
      this.vehicle = p3829afeb_1_0.readVarInt();
      this.passengers = p3829afeb_1_0.readVarIntArray();
   }

   private void write(FriendlyByteBuf p3829afeb_2_0) {
      p3829afeb_2_0.writeVarInt(this.vehicle);
      p3829afeb_2_0.writeVarIntArray(this.passengers);
   }

   @Override
   public PacketType<ClientboundSetPassengersPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_PASSENGERS;
   }

   public void handle(ClientGamePacketListener p3829afeb_3_0) {
      p3829afeb_3_0.handleSetEntityPassengersPacket(this);
   }

   public int[] getPassengers() {
      return this.passengers;
   }

   public int getVehicle() {
      return this.vehicle;
   }
}
