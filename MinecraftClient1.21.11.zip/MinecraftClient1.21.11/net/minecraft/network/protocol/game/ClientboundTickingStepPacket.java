package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.TickRateManager;

public record ClientboundTickingStepPacket(int tickSteps) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundTickingStepPacket> STREAM_CODEC = Packet.codec(
      ClientboundTickingStepPacket::write, ClientboundTickingStepPacket::new
   );

   private ClientboundTickingStepPacket(FriendlyByteBuf pdbb599e1_0_0) {
      this(pdbb599e1_0_0.readVarInt());
   }

   public static ClientboundTickingStepPacket from(TickRateManager pdbb599e1_2_0) {
      return new ClientboundTickingStepPacket(pdbb599e1_2_0.frozenTicksToRun());
   }

   private void write(FriendlyByteBuf pdbb599e1_3_0) {
      pdbb599e1_3_0.writeVarInt(this.tickSteps);
   }

   @Override
   public PacketType<ClientboundTickingStepPacket> type() {
      return GamePacketTypes.CLIENTBOUND_TICKING_STEP;
   }

   public void handle(ClientGamePacketListener pdbb599e1_4_0) {
      pdbb599e1_4_0.handleTickingStep(this);
   }
}
