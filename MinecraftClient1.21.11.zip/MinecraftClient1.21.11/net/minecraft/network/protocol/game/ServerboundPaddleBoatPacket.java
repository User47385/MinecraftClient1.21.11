package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundPaddleBoatPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundPaddleBoatPacket> STREAM_CODEC = Packet.codec(
      ServerboundPaddleBoatPacket::write, ServerboundPaddleBoatPacket::new
   );
   private final boolean left;
   private final boolean right;

   public ServerboundPaddleBoatPacket(boolean p93fa0f12_0_0, boolean p93fa0f12_1_1) {
      this.left = p93fa0f12_0_0;
      this.right = p93fa0f12_1_1;
   }

   private ServerboundPaddleBoatPacket(FriendlyByteBuf p93fa0f12_2_0) {
      this.left = p93fa0f12_2_0.readBoolean();
      this.right = p93fa0f12_2_0.readBoolean();
   }

   private void write(FriendlyByteBuf p93fa0f12_3_0) {
      p93fa0f12_3_0.writeBoolean(this.left);
      p93fa0f12_3_0.writeBoolean(this.right);
   }

   public void handle(ServerGamePacketListener p93fa0f12_4_0) {
      p93fa0f12_4_0.handlePaddleBoat(this);
   }

   @Override
   public PacketType<ServerboundPaddleBoatPacket> type() {
      return GamePacketTypes.SERVERBOUND_PADDLE_BOAT;
   }

   public boolean getLeft() {
      return this.left;
   }

   public boolean getRight() {
      return this.right;
   }
}
