package net.minecraft.network.protocol.game;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.saveddata.maps.MapDecoration;
import net.minecraft.world.level.saveddata.maps.MapId;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import org.jspecify.annotations.Nullable;

public record ClientboundMapItemDataPacket(
   MapId mapId, byte scale, boolean locked, Optional<List<MapDecoration>> decorations, Optional<MapItemSavedData.MapPatch> colorPatch
) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundMapItemDataPacket> STREAM_CODEC = StreamCodec.composite(
      MapId.STREAM_CODEC,
      ClientboundMapItemDataPacket::mapId,
      ByteBufCodecs.BYTE,
      ClientboundMapItemDataPacket::scale,
      ByteBufCodecs.BOOL,
      ClientboundMapItemDataPacket::locked,
      MapDecoration.STREAM_CODEC.apply(ByteBufCodecs.list()).apply(ByteBufCodecs::optional),
      ClientboundMapItemDataPacket::decorations,
      MapItemSavedData.MapPatch.STREAM_CODEC,
      ClientboundMapItemDataPacket::colorPatch,
      ClientboundMapItemDataPacket::new
   );

   public ClientboundMapItemDataPacket(
      MapId p4e422929_0_0,
      byte p4e422929_1_1,
      boolean p4e422929_2_2,
      @Nullable Collection<MapDecoration> p4e422929_3_3,
      MapItemSavedData.@Nullable MapPatch p4e422929_4_4
   ) {
      this(
         p4e422929_0_0,
         p4e422929_1_1,
         p4e422929_2_2,
         p4e422929_3_3 != null ? Optional.of(List.copyOf(p4e422929_3_3)) : Optional.empty(),
         Optional.ofNullable(p4e422929_4_4)
      );
   }

   @Override
   public PacketType<ClientboundMapItemDataPacket> type() {
      return GamePacketTypes.CLIENTBOUND_MAP_ITEM_DATA;
   }

   public void handle(ClientGamePacketListener p4e422929_10_0) {
      p4e422929_10_0.handleMapItemData(this);
   }

   public void applyToMap(MapItemSavedData p4e422929_11_0) {
      this.decorations.ifPresent(p4e422929_11_0::addClientSideDecorations);
      this.colorPatch.ifPresent(p4e422929_15_1 -> p4e422929_15_1.applyToMap(p4e422929_11_0));
   }
}
