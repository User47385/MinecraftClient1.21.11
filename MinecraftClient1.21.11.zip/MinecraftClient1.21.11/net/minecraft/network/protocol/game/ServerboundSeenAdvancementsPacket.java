package net.minecraft.network.protocol.game;

import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;

public class ServerboundSeenAdvancementsPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundSeenAdvancementsPacket> STREAM_CODEC = Packet.codec(
      ServerboundSeenAdvancementsPacket::write, ServerboundSeenAdvancementsPacket::new
   );
   private final ServerboundSeenAdvancementsPacket.Action action;
   private final @Nullable Identifier tab;

   public ServerboundSeenAdvancementsPacket(ServerboundSeenAdvancementsPacket.Action p1679df6_0_0, @Nullable Identifier p1679df6_1_1) {
      this.action = p1679df6_0_0;
      this.tab = p1679df6_1_1;
   }

   public static ServerboundSeenAdvancementsPacket openedTab(AdvancementHolder p1679df6_2_0) {
      return new ServerboundSeenAdvancementsPacket(ServerboundSeenAdvancementsPacket.Action.OPENED_TAB, p1679df6_2_0.id());
   }

   public static ServerboundSeenAdvancementsPacket closedScreen() {
      return new ServerboundSeenAdvancementsPacket(ServerboundSeenAdvancementsPacket.Action.CLOSED_SCREEN, null);
   }

   private ServerboundSeenAdvancementsPacket(FriendlyByteBuf p1679df6_3_0) {
      this.action = p1679df6_3_0.readEnum(ServerboundSeenAdvancementsPacket.Action.class);
      if (this.action == ServerboundSeenAdvancementsPacket.Action.OPENED_TAB) {
         this.tab = p1679df6_3_0.readIdentifier();
      } else {
         this.tab = null;
      }
   }

   private void write(FriendlyByteBuf p1679df6_4_0) {
      p1679df6_4_0.writeEnum(this.action);
      if (this.action == ServerboundSeenAdvancementsPacket.Action.OPENED_TAB) {
         p1679df6_4_0.writeIdentifier(this.tab);
      }
   }

   @Override
   public PacketType<ServerboundSeenAdvancementsPacket> type() {
      return GamePacketTypes.SERVERBOUND_SEEN_ADVANCEMENTS;
   }

   public void handle(ServerGamePacketListener p1679df6_5_0) {
      p1679df6_5_0.handleSeenAdvancements(this);
   }

   public ServerboundSeenAdvancementsPacket.Action getAction() {
      return this.action;
   }

   public @Nullable Identifier getTab() {
      return this.tab;
   }

   public enum Action {
      OPENED_TAB,
      CLOSED_SCREEN;
   }
}
