package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundContainerSetDataPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundContainerSetDataPacket> STREAM_CODEC = Packet.codec(
      ClientboundContainerSetDataPacket::write, ClientboundContainerSetDataPacket::new
   );
   private final int containerId;
   private final int id;
   private final int value;

   public ClientboundContainerSetDataPacket(int pec27986b_0_0, int pec27986b_1_1, int pec27986b_2_2) {
      this.containerId = pec27986b_0_0;
      this.id = pec27986b_1_1;
      this.value = pec27986b_2_2;
   }

   private ClientboundContainerSetDataPacket(FriendlyByteBuf pec27986b_3_0) {
      this.containerId = pec27986b_3_0.readContainerId();
      this.id = pec27986b_3_0.readShort();
      this.value = pec27986b_3_0.readShort();
   }

   private void write(FriendlyByteBuf pec27986b_4_0) {
      pec27986b_4_0.writeContainerId(this.containerId);
      pec27986b_4_0.writeShort(this.id);
      pec27986b_4_0.writeShort(this.value);
   }

   @Override
   public PacketType<ClientboundContainerSetDataPacket> type() {
      return GamePacketTypes.CLIENTBOUND_CONTAINER_SET_DATA;
   }

   public void handle(ClientGamePacketListener pec27986b_5_0) {
      pec27986b_5_0.handleContainerSetData(this);
   }

   public int getContainerId() {
      return this.containerId;
   }

   public int getId() {
      return this.id;
   }

   public int getValue() {
      return this.value;
   }
}
