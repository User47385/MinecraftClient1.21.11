package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.PositionMoveRotation;

public record ClientboundEntityPositionSyncPacket(int id, PositionMoveRotation values, boolean onGround) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundEntityPositionSyncPacket> STREAM_CODEC = StreamCodec.composite(
      ByteBufCodecs.VAR_INT,
      ClientboundEntityPositionSyncPacket::id,
      PositionMoveRotation.STREAM_CODEC,
      ClientboundEntityPositionSyncPacket::values,
      ByteBufCodecs.BOOL,
      ClientboundEntityPositionSyncPacket::onGround,
      ClientboundEntityPositionSyncPacket::new
   );

   public static ClientboundEntityPositionSyncPacket of(Entity p439ea4e7_3_0) {
      return new ClientboundEntityPositionSyncPacket(
         p439ea4e7_3_0.getId(),
         new PositionMoveRotation(p439ea4e7_3_0.trackingPosition(), p439ea4e7_3_0.getDeltaMovement(), p439ea4e7_3_0.getYRot(), p439ea4e7_3_0.getXRot()),
         p439ea4e7_3_0.onGround()
      );
   }

   @Override
   public PacketType<ClientboundEntityPositionSyncPacket> type() {
      return GamePacketTypes.CLIENTBOUND_ENTITY_POSITION_SYNC;
   }

   public void handle(ClientGamePacketListener p439ea4e7_4_0) {
      p439ea4e7_4_0.handleEntityPositionSync(this);
   }
}
