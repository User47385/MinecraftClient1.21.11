package net.minecraft.network.protocol.game;

import net.minecraft.core.Holder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

public class ClientboundSoundPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundSoundPacket> STREAM_CODEC = Packet.codec(
      ClientboundSoundPacket::write, ClientboundSoundPacket::new
   );
   public static final float LOCATION_ACCURACY = 8.0F;
   private final Holder<SoundEvent> sound;
   private final SoundSource source;
   private final int x;
   private final int y;
   private final int z;
   private final float volume;
   private final float pitch;
   private final long seed;

   public ClientboundSoundPacket(
      Holder<SoundEvent> pa74154df_0_0,
      SoundSource pa74154df_1_1,
      double pa74154df_2_2,
      double pa74154df_3_3,
      double pa74154df_4_4,
      float pa74154df_5_5,
      float pa74154df_6_6,
      long pa74154df_7_7
   ) {
      this.sound = pa74154df_0_0;
      this.source = pa74154df_1_1;
      this.x = (int)(pa74154df_2_2 * 8.0);
      this.y = (int)(pa74154df_3_3 * 8.0);
      this.z = (int)(pa74154df_4_4 * 8.0);
      this.volume = pa74154df_5_5;
      this.pitch = pa74154df_6_6;
      this.seed = pa74154df_7_7;
   }

   private ClientboundSoundPacket(RegistryFriendlyByteBuf pa74154df_8_0) {
      this.sound = SoundEvent.STREAM_CODEC.decode(pa74154df_8_0);
      this.source = pa74154df_8_0.readEnum(SoundSource.class);
      this.x = pa74154df_8_0.readInt();
      this.y = pa74154df_8_0.readInt();
      this.z = pa74154df_8_0.readInt();
      this.volume = pa74154df_8_0.readFloat();
      this.pitch = pa74154df_8_0.readFloat();
      this.seed = pa74154df_8_0.readLong();
   }

   private void write(RegistryFriendlyByteBuf pa74154df_9_0) {
      SoundEvent.STREAM_CODEC.encode(pa74154df_9_0, this.sound);
      pa74154df_9_0.writeEnum(this.source);
      pa74154df_9_0.writeInt(this.x);
      pa74154df_9_0.writeInt(this.y);
      pa74154df_9_0.writeInt(this.z);
      pa74154df_9_0.writeFloat(this.volume);
      pa74154df_9_0.writeFloat(this.pitch);
      pa74154df_9_0.writeLong(this.seed);
   }

   @Override
   public PacketType<ClientboundSoundPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SOUND;
   }

   public void handle(ClientGamePacketListener pa74154df_10_0) {
      pa74154df_10_0.handleSoundEvent(this);
   }

   public Holder<SoundEvent> getSound() {
      return this.sound;
   }

   public SoundSource getSource() {
      return this.source;
   }

   public double getX() {
      return this.x / 8.0F;
   }

   public double getY() {
      return this.y / 8.0F;
   }

   public double getZ() {
      return this.z / 8.0F;
   }

   public float getVolume() {
      return this.volume;
   }

   public float getPitch() {
      return this.pitch;
   }

   public long getSeed() {
      return this.seed;
   }
}
