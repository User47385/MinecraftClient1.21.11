package net.minecraft.network.protocol.game;

import java.util.UUID;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import org.jspecify.annotations.Nullable;

public class ServerboundTeleportToEntityPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundTeleportToEntityPacket> STREAM_CODEC = Packet.codec(
      ServerboundTeleportToEntityPacket::write, ServerboundTeleportToEntityPacket::new
   );
   private final UUID uuid;

   public ServerboundTeleportToEntityPacket(UUID pda1df291_0_0) {
      this.uuid = pda1df291_0_0;
   }

   private ServerboundTeleportToEntityPacket(FriendlyByteBuf pda1df291_1_0) {
      this.uuid = pda1df291_1_0.readUUID();
   }

   private void write(FriendlyByteBuf pda1df291_2_0) {
      pda1df291_2_0.writeUUID(this.uuid);
   }

   @Override
   public PacketType<ServerboundTeleportToEntityPacket> type() {
      return GamePacketTypes.SERVERBOUND_TELEPORT_TO_ENTITY;
   }

   public void handle(ServerGamePacketListener pda1df291_3_0) {
      pda1df291_3_0.handleTeleportToEntityPacket(this);
   }

   public @Nullable Entity getEntity(ServerLevel pda1df291_4_0) {
      return pda1df291_4_0.getEntity(this.uuid);
   }
}
