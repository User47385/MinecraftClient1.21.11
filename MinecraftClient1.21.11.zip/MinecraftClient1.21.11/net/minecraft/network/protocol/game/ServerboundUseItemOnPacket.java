package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;

public class ServerboundUseItemOnPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundUseItemOnPacket> STREAM_CODEC = Packet.codec(
      ServerboundUseItemOnPacket::write, ServerboundUseItemOnPacket::new
   );
   private final BlockHitResult blockHit;
   private final InteractionHand hand;
   private final int sequence;

   public ServerboundUseItemOnPacket(InteractionHand p1eb43c81_0_0, BlockHitResult p1eb43c81_1_1, int p1eb43c81_2_2) {
      this.hand = p1eb43c81_0_0;
      this.blockHit = p1eb43c81_1_1;
      this.sequence = p1eb43c81_2_2;
   }

   private ServerboundUseItemOnPacket(FriendlyByteBuf p1eb43c81_3_0) {
      this.hand = p1eb43c81_3_0.readEnum(InteractionHand.class);
      this.blockHit = p1eb43c81_3_0.readBlockHitResult();
      this.sequence = p1eb43c81_3_0.readVarInt();
   }

   private void write(FriendlyByteBuf p1eb43c81_4_0) {
      p1eb43c81_4_0.writeEnum(this.hand);
      p1eb43c81_4_0.writeBlockHitResult(this.blockHit);
      p1eb43c81_4_0.writeVarInt(this.sequence);
   }

   @Override
   public PacketType<ServerboundUseItemOnPacket> type() {
      return GamePacketTypes.SERVERBOUND_USE_ITEM_ON;
   }

   public void handle(ServerGamePacketListener p1eb43c81_5_0) {
      p1eb43c81_5_0.handleUseItemOn(this);
   }

   public InteractionHand getHand() {
      return this.hand;
   }

   public BlockHitResult getHitResult() {
      return this.blockHit;
   }

   public int getSequence() {
      return this.sequence;
   }
}
