package net.minecraft.network.protocol.game;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.item.ItemStack;

public class ClientboundContainerSetSlotPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundContainerSetSlotPacket> STREAM_CODEC = Packet.codec(
      ClientboundContainerSetSlotPacket::write, ClientboundContainerSetSlotPacket::new
   );
   private final int containerId;
   private final int stateId;
   private final int slot;
   private final ItemStack itemStack;

   public ClientboundContainerSetSlotPacket(int p811683bf_0_0, int p811683bf_1_1, int p811683bf_2_2, ItemStack p811683bf_3_3) {
      this.containerId = p811683bf_0_0;
      this.stateId = p811683bf_1_1;
      this.slot = p811683bf_2_2;
      this.itemStack = p811683bf_3_3.copy();
   }

   private ClientboundContainerSetSlotPacket(RegistryFriendlyByteBuf p811683bf_4_0) {
      this.containerId = p811683bf_4_0.readContainerId();
      this.stateId = p811683bf_4_0.readVarInt();
      this.slot = p811683bf_4_0.readShort();
      this.itemStack = ItemStack.OPTIONAL_STREAM_CODEC.decode(p811683bf_4_0);
   }

   private void write(RegistryFriendlyByteBuf p811683bf_5_0) {
      p811683bf_5_0.writeContainerId(this.containerId);
      p811683bf_5_0.writeVarInt(this.stateId);
      p811683bf_5_0.writeShort(this.slot);
      ItemStack.OPTIONAL_STREAM_CODEC.encode(p811683bf_5_0, this.itemStack);
   }

   @Override
   public PacketType<ClientboundContainerSetSlotPacket> type() {
      return GamePacketTypes.CLIENTBOUND_CONTAINER_SET_SLOT;
   }

   public void handle(ClientGamePacketListener p811683bf_6_0) {
      p811683bf_6_0.handleContainerSetSlot(this);
   }

   public int getContainerId() {
      return this.containerId;
   }

   public int getSlot() {
      return this.slot;
   }

   public ItemStack getItem() {
      return this.itemStack;
   }

   public int getStateId() {
      return this.stateId;
   }
}
