package net.minecraft.network.protocol.game;

import net.minecraft.core.Holder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;

public class ClientboundSoundEntityPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundSoundEntityPacket> STREAM_CODEC = Packet.codec(
      ClientboundSoundEntityPacket::write, ClientboundSoundEntityPacket::new
   );
   private final Holder<SoundEvent> sound;
   private final SoundSource source;
   private final int id;
   private final float volume;
   private final float pitch;
   private final long seed;

   public ClientboundSoundEntityPacket(
      Holder<SoundEvent> pa8c9162_0_0, SoundSource pa8c9162_1_1, Entity pa8c9162_2_2, float pa8c9162_3_3, float pa8c9162_4_4, long pa8c9162_5_5
   ) {
      this.sound = pa8c9162_0_0;
      this.source = pa8c9162_1_1;
      this.id = pa8c9162_2_2.getId();
      this.volume = pa8c9162_3_3;
      this.pitch = pa8c9162_4_4;
      this.seed = pa8c9162_5_5;
   }

   private ClientboundSoundEntityPacket(RegistryFriendlyByteBuf pa8c9162_6_0) {
      this.sound = SoundEvent.STREAM_CODEC.decode(pa8c9162_6_0);
      this.source = pa8c9162_6_0.readEnum(SoundSource.class);
      this.id = pa8c9162_6_0.readVarInt();
      this.volume = pa8c9162_6_0.readFloat();
      this.pitch = pa8c9162_6_0.readFloat();
      this.seed = pa8c9162_6_0.readLong();
   }

   private void write(RegistryFriendlyByteBuf pa8c9162_7_0) {
      SoundEvent.STREAM_CODEC.encode(pa8c9162_7_0, this.sound);
      pa8c9162_7_0.writeEnum(this.source);
      pa8c9162_7_0.writeVarInt(this.id);
      pa8c9162_7_0.writeFloat(this.volume);
      pa8c9162_7_0.writeFloat(this.pitch);
      pa8c9162_7_0.writeLong(this.seed);
   }

   @Override
   public PacketType<ClientboundSoundEntityPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SOUND_ENTITY;
   }

   public void handle(ClientGamePacketListener pa8c9162_8_0) {
      pa8c9162_8_0.handleSoundEntityEvent(this);
   }

   public Holder<SoundEvent> getSound() {
      return this.sound;
   }

   public SoundSource getSource() {
      return this.source;
   }

   public int getId() {
      return this.id;
   }

   public float getVolume() {
      return this.volume;
   }

   public float getPitch() {
      return this.pitch;
   }

   public long getSeed() {
      return this.seed;
   }
}
