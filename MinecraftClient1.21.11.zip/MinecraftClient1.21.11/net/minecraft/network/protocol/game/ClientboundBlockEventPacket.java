package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.block.Block;

public class ClientboundBlockEventPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundBlockEventPacket> STREAM_CODEC = Packet.codec(
      ClientboundBlockEventPacket::write, ClientboundBlockEventPacket::new
   );
   private final BlockPos pos;
   private final int b0;
   private final int b1;
   private final Block block;

   public ClientboundBlockEventPacket(BlockPos p15b4ef8d_0_0, Block p15b4ef8d_1_1, int p15b4ef8d_2_2, int p15b4ef8d_3_3) {
      this.pos = p15b4ef8d_0_0;
      this.block = p15b4ef8d_1_1;
      this.b0 = p15b4ef8d_2_2;
      this.b1 = p15b4ef8d_3_3;
   }

   private ClientboundBlockEventPacket(RegistryFriendlyByteBuf p15b4ef8d_4_0) {
      this.pos = p15b4ef8d_4_0.readBlockPos();
      this.b0 = p15b4ef8d_4_0.readUnsignedByte();
      this.b1 = p15b4ef8d_4_0.readUnsignedByte();
      this.block = ByteBufCodecs.registry(Registries.BLOCK).decode(p15b4ef8d_4_0);
   }

   private void write(RegistryFriendlyByteBuf p15b4ef8d_5_0) {
      p15b4ef8d_5_0.writeBlockPos(this.pos);
      p15b4ef8d_5_0.writeByte(this.b0);
      p15b4ef8d_5_0.writeByte(this.b1);
      ByteBufCodecs.registry(Registries.BLOCK).encode(p15b4ef8d_5_0, this.block);
   }

   @Override
   public PacketType<ClientboundBlockEventPacket> type() {
      return GamePacketTypes.CLIENTBOUND_BLOCK_EVENT;
   }

   public void handle(ClientGamePacketListener p15b4ef8d_6_0) {
      p15b4ef8d_6_0.handleBlockEvent(this);
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public int getB0() {
      return this.b0;
   }

   public int getB1() {
      return this.b1;
   }

   public Block getBlock() {
      return this.block;
   }
}
