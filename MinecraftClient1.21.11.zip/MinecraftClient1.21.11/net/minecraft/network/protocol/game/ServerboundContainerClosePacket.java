package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundContainerClosePacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundContainerClosePacket> STREAM_CODEC = Packet.codec(
      ServerboundContainerClosePacket::write, ServerboundContainerClosePacket::new
   );
   private final int containerId;

   public ServerboundContainerClosePacket(int p39b2a37f_0_0) {
      this.containerId = p39b2a37f_0_0;
   }

   private ServerboundContainerClosePacket(FriendlyByteBuf p39b2a37f_1_0) {
      this.containerId = p39b2a37f_1_0.readContainerId();
   }

   private void write(FriendlyByteBuf p39b2a37f_2_0) {
      p39b2a37f_2_0.writeContainerId(this.containerId);
   }

   @Override
   public PacketType<ServerboundContainerClosePacket> type() {
      return GamePacketTypes.SERVERBOUND_CONTAINER_CLOSE;
   }

   public void handle(ServerGamePacketListener p39b2a37f_3_0) {
      p39b2a37f_3_0.handleContainerClose(this);
   }

   public int getContainerId() {
      return this.containerId;
   }
}
