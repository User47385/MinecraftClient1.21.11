package net.minecraft.network.protocol.game;

import java.util.BitSet;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.lighting.LevelLightEngine;
import org.jspecify.annotations.Nullable;

public class ClientboundLevelChunkWithLightPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundLevelChunkWithLightPacket> STREAM_CODEC = Packet.codec(
      ClientboundLevelChunkWithLightPacket::write, ClientboundLevelChunkWithLightPacket::new
   );
   private final int x;
   private final int z;
   private final ClientboundLevelChunkPacketData chunkData;
   private final ClientboundLightUpdatePacketData lightData;

   public ClientboundLevelChunkWithLightPacket(
      LevelChunk p80899c77_0_0, LevelLightEngine p80899c77_1_1, @Nullable BitSet p80899c77_2_2, @Nullable BitSet p80899c77_3_3
   ) {
      ChunkPos $$4 = p80899c77_0_0.getPos();
      this.x = $$4.x;
      this.z = $$4.z;
      this.chunkData = new ClientboundLevelChunkPacketData(p80899c77_0_0);
      this.lightData = new ClientboundLightUpdatePacketData($$4, p80899c77_1_1, p80899c77_2_2, p80899c77_3_3);
   }

   private ClientboundLevelChunkWithLightPacket(RegistryFriendlyByteBuf p80899c77_4_0) {
      this.x = p80899c77_4_0.readInt();
      this.z = p80899c77_4_0.readInt();
      this.chunkData = new ClientboundLevelChunkPacketData(p80899c77_4_0, this.x, this.z);
      this.lightData = new ClientboundLightUpdatePacketData(p80899c77_4_0, this.x, this.z);
   }

   private void write(RegistryFriendlyByteBuf p80899c77_5_0) {
      p80899c77_5_0.writeInt(this.x);
      p80899c77_5_0.writeInt(this.z);
      this.chunkData.write(p80899c77_5_0);
      this.lightData.write(p80899c77_5_0);
   }

   @Override
   public PacketType<ClientboundLevelChunkWithLightPacket> type() {
      return GamePacketTypes.CLIENTBOUND_LEVEL_CHUNK_WITH_LIGHT;
   }

   public void handle(ClientGamePacketListener p80899c77_6_0) {
      p80899c77_6_0.handleLevelChunkWithLight(this);
   }

   public int getX() {
      return this.x;
   }

   public int getZ() {
      return this.z;
   }

   public ClientboundLevelChunkPacketData getChunkData() {
      return this.chunkData;
   }

   public ClientboundLightUpdatePacketData getLightData() {
      return this.lightData;
   }
}
