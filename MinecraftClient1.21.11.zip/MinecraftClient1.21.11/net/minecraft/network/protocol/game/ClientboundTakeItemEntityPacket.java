package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundTakeItemEntityPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundTakeItemEntityPacket> STREAM_CODEC = Packet.codec(
      ClientboundTakeItemEntityPacket::write, ClientboundTakeItemEntityPacket::new
   );
   private final int itemId;
   private final int playerId;
   private final int amount;

   public ClientboundTakeItemEntityPacket(int p354a563d_0_0, int p354a563d_1_1, int p354a563d_2_2) {
      this.itemId = p354a563d_0_0;
      this.playerId = p354a563d_1_1;
      this.amount = p354a563d_2_2;
   }

   private ClientboundTakeItemEntityPacket(FriendlyByteBuf p354a563d_3_0) {
      this.itemId = p354a563d_3_0.readVarInt();
      this.playerId = p354a563d_3_0.readVarInt();
      this.amount = p354a563d_3_0.readVarInt();
   }

   private void write(FriendlyByteBuf p354a563d_4_0) {
      p354a563d_4_0.writeVarInt(this.itemId);
      p354a563d_4_0.writeVarInt(this.playerId);
      p354a563d_4_0.writeVarInt(this.amount);
   }

   @Override
   public PacketType<ClientboundTakeItemEntityPacket> type() {
      return GamePacketTypes.CLIENTBOUND_TAKE_ITEM_ENTITY;
   }

   public void handle(ClientGamePacketListener p354a563d_5_0) {
      p354a563d_5_0.handleTakeItemEntity(this);
   }

   public int getItemId() {
      return this.itemId;
   }

   public int getPlayerId() {
      return this.playerId;
   }

   public int getAmount() {
      return this.amount;
   }
}
