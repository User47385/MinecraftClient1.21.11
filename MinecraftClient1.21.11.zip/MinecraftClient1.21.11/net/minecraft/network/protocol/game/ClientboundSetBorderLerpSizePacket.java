package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.border.WorldBorder;

public class ClientboundSetBorderLerpSizePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetBorderLerpSizePacket> STREAM_CODEC = Packet.codec(
      ClientboundSetBorderLerpSizePacket::write, ClientboundSetBorderLerpSizePacket::new
   );
   private final double oldSize;
   private final double newSize;
   private final long lerpTime;

   public ClientboundSetBorderLerpSizePacket(WorldBorder p91955f6_0_0) {
      this.oldSize = p91955f6_0_0.getSize();
      this.newSize = p91955f6_0_0.getLerpTarget();
      this.lerpTime = p91955f6_0_0.getLerpTime();
   }

   private ClientboundSetBorderLerpSizePacket(FriendlyByteBuf p91955f6_1_0) {
      this.oldSize = p91955f6_1_0.readDouble();
      this.newSize = p91955f6_1_0.readDouble();
      this.lerpTime = p91955f6_1_0.readVarLong();
   }

   private void write(FriendlyByteBuf p91955f6_2_0) {
      p91955f6_2_0.writeDouble(this.oldSize);
      p91955f6_2_0.writeDouble(this.newSize);
      p91955f6_2_0.writeVarLong(this.lerpTime);
   }

   @Override
   public PacketType<ClientboundSetBorderLerpSizePacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_BORDER_LERP_SIZE;
   }

   public void handle(ClientGamePacketListener p91955f6_3_0) {
      p91955f6_3_0.handleSetBorderLerpSize(this);
   }

   public double getOldSize() {
      return this.oldSize;
   }

   public double getNewSize() {
      return this.newSize;
   }

   public long getLerpTime() {
      return this.lerpTime;
   }
}
