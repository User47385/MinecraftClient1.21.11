package net.minecraft.network.protocol.game;

import com.google.common.collect.Sets;
import java.util.Set;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

public record ClientboundLoginPacket(
   int playerId,
   boolean hardcore,
   Set<ResourceKey<Level>> levels,
   int maxPlayers,
   int chunkRadius,
   int simulationDistance,
   boolean reducedDebugInfo,
   boolean showDeathScreen,
   boolean doLimitedCrafting,
   CommonPlayerSpawnInfo commonPlayerSpawnInfo,
   boolean enforcesSecureChat
) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundLoginPacket> STREAM_CODEC = Packet.codec(
      ClientboundLoginPacket::write, ClientboundLoginPacket::new
   );

   private ClientboundLoginPacket(RegistryFriendlyByteBuf p82dacfb9_0_0) {
      this(
         p82dacfb9_0_0.readInt(),
         p82dacfb9_0_0.readBoolean(),
         p82dacfb9_0_0.readCollection(Sets::newHashSetWithExpectedSize, p82dacfb9_16_0 -> p82dacfb9_16_0.readResourceKey(Registries.DIMENSION)),
         p82dacfb9_0_0.readVarInt(),
         p82dacfb9_0_0.readVarInt(),
         p82dacfb9_0_0.readVarInt(),
         p82dacfb9_0_0.readBoolean(),
         p82dacfb9_0_0.readBoolean(),
         p82dacfb9_0_0.readBoolean(),
         new CommonPlayerSpawnInfo(p82dacfb9_0_0),
         p82dacfb9_0_0.readBoolean()
      );
   }

   private void write(RegistryFriendlyByteBuf p82dacfb9_12_0) {
      p82dacfb9_12_0.writeInt(this.playerId);
      p82dacfb9_12_0.writeBoolean(this.hardcore);
      p82dacfb9_12_0.writeCollection(this.levels, FriendlyByteBuf::writeResourceKey);
      p82dacfb9_12_0.writeVarInt(this.maxPlayers);
      p82dacfb9_12_0.writeVarInt(this.chunkRadius);
      p82dacfb9_12_0.writeVarInt(this.simulationDistance);
      p82dacfb9_12_0.writeBoolean(this.reducedDebugInfo);
      p82dacfb9_12_0.writeBoolean(this.showDeathScreen);
      p82dacfb9_12_0.writeBoolean(this.doLimitedCrafting);
      this.commonPlayerSpawnInfo.write(p82dacfb9_12_0);
      p82dacfb9_12_0.writeBoolean(this.enforcesSecureChat);
   }

   @Override
   public PacketType<ClientboundLoginPacket> type() {
      return GamePacketTypes.CLIENTBOUND_LOGIN;
   }

   public void handle(ClientGamePacketListener p82dacfb9_13_0) {
      p82dacfb9_13_0.handleLogin(this);
   }
}
