package net.minecraft.network.protocol.game;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import java.util.List;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

public record ClientboundChunksBiomesPacket(List<ClientboundChunksBiomesPacket.ChunkBiomeData> chunkBiomeData) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundChunksBiomesPacket> STREAM_CODEC = Packet.codec(
      ClientboundChunksBiomesPacket::write, ClientboundChunksBiomesPacket::new
   );
   private static final int TWO_MEGABYTES = 2097152;

   private ClientboundChunksBiomesPacket(FriendlyByteBuf pc61c1199_0_0) {
      this(pc61c1199_0_0.readList(ClientboundChunksBiomesPacket.ChunkBiomeData::new));
   }

   public static ClientboundChunksBiomesPacket forChunks(List<LevelChunk> pc61c1199_2_0) {
      return new ClientboundChunksBiomesPacket(pc61c1199_2_0.stream().map(ClientboundChunksBiomesPacket.ChunkBiomeData::new).toList());
   }

   private void write(FriendlyByteBuf pc61c1199_3_0) {
      pc61c1199_3_0.writeCollection(this.chunkBiomeData, (pc61c1199_7_0, pc61c1199_8_1) -> pc61c1199_8_1.write(pc61c1199_7_0));
   }

   @Override
   public PacketType<ClientboundChunksBiomesPacket> type() {
      return GamePacketTypes.CLIENTBOUND_CHUNKS_BIOMES;
   }

   public void handle(ClientGamePacketListener pc61c1199_4_0) {
      pc61c1199_4_0.handleChunksBiomes(this);
   }

   public record ChunkBiomeData(ChunkPos pos, byte[] buffer) {
      public ChunkBiomeData(LevelChunk p11a0b08_0_0) {
         this(p11a0b08_0_0.getPos(), new byte[calculateChunkSize(p11a0b08_0_0)]);
         extractChunkData(new FriendlyByteBuf(this.getWriteBuffer()), p11a0b08_0_0);
      }

      public ChunkBiomeData(FriendlyByteBuf p11a0b08_1_0) {
         this(p11a0b08_1_0.readChunkPos(), p11a0b08_1_0.readByteArray(2097152));
      }

      private static int calculateChunkSize(LevelChunk p11a0b08_4_0) {
         int $$1 = 0;

         for (LevelChunkSection $$2 : p11a0b08_4_0.getSections()) {
            $$1 += $$2.getBiomes().getSerializedSize();
         }

         return $$1;
      }

      public FriendlyByteBuf getReadBuffer() {
         return new FriendlyByteBuf(Unpooled.wrappedBuffer(this.buffer));
      }

      private ByteBuf getWriteBuffer() {
         ByteBuf $$0 = Unpooled.wrappedBuffer(this.buffer);
         $$0.writerIndex(0);
         return $$0;
      }

      public static void extractChunkData(FriendlyByteBuf p11a0b08_5_0, LevelChunk p11a0b08_6_1) {
         for (LevelChunkSection $$2 : p11a0b08_6_1.getSections()) {
            $$2.getBiomes().write(p11a0b08_5_0);
         }

         if (p11a0b08_5_0.writerIndex() != p11a0b08_5_0.capacity()) {
            throw new IllegalStateException("Didn't fill biome buffer: expected " + p11a0b08_5_0.capacity() + " bytes, got " + p11a0b08_5_0.writerIndex());
         }
      }

      public void write(FriendlyByteBuf p11a0b08_7_0) {
         p11a0b08_7_0.writeChunkPos(this.pos);
         p11a0b08_7_0.writeByteArray(this.buffer);
      }
   }
}
