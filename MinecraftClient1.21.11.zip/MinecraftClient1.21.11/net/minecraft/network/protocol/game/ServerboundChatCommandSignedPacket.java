package net.minecraft.network.protocol.game;

import java.time.Instant;
import net.minecraft.commands.arguments.ArgumentSignatures;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.LastSeenMessages;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ServerboundChatCommandSignedPacket(
   String command, Instant timeStamp, long salt, ArgumentSignatures argumentSignatures, LastSeenMessages.Update lastSeenMessages
) implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundChatCommandSignedPacket> STREAM_CODEC = Packet.codec(
      ServerboundChatCommandSignedPacket::write, ServerboundChatCommandSignedPacket::new
   );

   private ServerboundChatCommandSignedPacket(FriendlyByteBuf p12379917_0_0) {
      this(
         p12379917_0_0.readUtf(),
         p12379917_0_0.readInstant(),
         p12379917_0_0.readLong(),
         new ArgumentSignatures(p12379917_0_0),
         new LastSeenMessages.Update(p12379917_0_0)
      );
   }

   private void write(FriendlyByteBuf p12379917_6_0) {
      p12379917_6_0.writeUtf(this.command);
      p12379917_6_0.writeInstant(this.timeStamp);
      p12379917_6_0.writeLong(this.salt);
      this.argumentSignatures.write(p12379917_6_0);
      this.lastSeenMessages.write(p12379917_6_0);
   }

   @Override
   public PacketType<ServerboundChatCommandSignedPacket> type() {
      return GamePacketTypes.SERVERBOUND_CHAT_COMMAND_SIGNED;
   }

   public void handle(ServerGamePacketListener p12379917_7_0) {
      p12379917_7_0.handleSignedChatCommand(this);
   }
}
