package net.minecraft.network.protocol.game;

import java.util.function.BiFunction;
import net.minecraft.core.BlockPos;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

public class ClientboundBlockEntityDataPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundBlockEntityDataPacket> STREAM_CODEC = StreamCodec.composite(
      BlockPos.STREAM_CODEC,
      ClientboundBlockEntityDataPacket::getPos,
      ByteBufCodecs.registry(Registries.BLOCK_ENTITY_TYPE),
      ClientboundBlockEntityDataPacket::getType,
      ByteBufCodecs.TRUSTED_COMPOUND_TAG,
      ClientboundBlockEntityDataPacket::getTag,
      ClientboundBlockEntityDataPacket::new
   );
   private final BlockPos pos;
   private final BlockEntityType<?> type;
   private final CompoundTag tag;

   public static ClientboundBlockEntityDataPacket create(BlockEntity p8566c82a_0_0, BiFunction<BlockEntity, RegistryAccess, CompoundTag> p8566c82a_1_1) {
      RegistryAccess $$2 = p8566c82a_0_0.getLevel().registryAccess();
      return new ClientboundBlockEntityDataPacket(p8566c82a_0_0.getBlockPos(), p8566c82a_0_0.getType(), p8566c82a_1_1.apply(p8566c82a_0_0, $$2));
   }

   public static ClientboundBlockEntityDataPacket create(BlockEntity p8566c82a_2_0) {
      return create(p8566c82a_2_0, BlockEntity::getUpdateTag);
   }

   private ClientboundBlockEntityDataPacket(BlockPos p8566c82a_3_0, BlockEntityType<?> p8566c82a_4_1, CompoundTag p8566c82a_5_2) {
      this.pos = p8566c82a_3_0;
      this.type = p8566c82a_4_1;
      this.tag = p8566c82a_5_2;
   }

   @Override
   public PacketType<ClientboundBlockEntityDataPacket> type() {
      return GamePacketTypes.CLIENTBOUND_BLOCK_ENTITY_DATA;
   }

   public void handle(ClientGamePacketListener p8566c82a_6_0) {
      p8566c82a_6_0.handleBlockEntityData(this);
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public BlockEntityType<?> getType() {
      return this.type;
   }

   public CompoundTag getTag() {
      return this.tag;
   }
}
