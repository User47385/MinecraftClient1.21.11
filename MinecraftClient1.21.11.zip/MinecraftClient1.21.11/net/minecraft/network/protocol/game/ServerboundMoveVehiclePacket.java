package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public record ServerboundMoveVehiclePacket(Vec3 position, float yRot, float xRot, boolean onGround) implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundMoveVehiclePacket> STREAM_CODEC = StreamCodec.composite(
      Vec3.STREAM_CODEC,
      ServerboundMoveVehiclePacket::position,
      ByteBufCodecs.FLOAT,
      ServerboundMoveVehiclePacket::yRot,
      ByteBufCodecs.FLOAT,
      ServerboundMoveVehiclePacket::xRot,
      ByteBufCodecs.BOOL,
      ServerboundMoveVehiclePacket::onGround,
      ServerboundMoveVehiclePacket::new
   );

   public static ServerboundMoveVehiclePacket fromEntity(Entity p86c72463_4_0) {
      return p86c72463_4_0.isInterpolating()
         ? new ServerboundMoveVehiclePacket(
            p86c72463_4_0.getInterpolation().position(),
            p86c72463_4_0.getInterpolation().yRot(),
            p86c72463_4_0.getInterpolation().xRot(),
            p86c72463_4_0.onGround()
         )
         : new ServerboundMoveVehiclePacket(p86c72463_4_0.position(), p86c72463_4_0.getYRot(), p86c72463_4_0.getXRot(), p86c72463_4_0.onGround());
   }

   @Override
   public PacketType<ServerboundMoveVehiclePacket> type() {
      return GamePacketTypes.SERVERBOUND_MOVE_VEHICLE;
   }

   public void handle(ServerGamePacketListener p86c72463_5_0) {
      p86c72463_5_0.handleMoveVehicle(this);
   }
}
