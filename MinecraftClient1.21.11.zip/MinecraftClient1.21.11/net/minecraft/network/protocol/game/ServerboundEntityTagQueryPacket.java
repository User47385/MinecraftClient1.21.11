package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundEntityTagQueryPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundEntityTagQueryPacket> STREAM_CODEC = Packet.codec(
      ServerboundEntityTagQueryPacket::write, ServerboundEntityTagQueryPacket::new
   );
   private final int transactionId;
   private final int entityId;

   public ServerboundEntityTagQueryPacket(int p6645fc59_0_0, int p6645fc59_1_1) {
      this.transactionId = p6645fc59_0_0;
      this.entityId = p6645fc59_1_1;
   }

   private ServerboundEntityTagQueryPacket(FriendlyByteBuf p6645fc59_2_0) {
      this.transactionId = p6645fc59_2_0.readVarInt();
      this.entityId = p6645fc59_2_0.readVarInt();
   }

   private void write(FriendlyByteBuf p6645fc59_3_0) {
      p6645fc59_3_0.writeVarInt(this.transactionId);
      p6645fc59_3_0.writeVarInt(this.entityId);
   }

   @Override
   public PacketType<ServerboundEntityTagQueryPacket> type() {
      return GamePacketTypes.SERVERBOUND_ENTITY_TAG_QUERY;
   }

   public void handle(ServerGamePacketListener p6645fc59_4_0) {
      p6645fc59_4_0.handleEntityTagQuery(this);
   }

   public int getTransactionId() {
      return this.transactionId;
   }

   public int getEntityId() {
      return this.entityId;
   }
}
