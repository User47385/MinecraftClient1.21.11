package net.minecraft.network.protocol.game;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundLevelParticlesPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundLevelParticlesPacket> STREAM_CODEC = Packet.codec(
      ClientboundLevelParticlesPacket::write, ClientboundLevelParticlesPacket::new
   );
   private final double x;
   private final double y;
   private final double z;
   private final float xDist;
   private final float yDist;
   private final float zDist;
   private final float maxSpeed;
   private final int count;
   private final boolean overrideLimiter;
   private final boolean alwaysShow;
   private final ParticleOptions particle;

   public <T extends ParticleOptions> ClientboundLevelParticlesPacket(
      T pa7d3e409_0_0,
      boolean pa7d3e409_1_1,
      boolean pa7d3e409_2_2,
      double pa7d3e409_3_3,
      double pa7d3e409_4_4,
      double pa7d3e409_5_5,
      float pa7d3e409_6_6,
      float pa7d3e409_7_7,
      float pa7d3e409_8_8,
      float pa7d3e409_9_9,
      int pa7d3e409_10_10
   ) {
      this.particle = pa7d3e409_0_0;
      this.overrideLimiter = pa7d3e409_1_1;
      this.alwaysShow = pa7d3e409_2_2;
      this.x = pa7d3e409_3_3;
      this.y = pa7d3e409_4_4;
      this.z = pa7d3e409_5_5;
      this.xDist = pa7d3e409_6_6;
      this.yDist = pa7d3e409_7_7;
      this.zDist = pa7d3e409_8_8;
      this.maxSpeed = pa7d3e409_9_9;
      this.count = pa7d3e409_10_10;
   }

   private ClientboundLevelParticlesPacket(RegistryFriendlyByteBuf pa7d3e409_11_0) {
      this.overrideLimiter = pa7d3e409_11_0.readBoolean();
      this.alwaysShow = pa7d3e409_11_0.readBoolean();
      this.x = pa7d3e409_11_0.readDouble();
      this.y = pa7d3e409_11_0.readDouble();
      this.z = pa7d3e409_11_0.readDouble();
      this.xDist = pa7d3e409_11_0.readFloat();
      this.yDist = pa7d3e409_11_0.readFloat();
      this.zDist = pa7d3e409_11_0.readFloat();
      this.maxSpeed = pa7d3e409_11_0.readFloat();
      this.count = pa7d3e409_11_0.readInt();
      this.particle = ParticleTypes.STREAM_CODEC.decode(pa7d3e409_11_0);
   }

   private void write(RegistryFriendlyByteBuf pa7d3e409_12_0) {
      pa7d3e409_12_0.writeBoolean(this.overrideLimiter);
      pa7d3e409_12_0.writeBoolean(this.alwaysShow);
      pa7d3e409_12_0.writeDouble(this.x);
      pa7d3e409_12_0.writeDouble(this.y);
      pa7d3e409_12_0.writeDouble(this.z);
      pa7d3e409_12_0.writeFloat(this.xDist);
      pa7d3e409_12_0.writeFloat(this.yDist);
      pa7d3e409_12_0.writeFloat(this.zDist);
      pa7d3e409_12_0.writeFloat(this.maxSpeed);
      pa7d3e409_12_0.writeInt(this.count);
      ParticleTypes.STREAM_CODEC.encode(pa7d3e409_12_0, this.particle);
   }

   @Override
   public PacketType<ClientboundLevelParticlesPacket> type() {
      return GamePacketTypes.CLIENTBOUND_LEVEL_PARTICLES;
   }

   public void handle(ClientGamePacketListener pa7d3e409_13_0) {
      pa7d3e409_13_0.handleParticleEvent(this);
   }

   public boolean isOverrideLimiter() {
      return this.overrideLimiter;
   }

   public boolean alwaysShow() {
      return this.alwaysShow;
   }

   public double getX() {
      return this.x;
   }

   public double getY() {
      return this.y;
   }

   public double getZ() {
      return this.z;
   }

   public float getXDist() {
      return this.xDist;
   }

   public float getYDist() {
      return this.yDist;
   }

   public float getZDist() {
      return this.zDist;
   }

   public float getMaxSpeed() {
      return this.maxSpeed;
   }

   public int getCount() {
      return this.count;
   }

   public ParticleOptions getParticle() {
      return this.particle;
   }
}
