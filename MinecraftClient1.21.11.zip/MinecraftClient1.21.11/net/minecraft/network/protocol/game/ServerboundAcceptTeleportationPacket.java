package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundAcceptTeleportationPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundAcceptTeleportationPacket> STREAM_CODEC = Packet.codec(
      ServerboundAcceptTeleportationPacket::write, ServerboundAcceptTeleportationPacket::new
   );
   private final int id;

   public ServerboundAcceptTeleportationPacket(int pa70ddb8a_0_0) {
      this.id = pa70ddb8a_0_0;
   }

   private ServerboundAcceptTeleportationPacket(FriendlyByteBuf pa70ddb8a_1_0) {
      this.id = pa70ddb8a_1_0.readVarInt();
   }

   private void write(FriendlyByteBuf pa70ddb8a_2_0) {
      pa70ddb8a_2_0.writeVarInt(this.id);
   }

   @Override
   public PacketType<ServerboundAcceptTeleportationPacket> type() {
      return GamePacketTypes.SERVERBOUND_ACCEPT_TELEPORTATION;
   }

   public void handle(ServerGamePacketListener pa70ddb8a_3_0) {
      pa70ddb8a_3_0.handleAcceptTeleportPacket(this);
   }

   public int getId() {
      return this.id;
   }
}
