package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundClearTitlesPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundClearTitlesPacket> STREAM_CODEC = Packet.codec(
      ClientboundClearTitlesPacket::write, ClientboundClearTitlesPacket::new
   );
   private final boolean resetTimes;

   public ClientboundClearTitlesPacket(boolean p44910cd8_0_0) {
      this.resetTimes = p44910cd8_0_0;
   }

   private ClientboundClearTitlesPacket(FriendlyByteBuf p44910cd8_1_0) {
      this.resetTimes = p44910cd8_1_0.readBoolean();
   }

   private void write(FriendlyByteBuf p44910cd8_2_0) {
      p44910cd8_2_0.writeBoolean(this.resetTimes);
   }

   @Override
   public PacketType<ClientboundClearTitlesPacket> type() {
      return GamePacketTypes.CLIENTBOUND_CLEAR_TITLES;
   }

   public void handle(ClientGamePacketListener p44910cd8_3_0) {
      p44910cd8_3_0.handleTitlesClear(this);
   }

   public boolean shouldResetTimes() {
      return this.resetTimes;
   }
}
