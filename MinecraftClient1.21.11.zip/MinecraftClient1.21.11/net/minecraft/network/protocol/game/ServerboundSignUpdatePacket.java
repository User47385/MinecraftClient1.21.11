package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundSignUpdatePacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundSignUpdatePacket> STREAM_CODEC = Packet.codec(
      ServerboundSignUpdatePacket::write, ServerboundSignUpdatePacket::new
   );
   private static final int MAX_STRING_LENGTH = 384;
   private final BlockPos pos;
   private final String[] lines;
   private final boolean isFrontText;

   public ServerboundSignUpdatePacket(
      BlockPos pa55c3b2e_0_0, boolean pa55c3b2e_1_1, String pa55c3b2e_2_2, String pa55c3b2e_3_3, String pa55c3b2e_4_4, String pa55c3b2e_5_5
   ) {
      this.pos = pa55c3b2e_0_0;
      this.isFrontText = pa55c3b2e_1_1;
      this.lines = new String[]{pa55c3b2e_2_2, pa55c3b2e_3_3, pa55c3b2e_4_4, pa55c3b2e_5_5};
   }

   private ServerboundSignUpdatePacket(FriendlyByteBuf pa55c3b2e_6_0) {
      this.pos = pa55c3b2e_6_0.readBlockPos();
      this.isFrontText = pa55c3b2e_6_0.readBoolean();
      this.lines = new String[4];

      for (int $$1 = 0; $$1 < 4; $$1++) {
         this.lines[$$1] = pa55c3b2e_6_0.readUtf(384);
      }
   }

   private void write(FriendlyByteBuf pa55c3b2e_7_0) {
      pa55c3b2e_7_0.writeBlockPos(this.pos);
      pa55c3b2e_7_0.writeBoolean(this.isFrontText);

      for (int $$1 = 0; $$1 < 4; $$1++) {
         pa55c3b2e_7_0.writeUtf(this.lines[$$1]);
      }
   }

   @Override
   public PacketType<ServerboundSignUpdatePacket> type() {
      return GamePacketTypes.SERVERBOUND_SIGN_UPDATE;
   }

   public void handle(ServerGamePacketListener pa55c3b2e_8_0) {
      pa55c3b2e_8_0.handleSignUpdate(this);
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public boolean isFrontText() {
      return this.isFrontText;
   }

   public String[] getLines() {
      return this.lines;
   }
}
