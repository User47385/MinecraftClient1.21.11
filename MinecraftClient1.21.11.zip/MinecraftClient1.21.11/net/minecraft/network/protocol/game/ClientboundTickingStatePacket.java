package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.TickRateManager;

public record ClientboundTickingStatePacket(float tickRate, boolean isFrozen) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundTickingStatePacket> STREAM_CODEC = Packet.codec(
      ClientboundTickingStatePacket::write, ClientboundTickingStatePacket::new
   );

   private ClientboundTickingStatePacket(FriendlyByteBuf p233156ac_0_0) {
      this(p233156ac_0_0.readFloat(), p233156ac_0_0.readBoolean());
   }

   public static ClientboundTickingStatePacket from(TickRateManager p233156ac_3_0) {
      return new ClientboundTickingStatePacket(p233156ac_3_0.tickrate(), p233156ac_3_0.isFrozen());
   }

   private void write(FriendlyByteBuf p233156ac_4_0) {
      p233156ac_4_0.writeFloat(this.tickRate);
      p233156ac_4_0.writeBoolean(this.isFrozen);
   }

   @Override
   public PacketType<ClientboundTickingStatePacket> type() {
      return GamePacketTypes.CLIENTBOUND_TICKING_STATE;
   }

   public void handle(ClientGamePacketListener p233156ac_5_0) {
      p233156ac_5_0.handleTickingState(this);
   }
}
