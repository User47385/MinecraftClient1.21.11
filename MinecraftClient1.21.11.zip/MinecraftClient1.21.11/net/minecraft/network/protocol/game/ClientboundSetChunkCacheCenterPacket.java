package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundSetChunkCacheCenterPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetChunkCacheCenterPacket> STREAM_CODEC = Packet.codec(
      ClientboundSetChunkCacheCenterPacket::write, ClientboundSetChunkCacheCenterPacket::new
   );
   private final int x;
   private final int z;

   public ClientboundSetChunkCacheCenterPacket(int pf2dd7e5c_0_0, int pf2dd7e5c_1_1) {
      this.x = pf2dd7e5c_0_0;
      this.z = pf2dd7e5c_1_1;
   }

   private ClientboundSetChunkCacheCenterPacket(FriendlyByteBuf pf2dd7e5c_2_0) {
      this.x = pf2dd7e5c_2_0.readVarInt();
      this.z = pf2dd7e5c_2_0.readVarInt();
   }

   private void write(FriendlyByteBuf pf2dd7e5c_3_0) {
      pf2dd7e5c_3_0.writeVarInt(this.x);
      pf2dd7e5c_3_0.writeVarInt(this.z);
   }

   @Override
   public PacketType<ClientboundSetChunkCacheCenterPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_CHUNK_CACHE_CENTER;
   }

   public void handle(ClientGamePacketListener pf2dd7e5c_4_0) {
      pf2dd7e5c_4_0.handleSetChunkCacheCenter(this);
   }

   public int getX() {
      return this.x;
   }

   public int getZ() {
      return this.z;
   }
}
