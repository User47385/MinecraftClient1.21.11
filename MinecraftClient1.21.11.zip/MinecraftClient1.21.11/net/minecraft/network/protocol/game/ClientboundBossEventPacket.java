package net.minecraft.network.protocol.game;

import java.util.UUID;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.codec.StreamDecoder;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.BossEvent;

public class ClientboundBossEventPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundBossEventPacket> STREAM_CODEC = Packet.codec(
      ClientboundBossEventPacket::write, ClientboundBossEventPacket::new
   );
   private static final int FLAG_DARKEN = 1;
   private static final int FLAG_MUSIC = 2;
   private static final int FLAG_FOG = 4;
   private final UUID id;
   private final ClientboundBossEventPacket.Operation operation;
   static final ClientboundBossEventPacket.Operation REMOVE_OPERATION = new ClientboundBossEventPacket.Operation() {
      @Override
      public ClientboundBossEventPacket.OperationType getType() {
         return ClientboundBossEventPacket.OperationType.REMOVE;
      }

      @Override
      public void dispatch(UUID pf4edc5ca_0_0, ClientboundBossEventPacket.Handler pf4edc5ca_1_1) {
         pf4edc5ca_1_1.remove(pf4edc5ca_0_0);
      }

      @Override
      public void write(RegistryFriendlyByteBuf pf4edc5ca_2_0) {
      }
   };

   private ClientboundBossEventPacket(UUID pd6f6ec7d_0_0, ClientboundBossEventPacket.Operation pd6f6ec7d_1_1) {
      this.id = pd6f6ec7d_0_0;
      this.operation = pd6f6ec7d_1_1;
   }

   private ClientboundBossEventPacket(RegistryFriendlyByteBuf pd6f6ec7d_2_0) {
      this.id = pd6f6ec7d_2_0.readUUID();
      ClientboundBossEventPacket.OperationType $$1 = pd6f6ec7d_2_0.readEnum(ClientboundBossEventPacket.OperationType.class);
      this.operation = $$1.reader.decode(pd6f6ec7d_2_0);
   }

   public static ClientboundBossEventPacket createAddPacket(BossEvent pd6f6ec7d_3_0) {
      return new ClientboundBossEventPacket(pd6f6ec7d_3_0.getId(), new ClientboundBossEventPacket.AddOperation(pd6f6ec7d_3_0));
   }

   public static ClientboundBossEventPacket createRemovePacket(UUID pd6f6ec7d_4_0) {
      return new ClientboundBossEventPacket(pd6f6ec7d_4_0, REMOVE_OPERATION);
   }

   public static ClientboundBossEventPacket createUpdateProgressPacket(BossEvent pd6f6ec7d_5_0) {
      return new ClientboundBossEventPacket(pd6f6ec7d_5_0.getId(), new ClientboundBossEventPacket.UpdateProgressOperation(pd6f6ec7d_5_0.getProgress()));
   }

   public static ClientboundBossEventPacket createUpdateNamePacket(BossEvent pd6f6ec7d_6_0) {
      return new ClientboundBossEventPacket(pd6f6ec7d_6_0.getId(), new ClientboundBossEventPacket.UpdateNameOperation(pd6f6ec7d_6_0.getName()));
   }

   public static ClientboundBossEventPacket createUpdateStylePacket(BossEvent pd6f6ec7d_7_0) {
      return new ClientboundBossEventPacket(
         pd6f6ec7d_7_0.getId(), new ClientboundBossEventPacket.UpdateStyleOperation(pd6f6ec7d_7_0.getColor(), pd6f6ec7d_7_0.getOverlay())
      );
   }

   public static ClientboundBossEventPacket createUpdatePropertiesPacket(BossEvent pd6f6ec7d_8_0) {
      return new ClientboundBossEventPacket(
         pd6f6ec7d_8_0.getId(),
         new ClientboundBossEventPacket.UpdatePropertiesOperation(
            pd6f6ec7d_8_0.shouldDarkenScreen(), pd6f6ec7d_8_0.shouldPlayBossMusic(), pd6f6ec7d_8_0.shouldCreateWorldFog()
         )
      );
   }

   private void write(RegistryFriendlyByteBuf pd6f6ec7d_9_0) {
      pd6f6ec7d_9_0.writeUUID(this.id);
      pd6f6ec7d_9_0.writeEnum(this.operation.getType());
      this.operation.write(pd6f6ec7d_9_0);
   }

   static int encodeProperties(boolean pd6f6ec7d_10_0, boolean pd6f6ec7d_11_1, boolean pd6f6ec7d_12_2) {
      int $$3 = 0;
      if (pd6f6ec7d_10_0) {
         $$3 |= 1;
      }

      if (pd6f6ec7d_11_1) {
         $$3 |= 2;
      }

      if (pd6f6ec7d_12_2) {
         $$3 |= 4;
      }

      return $$3;
   }

   @Override
   public PacketType<ClientboundBossEventPacket> type() {
      return GamePacketTypes.CLIENTBOUND_BOSS_EVENT;
   }

   public void handle(ClientGamePacketListener pd6f6ec7d_13_0) {
      pd6f6ec7d_13_0.handleBossUpdate(this);
   }

   public void dispatch(ClientboundBossEventPacket.Handler pd6f6ec7d_14_0) {
      this.operation.dispatch(this.id, pd6f6ec7d_14_0);
   }

   static class AddOperation implements ClientboundBossEventPacket.Operation {
      private final Component name;
      private final float progress;
      private final BossEvent.BossBarColor color;
      private final BossEvent.BossBarOverlay overlay;
      private final boolean darkenScreen;
      private final boolean playMusic;
      private final boolean createWorldFog;

      AddOperation(BossEvent p570ee6ad_0_0) {
         this.name = p570ee6ad_0_0.getName();
         this.progress = p570ee6ad_0_0.getProgress();
         this.color = p570ee6ad_0_0.getColor();
         this.overlay = p570ee6ad_0_0.getOverlay();
         this.darkenScreen = p570ee6ad_0_0.shouldDarkenScreen();
         this.playMusic = p570ee6ad_0_0.shouldPlayBossMusic();
         this.createWorldFog = p570ee6ad_0_0.shouldCreateWorldFog();
      }

      private AddOperation(RegistryFriendlyByteBuf p570ee6ad_1_0) {
         this.name = ComponentSerialization.TRUSTED_STREAM_CODEC.decode(p570ee6ad_1_0);
         this.progress = p570ee6ad_1_0.readFloat();
         this.color = p570ee6ad_1_0.readEnum(BossEvent.BossBarColor.class);
         this.overlay = p570ee6ad_1_0.readEnum(BossEvent.BossBarOverlay.class);
         int $$1 = p570ee6ad_1_0.readUnsignedByte();
         this.darkenScreen = ($$1 & 1) > 0;
         this.playMusic = ($$1 & 2) > 0;
         this.createWorldFog = ($$1 & 4) > 0;
      }

      @Override
      public ClientboundBossEventPacket.OperationType getType() {
         return ClientboundBossEventPacket.OperationType.ADD;
      }

      @Override
      public void dispatch(UUID p570ee6ad_2_0, ClientboundBossEventPacket.Handler p570ee6ad_3_1) {
         p570ee6ad_3_1.add(p570ee6ad_2_0, this.name, this.progress, this.color, this.overlay, this.darkenScreen, this.playMusic, this.createWorldFog);
      }

      @Override
      public void write(RegistryFriendlyByteBuf p570ee6ad_4_0) {
         ComponentSerialization.TRUSTED_STREAM_CODEC.encode(p570ee6ad_4_0, this.name);
         p570ee6ad_4_0.writeFloat(this.progress);
         p570ee6ad_4_0.writeEnum(this.color);
         p570ee6ad_4_0.writeEnum(this.overlay);
         p570ee6ad_4_0.writeByte(ClientboundBossEventPacket.encodeProperties(this.darkenScreen, this.playMusic, this.createWorldFog));
      }
   }

   public interface Handler {
      default void add(
         UUID p24e35e03_0_0,
         Component p24e35e03_1_1,
         float p24e35e03_2_2,
         BossEvent.BossBarColor p24e35e03_3_3,
         BossEvent.BossBarOverlay p24e35e03_4_4,
         boolean p24e35e03_5_5,
         boolean p24e35e03_6_6,
         boolean p24e35e03_7_7
      ) {
      }

      default void remove(UUID p24e35e03_8_0) {
      }

      default void updateProgress(UUID p24e35e03_9_0, float p24e35e03_10_1) {
      }

      default void updateName(UUID p24e35e03_11_0, Component p24e35e03_12_1) {
      }

      default void updateStyle(UUID p24e35e03_13_0, BossEvent.BossBarColor p24e35e03_14_1, BossEvent.BossBarOverlay p24e35e03_15_2) {
      }

      default void updateProperties(UUID p24e35e03_16_0, boolean p24e35e03_17_1, boolean p24e35e03_18_2, boolean p24e35e03_19_3) {
      }
   }

   interface Operation {
      ClientboundBossEventPacket.OperationType getType();

      void dispatch(UUID var1, ClientboundBossEventPacket.Handler var2);

      void write(RegistryFriendlyByteBuf var1);
   }

   enum OperationType {
      ADD(ClientboundBossEventPacket.AddOperation::new),
      REMOVE(p8ed8253a_4_0 -> ClientboundBossEventPacket.REMOVE_OPERATION),
      UPDATE_PROGRESS(ClientboundBossEventPacket.UpdateProgressOperation::new),
      UPDATE_NAME(ClientboundBossEventPacket.UpdateNameOperation::new),
      UPDATE_STYLE(ClientboundBossEventPacket.UpdateStyleOperation::new),
      UPDATE_PROPERTIES(ClientboundBossEventPacket.UpdatePropertiesOperation::new);

      final StreamDecoder<RegistryFriendlyByteBuf, ClientboundBossEventPacket.Operation> reader;

      OperationType(final StreamDecoder<RegistryFriendlyByteBuf, ClientboundBossEventPacket.Operation> p8ed8253a_3_2) {
         this.reader = p8ed8253a_3_2;
      }
   }

   record UpdateNameOperation(Component name) implements ClientboundBossEventPacket.Operation {
      private UpdateNameOperation(RegistryFriendlyByteBuf pcacf260c_0_0) {
         this(ComponentSerialization.TRUSTED_STREAM_CODEC.decode(pcacf260c_0_0));
      }

      @Override
      public ClientboundBossEventPacket.OperationType getType() {
         return ClientboundBossEventPacket.OperationType.UPDATE_NAME;
      }

      @Override
      public void dispatch(UUID pcacf260c_2_0, ClientboundBossEventPacket.Handler pcacf260c_3_1) {
         pcacf260c_3_1.updateName(pcacf260c_2_0, this.name);
      }

      @Override
      public void write(RegistryFriendlyByteBuf pcacf260c_4_0) {
         ComponentSerialization.TRUSTED_STREAM_CODEC.encode(pcacf260c_4_0, this.name);
      }
   }

   record UpdateProgressOperation(float progress) implements ClientboundBossEventPacket.Operation {
      private UpdateProgressOperation(RegistryFriendlyByteBuf p7bae5caa_0_0) {
         this(p7bae5caa_0_0.readFloat());
      }

      @Override
      public ClientboundBossEventPacket.OperationType getType() {
         return ClientboundBossEventPacket.OperationType.UPDATE_PROGRESS;
      }

      @Override
      public void dispatch(UUID p7bae5caa_2_0, ClientboundBossEventPacket.Handler p7bae5caa_3_1) {
         p7bae5caa_3_1.updateProgress(p7bae5caa_2_0, this.progress);
      }

      @Override
      public void write(RegistryFriendlyByteBuf p7bae5caa_4_0) {
         p7bae5caa_4_0.writeFloat(this.progress);
      }
   }

   static class UpdatePropertiesOperation implements ClientboundBossEventPacket.Operation {
      private final boolean darkenScreen;
      private final boolean playMusic;
      private final boolean createWorldFog;

      UpdatePropertiesOperation(boolean pabfc9c64_0_0, boolean pabfc9c64_1_1, boolean pabfc9c64_2_2) {
         this.darkenScreen = pabfc9c64_0_0;
         this.playMusic = pabfc9c64_1_1;
         this.createWorldFog = pabfc9c64_2_2;
      }

      private UpdatePropertiesOperation(RegistryFriendlyByteBuf pabfc9c64_3_0) {
         int $$1 = pabfc9c64_3_0.readUnsignedByte();
         this.darkenScreen = ($$1 & 1) > 0;
         this.playMusic = ($$1 & 2) > 0;
         this.createWorldFog = ($$1 & 4) > 0;
      }

      @Override
      public ClientboundBossEventPacket.OperationType getType() {
         return ClientboundBossEventPacket.OperationType.UPDATE_PROPERTIES;
      }

      @Override
      public void dispatch(UUID pabfc9c64_4_0, ClientboundBossEventPacket.Handler pabfc9c64_5_1) {
         pabfc9c64_5_1.updateProperties(pabfc9c64_4_0, this.darkenScreen, this.playMusic, this.createWorldFog);
      }

      @Override
      public void write(RegistryFriendlyByteBuf pabfc9c64_6_0) {
         pabfc9c64_6_0.writeByte(ClientboundBossEventPacket.encodeProperties(this.darkenScreen, this.playMusic, this.createWorldFog));
      }
   }

   static class UpdateStyleOperation implements ClientboundBossEventPacket.Operation {
      private final BossEvent.BossBarColor color;
      private final BossEvent.BossBarOverlay overlay;

      UpdateStyleOperation(BossEvent.BossBarColor pdf2d8dc6_0_0, BossEvent.BossBarOverlay pdf2d8dc6_1_1) {
         this.color = pdf2d8dc6_0_0;
         this.overlay = pdf2d8dc6_1_1;
      }

      private UpdateStyleOperation(RegistryFriendlyByteBuf pdf2d8dc6_2_0) {
         this.color = pdf2d8dc6_2_0.readEnum(BossEvent.BossBarColor.class);
         this.overlay = pdf2d8dc6_2_0.readEnum(BossEvent.BossBarOverlay.class);
      }

      @Override
      public ClientboundBossEventPacket.OperationType getType() {
         return ClientboundBossEventPacket.OperationType.UPDATE_STYLE;
      }

      @Override
      public void dispatch(UUID pdf2d8dc6_3_0, ClientboundBossEventPacket.Handler pdf2d8dc6_4_1) {
         pdf2d8dc6_4_1.updateStyle(pdf2d8dc6_3_0, this.color, this.overlay);
      }

      @Override
      public void write(RegistryFriendlyByteBuf pdf2d8dc6_5_0) {
         pdf2d8dc6_5_0.writeEnum(this.color);
         pdf2d8dc6_5_0.writeEnum(this.overlay);
      }
   }
}
