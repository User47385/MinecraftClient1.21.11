package net.minecraft.network.protocol.game;

import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.server.level.ServerEntity;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;

public class ClientboundAddEntityPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundAddEntityPacket> STREAM_CODEC = Packet.codec(
      ClientboundAddEntityPacket::write, ClientboundAddEntityPacket::new
   );
   private final int id;
   private final UUID uuid;
   private final EntityType<?> type;
   private final double x;
   private final double y;
   private final double z;
   private final Vec3 movement;
   private final byte xRot;
   private final byte yRot;
   private final byte yHeadRot;
   private final int data;

   public ClientboundAddEntityPacket(Entity p25e06ff4_0_0, ServerEntity p25e06ff4_1_1) {
      this(p25e06ff4_0_0, p25e06ff4_1_1, 0);
   }

   public ClientboundAddEntityPacket(Entity p25e06ff4_2_0, ServerEntity p25e06ff4_3_1, int p25e06ff4_4_2) {
      this(
         p25e06ff4_2_0.getId(),
         p25e06ff4_2_0.getUUID(),
         p25e06ff4_3_1.getPositionBase().x(),
         p25e06ff4_3_1.getPositionBase().y(),
         p25e06ff4_3_1.getPositionBase().z(),
         p25e06ff4_3_1.getLastSentXRot(),
         p25e06ff4_3_1.getLastSentYRot(),
         p25e06ff4_2_0.getType(),
         p25e06ff4_4_2,
         p25e06ff4_3_1.getLastSentMovement(),
         p25e06ff4_3_1.getLastSentYHeadRot()
      );
   }

   public ClientboundAddEntityPacket(Entity p25e06ff4_5_0, int p25e06ff4_6_1, BlockPos p25e06ff4_7_2) {
      this(
         p25e06ff4_5_0.getId(),
         p25e06ff4_5_0.getUUID(),
         p25e06ff4_7_2.getX(),
         p25e06ff4_7_2.getY(),
         p25e06ff4_7_2.getZ(),
         p25e06ff4_5_0.getXRot(),
         p25e06ff4_5_0.getYRot(),
         p25e06ff4_5_0.getType(),
         p25e06ff4_6_1,
         p25e06ff4_5_0.getDeltaMovement(),
         p25e06ff4_5_0.getYHeadRot()
      );
   }

   public ClientboundAddEntityPacket(
      int p25e06ff4_8_0,
      UUID p25e06ff4_9_1,
      double p25e06ff4_10_2,
      double p25e06ff4_11_3,
      double p25e06ff4_12_4,
      float p25e06ff4_13_5,
      float p25e06ff4_14_6,
      EntityType<?> p25e06ff4_15_7,
      int p25e06ff4_16_8,
      Vec3 p25e06ff4_17_9,
      double p25e06ff4_18_10
   ) {
      this.id = p25e06ff4_8_0;
      this.uuid = p25e06ff4_9_1;
      this.x = p25e06ff4_10_2;
      this.y = p25e06ff4_11_3;
      this.z = p25e06ff4_12_4;
      this.movement = p25e06ff4_17_9;
      this.xRot = Mth.packDegrees(p25e06ff4_13_5);
      this.yRot = Mth.packDegrees(p25e06ff4_14_6);
      this.yHeadRot = Mth.packDegrees((float)p25e06ff4_18_10);
      this.type = p25e06ff4_15_7;
      this.data = p25e06ff4_16_8;
   }

   private ClientboundAddEntityPacket(RegistryFriendlyByteBuf p25e06ff4_19_0) {
      this.id = p25e06ff4_19_0.readVarInt();
      this.uuid = p25e06ff4_19_0.readUUID();
      this.type = ByteBufCodecs.registry(Registries.ENTITY_TYPE).decode(p25e06ff4_19_0);
      this.x = p25e06ff4_19_0.readDouble();
      this.y = p25e06ff4_19_0.readDouble();
      this.z = p25e06ff4_19_0.readDouble();
      this.movement = p25e06ff4_19_0.readLpVec3();
      this.xRot = p25e06ff4_19_0.readByte();
      this.yRot = p25e06ff4_19_0.readByte();
      this.yHeadRot = p25e06ff4_19_0.readByte();
      this.data = p25e06ff4_19_0.readVarInt();
   }

   private void write(RegistryFriendlyByteBuf p25e06ff4_20_0) {
      p25e06ff4_20_0.writeVarInt(this.id);
      p25e06ff4_20_0.writeUUID(this.uuid);
      ByteBufCodecs.registry(Registries.ENTITY_TYPE).encode(p25e06ff4_20_0, this.type);
      p25e06ff4_20_0.writeDouble(this.x);
      p25e06ff4_20_0.writeDouble(this.y);
      p25e06ff4_20_0.writeDouble(this.z);
      p25e06ff4_20_0.writeLpVec3(this.movement);
      p25e06ff4_20_0.writeByte(this.xRot);
      p25e06ff4_20_0.writeByte(this.yRot);
      p25e06ff4_20_0.writeByte(this.yHeadRot);
      p25e06ff4_20_0.writeVarInt(this.data);
   }

   @Override
   public PacketType<ClientboundAddEntityPacket> type() {
      return GamePacketTypes.CLIENTBOUND_ADD_ENTITY;
   }

   public void handle(ClientGamePacketListener p25e06ff4_21_0) {
      p25e06ff4_21_0.handleAddEntity(this);
   }

   public int getId() {
      return this.id;
   }

   public UUID getUUID() {
      return this.uuid;
   }

   public EntityType<?> getType() {
      return this.type;
   }

   public double getX() {
      return this.x;
   }

   public double getY() {
      return this.y;
   }

   public double getZ() {
      return this.z;
   }

   public Vec3 getMovement() {
      return this.movement;
   }

   public float getXRot() {
      return Mth.unpackDegrees(this.xRot);
   }

   public float getYRot() {
      return Mth.unpackDegrees(this.yRot);
   }

   public float getYHeadRot() {
      return Mth.unpackDegrees(this.yHeadRot);
   }

   public int getData() {
      return this.data;
   }
}
