package net.minecraft.network.protocol.game;

import net.minecraft.network.protocol.BundlePacket;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundBundlePacket extends BundlePacket<ClientGamePacketListener> {
   public ClientboundBundlePacket(Iterable<Packet<? super ClientGamePacketListener>> p3b953242_0_0) {
      super(p3b953242_0_0);
   }

   @Override
   public PacketType<ClientboundBundlePacket> type() {
      return GamePacketTypes.CLIENTBOUND_BUNDLE;
   }

   public void handle(ClientGamePacketListener p3b953242_1_0) {
      p3b953242_1_0.handleBundlePacket(this);
   }
}
