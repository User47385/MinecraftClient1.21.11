package net.minecraft.network.protocol.game;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import org.jspecify.annotations.Nullable;

public class ClientboundTagQueryPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundTagQueryPacket> STREAM_CODEC = Packet.codec(
      ClientboundTagQueryPacket::write, ClientboundTagQueryPacket::new
   );
   private final int transactionId;
   private final @Nullable CompoundTag tag;

   public ClientboundTagQueryPacket(int pdeb10c0e_0_0, @Nullable CompoundTag pdeb10c0e_1_1) {
      this.transactionId = pdeb10c0e_0_0;
      this.tag = pdeb10c0e_1_1;
   }

   private ClientboundTagQueryPacket(FriendlyByteBuf pdeb10c0e_2_0) {
      this.transactionId = pdeb10c0e_2_0.readVarInt();
      this.tag = pdeb10c0e_2_0.readNbt();
   }

   private void write(FriendlyByteBuf pdeb10c0e_3_0) {
      pdeb10c0e_3_0.writeVarInt(this.transactionId);
      pdeb10c0e_3_0.writeNbt(this.tag);
   }

   @Override
   public PacketType<ClientboundTagQueryPacket> type() {
      return GamePacketTypes.CLIENTBOUND_TAG_QUERY;
   }

   public void handle(ClientGamePacketListener pdeb10c0e_4_0) {
      pdeb10c0e_4_0.handleTagQueryPacket(this);
   }

   public int getTransactionId() {
      return this.transactionId;
   }

   public @Nullable CompoundTag getTag() {
      return this.tag;
   }

   @Override
   public boolean isSkippable() {
      return true;
   }
}
