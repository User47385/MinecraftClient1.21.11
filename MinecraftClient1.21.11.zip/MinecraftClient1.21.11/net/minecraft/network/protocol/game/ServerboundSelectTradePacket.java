package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundSelectTradePacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundSelectTradePacket> STREAM_CODEC = Packet.codec(
      ServerboundSelectTradePacket::write, ServerboundSelectTradePacket::new
   );
   private final int item;

   public ServerboundSelectTradePacket(int p35b24a50_0_0) {
      this.item = p35b24a50_0_0;
   }

   private ServerboundSelectTradePacket(FriendlyByteBuf p35b24a50_1_0) {
      this.item = p35b24a50_1_0.readVarInt();
   }

   private void write(FriendlyByteBuf p35b24a50_2_0) {
      p35b24a50_2_0.writeVarInt(this.item);
   }

   @Override
   public PacketType<ServerboundSelectTradePacket> type() {
      return GamePacketTypes.SERVERBOUND_SELECT_TRADE;
   }

   public void handle(ServerGamePacketListener p35b24a50_3_0) {
      p35b24a50_3_0.handleSelectTrade(this);
   }

   public int getItem() {
      return this.item;
   }
}
