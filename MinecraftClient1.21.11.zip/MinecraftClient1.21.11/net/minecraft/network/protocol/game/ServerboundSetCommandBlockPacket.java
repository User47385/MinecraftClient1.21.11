package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.block.entity.CommandBlockEntity;

public class ServerboundSetCommandBlockPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundSetCommandBlockPacket> STREAM_CODEC = Packet.codec(
      ServerboundSetCommandBlockPacket::write, ServerboundSetCommandBlockPacket::new
   );
   private static final int FLAG_TRACK_OUTPUT = 1;
   private static final int FLAG_CONDITIONAL = 2;
   private static final int FLAG_AUTOMATIC = 4;
   private final BlockPos pos;
   private final String command;
   private final boolean trackOutput;
   private final boolean conditional;
   private final boolean automatic;
   private final CommandBlockEntity.Mode mode;

   public ServerboundSetCommandBlockPacket(
      BlockPos p49fa6d0c_0_0, String p49fa6d0c_1_1, CommandBlockEntity.Mode p49fa6d0c_2_2, boolean p49fa6d0c_3_3, boolean p49fa6d0c_4_4, boolean p49fa6d0c_5_5
   ) {
      this.pos = p49fa6d0c_0_0;
      this.command = p49fa6d0c_1_1;
      this.trackOutput = p49fa6d0c_3_3;
      this.conditional = p49fa6d0c_4_4;
      this.automatic = p49fa6d0c_5_5;
      this.mode = p49fa6d0c_2_2;
   }

   private ServerboundSetCommandBlockPacket(FriendlyByteBuf p49fa6d0c_6_0) {
      this.pos = p49fa6d0c_6_0.readBlockPos();
      this.command = p49fa6d0c_6_0.readUtf();
      this.mode = p49fa6d0c_6_0.readEnum(CommandBlockEntity.Mode.class);
      int $$1 = p49fa6d0c_6_0.readByte();
      this.trackOutput = ($$1 & 1) != 0;
      this.conditional = ($$1 & 2) != 0;
      this.automatic = ($$1 & 4) != 0;
   }

   private void write(FriendlyByteBuf p49fa6d0c_7_0) {
      p49fa6d0c_7_0.writeBlockPos(this.pos);
      p49fa6d0c_7_0.writeUtf(this.command);
      p49fa6d0c_7_0.writeEnum(this.mode);
      int $$1 = 0;
      if (this.trackOutput) {
         $$1 |= 1;
      }

      if (this.conditional) {
         $$1 |= 2;
      }

      if (this.automatic) {
         $$1 |= 4;
      }

      p49fa6d0c_7_0.writeByte($$1);
   }

   @Override
   public PacketType<ServerboundSetCommandBlockPacket> type() {
      return GamePacketTypes.SERVERBOUND_SET_COMMAND_BLOCK;
   }

   public void handle(ServerGamePacketListener p49fa6d0c_8_0) {
      p49fa6d0c_8_0.handleSetCommandBlock(this);
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public String getCommand() {
      return this.command;
   }

   public boolean isTrackOutput() {
      return this.trackOutput;
   }

   public boolean isConditional() {
      return this.conditional;
   }

   public boolean isAutomatic() {
      return this.automatic;
   }

   public CommandBlockEntity.Mode getMode() {
      return this.mode;
   }
}
