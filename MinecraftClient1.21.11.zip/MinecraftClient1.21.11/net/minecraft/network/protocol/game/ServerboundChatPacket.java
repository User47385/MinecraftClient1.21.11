package net.minecraft.network.protocol.game;

import java.time.Instant;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.LastSeenMessages;
import net.minecraft.network.chat.MessageSignature;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import org.jspecify.annotations.Nullable;

public record ServerboundChatPacket(String message, Instant timeStamp, long salt, @Nullable MessageSignature signature, LastSeenMessages.Update lastSeenMessages)
   implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundChatPacket> STREAM_CODEC = Packet.codec(ServerboundChatPacket::write, ServerboundChatPacket::new);

   private ServerboundChatPacket(FriendlyByteBuf pb437c820_0_0) {
      this(
         pb437c820_0_0.readUtf(256),
         pb437c820_0_0.readInstant(),
         pb437c820_0_0.readLong(),
         pb437c820_0_0.readNullable(MessageSignature::read),
         new LastSeenMessages.Update(pb437c820_0_0)
      );
   }

   private void write(FriendlyByteBuf pb437c820_6_0) {
      pb437c820_6_0.writeUtf(this.message, 256);
      pb437c820_6_0.writeInstant(this.timeStamp);
      pb437c820_6_0.writeLong(this.salt);
      pb437c820_6_0.writeNullable(this.signature, MessageSignature::write);
      this.lastSeenMessages.write(pb437c820_6_0);
   }

   @Override
   public PacketType<ServerboundChatPacket> type() {
      return GamePacketTypes.SERVERBOUND_CHAT;
   }

   public void handle(ServerGamePacketListener pb437c820_7_0) {
      pb437c820_7_0.handleChat(this);
   }
}
