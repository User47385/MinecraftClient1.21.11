package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.InteractionHand;

public class ServerboundSwingPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundSwingPacket> STREAM_CODEC = Packet.codec(
      ServerboundSwingPacket::write, ServerboundSwingPacket::new
   );
   private final InteractionHand hand;

   public ServerboundSwingPacket(InteractionHand p47c3a706_0_0) {
      this.hand = p47c3a706_0_0;
   }

   private ServerboundSwingPacket(FriendlyByteBuf p47c3a706_1_0) {
      this.hand = p47c3a706_1_0.readEnum(InteractionHand.class);
   }

   private void write(FriendlyByteBuf p47c3a706_2_0) {
      p47c3a706_2_0.writeEnum(this.hand);
   }

   @Override
   public PacketType<ServerboundSwingPacket> type() {
      return GamePacketTypes.SERVERBOUND_SWING;
   }

   public void handle(ServerGamePacketListener p47c3a706_3_0) {
      p47c3a706_3_0.handleAnimate(this);
   }

   public InteractionHand getHand() {
      return this.hand;
   }
}
