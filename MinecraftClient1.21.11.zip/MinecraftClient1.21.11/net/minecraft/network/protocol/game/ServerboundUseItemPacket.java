package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.InteractionHand;

public class ServerboundUseItemPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundUseItemPacket> STREAM_CODEC = Packet.codec(
      ServerboundUseItemPacket::write, ServerboundUseItemPacket::new
   );
   private final InteractionHand hand;
   private final int sequence;
   private final float yRot;
   private final float xRot;

   public ServerboundUseItemPacket(InteractionHand pe8486c42_0_0, int pe8486c42_1_1, float pe8486c42_2_2, float pe8486c42_3_3) {
      this.hand = pe8486c42_0_0;
      this.sequence = pe8486c42_1_1;
      this.yRot = pe8486c42_2_2;
      this.xRot = pe8486c42_3_3;
   }

   private ServerboundUseItemPacket(FriendlyByteBuf pe8486c42_4_0) {
      this.hand = pe8486c42_4_0.readEnum(InteractionHand.class);
      this.sequence = pe8486c42_4_0.readVarInt();
      this.yRot = pe8486c42_4_0.readFloat();
      this.xRot = pe8486c42_4_0.readFloat();
   }

   private void write(FriendlyByteBuf pe8486c42_5_0) {
      pe8486c42_5_0.writeEnum(this.hand);
      pe8486c42_5_0.writeVarInt(this.sequence);
      pe8486c42_5_0.writeFloat(this.yRot);
      pe8486c42_5_0.writeFloat(this.xRot);
   }

   @Override
   public PacketType<ServerboundUseItemPacket> type() {
      return GamePacketTypes.SERVERBOUND_USE_ITEM;
   }

   public void handle(ServerGamePacketListener pe8486c42_6_0) {
      pe8486c42_6_0.handleUseItem(this);
   }

   public InteractionHand getHand() {
      return this.hand;
   }

   public int getSequence() {
      return this.sequence;
   }

   public float getYRot() {
      return this.yRot;
   }

   public float getXRot() {
      return this.xRot;
   }
}
