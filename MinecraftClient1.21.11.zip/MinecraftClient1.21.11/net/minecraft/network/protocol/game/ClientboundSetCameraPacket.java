package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;

public class ClientboundSetCameraPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetCameraPacket> STREAM_CODEC = Packet.codec(
      ClientboundSetCameraPacket::write, ClientboundSetCameraPacket::new
   );
   private final int cameraId;

   public ClientboundSetCameraPacket(Entity pddeffff7_0_0) {
      this.cameraId = pddeffff7_0_0.getId();
   }

   private ClientboundSetCameraPacket(FriendlyByteBuf pddeffff7_1_0) {
      this.cameraId = pddeffff7_1_0.readVarInt();
   }

   private void write(FriendlyByteBuf pddeffff7_2_0) {
      pddeffff7_2_0.writeVarInt(this.cameraId);
   }

   @Override
   public PacketType<ClientboundSetCameraPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_CAMERA;
   }

   public void handle(ClientGamePacketListener pddeffff7_3_0) {
      pddeffff7_3_0.handleSetCamera(this);
   }

   public @Nullable Entity getEntity(Level pddeffff7_4_0) {
      return pddeffff7_4_0.getEntity(this.cameraId);
   }
}
