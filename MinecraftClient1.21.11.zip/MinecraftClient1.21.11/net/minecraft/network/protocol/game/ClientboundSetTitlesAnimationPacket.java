package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundSetTitlesAnimationPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetTitlesAnimationPacket> STREAM_CODEC = Packet.codec(
      ClientboundSetTitlesAnimationPacket::write, ClientboundSetTitlesAnimationPacket::new
   );
   private final int fadeIn;
   private final int stay;
   private final int fadeOut;

   public ClientboundSetTitlesAnimationPacket(int pbaee89e7_0_0, int pbaee89e7_1_1, int pbaee89e7_2_2) {
      this.fadeIn = pbaee89e7_0_0;
      this.stay = pbaee89e7_1_1;
      this.fadeOut = pbaee89e7_2_2;
   }

   private ClientboundSetTitlesAnimationPacket(FriendlyByteBuf pbaee89e7_3_0) {
      this.fadeIn = pbaee89e7_3_0.readInt();
      this.stay = pbaee89e7_3_0.readInt();
      this.fadeOut = pbaee89e7_3_0.readInt();
   }

   private void write(FriendlyByteBuf pbaee89e7_4_0) {
      pbaee89e7_4_0.writeInt(this.fadeIn);
      pbaee89e7_4_0.writeInt(this.stay);
      pbaee89e7_4_0.writeInt(this.fadeOut);
   }

   @Override
   public PacketType<ClientboundSetTitlesAnimationPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_TITLES_ANIMATION;
   }

   public void handle(ClientGamePacketListener pbaee89e7_5_0) {
      pbaee89e7_5_0.setTitlesAnimation(this);
   }

   public int getFadeIn() {
      return this.fadeIn;
   }

   public int getStay() {
      return this.stay;
   }

   public int getFadeOut() {
      return this.fadeOut;
   }
}
