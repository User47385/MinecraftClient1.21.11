package net.minecraft.network.protocol.game;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.network.syncher.SynchedEntityData;

public record ClientboundSetEntityDataPacket(int id, List<SynchedEntityData.DataValue<?>> packedItems) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundSetEntityDataPacket> STREAM_CODEC = Packet.codec(
      ClientboundSetEntityDataPacket::write, ClientboundSetEntityDataPacket::new
   );
   public static final int EOF_MARKER = 255;

   private ClientboundSetEntityDataPacket(RegistryFriendlyByteBuf pe17b6fff_0_0) {
      this(pe17b6fff_0_0.readVarInt(), unpack(pe17b6fff_0_0));
   }

   private static void pack(List<SynchedEntityData.DataValue<?>> pe17b6fff_3_0, RegistryFriendlyByteBuf pe17b6fff_4_1) {
      for (SynchedEntityData.DataValue<?> $$2 : pe17b6fff_3_0) {
         $$2.write(pe17b6fff_4_1);
      }

      pe17b6fff_4_1.writeByte(255);
   }

   private static List<SynchedEntityData.DataValue<?>> unpack(RegistryFriendlyByteBuf pe17b6fff_5_0) {
      List<SynchedEntityData.DataValue<?>> $$1 = new ArrayList<>();

      int $$2;
      while (($$2 = pe17b6fff_5_0.readUnsignedByte()) != 255) {
         $$1.add(SynchedEntityData.DataValue.read(pe17b6fff_5_0, $$2));
      }

      return $$1;
   }

   private void write(RegistryFriendlyByteBuf pe17b6fff_6_0) {
      pe17b6fff_6_0.writeVarInt(this.id);
      pack(this.packedItems, pe17b6fff_6_0);
   }

   @Override
   public PacketType<ClientboundSetEntityDataPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_ENTITY_DATA;
   }

   public void handle(ClientGamePacketListener pe17b6fff_7_0) {
      pe17b6fff_7_0.handleSetEntityData(this);
   }
}
