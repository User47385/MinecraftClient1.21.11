package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.border.WorldBorder;

public class ClientboundSetBorderSizePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetBorderSizePacket> STREAM_CODEC = Packet.codec(
      ClientboundSetBorderSizePacket::write, ClientboundSetBorderSizePacket::new
   );
   private final double size;

   public ClientboundSetBorderSizePacket(WorldBorder pd9fe0c1f_0_0) {
      this.size = pd9fe0c1f_0_0.getLerpTarget();
   }

   private ClientboundSetBorderSizePacket(FriendlyByteBuf pd9fe0c1f_1_0) {
      this.size = pd9fe0c1f_1_0.readDouble();
   }

   private void write(FriendlyByteBuf pd9fe0c1f_2_0) {
      pd9fe0c1f_2_0.writeDouble(this.size);
   }

   @Override
   public PacketType<ClientboundSetBorderSizePacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_BORDER_SIZE;
   }

   public void handle(ClientGamePacketListener pd9fe0c1f_3_0) {
      pd9fe0c1f_3_0.handleSetBorderSize(this);
   }

   public double getSize() {
      return this.size;
   }
}
