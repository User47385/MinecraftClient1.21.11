package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundContainerClosePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundContainerClosePacket> STREAM_CODEC = Packet.codec(
      ClientboundContainerClosePacket::write, ClientboundContainerClosePacket::new
   );
   private final int containerId;

   public ClientboundContainerClosePacket(int p85ba87f7_0_0) {
      this.containerId = p85ba87f7_0_0;
   }

   private ClientboundContainerClosePacket(FriendlyByteBuf p85ba87f7_1_0) {
      this.containerId = p85ba87f7_1_0.readContainerId();
   }

   private void write(FriendlyByteBuf p85ba87f7_2_0) {
      p85ba87f7_2_0.writeContainerId(this.containerId);
   }

   @Override
   public PacketType<ClientboundContainerClosePacket> type() {
      return GamePacketTypes.CLIENTBOUND_CONTAINER_CLOSE;
   }

   public void handle(ClientGamePacketListener p85ba87f7_3_0) {
      p85ba87f7_3_0.handleContainerClose(this);
   }

   public int getContainerId() {
      return this.containerId;
   }
}
