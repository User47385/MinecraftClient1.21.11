package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import org.jspecify.annotations.Nullable;

public record ClientboundResetScorePacket(String owner, @Nullable String objectiveName) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundResetScorePacket> STREAM_CODEC = Packet.codec(
      ClientboundResetScorePacket::write, ClientboundResetScorePacket::new
   );

   private ClientboundResetScorePacket(FriendlyByteBuf pb750db83_0_0) {
      this(pb750db83_0_0.readUtf(), pb750db83_0_0.readNullable(FriendlyByteBuf::readUtf));
   }

   private void write(FriendlyByteBuf pb750db83_3_0) {
      pb750db83_3_0.writeUtf(this.owner);
      pb750db83_3_0.writeNullable(this.objectiveName, FriendlyByteBuf::writeUtf);
   }

   @Override
   public PacketType<ClientboundResetScorePacket> type() {
      return GamePacketTypes.CLIENTBOUND_RESET_SCORE;
   }

   public void handle(ClientGamePacketListener pb750db83_4_0) {
      pb750db83_4_0.handleResetScore(this);
   }
}
