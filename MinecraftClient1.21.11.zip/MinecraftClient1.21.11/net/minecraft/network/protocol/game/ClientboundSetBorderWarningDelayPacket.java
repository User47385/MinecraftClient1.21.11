package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.border.WorldBorder;

public class ClientboundSetBorderWarningDelayPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetBorderWarningDelayPacket> STREAM_CODEC = Packet.codec(
      ClientboundSetBorderWarningDelayPacket::write, ClientboundSetBorderWarningDelayPacket::new
   );
   private final int warningDelay;

   public ClientboundSetBorderWarningDelayPacket(WorldBorder pb2e504e5_0_0) {
      this.warningDelay = pb2e504e5_0_0.getWarningTime();
   }

   private ClientboundSetBorderWarningDelayPacket(FriendlyByteBuf pb2e504e5_1_0) {
      this.warningDelay = pb2e504e5_1_0.readVarInt();
   }

   private void write(FriendlyByteBuf pb2e504e5_2_0) {
      pb2e504e5_2_0.writeVarInt(this.warningDelay);
   }

   @Override
   public PacketType<ClientboundSetBorderWarningDelayPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_BORDER_WARNING_DELAY;
   }

   public void handle(ClientGamePacketListener pb2e504e5_3_0) {
      pb2e504e5_3_0.handleSetBorderWarningDelay(this);
   }

   public int getWarningDelay() {
      return this.warningDelay;
   }
}
