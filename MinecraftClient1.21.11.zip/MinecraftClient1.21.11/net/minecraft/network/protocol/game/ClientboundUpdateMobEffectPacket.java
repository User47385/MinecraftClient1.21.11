package net.minecraft.network.protocol.game;

import net.minecraft.core.Holder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;

public class ClientboundUpdateMobEffectPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundUpdateMobEffectPacket> STREAM_CODEC = Packet.codec(
      ClientboundUpdateMobEffectPacket::write, ClientboundUpdateMobEffectPacket::new
   );
   private static final int FLAG_AMBIENT = 1;
   private static final int FLAG_VISIBLE = 2;
   private static final int FLAG_SHOW_ICON = 4;
   private static final int FLAG_BLEND = 8;
   private final int entityId;
   private final Holder<MobEffect> effect;
   private final int effectAmplifier;
   private final int effectDurationTicks;
   private final byte flags;

   public ClientboundUpdateMobEffectPacket(int p8b32a8f8_0_0, MobEffectInstance p8b32a8f8_1_1, boolean p8b32a8f8_2_2) {
      this.entityId = p8b32a8f8_0_0;
      this.effect = p8b32a8f8_1_1.getEffect();
      this.effectAmplifier = p8b32a8f8_1_1.getAmplifier();
      this.effectDurationTicks = p8b32a8f8_1_1.getDuration();
      byte $$3 = 0;
      if (p8b32a8f8_1_1.isAmbient()) {
         $$3 = (byte)($$3 | 1);
      }

      if (p8b32a8f8_1_1.isVisible()) {
         $$3 = (byte)($$3 | 2);
      }

      if (p8b32a8f8_1_1.showIcon()) {
         $$3 = (byte)($$3 | 4);
      }

      if (p8b32a8f8_2_2) {
         $$3 = (byte)($$3 | 8);
      }

      this.flags = $$3;
   }

   private ClientboundUpdateMobEffectPacket(RegistryFriendlyByteBuf p8b32a8f8_3_0) {
      this.entityId = p8b32a8f8_3_0.readVarInt();
      this.effect = MobEffect.STREAM_CODEC.decode(p8b32a8f8_3_0);
      this.effectAmplifier = p8b32a8f8_3_0.readVarInt();
      this.effectDurationTicks = p8b32a8f8_3_0.readVarInt();
      this.flags = p8b32a8f8_3_0.readByte();
   }

   private void write(RegistryFriendlyByteBuf p8b32a8f8_4_0) {
      p8b32a8f8_4_0.writeVarInt(this.entityId);
      MobEffect.STREAM_CODEC.encode(p8b32a8f8_4_0, this.effect);
      p8b32a8f8_4_0.writeVarInt(this.effectAmplifier);
      p8b32a8f8_4_0.writeVarInt(this.effectDurationTicks);
      p8b32a8f8_4_0.writeByte(this.flags);
   }

   @Override
   public PacketType<ClientboundUpdateMobEffectPacket> type() {
      return GamePacketTypes.CLIENTBOUND_UPDATE_MOB_EFFECT;
   }

   public void handle(ClientGamePacketListener p8b32a8f8_5_0) {
      p8b32a8f8_5_0.handleUpdateMobEffect(this);
   }

   public int getEntityId() {
      return this.entityId;
   }

   public Holder<MobEffect> getEffect() {
      return this.effect;
   }

   public int getEffectAmplifier() {
      return this.effectAmplifier;
   }

   public int getEffectDurationTicks() {
      return this.effectDurationTicks;
   }

   public boolean isEffectVisible() {
      return (this.flags & 2) != 0;
   }

   public boolean isEffectAmbient() {
      return (this.flags & 1) != 0;
   }

   public boolean effectShowsIcon() {
      return (this.flags & 4) != 0;
   }

   public boolean shouldBlend() {
      return (this.flags & 8) != 0;
   }
}
