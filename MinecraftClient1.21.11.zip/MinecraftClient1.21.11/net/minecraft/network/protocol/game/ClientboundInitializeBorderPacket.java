package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.border.WorldBorder;

public class ClientboundInitializeBorderPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundInitializeBorderPacket> STREAM_CODEC = Packet.codec(
      ClientboundInitializeBorderPacket::write, ClientboundInitializeBorderPacket::new
   );
   private final double newCenterX;
   private final double newCenterZ;
   private final double oldSize;
   private final double newSize;
   private final long lerpTime;
   private final int newAbsoluteMaxSize;
   private final int warningBlocks;
   private final int warningTime;

   private ClientboundInitializeBorderPacket(FriendlyByteBuf pb18d781c_0_0) {
      this.newCenterX = pb18d781c_0_0.readDouble();
      this.newCenterZ = pb18d781c_0_0.readDouble();
      this.oldSize = pb18d781c_0_0.readDouble();
      this.newSize = pb18d781c_0_0.readDouble();
      this.lerpTime = pb18d781c_0_0.readVarLong();
      this.newAbsoluteMaxSize = pb18d781c_0_0.readVarInt();
      this.warningBlocks = pb18d781c_0_0.readVarInt();
      this.warningTime = pb18d781c_0_0.readVarInt();
   }

   public ClientboundInitializeBorderPacket(WorldBorder pb18d781c_1_0) {
      this.newCenterX = pb18d781c_1_0.getCenterX();
      this.newCenterZ = pb18d781c_1_0.getCenterZ();
      this.oldSize = pb18d781c_1_0.getSize();
      this.newSize = pb18d781c_1_0.getLerpTarget();
      this.lerpTime = pb18d781c_1_0.getLerpTime();
      this.newAbsoluteMaxSize = pb18d781c_1_0.getAbsoluteMaxSize();
      this.warningBlocks = pb18d781c_1_0.getWarningBlocks();
      this.warningTime = pb18d781c_1_0.getWarningTime();
   }

   private void write(FriendlyByteBuf pb18d781c_2_0) {
      pb18d781c_2_0.writeDouble(this.newCenterX);
      pb18d781c_2_0.writeDouble(this.newCenterZ);
      pb18d781c_2_0.writeDouble(this.oldSize);
      pb18d781c_2_0.writeDouble(this.newSize);
      pb18d781c_2_0.writeVarLong(this.lerpTime);
      pb18d781c_2_0.writeVarInt(this.newAbsoluteMaxSize);
      pb18d781c_2_0.writeVarInt(this.warningBlocks);
      pb18d781c_2_0.writeVarInt(this.warningTime);
   }

   @Override
   public PacketType<ClientboundInitializeBorderPacket> type() {
      return GamePacketTypes.CLIENTBOUND_INITIALIZE_BORDER;
   }

   public void handle(ClientGamePacketListener pb18d781c_3_0) {
      pb18d781c_3_0.handleInitializeBorder(this);
   }

   public double getNewCenterX() {
      return this.newCenterX;
   }

   public double getNewCenterZ() {
      return this.newCenterZ;
   }

   public double getNewSize() {
      return this.newSize;
   }

   public double getOldSize() {
      return this.oldSize;
   }

   public long getLerpTime() {
      return this.lerpTime;
   }

   public int getNewAbsoluteMaxSize() {
      return this.newAbsoluteMaxSize;
   }

   public int getWarningTime() {
      return this.warningTime;
   }

   public int getWarningBlocks() {
      return this.warningBlocks;
   }
}
