package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundRenameItemPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundRenameItemPacket> STREAM_CODEC = Packet.codec(
      ServerboundRenameItemPacket::write, ServerboundRenameItemPacket::new
   );
   private final String name;

   public ServerboundRenameItemPacket(String p8def3d79_0_0) {
      this.name = p8def3d79_0_0;
   }

   private ServerboundRenameItemPacket(FriendlyByteBuf p8def3d79_1_0) {
      this.name = p8def3d79_1_0.readUtf();
   }

   private void write(FriendlyByteBuf p8def3d79_2_0) {
      p8def3d79_2_0.writeUtf(this.name);
   }

   @Override
   public PacketType<ServerboundRenameItemPacket> type() {
      return GamePacketTypes.SERVERBOUND_RENAME_ITEM;
   }

   public void handle(ServerGamePacketListener p8def3d79_3_0) {
      p8def3d79_3_0.handleRenameItem(this);
   }

   public String getName() {
      return this.name;
   }
}
