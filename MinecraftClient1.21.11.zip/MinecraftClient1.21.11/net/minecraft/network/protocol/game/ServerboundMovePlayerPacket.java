package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.phys.Vec3;

public abstract class ServerboundMovePlayerPacket implements Packet<ServerGamePacketListener> {
   private static final int FLAG_ON_GROUND = 1;
   private static final int FLAG_HORIZONTAL_COLLISION = 2;
   protected final double x;
   protected final double y;
   protected final double z;
   protected final float yRot;
   protected final float xRot;
   protected final boolean onGround;
   protected final boolean horizontalCollision;
   protected final boolean hasPos;
   protected final boolean hasRot;

   static int packFlags(boolean p797b8b5a_0_0, boolean p797b8b5a_1_1) {
      int $$2 = 0;
      if (p797b8b5a_0_0) {
         $$2 |= 1;
      }

      if (p797b8b5a_1_1) {
         $$2 |= 2;
      }

      return $$2;
   }

   static boolean unpackOnGround(int p797b8b5a_2_0) {
      return (p797b8b5a_2_0 & 1) != 0;
   }

   static boolean unpackHorizontalCollision(int p797b8b5a_3_0) {
      return (p797b8b5a_3_0 & 2) != 0;
   }

   protected ServerboundMovePlayerPacket(
      double p797b8b5a_4_0,
      double p797b8b5a_5_1,
      double p797b8b5a_6_2,
      float p797b8b5a_7_3,
      float p797b8b5a_8_4,
      boolean p797b8b5a_9_5,
      boolean p797b8b5a_10_6,
      boolean p797b8b5a_11_7,
      boolean p797b8b5a_12_8
   ) {
      this.x = p797b8b5a_4_0;
      this.y = p797b8b5a_5_1;
      this.z = p797b8b5a_6_2;
      this.yRot = p797b8b5a_7_3;
      this.xRot = p797b8b5a_8_4;
      this.onGround = p797b8b5a_9_5;
      this.horizontalCollision = p797b8b5a_10_6;
      this.hasPos = p797b8b5a_11_7;
      this.hasRot = p797b8b5a_12_8;
   }

   @Override
   public abstract PacketType<? extends ServerboundMovePlayerPacket> type();

   public void handle(ServerGamePacketListener p797b8b5a_13_0) {
      p797b8b5a_13_0.handleMovePlayer(this);
   }

   public double getX(double p797b8b5a_14_0) {
      return this.hasPos ? this.x : p797b8b5a_14_0;
   }

   public double getY(double p797b8b5a_15_0) {
      return this.hasPos ? this.y : p797b8b5a_15_0;
   }

   public double getZ(double p797b8b5a_16_0) {
      return this.hasPos ? this.z : p797b8b5a_16_0;
   }

   public float getYRot(float p797b8b5a_17_0) {
      return this.hasRot ? this.yRot : p797b8b5a_17_0;
   }

   public float getXRot(float p797b8b5a_18_0) {
      return this.hasRot ? this.xRot : p797b8b5a_18_0;
   }

   public boolean isOnGround() {
      return this.onGround;
   }

   public boolean horizontalCollision() {
      return this.horizontalCollision;
   }

   public boolean hasPosition() {
      return this.hasPos;
   }

   public boolean hasRotation() {
      return this.hasRot;
   }

   public static class Pos extends ServerboundMovePlayerPacket {
      public static final StreamCodec<FriendlyByteBuf, ServerboundMovePlayerPacket.Pos> STREAM_CODEC = Packet.codec(
         ServerboundMovePlayerPacket.Pos::write, ServerboundMovePlayerPacket.Pos::read
      );

      public Pos(Vec3 pefc3e5ea_0_0, boolean pefc3e5ea_1_1, boolean pefc3e5ea_2_2) {
         super(pefc3e5ea_0_0.x, pefc3e5ea_0_0.y, pefc3e5ea_0_0.z, 0.0F, 0.0F, pefc3e5ea_1_1, pefc3e5ea_2_2, true, false);
      }

      public Pos(double pefc3e5ea_3_0, double pefc3e5ea_4_1, double pefc3e5ea_5_2, boolean pefc3e5ea_6_3, boolean pefc3e5ea_7_4) {
         super(pefc3e5ea_3_0, pefc3e5ea_4_1, pefc3e5ea_5_2, 0.0F, 0.0F, pefc3e5ea_6_3, pefc3e5ea_7_4, true, false);
      }

      private static ServerboundMovePlayerPacket.Pos read(FriendlyByteBuf pefc3e5ea_8_0) {
         double $$1 = pefc3e5ea_8_0.readDouble();
         double $$2 = pefc3e5ea_8_0.readDouble();
         double $$3 = pefc3e5ea_8_0.readDouble();
         short $$4 = pefc3e5ea_8_0.readUnsignedByte();
         boolean $$5 = ServerboundMovePlayerPacket.unpackOnGround($$4);
         boolean $$6 = ServerboundMovePlayerPacket.unpackHorizontalCollision($$4);
         return new ServerboundMovePlayerPacket.Pos($$1, $$2, $$3, $$5, $$6);
      }

      private void write(FriendlyByteBuf pefc3e5ea_9_0) {
         pefc3e5ea_9_0.writeDouble(this.x);
         pefc3e5ea_9_0.writeDouble(this.y);
         pefc3e5ea_9_0.writeDouble(this.z);
         pefc3e5ea_9_0.writeByte(ServerboundMovePlayerPacket.packFlags(this.onGround, this.horizontalCollision));
      }

      @Override
      public PacketType<ServerboundMovePlayerPacket.Pos> type() {
         return GamePacketTypes.SERVERBOUND_MOVE_PLAYER_POS;
      }
   }

   public static class PosRot extends ServerboundMovePlayerPacket {
      public static final StreamCodec<FriendlyByteBuf, ServerboundMovePlayerPacket.PosRot> STREAM_CODEC = Packet.codec(
         ServerboundMovePlayerPacket.PosRot::write, ServerboundMovePlayerPacket.PosRot::read
      );

      public PosRot(Vec3 pbde19b8d_0_0, float pbde19b8d_1_1, float pbde19b8d_2_2, boolean pbde19b8d_3_3, boolean pbde19b8d_4_4) {
         super(pbde19b8d_0_0.x, pbde19b8d_0_0.y, pbde19b8d_0_0.z, pbde19b8d_1_1, pbde19b8d_2_2, pbde19b8d_3_3, pbde19b8d_4_4, true, true);
      }

      public PosRot(
         double pbde19b8d_5_0,
         double pbde19b8d_6_1,
         double pbde19b8d_7_2,
         float pbde19b8d_8_3,
         float pbde19b8d_9_4,
         boolean pbde19b8d_10_5,
         boolean pbde19b8d_11_6
      ) {
         super(pbde19b8d_5_0, pbde19b8d_6_1, pbde19b8d_7_2, pbde19b8d_8_3, pbde19b8d_9_4, pbde19b8d_10_5, pbde19b8d_11_6, true, true);
      }

      private static ServerboundMovePlayerPacket.PosRot read(FriendlyByteBuf pbde19b8d_12_0) {
         double $$1 = pbde19b8d_12_0.readDouble();
         double $$2 = pbde19b8d_12_0.readDouble();
         double $$3 = pbde19b8d_12_0.readDouble();
         float $$4 = pbde19b8d_12_0.readFloat();
         float $$5 = pbde19b8d_12_0.readFloat();
         short $$6 = pbde19b8d_12_0.readUnsignedByte();
         boolean $$7 = ServerboundMovePlayerPacket.unpackOnGround($$6);
         boolean $$8 = ServerboundMovePlayerPacket.unpackHorizontalCollision($$6);
         return new ServerboundMovePlayerPacket.PosRot($$1, $$2, $$3, $$4, $$5, $$7, $$8);
      }

      private void write(FriendlyByteBuf pbde19b8d_13_0) {
         pbde19b8d_13_0.writeDouble(this.x);
         pbde19b8d_13_0.writeDouble(this.y);
         pbde19b8d_13_0.writeDouble(this.z);
         pbde19b8d_13_0.writeFloat(this.yRot);
         pbde19b8d_13_0.writeFloat(this.xRot);
         pbde19b8d_13_0.writeByte(ServerboundMovePlayerPacket.packFlags(this.onGround, this.horizontalCollision));
      }

      @Override
      public PacketType<ServerboundMovePlayerPacket.PosRot> type() {
         return GamePacketTypes.SERVERBOUND_MOVE_PLAYER_POS_ROT;
      }
   }

   public static class Rot extends ServerboundMovePlayerPacket {
      public static final StreamCodec<FriendlyByteBuf, ServerboundMovePlayerPacket.Rot> STREAM_CODEC = Packet.codec(
         ServerboundMovePlayerPacket.Rot::write, ServerboundMovePlayerPacket.Rot::read
      );

      public Rot(float pefc3ed6d_0_0, float pefc3ed6d_1_1, boolean pefc3ed6d_2_2, boolean pefc3ed6d_3_3) {
         super(0.0, 0.0, 0.0, pefc3ed6d_0_0, pefc3ed6d_1_1, pefc3ed6d_2_2, pefc3ed6d_3_3, false, true);
      }

      private static ServerboundMovePlayerPacket.Rot read(FriendlyByteBuf pefc3ed6d_4_0) {
         float $$1 = pefc3ed6d_4_0.readFloat();
         float $$2 = pefc3ed6d_4_0.readFloat();
         short $$3 = pefc3ed6d_4_0.readUnsignedByte();
         boolean $$4 = ServerboundMovePlayerPacket.unpackOnGround($$3);
         boolean $$5 = ServerboundMovePlayerPacket.unpackHorizontalCollision($$3);
         return new ServerboundMovePlayerPacket.Rot($$1, $$2, $$4, $$5);
      }

      private void write(FriendlyByteBuf pefc3ed6d_5_0) {
         pefc3ed6d_5_0.writeFloat(this.yRot);
         pefc3ed6d_5_0.writeFloat(this.xRot);
         pefc3ed6d_5_0.writeByte(ServerboundMovePlayerPacket.packFlags(this.onGround, this.horizontalCollision));
      }

      @Override
      public PacketType<ServerboundMovePlayerPacket.Rot> type() {
         return GamePacketTypes.SERVERBOUND_MOVE_PLAYER_ROT;
      }
   }

   public static class StatusOnly extends ServerboundMovePlayerPacket {
      public static final StreamCodec<FriendlyByteBuf, ServerboundMovePlayerPacket.StatusOnly> STREAM_CODEC = Packet.codec(
         ServerboundMovePlayerPacket.StatusOnly::write, ServerboundMovePlayerPacket.StatusOnly::read
      );

      public StatusOnly(boolean pfaa4d268_0_0, boolean pfaa4d268_1_1) {
         super(0.0, 0.0, 0.0, 0.0F, 0.0F, pfaa4d268_0_0, pfaa4d268_1_1, false, false);
      }

      private static ServerboundMovePlayerPacket.StatusOnly read(FriendlyByteBuf pfaa4d268_2_0) {
         short $$1 = pfaa4d268_2_0.readUnsignedByte();
         boolean $$2 = ServerboundMovePlayerPacket.unpackOnGround($$1);
         boolean $$3 = ServerboundMovePlayerPacket.unpackHorizontalCollision($$1);
         return new ServerboundMovePlayerPacket.StatusOnly($$2, $$3);
      }

      private void write(FriendlyByteBuf pfaa4d268_3_0) {
         pfaa4d268_3_0.writeByte(ServerboundMovePlayerPacket.packFlags(this.onGround, this.horizontalCollision));
      }

      @Override
      public PacketType<ServerboundMovePlayerPacket.StatusOnly> type() {
         return GamePacketTypes.SERVERBOUND_MOVE_PLAYER_STATUS_ONLY;
      }
   }
}
