package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.inventory.RecipeBookType;

public class ServerboundRecipeBookChangeSettingsPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundRecipeBookChangeSettingsPacket> STREAM_CODEC = Packet.codec(
      ServerboundRecipeBookChangeSettingsPacket::write, ServerboundRecipeBookChangeSettingsPacket::new
   );
   private final RecipeBookType bookType;
   private final boolean isOpen;
   private final boolean isFiltering;

   public ServerboundRecipeBookChangeSettingsPacket(RecipeBookType p1ab658b2_0_0, boolean p1ab658b2_1_1, boolean p1ab658b2_2_2) {
      this.bookType = p1ab658b2_0_0;
      this.isOpen = p1ab658b2_1_1;
      this.isFiltering = p1ab658b2_2_2;
   }

   private ServerboundRecipeBookChangeSettingsPacket(FriendlyByteBuf p1ab658b2_3_0) {
      this.bookType = p1ab658b2_3_0.readEnum(RecipeBookType.class);
      this.isOpen = p1ab658b2_3_0.readBoolean();
      this.isFiltering = p1ab658b2_3_0.readBoolean();
   }

   private void write(FriendlyByteBuf p1ab658b2_4_0) {
      p1ab658b2_4_0.writeEnum(this.bookType);
      p1ab658b2_4_0.writeBoolean(this.isOpen);
      p1ab658b2_4_0.writeBoolean(this.isFiltering);
   }

   @Override
   public PacketType<ServerboundRecipeBookChangeSettingsPacket> type() {
      return GamePacketTypes.SERVERBOUND_RECIPE_BOOK_CHANGE_SETTINGS;
   }

   public void handle(ServerGamePacketListener p1ab658b2_5_0) {
      p1ab658b2_5_0.handleRecipeBookChangeSettingsPacket(this);
   }

   public RecipeBookType getBookType() {
      return this.bookType;
   }

   public boolean isOpen() {
      return this.isOpen;
   }

   public boolean isFiltering() {
      return this.isFiltering;
   }
}
