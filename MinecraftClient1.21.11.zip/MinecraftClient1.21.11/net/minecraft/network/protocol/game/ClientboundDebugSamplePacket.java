package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.util.debugchart.RemoteDebugSampleType;

public record ClientboundDebugSamplePacket(long[] sample, RemoteDebugSampleType debugSampleType) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundDebugSamplePacket> STREAM_CODEC = Packet.codec(
      ClientboundDebugSamplePacket::write, ClientboundDebugSamplePacket::new
   );

   private ClientboundDebugSamplePacket(FriendlyByteBuf pa927792d_0_0) {
      this(pa927792d_0_0.readLongArray(), pa927792d_0_0.readEnum(RemoteDebugSampleType.class));
   }

   private void write(FriendlyByteBuf pa927792d_3_0) {
      pa927792d_3_0.writeLongArray(this.sample);
      pa927792d_3_0.writeEnum(this.debugSampleType);
   }

   @Override
   public PacketType<ClientboundDebugSamplePacket> type() {
      return GamePacketTypes.CLIENTBOUND_DEBUG_SAMPLE;
   }

   public void handle(ClientGamePacketListener pa927792d_4_0) {
      pa927792d_4_0.handleDebugSample(this);
   }
}
