package net.minecraft.network.protocol.game;

import java.util.BitSet;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.lighting.LevelLightEngine;
import org.jspecify.annotations.Nullable;

public class ClientboundLightUpdatePacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundLightUpdatePacket> STREAM_CODEC = Packet.codec(
      ClientboundLightUpdatePacket::write, ClientboundLightUpdatePacket::new
   );
   private final int x;
   private final int z;
   private final ClientboundLightUpdatePacketData lightData;

   public ClientboundLightUpdatePacket(ChunkPos pdba6bb4f_0_0, LevelLightEngine pdba6bb4f_1_1, @Nullable BitSet pdba6bb4f_2_2, @Nullable BitSet pdba6bb4f_3_3) {
      this.x = pdba6bb4f_0_0.x;
      this.z = pdba6bb4f_0_0.z;
      this.lightData = new ClientboundLightUpdatePacketData(pdba6bb4f_0_0, pdba6bb4f_1_1, pdba6bb4f_2_2, pdba6bb4f_3_3);
   }

   private ClientboundLightUpdatePacket(FriendlyByteBuf pdba6bb4f_4_0) {
      this.x = pdba6bb4f_4_0.readVarInt();
      this.z = pdba6bb4f_4_0.readVarInt();
      this.lightData = new ClientboundLightUpdatePacketData(pdba6bb4f_4_0, this.x, this.z);
   }

   private void write(FriendlyByteBuf pdba6bb4f_5_0) {
      pdba6bb4f_5_0.writeVarInt(this.x);
      pdba6bb4f_5_0.writeVarInt(this.z);
      this.lightData.write(pdba6bb4f_5_0);
   }

   @Override
   public PacketType<ClientboundLightUpdatePacket> type() {
      return GamePacketTypes.CLIENTBOUND_LIGHT_UPDATE;
   }

   public void handle(ClientGamePacketListener pdba6bb4f_6_0) {
      pdba6bb4f_6_0.handleLightUpdatePacket(this);
   }

   public int getX() {
      return this.x;
   }

   public int getZ() {
      return this.z;
   }

   public ClientboundLightUpdatePacketData getLightData() {
      return this.lightData;
   }
}
