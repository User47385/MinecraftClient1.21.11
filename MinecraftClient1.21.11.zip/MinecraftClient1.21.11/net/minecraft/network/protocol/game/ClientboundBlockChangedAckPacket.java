package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ClientboundBlockChangedAckPacket(int sequence) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundBlockChangedAckPacket> STREAM_CODEC = Packet.codec(
      ClientboundBlockChangedAckPacket::write, ClientboundBlockChangedAckPacket::new
   );

   private ClientboundBlockChangedAckPacket(FriendlyByteBuf pb1fef532_0_0) {
      this(pb1fef532_0_0.readVarInt());
   }

   private void write(FriendlyByteBuf pb1fef532_2_0) {
      pb1fef532_2_0.writeVarInt(this.sequence);
   }

   @Override
   public PacketType<ClientboundBlockChangedAckPacket> type() {
      return GamePacketTypes.CLIENTBOUND_BLOCK_CHANGED_ACK;
   }

   public void handle(ClientGamePacketListener pb1fef532_3_0) {
      pb1fef532_3_0.handleBlockChangedAck(this);
   }
}
