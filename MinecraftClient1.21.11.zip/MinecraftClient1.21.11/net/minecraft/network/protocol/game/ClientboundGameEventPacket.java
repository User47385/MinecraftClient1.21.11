package net.minecraft.network.protocol.game;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundGameEventPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundGameEventPacket> STREAM_CODEC = Packet.codec(
      ClientboundGameEventPacket::write, ClientboundGameEventPacket::new
   );
   public static final ClientboundGameEventPacket.Type NO_RESPAWN_BLOCK_AVAILABLE = new ClientboundGameEventPacket.Type(0);
   public static final ClientboundGameEventPacket.Type START_RAINING = new ClientboundGameEventPacket.Type(1);
   public static final ClientboundGameEventPacket.Type STOP_RAINING = new ClientboundGameEventPacket.Type(2);
   public static final ClientboundGameEventPacket.Type CHANGE_GAME_MODE = new ClientboundGameEventPacket.Type(3);
   public static final ClientboundGameEventPacket.Type WIN_GAME = new ClientboundGameEventPacket.Type(4);
   public static final ClientboundGameEventPacket.Type DEMO_EVENT = new ClientboundGameEventPacket.Type(5);
   public static final ClientboundGameEventPacket.Type PLAY_ARROW_HIT_SOUND = new ClientboundGameEventPacket.Type(6);
   public static final ClientboundGameEventPacket.Type RAIN_LEVEL_CHANGE = new ClientboundGameEventPacket.Type(7);
   public static final ClientboundGameEventPacket.Type THUNDER_LEVEL_CHANGE = new ClientboundGameEventPacket.Type(8);
   public static final ClientboundGameEventPacket.Type PUFFER_FISH_STING = new ClientboundGameEventPacket.Type(9);
   public static final ClientboundGameEventPacket.Type GUARDIAN_ELDER_EFFECT = new ClientboundGameEventPacket.Type(10);
   public static final ClientboundGameEventPacket.Type IMMEDIATE_RESPAWN = new ClientboundGameEventPacket.Type(11);
   public static final ClientboundGameEventPacket.Type LIMITED_CRAFTING = new ClientboundGameEventPacket.Type(12);
   public static final ClientboundGameEventPacket.Type LEVEL_CHUNKS_LOAD_START = new ClientboundGameEventPacket.Type(13);
   public static final int DEMO_PARAM_INTRO = 0;
   public static final int DEMO_PARAM_HINT_1 = 101;
   public static final int DEMO_PARAM_HINT_2 = 102;
   public static final int DEMO_PARAM_HINT_3 = 103;
   public static final int DEMO_PARAM_HINT_4 = 104;
   private final ClientboundGameEventPacket.Type event;
   private final float param;

   public ClientboundGameEventPacket(ClientboundGameEventPacket.Type p3b55c6d8_0_0, float p3b55c6d8_1_1) {
      this.event = p3b55c6d8_0_0;
      this.param = p3b55c6d8_1_1;
   }

   private ClientboundGameEventPacket(FriendlyByteBuf p3b55c6d8_2_0) {
      this.event = ClientboundGameEventPacket.Type.TYPES.get(p3b55c6d8_2_0.readUnsignedByte());
      this.param = p3b55c6d8_2_0.readFloat();
   }

   private void write(FriendlyByteBuf p3b55c6d8_3_0) {
      p3b55c6d8_3_0.writeByte(this.event.id);
      p3b55c6d8_3_0.writeFloat(this.param);
   }

   @Override
   public PacketType<ClientboundGameEventPacket> type() {
      return GamePacketTypes.CLIENTBOUND_GAME_EVENT;
   }

   public void handle(ClientGamePacketListener p3b55c6d8_4_0) {
      p3b55c6d8_4_0.handleGameEvent(this);
   }

   public ClientboundGameEventPacket.Type getEvent() {
      return this.event;
   }

   public float getParam() {
      return this.param;
   }

   public static class Type {
      static final Int2ObjectMap<ClientboundGameEventPacket.Type> TYPES = new Int2ObjectOpenHashMap<>();
      final int id;

      public Type(int pe41011a6_0_0) {
         this.id = pe41011a6_0_0;
         TYPES.put(pe41011a6_0_0, this);
      }
   }
}
