package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundBlockEntityTagQueryPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundBlockEntityTagQueryPacket> STREAM_CODEC = Packet.codec(
      ServerboundBlockEntityTagQueryPacket::write, ServerboundBlockEntityTagQueryPacket::new
   );
   private final int transactionId;
   private final BlockPos pos;

   public ServerboundBlockEntityTagQueryPacket(int p4a579446_0_0, BlockPos p4a579446_1_1) {
      this.transactionId = p4a579446_0_0;
      this.pos = p4a579446_1_1;
   }

   private ServerboundBlockEntityTagQueryPacket(FriendlyByteBuf p4a579446_2_0) {
      this.transactionId = p4a579446_2_0.readVarInt();
      this.pos = p4a579446_2_0.readBlockPos();
   }

   private void write(FriendlyByteBuf p4a579446_3_0) {
      p4a579446_3_0.writeVarInt(this.transactionId);
      p4a579446_3_0.writeBlockPos(this.pos);
   }

   @Override
   public PacketType<ServerboundBlockEntityTagQueryPacket> type() {
      return GamePacketTypes.SERVERBOUND_BLOCK_ENTITY_TAG_QUERY;
   }

   public void handle(ServerGamePacketListener p4a579446_4_0) {
      p4a579446_4_0.handleBlockEntityTagQuery(this);
   }

   public int getTransactionId() {
      return this.transactionId;
   }

   public BlockPos getPos() {
      return this.pos;
   }
}
