package net.minecraft.network.protocol.game;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundRemoveEntitiesPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundRemoveEntitiesPacket> STREAM_CODEC = Packet.codec(
      ClientboundRemoveEntitiesPacket::write, ClientboundRemoveEntitiesPacket::new
   );
   private final IntList entityIds;

   public ClientboundRemoveEntitiesPacket(IntList p8f9813e5_0_0) {
      this.entityIds = new IntArrayList(p8f9813e5_0_0);
   }

   public ClientboundRemoveEntitiesPacket(int... p8f9813e5_1_0) {
      this.entityIds = new IntArrayList(p8f9813e5_1_0);
   }

   private ClientboundRemoveEntitiesPacket(FriendlyByteBuf p8f9813e5_2_0) {
      this.entityIds = p8f9813e5_2_0.readIntIdList();
   }

   private void write(FriendlyByteBuf p8f9813e5_3_0) {
      p8f9813e5_3_0.writeIntIdList(this.entityIds);
   }

   @Override
   public PacketType<ClientboundRemoveEntitiesPacket> type() {
      return GamePacketTypes.CLIENTBOUND_REMOVE_ENTITIES;
   }

   public void handle(ClientGamePacketListener p8f9813e5_4_0) {
      p8f9813e5_4_0.handleRemoveEntities(this);
   }

   public IntList getEntityIds() {
      return this.entityIds;
   }
}
