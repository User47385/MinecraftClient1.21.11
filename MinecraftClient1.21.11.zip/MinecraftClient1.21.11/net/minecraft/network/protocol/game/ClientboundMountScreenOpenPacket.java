package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundMountScreenOpenPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundMountScreenOpenPacket> STREAM_CODEC = Packet.codec(
      ClientboundMountScreenOpenPacket::write, ClientboundMountScreenOpenPacket::new
   );
   private final int containerId;
   private final int inventoryColumns;
   private final int entityId;

   public ClientboundMountScreenOpenPacket(int pcc4ceb9f_0_0, int pcc4ceb9f_1_1, int pcc4ceb9f_2_2) {
      this.containerId = pcc4ceb9f_0_0;
      this.inventoryColumns = pcc4ceb9f_1_1;
      this.entityId = pcc4ceb9f_2_2;
   }

   private ClientboundMountScreenOpenPacket(FriendlyByteBuf pcc4ceb9f_3_0) {
      this.containerId = pcc4ceb9f_3_0.readContainerId();
      this.inventoryColumns = pcc4ceb9f_3_0.readVarInt();
      this.entityId = pcc4ceb9f_3_0.readInt();
   }

   private void write(FriendlyByteBuf pcc4ceb9f_4_0) {
      pcc4ceb9f_4_0.writeContainerId(this.containerId);
      pcc4ceb9f_4_0.writeVarInt(this.inventoryColumns);
      pcc4ceb9f_4_0.writeInt(this.entityId);
   }

   @Override
   public PacketType<ClientboundMountScreenOpenPacket> type() {
      return GamePacketTypes.CLIENTBOUND_MOUNT_SCREEN_OPEN;
   }

   public void handle(ClientGamePacketListener pcc4ceb9f_5_0) {
      pcc4ceb9f_5_0.handleMountScreenOpen(this);
   }

   public int getContainerId() {
      return this.containerId;
   }

   public int getInventoryColumns() {
      return this.inventoryColumns;
   }

   public int getEntityId() {
      return this.entityId;
   }
}
