package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.RemoteChatSession;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ServerboundChatSessionUpdatePacket(RemoteChatSession.Data chatSession) implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundChatSessionUpdatePacket> STREAM_CODEC = Packet.codec(
      ServerboundChatSessionUpdatePacket::write, ServerboundChatSessionUpdatePacket::new
   );

   private ServerboundChatSessionUpdatePacket(FriendlyByteBuf p76ceb7cf_0_0) {
      this(RemoteChatSession.Data.read(p76ceb7cf_0_0));
   }

   private void write(FriendlyByteBuf p76ceb7cf_2_0) {
      RemoteChatSession.Data.write(p76ceb7cf_2_0, this.chatSession);
   }

   @Override
   public PacketType<ServerboundChatSessionUpdatePacket> type() {
      return GamePacketTypes.SERVERBOUND_CHAT_SESSION_UPDATE;
   }

   public void handle(ServerGamePacketListener p76ceb7cf_3_0) {
      p76ceb7cf_3_0.handleChatSessionUpdate(this);
   }
}
