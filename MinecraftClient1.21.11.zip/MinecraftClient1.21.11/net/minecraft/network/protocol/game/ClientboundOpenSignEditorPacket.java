package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundOpenSignEditorPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundOpenSignEditorPacket> STREAM_CODEC = Packet.codec(
      ClientboundOpenSignEditorPacket::write, ClientboundOpenSignEditorPacket::new
   );
   private final BlockPos pos;
   private final boolean isFrontText;

   public ClientboundOpenSignEditorPacket(BlockPos p315683b4_0_0, boolean p315683b4_1_1) {
      this.pos = p315683b4_0_0;
      this.isFrontText = p315683b4_1_1;
   }

   private ClientboundOpenSignEditorPacket(FriendlyByteBuf p315683b4_2_0) {
      this.pos = p315683b4_2_0.readBlockPos();
      this.isFrontText = p315683b4_2_0.readBoolean();
   }

   private void write(FriendlyByteBuf p315683b4_3_0) {
      p315683b4_3_0.writeBlockPos(this.pos);
      p315683b4_3_0.writeBoolean(this.isFrontText);
   }

   @Override
   public PacketType<ClientboundOpenSignEditorPacket> type() {
      return GamePacketTypes.CLIENTBOUND_OPEN_SIGN_EDITOR;
   }

   public void handle(ClientGamePacketListener p315683b4_4_0) {
      p315683b4_4_0.handleOpenSignEditor(this);
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public boolean isFrontText() {
      return this.isFrontText;
   }
}
