package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.InteractionHand;

public class ClientboundOpenBookPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundOpenBookPacket> STREAM_CODEC = Packet.codec(
      ClientboundOpenBookPacket::write, ClientboundOpenBookPacket::new
   );
   private final InteractionHand hand;

   public ClientboundOpenBookPacket(InteractionHand p415e7b53_0_0) {
      this.hand = p415e7b53_0_0;
   }

   private ClientboundOpenBookPacket(FriendlyByteBuf p415e7b53_1_0) {
      this.hand = p415e7b53_1_0.readEnum(InteractionHand.class);
   }

   private void write(FriendlyByteBuf p415e7b53_2_0) {
      p415e7b53_2_0.writeEnum(this.hand);
   }

   @Override
   public PacketType<ClientboundOpenBookPacket> type() {
      return GamePacketTypes.CLIENTBOUND_OPEN_BOOK;
   }

   public void handle(ClientGamePacketListener p415e7b53_3_0) {
      p415e7b53_3_0.handleOpenBook(this);
   }

   public InteractionHand getHand() {
      return this.hand;
   }
}
