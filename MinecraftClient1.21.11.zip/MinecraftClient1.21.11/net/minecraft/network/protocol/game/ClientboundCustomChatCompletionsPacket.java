package net.minecraft.network.protocol.game;

import java.util.List;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ClientboundCustomChatCompletionsPacket(ClientboundCustomChatCompletionsPacket.Action action, List<String> entries)
   implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundCustomChatCompletionsPacket> STREAM_CODEC = Packet.codec(
      ClientboundCustomChatCompletionsPacket::write, ClientboundCustomChatCompletionsPacket::new
   );

   private ClientboundCustomChatCompletionsPacket(FriendlyByteBuf p525aba7e_0_0) {
      this(p525aba7e_0_0.readEnum(ClientboundCustomChatCompletionsPacket.Action.class), p525aba7e_0_0.readList(FriendlyByteBuf::readUtf));
   }

   private void write(FriendlyByteBuf p525aba7e_3_0) {
      p525aba7e_3_0.writeEnum(this.action);
      p525aba7e_3_0.writeCollection(this.entries, FriendlyByteBuf::writeUtf);
   }

   @Override
   public PacketType<ClientboundCustomChatCompletionsPacket> type() {
      return GamePacketTypes.CLIENTBOUND_CUSTOM_CHAT_COMPLETIONS;
   }

   public void handle(ClientGamePacketListener p525aba7e_4_0) {
      p525aba7e_4_0.handleCustomChatCompletions(this);
   }

   public enum Action {
      ADD,
      REMOVE,
      SET;
   }
}
