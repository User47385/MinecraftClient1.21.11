package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.LivingEntity;

public record ClientboundHurtAnimationPacket(int id, float yaw) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundHurtAnimationPacket> STREAM_CODEC = Packet.codec(
      ClientboundHurtAnimationPacket::write, ClientboundHurtAnimationPacket::new
   );

   public ClientboundHurtAnimationPacket(LivingEntity pf2de7f85_0_0) {
      this(pf2de7f85_0_0.getId(), pf2de7f85_0_0.getHurtDir());
   }

   private ClientboundHurtAnimationPacket(FriendlyByteBuf pf2de7f85_1_0) {
      this(pf2de7f85_1_0.readVarInt(), pf2de7f85_1_0.readFloat());
   }

   private void write(FriendlyByteBuf pf2de7f85_4_0) {
      pf2de7f85_4_0.writeVarInt(this.id);
      pf2de7f85_4_0.writeFloat(this.yaw);
   }

   @Override
   public PacketType<ClientboundHurtAnimationPacket> type() {
      return GamePacketTypes.CLIENTBOUND_HURT_ANIMATION;
   }

   public void handle(ClientGamePacketListener pf2de7f85_5_0) {
      pf2de7f85_5_0.handleHurtAnimation(this);
   }
}
