package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundJigsawGeneratePacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundJigsawGeneratePacket> STREAM_CODEC = Packet.codec(
      ServerboundJigsawGeneratePacket::write, ServerboundJigsawGeneratePacket::new
   );
   private final BlockPos pos;
   private final int levels;
   private final boolean keepJigsaws;

   public ServerboundJigsawGeneratePacket(BlockPos p3b252abe_0_0, int p3b252abe_1_1, boolean p3b252abe_2_2) {
      this.pos = p3b252abe_0_0;
      this.levels = p3b252abe_1_1;
      this.keepJigsaws = p3b252abe_2_2;
   }

   private ServerboundJigsawGeneratePacket(FriendlyByteBuf p3b252abe_3_0) {
      this.pos = p3b252abe_3_0.readBlockPos();
      this.levels = p3b252abe_3_0.readVarInt();
      this.keepJigsaws = p3b252abe_3_0.readBoolean();
   }

   private void write(FriendlyByteBuf p3b252abe_4_0) {
      p3b252abe_4_0.writeBlockPos(this.pos);
      p3b252abe_4_0.writeVarInt(this.levels);
      p3b252abe_4_0.writeBoolean(this.keepJigsaws);
   }

   @Override
   public PacketType<ServerboundJigsawGeneratePacket> type() {
      return GamePacketTypes.SERVERBOUND_JIGSAW_GENERATE;
   }

   public void handle(ServerGamePacketListener p3b252abe_5_0) {
      p3b252abe_5_0.handleJigsawGenerate(this);
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public int levels() {
      return this.levels;
   }

   public boolean keepJigsaws() {
      return this.keepJigsaws;
   }
}
