package net.minecraft.network.protocol.game;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.tree.ArgumentCommandNode;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.LiteralCommandNode;
import com.mojang.brigadier.tree.RootCommandNode;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.IntSet;
import it.unimi.dsi.fastutil.ints.IntSets;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntMaps;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Queue;
import java.util.function.BiPredicate;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.synchronization.ArgumentTypeInfo;
import net.minecraft.commands.synchronization.ArgumentTypeInfos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;

public class ClientboundCommandsPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundCommandsPacket> STREAM_CODEC = Packet.codec(
      ClientboundCommandsPacket::write, ClientboundCommandsPacket::new
   );
   private static final byte MASK_TYPE = 3;
   private static final byte FLAG_EXECUTABLE = 4;
   private static final byte FLAG_REDIRECT = 8;
   private static final byte FLAG_CUSTOM_SUGGESTIONS = 16;
   private static final byte FLAG_RESTRICTED = 32;
   private static final byte TYPE_ROOT = 0;
   private static final byte TYPE_LITERAL = 1;
   private static final byte TYPE_ARGUMENT = 2;
   private final int rootIndex;
   private final List<ClientboundCommandsPacket.Entry> entries;

   public <S> ClientboundCommandsPacket(RootCommandNode<S> p9643a9c8_0_0, ClientboundCommandsPacket.NodeInspector<S> p9643a9c8_1_1) {
      Object2IntMap<CommandNode<S>> $$2 = enumerateNodes(p9643a9c8_0_0);
      this.entries = createEntries($$2, p9643a9c8_1_1);
      this.rootIndex = $$2.getInt(p9643a9c8_0_0);
   }

   private ClientboundCommandsPacket(FriendlyByteBuf p9643a9c8_2_0) {
      this.entries = p9643a9c8_2_0.readList(ClientboundCommandsPacket::readNode);
      this.rootIndex = p9643a9c8_2_0.readVarInt();
      validateEntries(this.entries);
   }

   private void write(FriendlyByteBuf p9643a9c8_3_0) {
      p9643a9c8_3_0.writeCollection(this.entries, (p9643a9c8_24_0, p9643a9c8_25_1) -> p9643a9c8_25_1.write(p9643a9c8_24_0));
      p9643a9c8_3_0.writeVarInt(this.rootIndex);
   }

   private static void validateEntries(List<ClientboundCommandsPacket.Entry> p9643a9c8_4_0, BiPredicate<ClientboundCommandsPacket.Entry, IntSet> p9643a9c8_5_1) {
      IntSet $$2 = new IntOpenHashSet(IntSets.fromTo(0, p9643a9c8_4_0.size()));

      while (!$$2.isEmpty()) {
         boolean $$3 = $$2.removeIf(p9643a9c8_23_3 -> p9643a9c8_5_1.test(p9643a9c8_4_0.get(p9643a9c8_23_3), $$2));
         if (!$$3) {
            throw new IllegalStateException("Server sent an impossible command tree");
         }
      }
   }

   private static void validateEntries(List<ClientboundCommandsPacket.Entry> p9643a9c8_6_0) {
      validateEntries(p9643a9c8_6_0, ClientboundCommandsPacket.Entry::canBuild);
      validateEntries(p9643a9c8_6_0, ClientboundCommandsPacket.Entry::canResolve);
   }

   private static <S> Object2IntMap<CommandNode<S>> enumerateNodes(RootCommandNode<S> p9643a9c8_7_0) {
      Object2IntMap<CommandNode<S>> $$1 = new Object2IntOpenHashMap<>();
      Queue<CommandNode<S>> $$2 = new ArrayDeque<>();
      $$2.add(p9643a9c8_7_0);

      CommandNode<S> $$3;
      while (($$3 = $$2.poll()) != null) {
         if (!$$1.containsKey($$3)) {
            int $$4 = $$1.size();
            $$1.put($$3, $$4);
            $$2.addAll($$3.getChildren());
            if ($$3.getRedirect() != null) {
               $$2.add($$3.getRedirect());
            }
         }
      }

      return $$1;
   }

   private static <S> List<ClientboundCommandsPacket.Entry> createEntries(
      Object2IntMap<CommandNode<S>> p9643a9c8_8_0, ClientboundCommandsPacket.NodeInspector<S> p9643a9c8_9_1
   ) {
      ObjectArrayList<ClientboundCommandsPacket.Entry> $$2 = new ObjectArrayList<>(p9643a9c8_8_0.size());
      $$2.size(p9643a9c8_8_0.size());

      for (Object2IntMap.Entry<CommandNode<S>> $$3 : Object2IntMaps.fastIterable(p9643a9c8_8_0)) {
         $$2.set($$3.getIntValue(), createEntry($$3.getKey(), p9643a9c8_9_1, p9643a9c8_8_0));
      }

      return $$2;
   }

   private static ClientboundCommandsPacket.Entry readNode(FriendlyByteBuf p9643a9c8_10_0) {
      byte $$1 = p9643a9c8_10_0.readByte();
      int[] $$2 = p9643a9c8_10_0.readVarIntArray();
      int $$3 = ($$1 & 8) != 0 ? p9643a9c8_10_0.readVarInt() : 0;
      ClientboundCommandsPacket.NodeStub $$4 = read(p9643a9c8_10_0, $$1);
      return new ClientboundCommandsPacket.Entry($$4, $$1, $$3, $$2);
   }

   private static ClientboundCommandsPacket.@Nullable NodeStub read(FriendlyByteBuf p9643a9c8_11_0, byte p9643a9c8_12_1) {
      int $$2 = p9643a9c8_12_1 & 3;
      if ($$2 == 2) {
         String $$3 = p9643a9c8_11_0.readUtf();
         int $$4 = p9643a9c8_11_0.readVarInt();
         ArgumentTypeInfo<?, ?> $$5 = BuiltInRegistries.COMMAND_ARGUMENT_TYPE.byId($$4);
         if ($$5 == null) {
            return null;
         }

         ArgumentTypeInfo.Template<?> $$6 = $$5.deserializeFromNetwork(p9643a9c8_11_0);
         Identifier $$7 = (p9643a9c8_12_1 & 16) != 0 ? p9643a9c8_11_0.readIdentifier() : null;
         return new ClientboundCommandsPacket.ArgumentNodeStub($$3, $$6, $$7);
      } else if ($$2 == 1) {
         String $$8 = p9643a9c8_11_0.readUtf();
         return new ClientboundCommandsPacket.LiteralNodeStub($$8);
      } else {
         return null;
      }
   }

   private static <S> ClientboundCommandsPacket.Entry createEntry(
      CommandNode<S> p9643a9c8_13_0, ClientboundCommandsPacket.NodeInspector<S> p9643a9c8_14_1, Object2IntMap<CommandNode<S>> p9643a9c8_15_2
   ) {
      int $$3 = 0;
      int $$4;
      if (p9643a9c8_13_0.getRedirect() != null) {
         $$3 |= 8;
         $$4 = p9643a9c8_15_2.getInt(p9643a9c8_13_0.getRedirect());
      } else {
         $$4 = 0;
      }

      if (p9643a9c8_14_1.isExecutable(p9643a9c8_13_0)) {
         $$3 |= 4;
      }

      if (p9643a9c8_14_1.isRestricted(p9643a9c8_13_0)) {
         $$3 |= 32;
      }

      ClientboundCommandsPacket.NodeStub $$7;
      switch (p9643a9c8_13_0) {
         case RootCommandNode<S> $$6:
            $$3 |= 0;
            $$7 = null;
            break;
         case ArgumentCommandNode<S, ?> $$8:
            Identifier $$9 = p9643a9c8_14_1.suggestionId($$8);
            $$7 = new ClientboundCommandsPacket.ArgumentNodeStub($$8.getName(), ArgumentTypeInfos.unpack($$8.getType()), $$9);
            $$3 |= 2;
            if ($$9 != null) {
               $$3 |= 16;
            }
            break;
         case LiteralCommandNode<S> $$11:
            $$7 = new ClientboundCommandsPacket.LiteralNodeStub($$11.getLiteral());
            $$3 |= 1;
            break;
         default:
            throw new UnsupportedOperationException("Unknown node type " + p9643a9c8_13_0);
      }

      int[] $$14 = p9643a9c8_13_0.getChildren().stream().mapToInt(p9643a9c8_15_2::getInt).toArray();
      return new ClientboundCommandsPacket.Entry($$7, $$3, $$4, $$14);
   }

   @Override
   public PacketType<ClientboundCommandsPacket> type() {
      return GamePacketTypes.CLIENTBOUND_COMMANDS;
   }

   public void handle(ClientGamePacketListener p9643a9c8_16_0) {
      p9643a9c8_16_0.handleCommands(this);
   }

   public <S> RootCommandNode<S> getRoot(CommandBuildContext p9643a9c8_17_0, ClientboundCommandsPacket.NodeBuilder<S> p9643a9c8_18_1) {
      return (RootCommandNode<S>)new ClientboundCommandsPacket.NodeResolver<>(p9643a9c8_17_0, p9643a9c8_18_1, this.entries).resolve(this.rootIndex);
   }

   record ArgumentNodeStub(String id, ArgumentTypeInfo.Template<?> argumentType, @Nullable Identifier suggestionId)
      implements ClientboundCommandsPacket.NodeStub {
      @Override
      public <S> ArgumentBuilder<S, ?> build(CommandBuildContext p2e55ab29_3_0, ClientboundCommandsPacket.NodeBuilder<S> p2e55ab29_4_1) {
         ArgumentType<?> $$2 = this.argumentType.instantiate(p2e55ab29_3_0);
         return p2e55ab29_4_1.createArgument(this.id, $$2, this.suggestionId);
      }

      @Override
      public void write(FriendlyByteBuf p2e55ab29_5_0) {
         p2e55ab29_5_0.writeUtf(this.id);
         serializeCap(p2e55ab29_5_0, this.argumentType);
         if (this.suggestionId != null) {
            p2e55ab29_5_0.writeIdentifier(this.suggestionId);
         }
      }

      private static <A extends ArgumentType<?>> void serializeCap(FriendlyByteBuf p2e55ab29_6_0, ArgumentTypeInfo.Template<A> p2e55ab29_7_1) {
         serializeCap(p2e55ab29_6_0, p2e55ab29_7_1.type(), p2e55ab29_7_1);
      }

      private static <A extends ArgumentType<?>, T extends ArgumentTypeInfo.Template<A>> void serializeCap(
         FriendlyByteBuf p2e55ab29_8_0, ArgumentTypeInfo<A, T> p2e55ab29_9_1, ArgumentTypeInfo.Template<A> p2e55ab29_10_2
      ) {
         p2e55ab29_8_0.writeVarInt(BuiltInRegistries.COMMAND_ARGUMENT_TYPE.getId(p2e55ab29_9_1));
         p2e55ab29_9_1.serializeToNetwork((T)p2e55ab29_10_2, p2e55ab29_8_0);
      }
   }

   record Entry(ClientboundCommandsPacket.@Nullable NodeStub stub, int flags, int redirect, int[] children) {

      public void write(FriendlyByteBuf p2a6dc276_4_0) {
         p2a6dc276_4_0.writeByte(this.flags);
         p2a6dc276_4_0.writeVarIntArray(this.children);
         if ((this.flags & 8) != 0) {
            p2a6dc276_4_0.writeVarInt(this.redirect);
         }

         if (this.stub != null) {
            this.stub.write(p2a6dc276_4_0);
         }
      }

      public boolean canBuild(IntSet p2a6dc276_5_0) {
         return (this.flags & 8) != 0 ? !p2a6dc276_5_0.contains(this.redirect) : true;
      }

      public boolean canResolve(IntSet p2a6dc276_6_0) {
         for (int $$1 : this.children) {
            if (p2a6dc276_6_0.contains($$1)) {
               return false;
            }
         }

         return true;
      }
   }

   record LiteralNodeStub(String id) implements ClientboundCommandsPacket.NodeStub {
      @Override
      public <S> ArgumentBuilder<S, ?> build(CommandBuildContext pafefc4a3_1_0, ClientboundCommandsPacket.NodeBuilder<S> pafefc4a3_2_1) {
         return pafefc4a3_2_1.createLiteral(this.id);
      }

      @Override
      public void write(FriendlyByteBuf pafefc4a3_3_0) {
         pafefc4a3_3_0.writeUtf(this.id);
      }
   }

   public interface NodeBuilder<S> {
      ArgumentBuilder<S, ?> createLiteral(String var1);

      ArgumentBuilder<S, ?> createArgument(String var1, ArgumentType<?> var2, @Nullable Identifier var3);

      ArgumentBuilder<S, ?> configure(ArgumentBuilder<S, ?> var1, boolean var2, boolean var3);
   }

   public interface NodeInspector<S> {
      @Nullable Identifier suggestionId(ArgumentCommandNode<S, ?> var1);

      boolean isExecutable(CommandNode<S> var1);

      boolean isRestricted(CommandNode<S> var1);
   }

   static class NodeResolver<S> {
      private final CommandBuildContext context;
      private final ClientboundCommandsPacket.NodeBuilder<S> builder;
      private final List<ClientboundCommandsPacket.Entry> entries;
      private final List<CommandNode<S>> nodes;

      NodeResolver(
         CommandBuildContext p1ae565a4_0_0, ClientboundCommandsPacket.NodeBuilder<S> p1ae565a4_1_1, List<ClientboundCommandsPacket.Entry> p1ae565a4_2_2
      ) {
         this.context = p1ae565a4_0_0;
         this.builder = p1ae565a4_1_1;
         this.entries = p1ae565a4_2_2;
         ObjectArrayList<CommandNode<S>> $$3 = new ObjectArrayList<>();
         $$3.size(p1ae565a4_2_2.size());
         this.nodes = $$3;
      }

      public CommandNode<S> resolve(int p1ae565a4_3_0) {
         CommandNode<S> $$1 = this.nodes.get(p1ae565a4_3_0);
         if ($$1 != null) {
            return $$1;
         }

         ClientboundCommandsPacket.Entry $$2 = this.entries.get(p1ae565a4_3_0);
         CommandNode<S> $$3;
         if ($$2.stub == null) {
            $$3 = new RootCommandNode<>();
         } else {
            ArgumentBuilder<S, ?> $$4 = $$2.stub.build(this.context, this.builder);
            if (($$2.flags & 8) != 0) {
               $$4.redirect(this.resolve($$2.redirect));
            }

            boolean $$5 = ($$2.flags & 4) != 0;
            boolean $$6 = ($$2.flags & 32) != 0;
            $$3 = this.builder.configure($$4, $$5, $$6).build();
         }

         this.nodes.set(p1ae565a4_3_0, $$3);

         for (int $$8 : $$2.children) {
            CommandNode<S> $$9 = this.resolve($$8);
            if (!($$9 instanceof RootCommandNode)) {
               $$3.addChild($$9);
            }
         }

         return $$3;
      }
   }

   interface NodeStub {
      <S> ArgumentBuilder<S, ?> build(CommandBuildContext var1, ClientboundCommandsPacket.NodeBuilder<S> var2);

      void write(FriendlyByteBuf var1);
   }
}
