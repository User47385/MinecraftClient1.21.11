package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.ChunkPos;

public record ClientboundForgetLevelChunkPacket(ChunkPos pos) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundForgetLevelChunkPacket> STREAM_CODEC = Packet.codec(
      ClientboundForgetLevelChunkPacket::write, ClientboundForgetLevelChunkPacket::new
   );

   private ClientboundForgetLevelChunkPacket(FriendlyByteBuf pd4f487d6_0_0) {
      this(pd4f487d6_0_0.readChunkPos());
   }

   private void write(FriendlyByteBuf pd4f487d6_2_0) {
      pd4f487d6_2_0.writeChunkPos(this.pos);
   }

   @Override
   public PacketType<ClientboundForgetLevelChunkPacket> type() {
      return GamePacketTypes.CLIENTBOUND_FORGET_LEVEL_CHUNK;
   }

   public void handle(ClientGamePacketListener pd4f487d6_3_0) {
      pd4f487d6_3_0.handleForgetLevelChunk(this);
   }
}
