package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundCommandSuggestionPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundCommandSuggestionPacket> STREAM_CODEC = Packet.codec(
      ServerboundCommandSuggestionPacket::write, ServerboundCommandSuggestionPacket::new
   );
   private final int id;
   private final String command;

   public ServerboundCommandSuggestionPacket(int p3972b2f7_0_0, String p3972b2f7_1_1) {
      this.id = p3972b2f7_0_0;
      this.command = p3972b2f7_1_1;
   }

   private ServerboundCommandSuggestionPacket(FriendlyByteBuf p3972b2f7_2_0) {
      this.id = p3972b2f7_2_0.readVarInt();
      this.command = p3972b2f7_2_0.readUtf(32500);
   }

   private void write(FriendlyByteBuf p3972b2f7_3_0) {
      p3972b2f7_3_0.writeVarInt(this.id);
      p3972b2f7_3_0.writeUtf(this.command, 32500);
   }

   @Override
   public PacketType<ServerboundCommandSuggestionPacket> type() {
      return GamePacketTypes.SERVERBOUND_COMMAND_SUGGESTION;
   }

   public void handle(ServerGamePacketListener p3972b2f7_4_0) {
      p3972b2f7_4_0.handleCustomCommandSuggestions(this);
   }

   public int getId() {
      return this.id;
   }

   public String getCommand() {
      return this.command;
   }
}
