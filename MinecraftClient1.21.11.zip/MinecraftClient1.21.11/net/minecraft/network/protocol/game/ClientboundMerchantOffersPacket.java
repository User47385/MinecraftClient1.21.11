package net.minecraft.network.protocol.game;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.item.trading.MerchantOffers;

public class ClientboundMerchantOffersPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundMerchantOffersPacket> STREAM_CODEC = Packet.codec(
      ClientboundMerchantOffersPacket::write, ClientboundMerchantOffersPacket::new
   );
   private final int containerId;
   private final MerchantOffers offers;
   private final int villagerLevel;
   private final int villagerXp;
   private final boolean showProgress;
   private final boolean canRestock;

   public ClientboundMerchantOffersPacket(
      int pdc7fe97f_0_0, MerchantOffers pdc7fe97f_1_1, int pdc7fe97f_2_2, int pdc7fe97f_3_3, boolean pdc7fe97f_4_4, boolean pdc7fe97f_5_5
   ) {
      this.containerId = pdc7fe97f_0_0;
      this.offers = pdc7fe97f_1_1.copy();
      this.villagerLevel = pdc7fe97f_2_2;
      this.villagerXp = pdc7fe97f_3_3;
      this.showProgress = pdc7fe97f_4_4;
      this.canRestock = pdc7fe97f_5_5;
   }

   private ClientboundMerchantOffersPacket(RegistryFriendlyByteBuf pdc7fe97f_6_0) {
      this.containerId = pdc7fe97f_6_0.readContainerId();
      this.offers = MerchantOffers.STREAM_CODEC.decode(pdc7fe97f_6_0);
      this.villagerLevel = pdc7fe97f_6_0.readVarInt();
      this.villagerXp = pdc7fe97f_6_0.readVarInt();
      this.showProgress = pdc7fe97f_6_0.readBoolean();
      this.canRestock = pdc7fe97f_6_0.readBoolean();
   }

   private void write(RegistryFriendlyByteBuf pdc7fe97f_7_0) {
      pdc7fe97f_7_0.writeContainerId(this.containerId);
      MerchantOffers.STREAM_CODEC.encode(pdc7fe97f_7_0, this.offers);
      pdc7fe97f_7_0.writeVarInt(this.villagerLevel);
      pdc7fe97f_7_0.writeVarInt(this.villagerXp);
      pdc7fe97f_7_0.writeBoolean(this.showProgress);
      pdc7fe97f_7_0.writeBoolean(this.canRestock);
   }

   @Override
   public PacketType<ClientboundMerchantOffersPacket> type() {
      return GamePacketTypes.CLIENTBOUND_MERCHANT_OFFERS;
   }

   public void handle(ClientGamePacketListener pdc7fe97f_8_0) {
      pdc7fe97f_8_0.handleMerchantOffers(this);
   }

   public int getContainerId() {
      return this.containerId;
   }

   public MerchantOffers getOffers() {
      return this.offers;
   }

   public int getVillagerLevel() {
      return this.villagerLevel;
   }

   public int getVillagerXp() {
      return this.villagerXp;
   }

   public boolean showProgress() {
      return this.showProgress;
   }

   public boolean canRestock() {
      return this.canRestock;
   }
}
