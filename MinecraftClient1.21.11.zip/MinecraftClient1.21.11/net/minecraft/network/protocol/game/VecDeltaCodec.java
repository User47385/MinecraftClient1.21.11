package net.minecraft.network.protocol.game;

import com.google.common.annotations.VisibleForTesting;
import net.minecraft.world.phys.Vec3;

public class VecDeltaCodec {
   private static final double TRUNCATION_STEPS = 4096.0;
   private Vec3 base = Vec3.ZERO;

   @VisibleForTesting
   static long encode(double padb5b297_0_0) {
      return Math.round(padb5b297_0_0 * 4096.0);
   }

   @VisibleForTesting
   static double decode(long padb5b297_1_0) {
      return padb5b297_1_0 / 4096.0;
   }

   public Vec3 decode(long padb5b297_2_0, long padb5b297_3_1, long padb5b297_4_2) {
      if (padb5b297_2_0 == 0L && padb5b297_3_1 == 0L && padb5b297_4_2 == 0L) {
         return this.base;
      }

      double $$3 = padb5b297_2_0 == 0L ? this.base.x : decode(encode(this.base.x) + padb5b297_2_0);
      double $$4 = padb5b297_3_1 == 0L ? this.base.y : decode(encode(this.base.y) + padb5b297_3_1);
      double $$5 = padb5b297_4_2 == 0L ? this.base.z : decode(encode(this.base.z) + padb5b297_4_2);
      return new Vec3($$3, $$4, $$5);
   }

   public long encodeX(Vec3 padb5b297_5_0) {
      return encode(padb5b297_5_0.x) - encode(this.base.x);
   }

   public long encodeY(Vec3 padb5b297_6_0) {
      return encode(padb5b297_6_0.y) - encode(this.base.y);
   }

   public long encodeZ(Vec3 padb5b297_7_0) {
      return encode(padb5b297_7_0.z) - encode(this.base.z);
   }

   public Vec3 delta(Vec3 padb5b297_8_0) {
      return padb5b297_8_0.subtract(this.base);
   }

   public void setBase(Vec3 padb5b297_9_0) {
      this.base = padb5b297_9_0;
   }

   public Vec3 getBase() {
      return this.base;
   }
}
