package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.player.Abilities;

public class ClientboundPlayerAbilitiesPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundPlayerAbilitiesPacket> STREAM_CODEC = Packet.codec(
      ClientboundPlayerAbilitiesPacket::write, ClientboundPlayerAbilitiesPacket::new
   );
   private static final int FLAG_INVULNERABLE = 1;
   private static final int FLAG_FLYING = 2;
   private static final int FLAG_CAN_FLY = 4;
   private static final int FLAG_INSTABUILD = 8;
   private final boolean invulnerable;
   private final boolean isFlying;
   private final boolean canFly;
   private final boolean instabuild;
   private final float flyingSpeed;
   private final float walkingSpeed;

   public ClientboundPlayerAbilitiesPacket(Abilities p768a1d37_0_0) {
      this.invulnerable = p768a1d37_0_0.invulnerable;
      this.isFlying = p768a1d37_0_0.flying;
      this.canFly = p768a1d37_0_0.mayfly;
      this.instabuild = p768a1d37_0_0.instabuild;
      this.flyingSpeed = p768a1d37_0_0.getFlyingSpeed();
      this.walkingSpeed = p768a1d37_0_0.getWalkingSpeed();
   }

   private ClientboundPlayerAbilitiesPacket(FriendlyByteBuf p768a1d37_1_0) {
      byte $$1 = p768a1d37_1_0.readByte();
      this.invulnerable = ($$1 & 1) != 0;
      this.isFlying = ($$1 & 2) != 0;
      this.canFly = ($$1 & 4) != 0;
      this.instabuild = ($$1 & 8) != 0;
      this.flyingSpeed = p768a1d37_1_0.readFloat();
      this.walkingSpeed = p768a1d37_1_0.readFloat();
   }

   private void write(FriendlyByteBuf p768a1d37_2_0) {
      byte $$1 = 0;
      if (this.invulnerable) {
         $$1 = (byte)($$1 | 1);
      }

      if (this.isFlying) {
         $$1 = (byte)($$1 | 2);
      }

      if (this.canFly) {
         $$1 = (byte)($$1 | 4);
      }

      if (this.instabuild) {
         $$1 = (byte)($$1 | 8);
      }

      p768a1d37_2_0.writeByte($$1);
      p768a1d37_2_0.writeFloat(this.flyingSpeed);
      p768a1d37_2_0.writeFloat(this.walkingSpeed);
   }

   @Override
   public PacketType<ClientboundPlayerAbilitiesPacket> type() {
      return GamePacketTypes.CLIENTBOUND_PLAYER_ABILITIES;
   }

   public void handle(ClientGamePacketListener p768a1d37_3_0) {
      p768a1d37_3_0.handlePlayerAbilities(this);
   }

   public boolean isInvulnerable() {
      return this.invulnerable;
   }

   public boolean isFlying() {
      return this.isFlying;
   }

   public boolean canFly() {
      return this.canFly;
   }

   public boolean canInstabuild() {
      return this.instabuild;
   }

   public float getFlyingSpeed() {
      return this.flyingSpeed;
   }

   public float getWalkingSpeed() {
      return this.walkingSpeed;
   }
}
