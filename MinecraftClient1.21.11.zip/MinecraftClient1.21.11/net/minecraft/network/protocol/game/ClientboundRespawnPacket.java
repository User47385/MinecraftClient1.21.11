package net.minecraft.network.protocol.game;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ClientboundRespawnPacket(CommonPlayerSpawnInfo commonPlayerSpawnInfo, byte dataToKeep) implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundRespawnPacket> STREAM_CODEC = Packet.codec(
      ClientboundRespawnPacket::write, ClientboundRespawnPacket::new
   );
   public static final byte KEEP_ATTRIBUTE_MODIFIERS = 1;
   public static final byte KEEP_ENTITY_DATA = 2;
   public static final byte KEEP_ALL_DATA = 3;

   private ClientboundRespawnPacket(RegistryFriendlyByteBuf p4cd2838_0_0) {
      this(new CommonPlayerSpawnInfo(p4cd2838_0_0), p4cd2838_0_0.readByte());
   }

   private void write(RegistryFriendlyByteBuf p4cd2838_3_0) {
      this.commonPlayerSpawnInfo.write(p4cd2838_3_0);
      p4cd2838_3_0.writeByte(this.dataToKeep);
   }

   @Override
   public PacketType<ClientboundRespawnPacket> type() {
      return GamePacketTypes.CLIENTBOUND_RESPAWN;
   }

   public void handle(ClientGamePacketListener p4cd2838_4_0) {
      p4cd2838_4_0.handleRespawn(this);
   }

   public boolean shouldKeep(byte p4cd2838_5_0) {
      return (this.dataToKeep & p4cd2838_5_0) != 0;
   }
}
