package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.Entity;

public class ServerboundPlayerCommandPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundPlayerCommandPacket> STREAM_CODEC = Packet.codec(
      ServerboundPlayerCommandPacket::write, ServerboundPlayerCommandPacket::new
   );
   private final int id;
   private final ServerboundPlayerCommandPacket.Action action;
   private final int data;

   public ServerboundPlayerCommandPacket(Entity p9dea4432_0_0, ServerboundPlayerCommandPacket.Action p9dea4432_1_1) {
      this(p9dea4432_0_0, p9dea4432_1_1, 0);
   }

   public ServerboundPlayerCommandPacket(Entity p9dea4432_2_0, ServerboundPlayerCommandPacket.Action p9dea4432_3_1, int p9dea4432_4_2) {
      this.id = p9dea4432_2_0.getId();
      this.action = p9dea4432_3_1;
      this.data = p9dea4432_4_2;
   }

   private ServerboundPlayerCommandPacket(FriendlyByteBuf p9dea4432_5_0) {
      this.id = p9dea4432_5_0.readVarInt();
      this.action = p9dea4432_5_0.readEnum(ServerboundPlayerCommandPacket.Action.class);
      this.data = p9dea4432_5_0.readVarInt();
   }

   private void write(FriendlyByteBuf p9dea4432_6_0) {
      p9dea4432_6_0.writeVarInt(this.id);
      p9dea4432_6_0.writeEnum(this.action);
      p9dea4432_6_0.writeVarInt(this.data);
   }

   @Override
   public PacketType<ServerboundPlayerCommandPacket> type() {
      return GamePacketTypes.SERVERBOUND_PLAYER_COMMAND;
   }

   public void handle(ServerGamePacketListener p9dea4432_7_0) {
      p9dea4432_7_0.handlePlayerCommand(this);
   }

   public int getId() {
      return this.id;
   }

   public ServerboundPlayerCommandPacket.Action getAction() {
      return this.action;
   }

   public int getData() {
      return this.data;
   }

   public enum Action {
      STOP_SLEEPING,
      START_SPRINTING,
      STOP_SPRINTING,
      START_RIDING_JUMP,
      STOP_RIDING_JUMP,
      OPEN_INVENTORY,
      START_FALL_FLYING;
   }
}
