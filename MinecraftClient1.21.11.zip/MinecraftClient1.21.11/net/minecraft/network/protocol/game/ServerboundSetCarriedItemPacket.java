package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundSetCarriedItemPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundSetCarriedItemPacket> STREAM_CODEC = Packet.codec(
      ServerboundSetCarriedItemPacket::write, ServerboundSetCarriedItemPacket::new
   );
   private final int slot;

   public ServerboundSetCarriedItemPacket(int p85ecc1e3_0_0) {
      this.slot = p85ecc1e3_0_0;
   }

   private ServerboundSetCarriedItemPacket(FriendlyByteBuf p85ecc1e3_1_0) {
      this.slot = p85ecc1e3_1_0.readShort();
   }

   private void write(FriendlyByteBuf p85ecc1e3_2_0) {
      p85ecc1e3_2_0.writeShort(this.slot);
   }

   @Override
   public PacketType<ServerboundSetCarriedItemPacket> type() {
      return GamePacketTypes.SERVERBOUND_SET_CARRIED_ITEM;
   }

   public void handle(ServerGamePacketListener p85ecc1e3_3_0) {
      p85ecc1e3_3_0.handleSetCarriedItem(this);
   }

   public int getSlot() {
      return this.slot;
   }
}
