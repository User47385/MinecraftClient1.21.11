package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundSetHealthPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundSetHealthPacket> STREAM_CODEC = Packet.codec(
      ClientboundSetHealthPacket::write, ClientboundSetHealthPacket::new
   );
   private final float health;
   private final int food;
   private final float saturation;

   public ClientboundSetHealthPacket(float p3476b9ee_0_0, int p3476b9ee_1_1, float p3476b9ee_2_2) {
      this.health = p3476b9ee_0_0;
      this.food = p3476b9ee_1_1;
      this.saturation = p3476b9ee_2_2;
   }

   private ClientboundSetHealthPacket(FriendlyByteBuf p3476b9ee_3_0) {
      this.health = p3476b9ee_3_0.readFloat();
      this.food = p3476b9ee_3_0.readVarInt();
      this.saturation = p3476b9ee_3_0.readFloat();
   }

   private void write(FriendlyByteBuf p3476b9ee_4_0) {
      p3476b9ee_4_0.writeFloat(this.health);
      p3476b9ee_4_0.writeVarInt(this.food);
      p3476b9ee_4_0.writeFloat(this.saturation);
   }

   @Override
   public PacketType<ClientboundSetHealthPacket> type() {
      return GamePacketTypes.CLIENTBOUND_SET_HEALTH;
   }

   public void handle(ClientGamePacketListener p3476b9ee_5_0) {
      p3476b9ee_5_0.handleSetHealth(this);
   }

   public float getHealth() {
      return this.health;
   }

   public int getFood() {
      return this.food;
   }

   public float getSaturation() {
      return this.saturation;
   }
}
