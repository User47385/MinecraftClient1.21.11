package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundProjectilePowerPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundProjectilePowerPacket> STREAM_CODEC = Packet.codec(
      ClientboundProjectilePowerPacket::write, ClientboundProjectilePowerPacket::new
   );
   private final int id;
   private final double accelerationPower;

   public ClientboundProjectilePowerPacket(int pa815a4ac_0_0, double pa815a4ac_1_1) {
      this.id = pa815a4ac_0_0;
      this.accelerationPower = pa815a4ac_1_1;
   }

   private ClientboundProjectilePowerPacket(FriendlyByteBuf pa815a4ac_2_0) {
      this.id = pa815a4ac_2_0.readVarInt();
      this.accelerationPower = pa815a4ac_2_0.readDouble();
   }

   private void write(FriendlyByteBuf pa815a4ac_3_0) {
      pa815a4ac_3_0.writeVarInt(this.id);
      pa815a4ac_3_0.writeDouble(this.accelerationPower);
   }

   @Override
   public PacketType<ClientboundProjectilePowerPacket> type() {
      return GamePacketTypes.CLIENTBOUND_PROJECTILE_POWER;
   }

   public void handle(ClientGamePacketListener pa815a4ac_4_0) {
      pa815a4ac_4_0.handleProjectilePowerPacket(this);
   }

   public int getId() {
      return this.id;
   }

   public double getAccelerationPower() {
      return this.accelerationPower;
   }
}
