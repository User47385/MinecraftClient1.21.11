package net.minecraft.network.protocol.game;

import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

public class ClientboundPlayerLookAtPacket implements Packet<ClientGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundPlayerLookAtPacket> STREAM_CODEC = Packet.codec(
      ClientboundPlayerLookAtPacket::write, ClientboundPlayerLookAtPacket::new
   );
   private final double x;
   private final double y;
   private final double z;
   private final int entity;
   private final EntityAnchorArgument.Anchor fromAnchor;
   private final EntityAnchorArgument.Anchor toAnchor;
   private final boolean atEntity;

   public ClientboundPlayerLookAtPacket(EntityAnchorArgument.Anchor p427e3473_0_0, double p427e3473_1_1, double p427e3473_2_2, double p427e3473_3_3) {
      this.fromAnchor = p427e3473_0_0;
      this.x = p427e3473_1_1;
      this.y = p427e3473_2_2;
      this.z = p427e3473_3_3;
      this.entity = 0;
      this.atEntity = false;
      this.toAnchor = null;
   }

   public ClientboundPlayerLookAtPacket(EntityAnchorArgument.Anchor p427e3473_4_0, Entity p427e3473_5_1, EntityAnchorArgument.Anchor p427e3473_6_2) {
      this.fromAnchor = p427e3473_4_0;
      this.entity = p427e3473_5_1.getId();
      this.toAnchor = p427e3473_6_2;
      Vec3 $$3 = p427e3473_6_2.apply(p427e3473_5_1);
      this.x = $$3.x;
      this.y = $$3.y;
      this.z = $$3.z;
      this.atEntity = true;
   }

   private ClientboundPlayerLookAtPacket(FriendlyByteBuf p427e3473_7_0) {
      this.fromAnchor = p427e3473_7_0.readEnum(EntityAnchorArgument.Anchor.class);
      this.x = p427e3473_7_0.readDouble();
      this.y = p427e3473_7_0.readDouble();
      this.z = p427e3473_7_0.readDouble();
      this.atEntity = p427e3473_7_0.readBoolean();
      if (this.atEntity) {
         this.entity = p427e3473_7_0.readVarInt();
         this.toAnchor = p427e3473_7_0.readEnum(EntityAnchorArgument.Anchor.class);
      } else {
         this.entity = 0;
         this.toAnchor = null;
      }
   }

   private void write(FriendlyByteBuf p427e3473_8_0) {
      p427e3473_8_0.writeEnum(this.fromAnchor);
      p427e3473_8_0.writeDouble(this.x);
      p427e3473_8_0.writeDouble(this.y);
      p427e3473_8_0.writeDouble(this.z);
      p427e3473_8_0.writeBoolean(this.atEntity);
      if (this.atEntity) {
         p427e3473_8_0.writeVarInt(this.entity);
         p427e3473_8_0.writeEnum(this.toAnchor);
      }
   }

   @Override
   public PacketType<ClientboundPlayerLookAtPacket> type() {
      return GamePacketTypes.CLIENTBOUND_PLAYER_LOOK_AT;
   }

   public void handle(ClientGamePacketListener p427e3473_9_0) {
      p427e3473_9_0.handleLookAt(this);
   }

   public EntityAnchorArgument.Anchor getFromAnchor() {
      return this.fromAnchor;
   }

   public @Nullable Vec3 getPosition(Level p427e3473_10_0) {
      if (this.atEntity) {
         Entity $$1 = p427e3473_10_0.getEntity(this.entity);
         return $$1 == null ? new Vec3(this.x, this.y, this.z) : this.toAnchor.apply($$1);
      } else {
         return new Vec3(this.x, this.y, this.z);
      }
   }
}
