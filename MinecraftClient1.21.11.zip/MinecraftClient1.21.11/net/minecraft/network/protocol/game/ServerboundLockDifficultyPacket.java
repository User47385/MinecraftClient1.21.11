package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundLockDifficultyPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundLockDifficultyPacket> STREAM_CODEC = Packet.codec(
      ServerboundLockDifficultyPacket::write, ServerboundLockDifficultyPacket::new
   );
   private final boolean locked;

   public ServerboundLockDifficultyPacket(boolean p2331418e_0_0) {
      this.locked = p2331418e_0_0;
   }

   private ServerboundLockDifficultyPacket(FriendlyByteBuf p2331418e_1_0) {
      this.locked = p2331418e_1_0.readBoolean();
   }

   private void write(FriendlyByteBuf p2331418e_2_0) {
      p2331418e_2_0.writeBoolean(this.locked);
   }

   @Override
   public PacketType<ServerboundLockDifficultyPacket> type() {
      return GamePacketTypes.SERVERBOUND_LOCK_DIFFICULTY;
   }

   public void handle(ServerGamePacketListener p2331418e_3_0) {
      p2331418e_3_0.handleLockDifficulty(this);
   }

   public boolean isLocked() {
      return this.locked;
   }
}
