package net.minecraft.network.protocol.game;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ServerboundPlayerActionPacket implements Packet<ServerGamePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundPlayerActionPacket> STREAM_CODEC = Packet.codec(
      ServerboundPlayerActionPacket::write, ServerboundPlayerActionPacket::new
   );
   private final BlockPos pos;
   private final Direction direction;
   private final ServerboundPlayerActionPacket.Action action;
   private final int sequence;

   public ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action p81f419ff_0_0, BlockPos p81f419ff_1_1, Direction p81f419ff_2_2, int p81f419ff_3_3) {
      this.action = p81f419ff_0_0;
      this.pos = p81f419ff_1_1.immutable();
      this.direction = p81f419ff_2_2;
      this.sequence = p81f419ff_3_3;
   }

   public ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action p81f419ff_4_0, BlockPos p81f419ff_5_1, Direction p81f419ff_6_2) {
      this(p81f419ff_4_0, p81f419ff_5_1, p81f419ff_6_2, 0);
   }

   private ServerboundPlayerActionPacket(FriendlyByteBuf p81f419ff_7_0) {
      this.action = p81f419ff_7_0.readEnum(ServerboundPlayerActionPacket.Action.class);
      this.pos = p81f419ff_7_0.readBlockPos();
      this.direction = Direction.from3DDataValue(p81f419ff_7_0.readUnsignedByte());
      this.sequence = p81f419ff_7_0.readVarInt();
   }

   private void write(FriendlyByteBuf p81f419ff_8_0) {
      p81f419ff_8_0.writeEnum(this.action);
      p81f419ff_8_0.writeBlockPos(this.pos);
      p81f419ff_8_0.writeByte(this.direction.get3DDataValue());
      p81f419ff_8_0.writeVarInt(this.sequence);
   }

   @Override
   public PacketType<ServerboundPlayerActionPacket> type() {
      return GamePacketTypes.SERVERBOUND_PLAYER_ACTION;
   }

   public void handle(ServerGamePacketListener p81f419ff_9_0) {
      p81f419ff_9_0.handlePlayerAction(this);
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public Direction getDirection() {
      return this.direction;
   }

   public ServerboundPlayerActionPacket.Action getAction() {
      return this.action;
   }

   public int getSequence() {
      return this.sequence;
   }

   public enum Action {
      START_DESTROY_BLOCK,
      ABORT_DESTROY_BLOCK,
      STOP_DESTROY_BLOCK,
      DROP_ALL_ITEMS,
      DROP_ITEM,
      RELEASE_USE_ITEM,
      SWAP_ITEM_WITH_OFFHAND,
      STAB;
   }
}
