package net.minecraft.network.protocol.login;

import java.util.UUID;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ServerboundHelloPacket(String name, UUID profileId) implements Packet<ServerLoginPacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundHelloPacket> STREAM_CODEC = Packet.codec(
      ServerboundHelloPacket::write, ServerboundHelloPacket::new
   );

   private ServerboundHelloPacket(FriendlyByteBuf p96019007_0_0) {
      this(p96019007_0_0.readUtf(16), p96019007_0_0.readUUID());
   }

   private void write(FriendlyByteBuf p96019007_3_0) {
      p96019007_3_0.writeUtf(this.name, 16);
      p96019007_3_0.writeUUID(this.profileId);
   }

   @Override
   public PacketType<ServerboundHelloPacket> type() {
      return LoginPacketTypes.SERVERBOUND_HELLO;
   }

   public void handle(ServerLoginPacketListener p96019007_4_0) {
      p96019007_4_0.handleHello(this);
   }
}
