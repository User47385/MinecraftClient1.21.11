package net.minecraft.network.protocol.login;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.network.protocol.login.custom.CustomQueryAnswerPayload;
import net.minecraft.network.protocol.login.custom.DiscardedQueryAnswerPayload;
import org.jspecify.annotations.Nullable;

public record ServerboundCustomQueryAnswerPacket(int transactionId, @Nullable CustomQueryAnswerPayload payload) implements Packet<ServerLoginPacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundCustomQueryAnswerPacket> STREAM_CODEC = Packet.codec(
      ServerboundCustomQueryAnswerPacket::write, ServerboundCustomQueryAnswerPacket::read
   );
   private static final int MAX_PAYLOAD_SIZE = 1048576;

   private static ServerboundCustomQueryAnswerPacket read(FriendlyByteBuf p2bcb8fea_2_0) {
      int $$1 = p2bcb8fea_2_0.readVarInt();
      return new ServerboundCustomQueryAnswerPacket($$1, readPayload($$1, p2bcb8fea_2_0));
   }

   private static CustomQueryAnswerPayload readPayload(int p2bcb8fea_3_0, FriendlyByteBuf p2bcb8fea_4_1) {
      return readUnknownPayload(p2bcb8fea_4_1);
   }

   private static CustomQueryAnswerPayload readUnknownPayload(FriendlyByteBuf p2bcb8fea_5_0) {
      int $$1 = p2bcb8fea_5_0.readableBytes();
      if ($$1 >= 0 && $$1 <= 1048576) {
         p2bcb8fea_5_0.skipBytes($$1);
         return DiscardedQueryAnswerPayload.INSTANCE;
      } else {
         throw new IllegalArgumentException("Payload may not be larger than 1048576 bytes");
      }
   }

   private void write(FriendlyByteBuf p2bcb8fea_6_0) {
      p2bcb8fea_6_0.writeVarInt(this.transactionId);
      p2bcb8fea_6_0.writeNullable(this.payload, (p2bcb8fea_10_0, p2bcb8fea_11_1) -> p2bcb8fea_11_1.write(p2bcb8fea_10_0));
   }

   @Override
   public PacketType<ServerboundCustomQueryAnswerPacket> type() {
      return LoginPacketTypes.SERVERBOUND_CUSTOM_QUERY_ANSWER;
   }

   public void handle(ServerLoginPacketListener p2bcb8fea_7_0) {
      p2bcb8fea_7_0.handleCustomQueryPacket(this);
   }
}
