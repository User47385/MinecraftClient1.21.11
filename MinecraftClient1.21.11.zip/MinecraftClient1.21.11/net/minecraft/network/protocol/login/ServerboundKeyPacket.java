package net.minecraft.network.protocol.login;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Arrays;
import javax.crypto.SecretKey;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.util.Crypt;
import net.minecraft.util.CryptException;

public class ServerboundKeyPacket implements Packet<ServerLoginPacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ServerboundKeyPacket> STREAM_CODEC = Packet.codec(ServerboundKeyPacket::write, ServerboundKeyPacket::new);
   private final byte[] keybytes;
   private final byte[] encryptedChallenge;

   public ServerboundKeyPacket(SecretKey p96b49714_0_0, PublicKey p96b49714_1_1, byte[] p96b49714_2_2) throws CryptException {
      this.keybytes = Crypt.encryptUsingKey(p96b49714_1_1, p96b49714_0_0.getEncoded());
      this.encryptedChallenge = Crypt.encryptUsingKey(p96b49714_1_1, p96b49714_2_2);
   }

   private ServerboundKeyPacket(FriendlyByteBuf p96b49714_3_0) {
      this.keybytes = p96b49714_3_0.readByteArray();
      this.encryptedChallenge = p96b49714_3_0.readByteArray();
   }

   private void write(FriendlyByteBuf p96b49714_4_0) {
      p96b49714_4_0.writeByteArray(this.keybytes);
      p96b49714_4_0.writeByteArray(this.encryptedChallenge);
   }

   @Override
   public PacketType<ServerboundKeyPacket> type() {
      return LoginPacketTypes.SERVERBOUND_KEY;
   }

   public void handle(ServerLoginPacketListener p96b49714_5_0) {
      p96b49714_5_0.handleKey(this);
   }

   public SecretKey getSecretKey(PrivateKey p96b49714_6_0) throws CryptException {
      return Crypt.decryptByteToSecretKey(p96b49714_6_0, this.keybytes);
   }

   public boolean isChallengeValid(byte[] p96b49714_7_0, PrivateKey p96b49714_8_1) {
      try {
         return Arrays.equals(p96b49714_7_0, Crypt.decryptUsingKey(p96b49714_8_1, this.encryptedChallenge));
      } catch (CryptException $$2) {
         return false;
      }
   }
}
