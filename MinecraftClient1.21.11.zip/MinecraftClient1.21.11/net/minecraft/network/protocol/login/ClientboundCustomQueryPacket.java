package net.minecraft.network.protocol.login;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.network.protocol.login.custom.CustomQueryPayload;
import net.minecraft.network.protocol.login.custom.DiscardedQueryPayload;
import net.minecraft.resources.Identifier;

public record ClientboundCustomQueryPacket(int transactionId, CustomQueryPayload payload) implements Packet<ClientLoginPacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundCustomQueryPacket> STREAM_CODEC = Packet.codec(
      ClientboundCustomQueryPacket::write, ClientboundCustomQueryPacket::new
   );
   private static final int MAX_PAYLOAD_SIZE = 1048576;

   private ClientboundCustomQueryPacket(FriendlyByteBuf p8cb6ac14_0_0) {
      this(p8cb6ac14_0_0.readVarInt(), readPayload(p8cb6ac14_0_0.readIdentifier(), p8cb6ac14_0_0));
   }

   private static CustomQueryPayload readPayload(Identifier p8cb6ac14_3_0, FriendlyByteBuf p8cb6ac14_4_1) {
      return readUnknownPayload(p8cb6ac14_3_0, p8cb6ac14_4_1);
   }

   private static DiscardedQueryPayload readUnknownPayload(Identifier p8cb6ac14_5_0, FriendlyByteBuf p8cb6ac14_6_1) {
      int $$2 = p8cb6ac14_6_1.readableBytes();
      if ($$2 >= 0 && $$2 <= 1048576) {
         p8cb6ac14_6_1.skipBytes($$2);
         return new DiscardedQueryPayload(p8cb6ac14_5_0);
      } else {
         throw new IllegalArgumentException("Payload may not be larger than 1048576 bytes");
      }
   }

   private void write(FriendlyByteBuf p8cb6ac14_7_0) {
      p8cb6ac14_7_0.writeVarInt(this.transactionId);
      p8cb6ac14_7_0.writeIdentifier(this.payload.id());
      this.payload.write(p8cb6ac14_7_0);
   }

   @Override
   public PacketType<ClientboundCustomQueryPacket> type() {
      return LoginPacketTypes.CLIENTBOUND_CUSTOM_QUERY;
   }

   public void handle(ClientLoginPacketListener p8cb6ac14_8_0) {
      p8cb6ac14_8_0.handleCustomQuery(this);
   }
}
