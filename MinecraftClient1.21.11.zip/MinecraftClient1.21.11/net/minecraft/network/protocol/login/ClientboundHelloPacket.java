package net.minecraft.network.protocol.login;

import java.security.PublicKey;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.util.Crypt;
import net.minecraft.util.CryptException;

public class ClientboundHelloPacket implements Packet<ClientLoginPacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientboundHelloPacket> STREAM_CODEC = Packet.codec(
      ClientboundHelloPacket::write, ClientboundHelloPacket::new
   );
   private final String serverId;
   private final byte[] publicKey;
   private final byte[] challenge;
   private final boolean shouldAuthenticate;

   public ClientboundHelloPacket(String p4348448f_0_0, byte[] p4348448f_1_1, byte[] p4348448f_2_2, boolean p4348448f_3_3) {
      this.serverId = p4348448f_0_0;
      this.publicKey = p4348448f_1_1;
      this.challenge = p4348448f_2_2;
      this.shouldAuthenticate = p4348448f_3_3;
   }

   private ClientboundHelloPacket(FriendlyByteBuf p4348448f_4_0) {
      this.serverId = p4348448f_4_0.readUtf(20);
      this.publicKey = p4348448f_4_0.readByteArray();
      this.challenge = p4348448f_4_0.readByteArray();
      this.shouldAuthenticate = p4348448f_4_0.readBoolean();
   }

   private void write(FriendlyByteBuf p4348448f_5_0) {
      p4348448f_5_0.writeUtf(this.serverId);
      p4348448f_5_0.writeByteArray(this.publicKey);
      p4348448f_5_0.writeByteArray(this.challenge);
      p4348448f_5_0.writeBoolean(this.shouldAuthenticate);
   }

   @Override
   public PacketType<ClientboundHelloPacket> type() {
      return LoginPacketTypes.CLIENTBOUND_HELLO;
   }

   public void handle(ClientLoginPacketListener p4348448f_6_0) {
      p4348448f_6_0.handleHello(this);
   }

   public String getServerId() {
      return this.serverId;
   }

   public PublicKey getPublicKey() throws CryptException {
      return Crypt.byteToPublicKey(this.publicKey);
   }

   public byte[] getChallenge() {
      return this.challenge;
   }

   public boolean shouldAuthenticate() {
      return this.shouldAuthenticate;
   }
}
