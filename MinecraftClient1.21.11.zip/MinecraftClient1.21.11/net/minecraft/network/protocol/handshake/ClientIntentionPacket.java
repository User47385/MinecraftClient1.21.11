package net.minecraft.network.protocol.handshake;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ClientIntentionPacket(int protocolVersion, String hostName, int port, ClientIntent intention) implements Packet<ServerHandshakePacketListener> {
   public static final StreamCodec<FriendlyByteBuf, ClientIntentionPacket> STREAM_CODEC = Packet.codec(ClientIntentionPacket::write, ClientIntentionPacket::new);
   private static final int MAX_HOST_LENGTH = 255;

   @Deprecated
   public ClientIntentionPacket {
   }

   private ClientIntentionPacket(FriendlyByteBuf pf3ed1b2f_4_0) {
      this(pf3ed1b2f_4_0.readVarInt(), pf3ed1b2f_4_0.readUtf(255), pf3ed1b2f_4_0.readUnsignedShort(), ClientIntent.byId(pf3ed1b2f_4_0.readVarInt()));
   }

   private void write(FriendlyByteBuf pf3ed1b2f_5_0) {
      pf3ed1b2f_5_0.writeVarInt(this.protocolVersion);
      pf3ed1b2f_5_0.writeUtf(this.hostName);
      pf3ed1b2f_5_0.writeShort(this.port);
      pf3ed1b2f_5_0.writeVarInt(this.intention.id());
   }

   @Override
   public PacketType<ClientIntentionPacket> type() {
      return HandshakePacketTypes.CLIENT_INTENTION;
   }

   public void handle(ServerHandshakePacketListener pf3ed1b2f_6_0) {
      pf3ed1b2f_6_0.handleIntention(this);
   }

   @Override
   public boolean isTerminal() {
      return true;
   }
}
