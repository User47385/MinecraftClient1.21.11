package net.minecraft.network.protocol.handshake;

import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.resources.Identifier;

public class HandshakePacketTypes {
   public static final PacketType<ClientIntentionPacket> CLIENT_INTENTION = createServerbound("intention");

   private static <T extends Packet<ServerHandshakePacketListener>> PacketType<T> createServerbound(String p12a2f4b4_0_0) {
      return new PacketType<>(PacketFlow.SERVERBOUND, Identifier.withDefaultNamespace(p12a2f4b4_0_0));
   }
}
