package net.minecraft.network;

import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageEncoder;
import java.util.List;
import net.minecraft.network.protocol.BundlerInfo;
import net.minecraft.network.protocol.Packet;

public class PacketBundleUnpacker extends MessageToMessageEncoder<Packet<?>> {
   private final BundlerInfo bundlerInfo;

   public PacketBundleUnpacker(BundlerInfo pca7060de_0_0) {
      this.bundlerInfo = pca7060de_0_0;
   }

   protected void encode(ChannelHandlerContext pca7060de_1_0, Packet<?> pca7060de_2_1, List<Object> pca7060de_3_2) throws Exception {
      this.bundlerInfo.unbundlePacket(pca7060de_2_1, pca7060de_3_2::add);
      if (pca7060de_2_1.isTerminal()) {
         pca7060de_1_0.pipeline().remove(pca7060de_1_0.name());
      }
   }
}
