package net.minecraft.network;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPromise;

public class LocalFrameEncoder extends ChannelOutboundHandlerAdapter {
   @Override
   public void write(ChannelHandlerContext pd1af8ee5_0_0, Object pd1af8ee5_1_1, ChannelPromise pd1af8ee5_2_2) {
      pd1af8ee5_0_0.write(HiddenByteBuf.pack(pd1af8ee5_1_1), pd1af8ee5_2_2);
   }
}
