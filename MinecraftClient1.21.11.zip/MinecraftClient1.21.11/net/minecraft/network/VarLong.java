package net.minecraft.network;

import io.netty.buffer.ByteBuf;

public class VarLong {
   private static final int MAX_VARLONG_SIZE = 10;
   private static final int DATA_BITS_MASK = 127;
   private static final int CONTINUATION_BIT_MASK = 128;
   private static final int DATA_BITS_PER_BYTE = 7;

   public static int getByteSize(long p1b2fe4ee_0_0) {
      for (int $$1 = 1; $$1 < 10; $$1++) {
         if ((p1b2fe4ee_0_0 & -1L << $$1 * 7) == 0L) {
            return $$1;
         }
      }

      return 10;
   }

   public static boolean hasContinuationBit(byte p1b2fe4ee_1_0) {
      return (p1b2fe4ee_1_0 & 128) == 128;
   }

   public static long read(ByteBuf p1b2fe4ee_2_0) {
      long $$1 = 0L;
      int $$2 = 0;

      byte $$3;
      do {
         $$3 = p1b2fe4ee_2_0.readByte();
         $$1 |= (long)($$3 & 127) << $$2++ * 7;
         if ($$2 > 10) {
            throw new RuntimeException("VarLong too big");
         }
      } while (hasContinuationBit($$3));

      return $$1;
   }

   public static ByteBuf write(ByteBuf p1b2fe4ee_3_0, long p1b2fe4ee_4_1) {
      while ((p1b2fe4ee_4_1 & -128L) != 0L) {
         p1b2fe4ee_3_0.writeByte((int)(p1b2fe4ee_4_1 & 127L) | 128);
         p1b2fe4ee_4_1 >>>= 7;
      }

      p1b2fe4ee_3_0.writeByte((int)p1b2fe4ee_4_1);
      return p1b2fe4ee_3_0;
   }
}
