package net.minecraft.network;

public enum ConnectionProtocol {
   HANDSHAKING("handshake"),
   PLAY("play"),
   STATUS("status"),
   LOGIN("login"),
   CONFIGURATION("configuration");

   private final String id;

   ConnectionProtocol(final String pc8e09c0b_3_2) {
      this.id = pc8e09c0b_3_2;
   }

   public String id() {
      return this.id;
   }
}
