package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import javax.crypto.Cipher;
import javax.crypto.ShortBufferException;

public class CipherBase {
   private final Cipher cipher;
   private byte[] heapIn = new byte[0];
   private byte[] heapOut = new byte[0];

   protected CipherBase(Cipher p33b690f1_0_0) {
      this.cipher = p33b690f1_0_0;
   }

   private byte[] bufToByte(ByteBuf p33b690f1_1_0) {
      int $$1 = p33b690f1_1_0.readableBytes();
      if (this.heapIn.length < $$1) {
         this.heapIn = new byte[$$1];
      }

      p33b690f1_1_0.readBytes(this.heapIn, 0, $$1);
      return this.heapIn;
   }

   protected ByteBuf decipher(ChannelHandlerContext p33b690f1_2_0, ByteBuf p33b690f1_3_1) throws ShortBufferException {
      int $$2 = p33b690f1_3_1.readableBytes();
      byte[] $$3 = this.bufToByte(p33b690f1_3_1);
      ByteBuf $$4 = p33b690f1_2_0.alloc().heapBuffer(this.cipher.getOutputSize($$2));
      $$4.writerIndex(this.cipher.update($$3, 0, $$2, $$4.array(), $$4.arrayOffset()));
      return $$4;
   }

   protected void encipher(ByteBuf p33b690f1_4_0, ByteBuf p33b690f1_5_1) throws ShortBufferException {
      int $$2 = p33b690f1_4_0.readableBytes();
      byte[] $$3 = this.bufToByte(p33b690f1_4_0);
      int $$4 = this.cipher.getOutputSize($$2);
      if (this.heapOut.length < $$4) {
         this.heapOut = new byte[$$4];
      }

      p33b690f1_5_1.writeBytes(this.heapOut, 0, this.cipher.update($$3, 0, $$2, this.heapOut));
   }
}
