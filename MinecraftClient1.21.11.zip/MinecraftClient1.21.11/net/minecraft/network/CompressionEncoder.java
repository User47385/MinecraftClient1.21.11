package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import java.util.zip.Deflater;

public class CompressionEncoder extends MessageToByteEncoder<ByteBuf> {
   private final byte[] encodeBuf = new byte[8192];
   private final Deflater deflater;
   private int threshold;

   public CompressionEncoder(int p715e6d4b_0_0) {
      this.threshold = p715e6d4b_0_0;
      this.deflater = new Deflater();
   }

   protected void encode(ChannelHandlerContext p715e6d4b_1_0, ByteBuf p715e6d4b_2_1, ByteBuf p715e6d4b_3_2) {
      int $$3 = p715e6d4b_2_1.readableBytes();
      if ($$3 > 8388608) {
         throw new IllegalArgumentException("Packet too big (is " + $$3 + ", should be less than 8388608)");
      }

      if ($$3 < this.threshold) {
         VarInt.write(p715e6d4b_3_2, 0);
         p715e6d4b_3_2.writeBytes(p715e6d4b_2_1);
      } else {
         byte[] $$4 = new byte[$$3];
         p715e6d4b_2_1.readBytes($$4);
         VarInt.write(p715e6d4b_3_2, $$4.length);
         this.deflater.setInput($$4, 0, $$3);
         this.deflater.finish();

         while (!this.deflater.finished()) {
            int $$5 = this.deflater.deflate(this.encodeBuf);
            p715e6d4b_3_2.writeBytes(this.encodeBuf, 0, $$5);
         }

         this.deflater.reset();
      }
   }

   public int getThreshold() {
      return this.threshold;
   }

   public void setThreshold(int p715e6d4b_4_0) {
      this.threshold = p715e6d4b_4_0;
   }
}
